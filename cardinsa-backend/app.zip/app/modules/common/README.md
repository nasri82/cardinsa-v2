Optional shared utilities: query, response, validators. See app/utils/slug.py and app/utils/files.py.
