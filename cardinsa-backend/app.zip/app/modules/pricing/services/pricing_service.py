from __future__ import annotations
from typing import Any, Dict, List
from sqlalchemy.orm import Session
from app.modules.pricing.repositories.pricing_repository import PricingRepository
from app.modules.pricing.schemas.pricing_schema import PricingInput, PricingQuote, BreakdownItem
from app.modules.pricing.models.pricing_model import PricingModel, RateTable, TaxFeeRule, RateType, TaxFeeType, TaxBasis

def _match_row(row: dict, factors: dict) -> bool:
    # Row matches if all its keys except 'value' are satisfied by factors
    for k, v in row.items():
        if k == "value":
            continue
        if k not in factors:
            return False
        if isinstance(v, list):
            if factors[k] not in v:
                return False
        else:
            if str(factors[k]) != str(v):
                return False
    return True

def _apply_rate_tables(base: float, tables: List[RateTable], factors: dict, breakdown: List[BreakdownItem]) -> float:
    premium = base
    for t in tables:
        # simple logic: find first matching row, treat 'value' as multiplier
        matched = None
        for row in t.rows or []:
            if _match_row(row, factors):
                matched = row
                break
        if matched:
            factor = float(matched.get("value", 1.0))
            amount = premium * (factor - 1.0)
            premium *= factor
            breakdown.append(BreakdownItem(
                key=f"rate:{t.name}", label=f"Rate {t.name}", kind="multiplier",
                value=factor, amount=round(amount, 2)
            ))
    return premium

def _apply_tax_fee_rules(subtotal: float, rules: List[TaxFeeRule], breakdown: List[BreakdownItem]) -> dict:
    total_fees = 0.0
    total_taxes = 0.0
    running = subtotal
    for r in rules:
        basis_amount = subtotal if r.basis == TaxBasis.NET else running
        if r.rate_type == RateType.PERCENT:
            amount = basis_amount * (r.rate / 100.0)
        else:
            amount = r.rate
        amount = float(round(amount, 2))
        kind = "tax" if r.type in (TaxFeeType.VAT, ) else "fee"
        if kind == "tax":
            total_taxes += amount
        else:
            total_fees += amount
        running += amount
        breakdown.append(BreakdownItem(
            key=f"{kind}:{r.name}", label=r.name, kind=kind,
            value=r.rate, amount=amount
        ))
    return {"fees": round(total_fees, 2), "taxes": round(total_taxes, 2), "total_after": round(running, 2)}

class PricingService:
    def __init__(self, db: Session):
        self.repo = PricingRepository(db)

    def price_quote(self, payload: PricingInput) -> PricingQuote:
        # choose model: by key or latest approved
        model = None
        if payload.model_key:
            model = self.repo.get_active_model_by_key(payload.model_key)
        if model is None:
            model = self.repo.get_latest_approved()
        if model is None:
            raise ValueError("No approved pricing model available")

        # Base premium: accept 'base_rate' from factors or default
        base_rate = float(payload.factors.get("base_rate", 100.0))
        base_amount = base_rate
        breakdown: List[BreakdownItem] = [
            BreakdownItem(key="base", label="Base Premium", kind="base", value=base_rate, amount=base_amount)
        ]

        # Rate tables (multipliers)
        tables = self.repo.get_rate_tables(model.id)
        subtotal = _apply_rate_tables(base_amount, tables, payload.factors, breakdown)
        subtotal = float(round(subtotal, 2))

        # Taxes & fees
        rules = self.repo.get_tax_fee_rules(model.id)
        tax_fee = _apply_tax_fee_rules(subtotal, rules, breakdown)

        quote = PricingQuote(
            currency=payload.currency or model.currency,
            subtotal=subtotal,
            total_fees=tax_fee["fees"],
            total_taxes=tax_fee["taxes"],
            total=tax_fee["total_after"],
            breakdown=breakdown
        )
        return quote
