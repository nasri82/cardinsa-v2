from __future__ import annotations
from typing import Optional
from sqlalchemy import select, and_
from sqlalchemy.orm import Session
from datetime import datetime, timezone

from app.modules.pricing.models.pricing_model import PricingModel, PricingModelStatus, RateTable, TaxFeeRule

class PricingRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_active_model_by_key(self, key: str) -> Optional[PricingModel]:
        now = datetime.now(timezone.utc)
        stmt = select(PricingModel).where(
            and_(
                PricingModel.key == key,
                PricingModel.status == PricingModelStatus.APPROVED,
                (PricingModel.effective_from.is_(None) | (PricingModel.effective_from <= now)),
                (PricingModel.effective_to.is_(None) | (PricingModel.effective_to >= now)),
            )
        ).order_by(PricingModel.version.desc())
        return self.db.execute(stmt).scalars().first()

    def get_latest_approved(self) -> Optional[PricingModel]:
        stmt = select(PricingModel).where(
            PricingModel.status == PricingModelStatus.APPROVED
        ).order_by(PricingModel.effective_from.desc().nullslast(), PricingModel.version.desc())
        return self.db.execute(stmt).scalars().first()

    def get_rate_tables(self, model_id):
        stmt = select(RateTable).where(RateTable.model_id == model_id)
        return self.db.execute(stmt).scalars().all()

    def get_tax_fee_rules(self, model_id):
        stmt = select(TaxFeeRule).where(TaxFeeRule.model_id == model_id, TaxFeeRule.enabled == True)
        return self.db.execute(stmt).scalars().all()
