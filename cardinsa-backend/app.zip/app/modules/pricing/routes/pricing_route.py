from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.dependencies import get_db
from app.modules.pricing.schemas.pricing_schema import PricingInput, PricingQuote
from app.modules.pricing.services.pricing_service import PricingService
from app.modules.common.response import ok, Envelope

router = APIRouter(prefix="/pricing", tags=["pricing"])

@router.post("/preview", response_model=Envelope[PricingQuote])
def preview_price(payload: PricingInput, db: Session = Depends(get_db)):
    try:
        svc = PricingService(db)
        quote = svc.price_quote(payload)
        return ok(quote)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
