from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, ConfigDict

# Admin DTOs
class PricingModelBase(BaseModel):
    key: str = Field(..., description="unique code for model, e.g., 'health_lb_standard'")
    name: str
    version: int = 1
    currency: str = "USD"
    status: str = "draft"
    effective_from: Optional[str] = None
    effective_to: Optional[str] = None
    meta: Dict[str, Any] = {}

class PricingModelCreate(PricingModelBase): pass
class PricingModelUpdate(BaseModel):
    name: Optional[str] = None
    version: Optional[int] = None
    status: Optional[str] = None
    currency: Optional[str] = None
    effective_from: Optional[str] = None
    effective_to: Optional[str] = None
    meta: Optional[Dict[str, Any]] = None

class PricingModelRead(PricingModelBase):
    model_config = ConfigDict(from_attributes=True)
    id: str

class RateTableRow(BaseModel):
    # arbitrary keys, must include all key_fields from the table
    value: float

class RateTableBase(BaseModel):
    model_id: str
    name: str
    key_fields: List[str] = []
    rows: List[Dict[str, Any]] = []

class RateTableCreate(RateTableBase): pass
class RateTableUpdate(BaseModel):
    name: Optional[str] = None
    key_fields: Optional[List[str]] = None
    rows: Optional[List[Dict[str, Any]]] = None

class RateTableRead(RateTableBase):
    model_config = ConfigDict(from_attributes=True)
    id: str

class TaxFeeRuleBase(BaseModel):
    model_id: str
    name: str
    type: str  # vat, stamp, admin_fee, commission, other
    rate_type: str = "percent"
    rate: float = 0.0
    basis: str = "net"
    enabled: bool = True
    metadata: Dict[str, Any] | None = None

class TaxFeeRuleCreate(TaxFeeRuleBase): pass
class TaxFeeRuleUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    rate_type: Optional[str] = None
    rate: Optional[float] = None
    basis: Optional[str] = None
    enabled: Optional[bool] = None
    metadata: Optional[Dict[str, Any]] = None

class TaxFeeRuleRead(TaxFeeRuleBase):
    model_config = ConfigDict(from_attributes=True)
    id: str

# Pricing Input/Output
class PricingInput(BaseModel):
    model_key: Optional[str] = None     # choose active model by key; fallback to latest APPROVED
    currency: Optional[str] = None
    sum_insured: float = 0.0
    factors: Dict[str, Any] = {}        # e.g., {'age': 27, 'region': 'beirut', 'vehicle_group': 'A'}
    members: List[Dict[str, Any]] = []  # optional: for family/multi-party pricing

class BreakdownItem(BaseModel):
    key: str
    label: str
    kind: str         # base | multiplier | additive | fee | tax | cap | total
    value: float      # amount or factor
    amount: float     # monetary amount applied at this step

class PricingQuote(BaseModel):
    currency: str
    subtotal: float
    total_fees: float
    total_taxes: float
    total: float
    breakdown: List[BreakdownItem] = []
