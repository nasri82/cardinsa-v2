import uuid
from sqlalchemy import String, Text, Enum, DateTime
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func
from app.core.database import Base

class PricingModelStatus(str, Enum):
    DRAFT = "draft"
    APPROVED = "approved"
    DEPRECATED = "deprecated"

class PricingModel(Base):
    __tablename__ = "pricing_models"
    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    key: Mapped[str] = mapped_column(String(80), index=True)          # e.g. 'health_standard_lb'
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    version: Mapped[int] = mapped_column(nullable=False, default=1)
    status: Mapped[PricingModelStatus] = mapped_column(Enum(PricingModelStatus), nullable=False, default=PricingModelStatus.DRAFT)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="USD")
    effective_from: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    effective_to: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    meta: Mapped[dict | None] = mapped_column(JSONB, default=dict)
    created_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    rules = relationship("PricingRule", back_populates="model", cascade="all, delete-orphan")
    rate_tables = relationship("RateTable", back_populates="model", cascade="all, delete-orphan")
    tax_fee_rules = relationship("TaxFeeRule", back_populates="model", cascade="all, delete-orphan")


class RuleType(str, Enum):
    MULTIPLIER = "multiplier"  # multiply subtotal by factor
    ADDITIVE = "additive"      # add amount
    CAP_MIN = "cap_min"        # enforce minimum premium
    CAP_MAX = "cap_max"        # enforce maximum premium

class PricingRule(Base):
    __tablename__ = "pricing_rules"
    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    model_id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), nullable=False)
    rule_key: Mapped[str] = mapped_column(String(100), nullable=False)  # e.g. 'young_driver_loading'
    type: Mapped[RuleType] = mapped_column(Enum(RuleType), nullable=False)
    condition: Mapped[dict | None] = mapped_column(JSONB, default=dict) # {field, op, value}
    value: Mapped[float] = mapped_column(nullable=False, default=0.0)   # factor or amount
    priority: Mapped[int] = mapped_column(nullable=False, default=100)
    enabled: Mapped[bool] = mapped_column(nullable=False, default=True)

    created_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    model = relationship("PricingModel", back_populates="rules", primaryjoin="PricingRule.model_id==PricingModel.id")


class RateTable(Base):
    __tablename__ = "rate_tables"
    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    model_id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)     # e.g. 'age_band', 'region_factor'
    key_fields: Mapped[list] = mapped_column(JSONB, default=list)      # ['age_min','age_max','region']
    rows: Mapped[list] = mapped_column(JSONB, default=list)            # [{age_min:18, age_max:25, value:1.25}, ...]

    created_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    model = relationship("PricingModel", back_populates="rate_tables", primaryjoin="RateTable.model_id==PricingModel.id")


class TaxBasis(str, Enum):
    NET = "net"        # premium before taxes/fees
    GROSS = "gross"    # after some fees
    SUBTOTAL = "subtotal"

class RateType(str, Enum):
    PERCENT = "percent"
    FIXED = "fixed"

class TaxFeeType(str, Enum):
    VAT = "vat"
    STAMP = "stamp"
    ADMIN_FEE = "admin_fee"
    BROKER_COMMISSION = "broker_commission"
    OTHER = "other"

class TaxFeeRule(Base):
    __tablename__ = "tax_fee_rules"
    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    model_id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), nullable=False)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    type: Mapped[TaxFeeType] = mapped_column(Enum(TaxFeeType), nullable=False)
    rate_type: Mapped[RateType] = mapped_column(Enum(RateType), nullable=False, default=RateType.PERCENT)
    rate: Mapped[float] = mapped_column(nullable=False, default=0.0)   # percent or fixed amount
    basis: Mapped[TaxBasis] = mapped_column(Enum(TaxBasis), nullable=False, default=TaxBasis.NET)
    enabled: Mapped[bool] = mapped_column(nullable=False, default=True)
    metadata_: Mapped[dict | None] = mapped_column("metadata", JSONB, default=dict)

    created_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    model = relationship("PricingModel", back_populates="tax_fee_rules", primaryjoin="TaxFeeRule.model_id==PricingModel.id")


class PricingSnapshot(Base):
    __tablename__ = "pricing_snapshots"
    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    model_id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), nullable=False)
    quotation_id: Mapped[uuid.UUID | None] = mapped_column(PG_UUID(as_uuid=True), nullable=True)
    policy_id: Mapped[uuid.UUID | None] = mapped_column(PG_UUID(as_uuid=True), nullable=True)
    input: Mapped[dict] = mapped_column(JSONB, default=dict)
    breakdown: Mapped[list] = mapped_column(JSONB, default=list)
    totals: Mapped[dict] = mapped_column(JSONB, default=dict)
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="USD")
    created_at = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
