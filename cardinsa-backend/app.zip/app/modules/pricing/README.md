Pricing Module
--------------
Files:
- models: PricingModel, PricingRule, RateTable, TaxFeeRule, PricingSnapshot
- services: PricingService.price_quote(payload) -> PricingQuote
- routes: POST /pricing/preview to compute a quote (no persistence)
- repositories: accessors for active model, tables, rules

Minimal logic:
- Base premium from `factors.base_rate` (default 100)
- Each RateTable applies a multiplier if a row matches the provided factors
- Tax/Fee rules apply (percent or fixed) on NET (subtotal) or running total
- Returns a full breakdown
