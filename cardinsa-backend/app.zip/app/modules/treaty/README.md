Treaty module
-------------
Contains core treaty constructs:
  - treaty_programs, treaty_contracts, treaty_layers, treaty_reinstatements
Add real columns to models to match your SQL tables, then implement repositories/services.
