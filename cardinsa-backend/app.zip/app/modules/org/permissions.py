# app/modules/org/permissions.py
COMPANIES_READ   = ("companies", "read")
COMPANIES_MANAGE = ("companies", "manage")
DEPARTMENTS_READ   = ("departments", "read")
DEPARTMENTS_MANAGE = ("departments", "manage")
UNITS_READ   = ("units", "read")
UNITS_MANAGE = ("units", "manage")
