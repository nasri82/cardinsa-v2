Reinsurance module
------------------
Operational reinsurance artifacts:
  - reinsurers, treaty_participations, cessions, reinsurance_recoveries, reinsurance_settlements, ceded_bordereau
Extend models to match your SQL schema and implement real queries.
