Accounting (General Ledger) module
----------------------------------
Core GL objects:
  - gl_accounts, gl_journals, gl_entries, gl_periods, tax_rules
Wire posting services from domain events (policies, invoices, reinsurance settlements).
