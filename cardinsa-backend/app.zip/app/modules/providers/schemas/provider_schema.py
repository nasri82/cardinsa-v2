from pydantic import BaseModel

class ProviderBase(BaseModel):
    pass

class ProviderCreate(ProviderBase):
    pass

class ProviderRead(ProviderBase):
    id: str | None = None
