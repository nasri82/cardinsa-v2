from fastapi import APIRouter
from app.api.health_route import router as health_router


### import auth routes
from app.modules.auth.routes.auth_route import router as auth_router
from app.modules.auth.routes.users_route import router as users_router
from app.modules.auth.routes.roles_route import router as roles_router
from app.modules.auth.routes.user_roles_route import router as user_roles_router
from app.modules.auth.routes.password_reset_route import router as password_reset_router

### import org routes
from app.modules.org.routes.companies_route import router as companies_router
from app.modules.org.routes.departments_route import router as departments_router
from app.modules.org.routes.units_route import router as units_router
from app.modules.org.routes.org_tree_route import router as org_tree_router
from app.modules.auth.routes.user_roles_effective_route import router as user_roles_effective_router

### import employees routes
from app.api.v1.employee_router import router as employee_module_router

api_router = APIRouter()
api_router.include_router(health_router, tags=["health"])


###vauth routes 
api_router = APIRouter()
api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(roles_router)
api_router.include_router(user_roles_router)
api_router.include_router(password_reset_router)
api_router.include_router(user_roles_effective_router)

###org routes 
api_router.include_router(companies_router)
api_router.include_router(departments_router)
api_router.include_router(units_router)
api_router.include_router(org_tree_router)


### employee  routes 
api_router.include_router(employee_module_router)
