import logging
import logging.config
import sys

def configure_logging() -> None:
    LOG_LEVEL = "DEBUG"

    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "plain": {
                    "format": "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
                },
                "uvicorn": {
                    "format": "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
                },
            },
            "handlers": {
                "default": {
                    "class": "logging.StreamHandler",
                    "stream": sys.stdout,
                    "formatter": "plain",
                },
                "uvicorn": {
                    "class": "logging.StreamHandler",
                    "stream": sys.stdout,
                    "formatter": "uvicorn",
                },
            },
            "loggers": {
                "": {"handlers": ["default"], "level": LOG_LEVEL},
                "uvicorn.error": {"level": LOG_LEVEL},
                "uvicorn.access": {"handlers": ["uvicorn"], "level": LOG_LEVEL, "propagate": False},
            },
        }
    )
