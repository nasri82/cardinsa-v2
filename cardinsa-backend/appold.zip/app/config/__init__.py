"""
Configuration module for Cardinsa Insurance API.
"""

try:
    from .database import db_manager, get_db, DatabaseHealth
    database_available = True
except ImportError as e:
    print(f"Warning: Database modules not available: {e}")
    database_available = False
    
    # Create mock objects for graceful degradation
    class MockDatabaseHealth:
        @staticmethod
        async def health_check():
            return {
                "database": {
                    "status": "unavailable",
                    "message": "Database modules not loaded",
                    "connected": False
                }
            }
    
    class MockDbManager:
        def initialize(self):
            pass
            
        async def check_connection(self):
            return False
            
        async def close_connections(self):
            pass
    
    def mock_get_db():
        raise RuntimeError("Database not available")
    
    db_manager = MockDbManager()
    get_db = mock_get_db
    DatabaseHealth = MockDatabaseHealth

from .settings import get_settings

# Remove the problematic create_tables import
# from .database import create_tables  # This was causing the error

__all__ = [
    "db_manager", 
    "get_db", 
    "DatabaseHealth", 
    "get_settings",
    "database_available"
]