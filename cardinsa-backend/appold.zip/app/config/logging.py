"""
Logging Configuration
CARDINSA Insurance Platform
"""

import logging
import logging.config
import sys
from pathlib import Path
from typing import Dict, Any

from .settings import get_settings

# Get settings
settings = get_settings()

# Create logs directory if it doesn't exist
LOGS_DIR = Path("logs")
LOGS_DIR.mkdir(exist_ok=True)


def get_logging_config() -> Dict[str, Any]:
    """
    Get logging configuration dictionary.
    
    Returns:
        Dict[str, Any]: Logging configuration
    """
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
            "detailed": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(module)s - %(funcName)s:%(lineno)d - %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
            "json": {
                "()": "app.config.logging.JSONFormatter",
            },
        },
        "handlers": {
            "console": {
                "level": "DEBUG",
                "class": "logging.StreamHandler",
                "formatter": "default",
                "stream": sys.stdout,
            },
            "file": {
                "level": "INFO",
                "class": "logging.handlers.RotatingFileHandler",
                "formatter": "detailed",
                "filename": LOGS_DIR / "cardinsa.log",
                "maxBytes": 10485760,  # 10MB
                "backupCount": 5,
                "encoding": "utf8",
            },
            "error_file": {
                "level": "ERROR",
                "class": "logging.handlers.RotatingFileHandler",
                "formatter": "detailed",
                "filename": LOGS_DIR / "cardinsa_errors.log",
                "maxBytes": 10485760,  # 10MB
                "backupCount": 5,
                "encoding": "utf8",
            },
            "access_file": {
                "level": "INFO",
                "class": "logging.handlers.RotatingFileHandler",
                "formatter": "default",
                "filename": LOGS_DIR / "cardinsa_access.log",
                "maxBytes": 10485760,  # 10MB
                "backupCount": 5,
                "encoding": "utf8",
            },
        },
        "loggers": {
            # Root logger
            "": {
                "level": settings.LOG_LEVEL,
                "handlers": ["console", "file", "error_file"],
                "propagate": False,
            },
            # Application loggers
            "app": {
                "level": settings.LOG_LEVEL,
                "handlers": ["console", "file", "error_file"],
                "propagate": False,
            },
            # FastAPI access logs
            "uvicorn.access": {
                "level": "INFO",
                "handlers": ["console", "access_file"],
                "propagate": False,
            },
            # Database logs
            "sqlalchemy.engine": {
                "level": "WARNING",
                "handlers": ["console", "file"],
                "propagate": False,
            },
            "sqlalchemy.dialects": {
                "level": "WARNING",
                "handlers": ["console", "file"],
                "propagate": False,
            },
            "sqlalchemy.pool": {
                "level": "WARNING",
                "handlers": ["console", "file"],
                "propagate": False,
            },
            "sqlalchemy.orm": {
                "level": "WARNING",
                "handlers": ["console", "file"],
                "propagate": False,
            },
            # Third-party loggers
            "httpx": {
                "level": "WARNING",
                "handlers": ["console", "file"],
                "propagate": False,
            },
            "httpcore": {
                "level": "WARNING",
                "handlers": ["console", "file"],
                "propagate": False,
            },
        },
        "root": {
            "level": settings.LOG_LEVEL,
            "handlers": ["console", "file", "error_file"],
        },
    }


class JSONFormatter(logging.Formatter):
    """
    JSON formatter for structured logging.
    """
    
    def format(self, record: logging.LogRecord) -> str:
        """
        Format log record as JSON.
        
        Args:
            record: Log record
            
        Returns:
            str: JSON formatted log message
        """
        import json
        from datetime import datetime
        
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
            "message": record.getMessage(),
        }
        
        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields
        for key, value in record.__dict__.items():
            if key not in {
                "name", "msg", "args", "levelname", "levelno", "pathname",
                "filename", "module", "lineno", "funcName", "created",
                "msecs", "relativeCreated", "thread", "threadName",
                "processName", "process", "getMessage", "exc_info",
                "exc_text", "stack_info"
            }:
                log_entry[key] = value
        
        return json.dumps(log_entry, default=str)


def setup_logging() -> None:
    """
    Setup application logging configuration.
    This function is called during application startup.
    """
    try:
        # Get logging configuration
        logging_config = get_logging_config()
        
        # Configure logging
        logging.config.dictConfig(logging_config)
        
        # Get logger and log startup message
        logger = logging.getLogger(__name__)
        logger.info(f"Logging initialized - Level: {settings.LOG_LEVEL}")
        logger.info(f"Environment: {settings.ENVIRONMENT}")
        logger.info(f"Log files directory: {LOGS_DIR.absolute()}")
        
        # Log configuration details in development
        if settings.ENVIRONMENT == "development":
            logger.debug("Logging configuration loaded successfully")
            logger.debug(f"Console handler level: DEBUG")
            logger.debug(f"File handler level: INFO")
            logger.debug(f"Error file handler level: ERROR")
        
    except Exception as e:
        # Fallback to basic configuration if setup fails
        logging.basicConfig(
            level=getattr(logging, settings.LOG_LEVEL),
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[
                logging.StreamHandler(sys.stdout),
                logging.FileHandler(LOGS_DIR / "cardinsa_fallback.log")
            ]
        )
        logger = logging.getLogger(__name__)
        logger.error(f"Failed to setup logging configuration: {e}")
        logger.warning("Using fallback logging configuration")


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance with the given name.
    
    Args:
        name: Logger name
        
    Returns:
        logging.Logger: Logger instance
    """
    return logging.getLogger(name)


def log_request(request_id: str, method: str, url: str, status_code: int = None, 
                response_time: float = None, user_id: str = None) -> None:
    """
    Log HTTP request information.
    
    Args:
        request_id: Unique request identifier
        method: HTTP method
        url: Request URL
        status_code: HTTP status code
        response_time: Response time in seconds
        user_id: User ID if authenticated
    """
    logger = get_logger("app.requests")
    
    log_data = {
        "request_id": request_id,
        "method": method,
        "url": url,
        "user_id": user_id,
    }
    
    if status_code is not None:
        log_data["status_code"] = status_code
    
    if response_time is not None:
        log_data["response_time"] = response_time
    
    # Log with appropriate level based on status code
    if status_code is None:
        logger.info("Request started", extra=log_data)
    elif status_code < 400:
        logger.info("Request completed", extra=log_data)
    elif status_code < 500:
        logger.warning("Client error", extra=log_data)
    else:
        logger.error("Server error", extra=log_data)


# Export commonly used items
__all__ = [
    "setup_logging",
    "get_logger",
    "log_request",
    "JSONFormatter",
    "LOGS_DIR",
]