"""Application settings using Pydantic v2."""

import os
from pathlib import Path
from typing import List, Optional, Dict, Any, Union
from functools import lru_cache

try:
    from pydantic_settings import BaseSettings
    from pydantic import Field, field_validator
except ImportError:
    print("Please install: pip install pydantic-settings==2.1.0")
    raise


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Application settings
    APP_NAME: str = "Cardinsa Insurance API"
    ENVIRONMENT: str = "development"
    DEBUG: bool = False
    API_VERSION: str = "v1"
    
    # Security settings - These are required
    SECRET_KEY: str = "default-secret-key-change-in-production"
    JWT_SECRET_KEY: str = "default-jwt-secret-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Database settings - Required
    DATABASE_URL: str = "postgresql://postgres:password@localhost:5432/cardinsa"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    DATABASE_ECHO: bool = False
    DATABASE_POOL_RECYCLE: int = 3600
    DATABASE_POOL_PRE_PING: bool = True
    
    # CORS settings - Handle as string or list
    CORS_ORIGINS: Union[str, List[str]] = "*"
    ALLOWED_HOSTS: Union[str, List[str]] = "*"
    
    # Redis settings (optional)
    REDIS_URL: Optional[str] = None
    REDIS_PASSWORD: Optional[str] = None
    REDIS_DB: int = 0
    REDIS_DECODE_RESPONSES: bool = True
    
    # File upload settings
    UPLOAD_PATH: str = "uploads"
    MAX_FILE_SIZE: int = 10485760  # 10MB
    ALLOWED_FILE_TYPES: Union[str, List[str]] = ".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
    
    # Email settings
    EMAIL_HOST: Optional[str] = None
    EMAIL_PORT: int = 587
    EMAIL_USERNAME: Optional[str] = None
    EMAIL_PASSWORD: Optional[str] = None
    EMAIL_USE_TLS: bool = True
    EMAIL_USE_SSL: bool = False
    EMAIL_FROM: Optional[str] = None
    EMAIL_FROM_NAME: Optional[str] = None
    
    # External services
    PAYMENT_GATEWAY_URL: Optional[str] = None
    PAYMENT_GATEWAY_KEY: Optional[str] = None
    
    # Rate limiting
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_WINDOW: int = 60
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "text"
    LOG_FILE: Optional[str] = None
    
    # Security headers
    ENABLE_SECURITY_HEADERS: bool = True
    
    # Session settings
    SESSION_COOKIE_NAME: str = "cardinsa_session"
    SESSION_COOKIE_SECURE: bool = False  # Set to False for development
    SESSION_COOKIE_HTTPONLY: bool = True
    SESSION_COOKIE_SAMESITE: str = "lax"
    
    # Password policy
    PASSWORD_MIN_LENGTH: int = 8
    PASSWORD_REQUIRE_UPPERCASE: bool = True
    PASSWORD_REQUIRE_LOWERCASE: bool = True
    PASSWORD_REQUIRE_DIGITS: bool = True
    PASSWORD_REQUIRE_SPECIAL_CHARS: bool = True
    PASSWORD_HISTORY_COUNT: int = 5
    PASSWORD_EXPIRY_DAYS: int = 90
    
    # Account lockout policy
    MAX_LOGIN_ATTEMPTS: int = 5
    LOCKOUT_DURATION_MINUTES: int = 30
    
    # MFA settings
    MFA_ISSUER_NAME: str = "Cardinsa Insurance"
    MFA_BACKUP_CODES_COUNT: int = 10
    
    # API documentation
    DOCS_URL: Optional[str] = "/docs"
    REDOC_URL: Optional[str] = "/redoc"
    OPENAPI_URL: Optional[str] = "/openapi.json"
    
    # Monitoring and health checks
    ENABLE_METRICS: bool = True
    HEALTH_CHECK_PATH: str = "/health"
    
    # Timezone and localization
    DEFAULT_TIMEZONE: str = "UTC"
    DEFAULT_LANGUAGE: str = "en"
    SUPPORTED_LANGUAGES: Union[str, List[str]] = "en,ar"
    
    # Field validators with better error handling
    @field_validator('CORS_ORIGINS', mode='before')
    @classmethod
    def parse_cors_origins(cls, value):
        """Parse CORS origins from various formats."""
        if value is None:
            return ["*"]
        if isinstance(value, str):
            if value == "*":
                return ["*"]
            return [origin.strip() for origin in value.split(',') if origin.strip()]
        if isinstance(value, list):
            return value
        return ["*"]
    
    @field_validator('ALLOWED_HOSTS', mode='before')
    @classmethod  
    def parse_allowed_hosts(cls, value):
        """Parse allowed hosts from various formats."""
        if value is None:
            return ["*"]
        if isinstance(value, str):
            if value == "*":
                return ["*"]
            return [host.strip() for host in value.split(',') if host.strip()]
        if isinstance(value, list):
            return value
        return ["*"]
    
    @field_validator('ALLOWED_FILE_TYPES', mode='before')
    @classmethod
    def parse_file_types(cls, value):
        """Parse file types from various formats."""
        if value is None:
            return [".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png", ".gif"]
        if isinstance(value, str):
            return [ext.strip() for ext in value.split(',') if ext.strip()]
        if isinstance(value, list):
            return value
        return [".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png", ".gif"]
    
    @field_validator('SUPPORTED_LANGUAGES', mode='before')
    @classmethod
    def parse_languages(cls, value):
        """Parse supported languages from various formats."""
        if value is None:
            return ["en", "ar"]
        if isinstance(value, str):
            return [lang.strip() for lang in value.split(',') if lang.strip()]
        if isinstance(value, list):
            return value
        return ["en", "ar"]
    
    @field_validator('LOG_LEVEL', mode='before')
    @classmethod
    def validate_log_level(cls, value):
        """Validate and normalize log level."""
        if value is None:
            return "INFO"
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        value_upper = str(value).upper()
        if value_upper in valid_levels:
            return value_upper
        return "INFO"
    
    @field_validator('ENVIRONMENT', mode='before')
    @classmethod
    def validate_environment(cls, value):
        """Validate and normalize environment."""
        if value is None:
            return "development"
        valid_environments = ['development', 'testing', 'staging', 'production']
        value_lower = str(value).lower()
        if value_lower in valid_environments:
            return value_lower
        return "development"
    
    # Properties
    @property
    def is_development(self) -> bool:
        return self.ENVIRONMENT == 'development'
    
    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == 'production'
    
    @property
    def is_testing(self) -> bool:
        return self.ENVIRONMENT == 'testing'
    
    @property
    def upload_directory(self) -> Path:
        return Path(self.UPLOAD_PATH)
    
    @property
    def database_url_sync(self) -> str:
        """Get synchronous database URL."""
        return str(self.DATABASE_URL)
    
    @property
    def database_url_async(self) -> str:
        """Get asynchronous database URL."""
        url = str(self.DATABASE_URL)
        if url.startswith('postgresql://'):
            return url.replace('postgresql://', 'postgresql+asyncpg://')
        return url
    
    def get_cors_origins(self) -> List[str]:
        """Get CORS origins as a list."""
        if isinstance(self.CORS_ORIGINS, str):
            if self.CORS_ORIGINS == "*":
                return ["*"]
            return [origin.strip() for origin in self.CORS_ORIGINS.split(',')]
        return self.CORS_ORIGINS
    
    def get_allowed_hosts(self) -> List[str]:
        """Get allowed hosts as a list."""
        if isinstance(self.ALLOWED_HOSTS, str):
            if self.ALLOWED_HOSTS == "*":
                return ["*"]
            return [host.strip() for host in self.ALLOWED_HOSTS.split(',')]
        return self.ALLOWED_HOSTS
    
    # Pydantic v2 config
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8", 
        "case_sensitive": True,
        "extra": "ignore",
        "validate_default": True
    }


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    try:
        return Settings()
    except Exception as e:
        print(f"Error loading settings: {e}")
        print("Using default settings...")
        # Return settings with minimal required values
        return Settings(
            SECRET_KEY="default-secret-key",
            JWT_SECRET_KEY="default-jwt-secret",
            DATABASE_URL="postgresql://postgres:Rasha%401973@localhost:5432/cardinsa"
        )


# Global settings instance
settings = get_settings()