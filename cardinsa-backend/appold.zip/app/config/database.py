"""
Database connection and session management - Simplified Version.
"""

import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy import create_engine, event, MetaData, text
from sqlalchemy.ext.asyncio import (
    AsyncSession, 
    create_async_engine, 
    async_sessionmaker
)
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import NullPool, QueuePool
from sqlalchemy.exc import DisconnectionError

from app.config.settings import get_settings
from app.models.base import Base

logger = logging.getLogger(__name__)

# Global settings
settings = get_settings()

# Naming convention for constraints
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s"
}

# Configure metadata with naming convention
Base.metadata.naming_convention = NAMING_CONVENTION


class DatabaseManager:
    """Database connection and session manager."""
    
    def __init__(self):
        self.sync_engine = None
        self.async_engine = None
        self.SessionLocal = None
        self.AsyncSessionLocal = None
        self._initialized = False
    
    def initialize(self):
        """Initialize database engines and session makers."""
        if self._initialized:
            return
        
        try:
            # Create synchronous engine
            sync_url = str(settings.DATABASE_URL)
            self.sync_engine = create_engine(
                sync_url,
                pool_size=getattr(settings, 'DATABASE_POOL_SIZE', 10),
                max_overflow=getattr(settings, 'DATABASE_MAX_OVERFLOW', 20),
                pool_recycle=getattr(settings, 'DATABASE_POOL_RECYCLE', 3600),
                pool_pre_ping=getattr(settings, 'DATABASE_POOL_PRE_PING', True),
                echo=getattr(settings, 'DATABASE_ECHO', False),
                future=True,
            )
            
            # Create asynchronous engine
            async_url = sync_url.replace('postgresql://', 'postgresql+asyncpg://')
            self.async_engine = create_async_engine(
                async_url,
                pool_size=getattr(settings, 'DATABASE_POOL_SIZE', 10),
                max_overflow=getattr(settings, 'DATABASE_MAX_OVERFLOW', 20),
                pool_recycle=getattr(settings, 'DATABASE_POOL_RECYCLE', 3600),
                pool_pre_ping=getattr(settings, 'DATABASE_POOL_PRE_PING', True),
                echo=getattr(settings, 'DATABASE_ECHO', False),
                future=True,
            )
            
            # Create session makers
            self.SessionLocal = sessionmaker(
                bind=self.sync_engine,
                class_=Session,
                autocommit=False,
                autoflush=False,
                expire_on_commit=False,
            )
            
            self.AsyncSessionLocal = async_sessionmaker(
                bind=self.async_engine,
                class_=AsyncSession,
                autocommit=False,
                autoflush=False,
                expire_on_commit=False,
            )
            
            self._initialized = True
            logger.info("Database engines and session makers initialized")
            
        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            raise
    
    async def check_connection(self) -> bool:
        """Check database connection health."""
        if not self._initialized:
            try:
                self.initialize()
            except Exception as e:
                logger.error(f"Database initialization failed: {e}")
                return False
        
        try:
            # Test with a simple query
            async with self.async_engine.begin() as conn:
                result = await conn.execute(text("SELECT 1 as test"))
                row = result.fetchone()
                return row is not None
        except Exception as e:
            logger.error(f"Async database connection check failed: {e}")
            return False
    
    def check_connection_sync(self) -> bool:
        """Check database connection health synchronously."""
        if not self._initialized:
            try:
                self.initialize()
            except Exception as e:
                logger.error(f"Database initialization failed: {e}")
                return False
        
        try:
            # Test with a simple query
            with self.sync_engine.connect() as conn:
                result = conn.execute(text("SELECT 1 as test"))
                row = result.fetchone()
                return row is not None
        except Exception as e:
            logger.error(f"Sync database connection check failed: {e}")
            return False
    
    def test_direct_connection(self) -> dict:
        """Test direct database connection and return detailed info."""
        if not self._initialized:
            try:
                self.initialize()
            except Exception as e:
                return {"connected": False, "error": f"Initialization failed: {e}"}
        
        try:
            with self.sync_engine.connect() as conn:
                # Test basic connectivity
                result = conn.execute(text("SELECT version() as version"))
                version_row = result.fetchone()
                
                # Test pool info
                pool = self.sync_engine.pool
                
                return {
                    "connected": True,
                    "postgresql_version": version_row.version if version_row else "Unknown",
                    "pool_size": pool.size(),
                    "pool_checked_in": pool.checkedin(),
                    "pool_checked_out": pool.checkedout(),
                    "pool_overflow": pool.overflow(),
                }
                
        except Exception as e:
            return {"connected": False, "error": str(e)}
    
    async def create_all_tables(self):
        """Create all database tables."""
        if not self._initialized:
            self.initialize()
        
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("All database tables created")
    
    def create_tables(self):
        """Create all database tables synchronously.""" 
        return self.create_all_tables_sync()
    
    def create_all_tables_sync(self):
        """Create all database tables synchronously."""
        if not self._initialized:
            self.initialize()
        
        Base.metadata.create_all(bind=self.sync_engine)
        logger.info("All database tables created (sync)")
    
    async def drop_all_tables(self):
        """Drop all database tables."""
        if not self._initialized:
            self.initialize()
        
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
        logger.info("All database tables dropped")
    
    def drop_all_tables_sync(self):
        """Drop all database tables synchronously."""
        if not self._initialized:
            self.initialize()
        
        Base.metadata.drop_all(bind=self.sync_engine)
        logger.info("All database tables dropped (sync)")
    
    async def close_connections(self):
        """Close all database connections."""
        try:
            if self.async_engine:
                await self.async_engine.dispose()
            if self.sync_engine:
                self.sync_engine.dispose()
            logger.info("Database connections closed")
        except Exception as e:
            logger.error(f"Error closing database connections: {e}")
    
    def get_sync_session(self) -> Session:
        """Get a synchronous database session."""
        if not self._initialized:
            self.initialize()
        return self.SessionLocal()
    
    def get_async_session(self) -> AsyncSession:
        """Get an asynchronous database session."""
        if not self._initialized:
            self.initialize()
        return self.AsyncSessionLocal()


# Global database manager instance
db_manager = DatabaseManager()


def get_db() -> Session:
    """
    Dependency to get a synchronous database session.
    This is used in FastAPI dependency injection.
    """
    session = db_manager.get_sync_session()
    try:
        yield session
    except Exception as e:
        session.rollback()
        logger.error(f"Database session error: {e}")
        raise
    finally:
        session.close()


async def get_async_db() -> AsyncSession:
    """
    Dependency to get an asynchronous database session.
    This is used in FastAPI dependency injection.
    """
    session = db_manager.get_async_session()
    try:
        yield session
    except Exception as e:
        await session.rollback()
        logger.error(f"Async database session error: {e}")
        raise
    finally:
        await session.close()


@asynccontextmanager
async def get_db_context() -> AsyncGenerator[AsyncSession, None]:
    """
    Context manager to get an asynchronous database session.
    Use this in services and other non-FastAPI contexts.
    """
    session = db_manager.get_async_session()
    try:
        yield session
        await session.commit()
    except Exception as e:
        await session.rollback()
        logger.error(f"Database context error: {e}")
        raise
    finally:
        await session.close()


class DatabaseHealth:
    """Database health checker."""
    
    @staticmethod
    async def health_check() -> dict:
        """Perform database health check."""
        try:
            # Test async connection
            is_async_healthy = await db_manager.check_connection()
            
            # Get detailed connection info
            connection_info = db_manager.test_direct_connection()
            
            if is_async_healthy and connection_info.get("connected"):
                status = "healthy"
                message = "Database connection is working properly"
            elif connection_info.get("connected"):
                status = "partial" 
                message = "Database reachable but async connection issues"
            else:
                status = "unhealthy"
                message = f"Database connection failed: {connection_info.get('error', 'Unknown error')}"
            
            health_data = {
                "database": {
                    "status": status,
                    "connected": connection_info.get("connected", False),
                    "message": message,
                    **connection_info
                }
            }
            
            return health_data
        
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            return {
                "database": {
                    "status": "unhealthy",
                    "connected": False,
                    "error": str(e),
                    "message": "Health check failed"
                }
            }
    
    @staticmethod
    def health_check_sync() -> dict:
        """Perform synchronous database health check."""
        try:
            # Test sync connection
            is_healthy = db_manager.check_connection_sync()
            
            # Get detailed connection info
            connection_info = db_manager.test_direct_connection()
            
            status = "healthy" if is_healthy else "unhealthy"
            message = "Database connection working" if is_healthy else "Database connection failed"
            
            return {
                "database": {
                    "status": status,
                    "connected": is_healthy,
                    "message": message,
                    **connection_info
                }
            }
        
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            return {
                "database": {
                    "status": "unhealthy",
                    "connected": False,
                    "error": str(e),
                    "message": "Health check failed"
                }
            }


# Initialize database manager on module import
try:
    db_manager.initialize()
    logger.info("Database manager auto-initialized")
except Exception as e:
    logger.warning(f"Database auto-initialization failed: {e}")