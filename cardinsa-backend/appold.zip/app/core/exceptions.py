# FILE PATH: app/core/exceptions.py
"""
Enhanced Custom Exceptions for CARDINSA Insurance Platform

Enterprise-grade exception handling with comprehensive error context,
logging integration, and security-aware error messages.
"""

import uuid
import logging
from typing import Any, Dict, Optional, List, Union
from datetime import datetime
from enum import Enum

from fastapi import HTTPException, status


class ErrorSeverity(Enum):
    """Error severity levels for monitoring and alerting."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ErrorCategory(Enum):
    """Error categories for classification and handling."""
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    VALIDATION = "validation"
    BUSINESS_LOGIC = "business_logic"
    EXTERNAL_SERVICE = "external_service"
    DATABASE = "database"
    SYSTEM = "system"
    SECURITY = "security"
    COMPLIANCE = "compliance"


class BaseAppException(Exception):
    """
    Enhanced base exception class for application-specific exceptions.
    
    Features:
    - Structured error information
    - Correlation tracking
    - Security-aware error messages
    - Automatic logging integration
    - Compliance and audit support
    """
    
    def __init__(
        self,
        message: str = "An error occurred",
        details: Optional[Dict[str, Any]] = None,
        error_code: Optional[str] = None,
        severity: ErrorSeverity = ErrorSeverity.MEDIUM,
        category: ErrorCategory = ErrorCategory.SYSTEM,
        correlation_id: Optional[str] = None,
        user_id: Optional[str] = None,
        sensitive_data: bool = False,
        should_log: bool = True,
        should_alert: bool = False,
        remediation_hint: Optional[str] = None
    ):
        self.message = message
        self.details = details or {}
        self.error_code = error_code
        self.severity = severity
        self.category = category
        self.correlation_id = correlation_id or str(uuid.uuid4())
        self.user_id = user_id
        self.sensitive_data = sensitive_data
        self.should_log = should_log
        self.should_alert = should_alert
        self.remediation_hint = remediation_hint
        self.timestamp = datetime.utcnow()
        
        # Auto-generate error code if not provided
        if not self.error_code:
            self.error_code = f"{category.value.upper()}_{type(self).__name__.upper()}"
        
        super().__init__(self.message)
        
        # Automatic logging
        if self.should_log:
            self._log_exception()
    
    def _log_exception(self):
        """Log exception with appropriate level based on severity."""
        logger = logging.getLogger(__name__)
        
        log_data = {
            "error_code": self.error_code,
            "category": self.category.value,
            "severity": self.severity.value,
            "correlation_id": self.correlation_id,
            "user_id": self.user_id,
            "details": self._get_safe_details(),
            "timestamp": self.timestamp.isoformat()
        }
        
        if self.severity == ErrorSeverity.CRITICAL:
            logger.critical(f"Critical error: {self.message}", extra=log_data)
        elif self.severity == ErrorSeverity.HIGH:
            logger.error(f"High severity error: {self.message}", extra=log_data)
        elif self.severity == ErrorSeverity.MEDIUM:
            logger.warning(f"Medium severity error: {self.message}", extra=log_data)
        else:
            logger.info(f"Low severity error: {self.message}", extra=log_data)
    
    def _get_safe_details(self) -> Dict[str, Any]:
        """Get details with sensitive data filtered out for logging."""
        if not self.sensitive_data:
            return self.details
        
        # Filter out sensitive fields
        sensitive_fields = ['password', 'token', 'secret', 'key', 'credential']
        safe_details = {}
        
        for key, value in self.details.items():
            if any(field in key.lower() for field in sensitive_fields):
                safe_details[key] = "[REDACTED]"
            else:
                safe_details[key] = value
        
        return safe_details
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        return {
            "error": {
                "code": self.error_code,
                "message": self.message,
                "category": self.category.value,
                "severity": self.severity.value,
                "correlation_id": self.correlation_id,
                "timestamp": self.timestamp.isoformat(),
                "details": self._get_safe_details(),
                "remediation": self.remediation_hint
            }
        }


# ===== VALIDATION EXCEPTIONS =====

class ValidationError(BaseAppException):
    """Enhanced validation error with field-specific details."""
    
    def __init__(
        self,
        message: str = "Validation failed",
        field_errors: Optional[Dict[str, List[str]]] = None,
        **kwargs
    ):
        self.field_errors = field_errors or {}
        details = kwargs.get("details", {})
        details["field_errors"] = self.field_errors
        
        super().__init__(
            message=message,
            details=details,
            category=ErrorCategory.VALIDATION,
            severity=ErrorSeverity.LOW,
            **kwargs
        )


class ValidationException(ValidationError):
    """Alias for ValidationError for backward compatibility."""
    pass


class SchemaValidationError(ValidationError):
    """Schema validation specific error."""
    
    def __init__(self, schema_name: str, errors: List[Dict[str, Any]], **kwargs):
        field_errors = {}
        for error in errors:
            field = ".".join(str(loc) for loc in error.get("loc", []))
            if field not in field_errors:
                field_errors[field] = []
            field_errors[field].append(error.get("msg", "Invalid value"))
        
        super().__init__(
            message=f"Schema validation failed for {schema_name}",
            field_errors=field_errors,
            details={"schema": schema_name, "validation_errors": errors},
            error_code="SCHEMA_VALIDATION_FAILED",
            **kwargs
        )


# ===== RESOURCE EXCEPTIONS =====

class ResourceError(BaseAppException):
    """Base class for resource-related errors."""
    
    def __init__(
        self,
        resource_type: str,
        resource_id: Optional[str] = None,
        operation: Optional[str] = None,
        **kwargs
    ):
        self.resource_type = resource_type
        self.resource_id = resource_id
        self.operation = operation
        
        details = kwargs.get("details", {})
        details.update({
            "resource_type": resource_type,
            "resource_id": resource_id,
            "operation": operation
        })
        
        super().__init__(details=details, **kwargs)


class NotFoundError(ResourceError):
    """Enhanced resource not found error."""
    
    def __init__(self, resource_type: str = "Resource", resource_id: Optional[str] = None, **kwargs):
        message = f"{resource_type} not found"
        if resource_id:
            message = f"{resource_type} with ID '{resource_id}' not found"
        
        super().__init__(
            message=message,
            resource_type=resource_type,
            resource_id=resource_id,
            operation="read",
            category=ErrorCategory.VALIDATION,
            severity=ErrorSeverity.LOW,
            error_code="RESOURCE_NOT_FOUND",
            remediation_hint="Verify the resource ID and ensure the resource exists",
            **kwargs
        )


class ResourceNotFoundException(NotFoundError):
    """Alias for NotFoundError for backward compatibility."""
    pass


class AlreadyExistsError(ResourceError):
    """Enhanced resource already exists error."""
    
    def __init__(
        self, 
        resource_type: str = "Resource", 
        conflicting_field: Optional[str] = None,
        conflicting_value: Optional[str] = None,
        **kwargs
    ):
        message = f"{resource_type} already exists"
        if conflicting_field:
            message = f"{resource_type} with {conflicting_field}"
            if conflicting_value:
                message += f" '{conflicting_value}'"
            message += " already exists"
        
        details = kwargs.get("details", {})
        details.update({
            "conflicting_field": conflicting_field,
            "conflicting_value": conflicting_value
        })
        
        super().__init__(
            message=message,
            resource_type=resource_type,
            operation="create",
            category=ErrorCategory.BUSINESS_LOGIC,
            severity=ErrorSeverity.MEDIUM,
            error_code="RESOURCE_ALREADY_EXISTS",
            details=details,
            remediation_hint="Use a different value for the conflicting field or update the existing resource",
            **kwargs
        )


# ===== AUTHENTICATION EXCEPTIONS =====

class AuthenticationError(BaseAppException):
    """Enhanced authentication error with security features."""
    
    def __init__(
        self,
        message: str = "Authentication failed",
        auth_method: Optional[str] = None,
        failure_reason: Optional[str] = None,
        lockout_info: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        details = kwargs.get("details", {})
        details.update({
            "auth_method": auth_method,
            "failure_reason": failure_reason,
            "lockout_info": lockout_info
        })
        
        super().__init__(
            message=message,
            details=details,
            category=ErrorCategory.AUTHENTICATION,
            severity=ErrorSeverity.HIGH,
            sensitive_data=True,
            should_alert=True,
            **kwargs
        )


class InvalidCredentialsError(AuthenticationError):
    """Invalid login credentials error."""
    
    def __init__(
        self,
        username: Optional[str] = None,
        failed_attempts: int = 0,
        **kwargs
    ):
        details = kwargs.get("details", {})
        details.update({
            "username": username,
            "failed_attempts": failed_attempts,
            "security_note": "Multiple failed attempts may result in account lockout"
        })
        
        super().__init__(
            message="Invalid username or password",
            auth_method="password",
            failure_reason="invalid_credentials",
            error_code="INVALID_CREDENTIALS",
            details=details,
            remediation_hint="Verify your username and password are correct",
            **kwargs
        )


class AccountLockedError(AuthenticationError):
    """Account locked error with detailed lockout information."""
    
    def __init__(
        self,
        username: Optional[str] = None,
        locked_until: Optional[datetime] = None,
        reason: str = "too_many_failed_attempts",
        **kwargs
    ):
        lockout_info = {
            "reason": reason,
            "locked_until": locked_until.isoformat() if locked_until else None,
            "auto_unlock": locked_until is not None
        }
        
        message = "Account is locked"
        if locked_until:
            message += f" until {locked_until.strftime('%Y-%m-%d %H:%M:%S UTC')}"
        
        super().__init__(
            message=message,
            auth_method="account_status",
            failure_reason="account_locked",
            lockout_info=lockout_info,
            error_code="ACCOUNT_LOCKED",
            severity=ErrorSeverity.CRITICAL,
            details={"username": username},
            remediation_hint="Contact administrator or wait for automatic unlock",
            **kwargs
        )


class TokenExpiredError(AuthenticationError):
    """Token expiration error with renewal information."""
    
    def __init__(
        self,
        token_type: str = "access_token",
        expired_at: Optional[datetime] = None,
        can_refresh: bool = False,
        **kwargs
    ):
        details = kwargs.get("details", {})
        details.update({
            "token_type": token_type,
            "expired_at": expired_at.isoformat() if expired_at else None,
            "can_refresh": can_refresh
        })
        
        super().__init__(
            message=f"{token_type.replace('_', ' ').title()} has expired",
            auth_method="token",
            failure_reason="token_expired",
            error_code="TOKEN_EXPIRED",
            details=details,
            remediation_hint="Refresh your token or log in again" if can_refresh else "Please log in again",
            **kwargs
        )


class InvalidTokenError(AuthenticationError):
    """Invalid token error."""
    
    def __init__(
        self,
        token_type: str = "access_token",
        validation_error: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            message=f"Invalid {token_type.replace('_', ' ')}",
            auth_method="token",
            failure_reason="invalid_token",
            error_code="INVALID_TOKEN",
            details={
                "token_type": token_type,
                "validation_error": validation_error
            },
            remediation_hint="Please log in again to obtain a valid token",
            **kwargs
        )


# ===== MFA EXCEPTIONS =====

class MFAError(AuthenticationError):
    """Base MFA error class."""
    
    def __init__(self, mfa_method: Optional[str] = None, **kwargs):
        details = kwargs.get("details", {})
        details["mfa_method"] = mfa_method
        
        super().__init__(
            category=ErrorCategory.AUTHENTICATION,
            details=details,
            **kwargs
        )


class MFARequiredError(MFAError):
    """MFA verification required error."""
    
    def __init__(
        self,
        available_methods: Optional[List[str]] = None,
        challenge_id: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            message="Multi-factor authentication required",
            error_code="MFA_REQUIRED",
            details={
                "available_methods": available_methods or [],
                "challenge_id": challenge_id,
                "next_step": "complete_mfa_challenge"
            },
            remediation_hint="Complete MFA verification using one of the available methods",
            **kwargs
        )


class InvalidMFACodeError(MFAError):
    """Invalid MFA code error."""
    
    def __init__(
        self,
        method: str,
        attempts_remaining: Optional[int] = None,
        **kwargs
    ):
        details = {
            "attempts_remaining": attempts_remaining,
            "method_blocked": attempts_remaining == 0
        }
        
        message = f"Invalid {method.upper()} code"
        if attempts_remaining is not None:
            message += f". {attempts_remaining} attempts remaining"
        
        super().__init__(
            message=message,
            mfa_method=method,
            error_code="INVALID_MFA_CODE",
            details=details,
            remediation_hint="Check your code and try again" if attempts_remaining else "Use alternative MFA method",
            **kwargs
        )


class MFASetupRequiredError(MFAError):
    """MFA setup required error."""
    
    def __init__(self, supported_methods: Optional[List[str]] = None, **kwargs):
        super().__init__(
            message="Multi-factor authentication setup required",
            error_code="MFA_SETUP_REQUIRED",
            details={
                "supported_methods": supported_methods or ["totp", "sms", "email"],
                "setup_required": True
            },
            remediation_hint="Set up MFA using one of the supported methods",
            **kwargs
        )


# ===== AUTHORIZATION EXCEPTIONS =====

class AuthorizationError(BaseAppException):
    """Enhanced authorization error with context."""
    
    def __init__(
        self,
        message: str = "Access denied",
        required_permission: Optional[str] = None,
        current_permissions: Optional[List[str]] = None,
        resource_context: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        details = kwargs.get("details", {})
        details.update({
            "required_permission": required_permission,
            "current_permissions": current_permissions,
            "resource_context": resource_context
        })
        
        super().__init__(
            message=message,
            details=details,
            category=ErrorCategory.AUTHORIZATION,
            severity=ErrorSeverity.HIGH,
            should_alert=True,
            **kwargs
        )


class AuthorizationException(AuthorizationError):
    """Alias for AuthorizationError for backward compatibility."""
    pass


class InsufficientPermissionsError(AuthorizationError):
    """Insufficient permissions error."""
    
    def __init__(
        self,
        required_permissions: Union[str, List[str]],
        missing_permissions: Optional[List[str]] = None,
        **kwargs
    ):
        if isinstance(required_permissions, str):
            required_permissions = [required_permissions]
        
        missing = missing_permissions or required_permissions
        message = f"Insufficient permissions. Required: {', '.join(missing)}"
        
        super().__init__(
            message=message,
            required_permission=", ".join(required_permissions),
            error_code="INSUFFICIENT_PERMISSIONS",
            details={"missing_permissions": missing},
            remediation_hint="Contact administrator to request required permissions",
            **kwargs
        )


class ResourceAccessDeniedError(AuthorizationError):
    """Resource access denied error."""
    
    def __init__(
        self,
        resource_type: str,
        resource_id: Optional[str] = None,
        access_level: Optional[str] = None,
        **kwargs
    ):
        message = f"Access denied to {resource_type}"
        if resource_id:
            message += f" '{resource_id}'"
        if access_level:
            message += f" for {access_level} access"
        
        super().__init__(
            message=message,
            error_code="RESOURCE_ACCESS_DENIED",
            resource_context={
                "resource_type": resource_type,
                "resource_id": resource_id,
                "access_level": access_level
            },
            remediation_hint="Verify you have permission to access this resource",
            **kwargs
        )


# ===== BUSINESS LOGIC EXCEPTIONS =====

class BusinessLogicError(BaseAppException):
    """Enhanced business logic error."""
    
    def __init__(
        self,
        message: str = "Business rule violation",
        rule_name: Optional[str] = None,
        rule_context: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        details = kwargs.get("details", {})
        details.update({
            "rule_name": rule_name,
            "rule_context": rule_context
        })
        
        super().__init__(
            message=message,
            details=details,
            category=ErrorCategory.BUSINESS_LOGIC,
            severity=ErrorSeverity.MEDIUM,
            **kwargs
        )


class BusinessLogicException(BusinessLogicError):
    """Alias for BusinessLogicError for backward compatibility."""
    pass


class StateTransitionError(BusinessLogicError):
    """Invalid state transition error."""
    
    def __init__(
        self,
        current_state: str,
        attempted_state: str,
        valid_transitions: Optional[List[str]] = None,
        **kwargs
    ):
        message = f"Invalid state transition from '{current_state}' to '{attempted_state}'"
        
        super().__init__(
            message=message,
            rule_name="state_transition",
            rule_context={
                "current_state": current_state,
                "attempted_state": attempted_state,
                "valid_transitions": valid_transitions or []
            },
            error_code="INVALID_STATE_TRANSITION",
            remediation_hint=f"Valid transitions from '{current_state}': {', '.join(valid_transitions or [])}",
            **kwargs
        )


# ===== EXTERNAL SERVICE EXCEPTIONS =====

class ExternalServiceError(BaseAppException):
    """Enhanced external service error."""
    
    def __init__(
        self,
        service_name: str,
        operation: Optional[str] = None,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        message = f"External service error: {service_name}"
        if operation:
            message += f" ({operation})"
        
        details = kwargs.get("details", {})
        details.update({
            "service_name": service_name,
            "operation": operation,
            "status_code": status_code,
            "response_data": response_data
        })
        
        super().__init__(
            message=message,
            details=details,
            category=ErrorCategory.EXTERNAL_SERVICE,
            severity=ErrorSeverity.HIGH,
            should_alert=True,
            **kwargs
        )


class ServiceUnavailableError(ExternalServiceError):
    """Service unavailable error."""
    
    def __init__(self, service_name: str, retry_after: Optional[int] = None, **kwargs):
        super().__init__(
            service_name=service_name,
            error_code="SERVICE_UNAVAILABLE",
            details={"retry_after_seconds": retry_after},
            remediation_hint=f"Try again in {retry_after} seconds" if retry_after else "Try again later",
            **kwargs
        )


# ===== DATABASE EXCEPTIONS =====

class DatabaseError(BaseAppException):
    """Enhanced database error."""
    
    def __init__(
        self,
        message: str = "Database operation failed",
        operation: Optional[str] = None,
        table: Optional[str] = None,
        constraint: Optional[str] = None,
        **kwargs
    ):
        details = kwargs.get("details", {})
        details.update({
            "operation": operation,
            "table": table,
            "constraint": constraint
        })
        
        super().__init__(
            message=message,
            details=details,
            category=ErrorCategory.DATABASE,
            severity=ErrorSeverity.HIGH,
            should_alert=True,
            **kwargs
        )


class ForeignKeyConstraintError(DatabaseError):
    """Foreign key constraint violation."""
    
    def __init__(
        self,
        table: str,
        foreign_key: str,
        referenced_table: str,
        **kwargs
    ):
        super().__init__(
            message=f"Foreign key constraint violation: {foreign_key} in {table}",
            operation="constraint_check",
            table=table,
            constraint=foreign_key,
            error_code="FOREIGN_KEY_CONSTRAINT",
            details={
                "foreign_key": foreign_key,
                "referenced_table": referenced_table
            },
            remediation_hint=f"Ensure the referenced record exists in {referenced_table}",
            **kwargs
        )


# ===== SECURITY EXCEPTIONS =====

class SecurityError(BaseAppException):
    """Enhanced security error."""
    
    def __init__(
        self,
        message: str = "Security violation detected",
        threat_type: Optional[str] = None,
        risk_level: str = "medium",
        **kwargs
    ):
        super().__init__(
            message=message,
            details={
                "threat_type": threat_type,
                "risk_level": risk_level
            },
            category=ErrorCategory.SECURITY,
            severity=ErrorSeverity.CRITICAL,
            should_alert=True,
            **kwargs
        )


class SecurityViolationError(SecurityError):
    """Security violation error."""
    
    def __init__(self, violation_type: str, **kwargs):
        super().__init__(
            message=f"Security violation: {violation_type}",
            threat_type=violation_type,
            error_code="SECURITY_VIOLATION",
            **kwargs
        )


class RateLimitError(SecurityError):
    """Enhanced rate limit error."""
    
    def __init__(
        self,
        limit: int,
        window: int,
        retry_after: Optional[int] = None,
        **kwargs
    ):
        message = f"Rate limit exceeded: {limit} requests per {window} seconds"
        
        super().__init__(
            message=message,
            threat_type="rate_limit_exceeded",
            error_code="RATE_LIMIT_EXCEEDED",
            details={
                "limit": limit,
                "window_seconds": window,
                "retry_after_seconds": retry_after
            },
            remediation_hint=f"Wait {retry_after} seconds before retrying" if retry_after else "Reduce request frequency",
            **kwargs
        )


class RateLimitExceededError(RateLimitError):
    """Alias for RateLimitError."""
    pass


# ===== HTTP EXCEPTIONS FOR FASTAPI =====

class EnhancedHTTPException(HTTPException):
    """Enhanced HTTP exception with structured error information."""
    
    def __init__(
        self,
        status_code: int,
        detail: Any = None,
        headers: Optional[Dict[str, Any]] = None,
        error_code: Optional[str] = None,
        correlation_id: Optional[str] = None
    ):
        if isinstance(detail, BaseAppException):
            structured_detail = detail.to_dict()
        elif isinstance(detail, dict):
            structured_detail = detail
        else:
            structured_detail = {
                "error": {
                    "message": str(detail) if detail else "An error occurred",
                    "code": error_code or f"HTTP_{status_code}",
                    "correlation_id": correlation_id or str(uuid.uuid4())
                }
            }
        
        super().__init__(status_code=status_code, detail=structured_detail, headers=headers)


class HTTPBadRequestError(EnhancedHTTPException):
    """HTTP 400 Bad Request exception."""
    
    def __init__(self, message: str = "Bad request", **kwargs):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=message,
            error_code="BAD_REQUEST",
            **kwargs
        )


class HTTPUnauthorizedError(EnhancedHTTPException):
    """HTTP 401 Unauthorized exception."""
    
    def __init__(self, message: str = "Authentication required", **kwargs):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=message,
            error_code="UNAUTHORIZED",
            **kwargs
        )


class HTTPForbiddenError(EnhancedHTTPException):
    """HTTP 403 Forbidden exception."""
    
    def __init__(self, message: str = "Access forbidden", **kwargs):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=message,
            error_code="FORBIDDEN",
            **kwargs
        )


class HTTPNotFoundError(EnhancedHTTPException):
    """HTTP 404 Not Found exception."""
    
    def __init__(self, resource: str = "Resource", identifier: str = "", **kwargs):
        detail = f"{resource} not found"
        if identifier:
            detail = f"{resource} with identifier '{identifier}' not found"
        
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=detail,
            error_code="NOT_FOUND",
            **kwargs
        )


class HTTPConflictError(EnhancedHTTPException):
    """HTTP 409 Conflict exception."""
    
    def __init__(self, message: str = "Resource conflict", **kwargs):
        super().__init__(
            status_code=status.HTTP_409_CONFLICT,
            detail=message,
            error_code="CONFLICT",
            **kwargs
        )


class HTTPUnprocessableEntityError(EnhancedHTTPException):
    """HTTP 422 Unprocessable Entity exception."""
    
    def __init__(self, message: str = "Validation error", **kwargs):
        super().__init__(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=message,
            error_code="VALIDATION_ERROR",
            **kwargs
        )


class HTTPTooManyRequestsError(EnhancedHTTPException):
    """HTTP 429 Too Many Requests exception."""
    
    def __init__(self, message: str = "Rate limit exceeded", retry_after: Optional[int] = None, **kwargs):
        headers = kwargs.get("headers", {})
        if retry_after:
            headers["Retry-After"] = str(retry_after)
        
        super().__init__(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=message,
            headers=headers,
            error_code="RATE_LIMIT_EXCEEDED",
            **kwargs
        )


class HTTPInternalServerError(EnhancedHTTPException):
    """HTTP 500 Internal Server Error exception."""
    
    def __init__(self, message: str = "Internal server error", **kwargs):
        super().__init__(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=message,
            error_code="INTERNAL_SERVER_ERROR",
            **kwargs
        )


class HTTPServiceUnavailableError(EnhancedHTTPException):
    """HTTP 503 Service Unavailable exception."""
    
    def __init__(self, message: str = "Service temporarily unavailable", retry_after: Optional[int] = None, **kwargs):
        headers = kwargs.get("headers", {})
        if retry_after:
            headers["Retry-After"] = str(retry_after)
        
        super().__init__(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=message,
            headers=headers,
            error_code="SERVICE_UNAVAILABLE",
            **kwargs
        )


# ===== COMPLIANCE AND AUDIT EXCEPTIONS =====

class ComplianceError(BaseAppException):
    """Enhanced compliance error."""
    
    def __init__(
        self,
        framework: str,
        violation_type: str,
        regulation_reference: Optional[str] = None,
        **kwargs
    ):
        message = f"Compliance violation: {violation_type} ({framework})"
        
        super().__init__(
            message=message,
            details={
                "framework": framework,
                "violation_type": violation_type,
                "regulation_reference": regulation_reference
            },
            category=ErrorCategory.COMPLIANCE,
            severity=ErrorSeverity.CRITICAL,
            should_alert=True,
            error_code="COMPLIANCE_VIOLATION",
            **kwargs
        )


class DataRetentionError(ComplianceError):
    """Data retention policy violation."""
    
    def __init__(self, data_type: str, retention_period: str, **kwargs):
        super().__init__(
            framework="DATA_RETENTION",
            violation_type="retention_period_exceeded",
            details={
                "data_type": data_type,
                "retention_period": retention_period
            },
            remediation_hint=f"Archive or delete {data_type} data older than {retention_period}",
            **kwargs
        )


class PrivacyError(ComplianceError):
    """Privacy regulation violation."""
    
    def __init__(
        self,
        regulation: str = "GDPR",
        violation_type: str = "unauthorized_access",
        data_subject_id: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            framework=regulation,
            violation_type=violation_type,
            details={"data_subject_id": data_subject_id},
            sensitive_data=True,
            **kwargs
        )


# ===== INTEGRATION AND COMPATIBILITY EXCEPTIONS =====

class IntegrationError(BaseAppException):
    """Integration-specific error."""
    
    def __init__(
        self,
        integration_name: str,
        operation: Optional[str] = None,
        error_details: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        super().__init__(
            message=f"Integration error: {integration_name}",
            details={
                "integration": integration_name,
                "operation": operation,
                "error_details": error_details or {}
            },
            category=ErrorCategory.EXTERNAL_SERVICE,
            **kwargs
        )


class ConfigurationError(BaseAppException):
    """Enhanced configuration error."""
    
    def __init__(
        self,
        config_key: str,
        issue_type: str = "missing",
        expected_type: Optional[str] = None,
        **kwargs
    ):
        message = f"Configuration error: {config_key} is {issue_type}"
        
        super().__init__(
            message=message,
            details={
                "config_key": config_key,
                "issue_type": issue_type,
                "expected_type": expected_type
            },
            category=ErrorCategory.SYSTEM,
            severity=ErrorSeverity.CRITICAL,
            error_code="CONFIGURATION_ERROR",
            remediation_hint=f"Check configuration for {config_key}",
            **kwargs
        )


# ===== LEGACY COMPATIBILITY ALIASES =====

# Maintain backward compatibility with existing code
PermissionDeniedError = InsufficientPermissionsError
AccountInactiveError = AccountLockedError
RecordNotFoundError = NotFoundError
RecordNotFoundException = NotFoundError
ResourceNotFoundError = NotFoundError
DuplicateRecordError = AlreadyExistsError
DatabaseConnectionError = DatabaseError
DepartmentAccessDeniedError = ResourceAccessDeniedError


# ===== EXCEPTION UTILITIES =====

class ExceptionHandler:
    """Utility class for exception handling and conversion."""
    
    @staticmethod
    def to_http_exception(exc: BaseAppException) -> EnhancedHTTPException:
        """Convert BaseAppException to appropriate HTTP exception."""
        
        if isinstance(exc, ValidationError):
            return HTTPUnprocessableEntityError(exc.message, correlation_id=exc.correlation_id)
        elif isinstance(exc, AuthenticationError):
            return HTTPUnauthorizedError(exc.message, correlation_id=exc.correlation_id)
        elif isinstance(exc, AuthorizationError):
            return HTTPForbiddenError(exc.message, correlation_id=exc.correlation_id)
        elif isinstance(exc, NotFoundError):
            return HTTPNotFoundError(exc.resource_type, exc.resource_id, correlation_id=exc.correlation_id)
        elif isinstance(exc, AlreadyExistsError):
            return HTTPConflictError(exc.message, correlation_id=exc.correlation_id)
        elif isinstance(exc, RateLimitError):
            retry_after = exc.details.get("retry_after_seconds")
            return HTTPTooManyRequestsError(exc.message, retry_after=retry_after, correlation_id=exc.correlation_id)
        elif isinstance(exc, ExternalServiceError):
            return HTTPServiceUnavailableError(exc.message, correlation_id=exc.correlation_id)
        else:
            return HTTPInternalServerError(exc.message, correlation_id=exc.correlation_id)
    
    @staticmethod
    def log_exception_chain(exc: Exception, logger: logging.Logger):
        """Log exception with full chain and context."""
        
        if isinstance(exc, BaseAppException):
            logger.error(
                f"Application exception: {exc.message}",
                extra={
                    "exception_type": type(exc).__name__,
                    "error_code": exc.error_code,
                    "category": exc.category.value,
                    "severity": exc.severity.value,
                    "correlation_id": exc.correlation_id,
                    "details": exc._get_safe_details()
                },
                exc_info=True
            )
        else:
            logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)


# ===== EXCEPTION REGISTRY =====

class ExceptionRegistry:
    """Registry for mapping error codes to exception classes."""
    
    _registry = {}
    
    @classmethod
    def register(cls, error_code: str, exception_class: type):
        """Register exception class for error code."""
        cls._registry[error_code] = exception_class
    
    @classmethod
    def get_exception_class(cls, error_code: str) -> Optional[type]:
        """Get exception class for error code."""
        return cls._registry.get(error_code)
    
    @classmethod
    def create_exception(cls, error_code: str, **kwargs) -> Optional[BaseAppException]:
        """Create exception instance from error code."""
        exception_class = cls.get_exception_class(error_code)
        if exception_class:
            return exception_class(**kwargs)
        return None


# Auto-register common exceptions
ExceptionRegistry.register("VALIDATION_ERROR", ValidationError)
ExceptionRegistry.register("AUTHENTICATION_FAILED", AuthenticationError)
ExceptionRegistry.register("AUTHORIZATION_DENIED", AuthorizationError)
ExceptionRegistry.register("RESOURCE_NOT_FOUND", NotFoundError)
ExceptionRegistry.register("RESOURCE_ALREADY_EXISTS", AlreadyExistsError)
ExceptionRegistry.register("RATE_LIMIT_EXCEEDED", RateLimitError)
ExceptionRegistry.register("MFA_REQUIRED", MFARequiredError)
ExceptionRegistry.register("INVALID_MFA_CODE", InvalidMFACodeError)
ExceptionRegistry.register("ACCOUNT_LOCKED", AccountLockedError)
ExceptionRegistry.register("TOKEN_EXPIRED", TokenExpiredError)
ExceptionRegistry.register("INVALID_TOKEN", InvalidTokenError)


# Export all exceptions and utilities
__all__ = [
    # Base classes
    "BaseAppException", "ErrorSeverity", "ErrorCategory",
    
    # Core exceptions
    "ValidationError", "ValidationException", "SchemaValidationError",
    "NotFoundError", "ResourceNotFoundException", "AlreadyExistsError",
    "AuthenticationError", "AuthorizationError", "AuthorizationException",
    "BusinessLogicError", "BusinessLogicException", "ExternalServiceError",
    "DatabaseError", "SecurityError", "ComplianceError",
    
    # Authentication exceptions
    "InvalidCredentialsError", "AccountLockedError", "TokenExpiredError", 
    "InvalidTokenError", "MFARequiredError", "InvalidMFACodeError", 
    "MFASetupRequiredError", "SecurityViolationError",
    
    # Authorization exceptions
    "InsufficientPermissionsError", "ResourceAccessDeniedError",
    
    # Rate limiting
    "RateLimitError", "RateLimitExceededError",
    
    # Business logic
    "StateTransitionError",
    
    # External services
    "ServiceUnavailableError", "IntegrationError",
    
    # Database
    "ForeignKeyConstraintError",
    
    # System
    "ConfigurationError",
    
    # Compliance
    "DataRetentionError", "PrivacyError",
    
    # HTTP exceptions
    "EnhancedHTTPException", "HTTPBadRequestError", "HTTPUnauthorizedError",
    "HTTPForbiddenError", "HTTPNotFoundError", "HTTPConflictError",
    "HTTPUnprocessableEntityError", "HTTPTooManyRequestsError",
    "HTTPInternalServerError", "HTTPServiceUnavailableError",
    
    # Utilities
    "ExceptionHandler", "ExceptionRegistry",
    
    # Legacy aliases
    "PermissionDeniedError", "AccountInactiveError", "RecordNotFoundError",
    "RecordNotFoundException", "ResourceNotFoundError", "DuplicateRecordError",
    "DatabaseConnectionError", "DepartmentAccessDeniedError"
]

# Add these lines at the end of your exceptions.py file, just before the __all__ export

# ===== ADDITIONAL LEGACY COMPATIBILITY ALIASES =====

# Common naming variations that routers might expect
DatabaseException = DatabaseError
ValidationException = ValidationError
AuthenticationException = AuthenticationError
AuthorizationException = AuthorizationError
BusinessLogicException = BusinessLogicError
ExternalServiceException = ExternalServiceError
SecurityException = SecurityError
ComplianceException = ComplianceError
ConfigurationException = ConfigurationError
IntegrationException = IntegrationError

# Resource operation aliases
ResourceError = NotFoundError
ResourceException = NotFoundError
RecordError = NotFoundError
RecordException = NotFoundError

# State and transition aliases
StateError = StateTransitionError
StateException = StateTransitionError
WorkflowError = StateTransitionError
WorkflowException = StateTransitionError

# MFA and security aliases
MFAException = MFAError
SecurityViolationException = SecurityViolationError
RateLimitException = RateLimitError

# Service and integration aliases
ServiceError = ExternalServiceError
ServiceException = ExternalServiceError
APIError = ExternalServiceError
APIException = ExternalServiceError

# Add to the __all__ export list
__all__ = [
    # Base classes
    "BaseAppException", "ErrorSeverity", "ErrorCategory",
    
    # Core exceptions
    "ValidationError", "ValidationException", "SchemaValidationError",
    "NotFoundError", "ResourceNotFoundException", "AlreadyExistsError",
    "AuthenticationError", "AuthorizationError", "AuthorizationException",
    "BusinessLogicError", "BusinessLogicException", "ExternalServiceError",
    "DatabaseError", "SecurityError", "ComplianceError",
    
    # Authentication exceptions
    "InvalidCredentialsError", "AccountLockedError", "TokenExpiredError", 
    "InvalidTokenError", "MFARequiredError", "InvalidMFACodeError", 
    "MFASetupRequiredError", "SecurityViolationError",
    
    # Authorization exceptions
    "InsufficientPermissionsError", "ResourceAccessDeniedError",
    
    # Rate limiting
    "RateLimitError", "RateLimitExceededError",
    
    # Business logic
    "StateTransitionError",
    
    # External services
    "ServiceUnavailableError", "IntegrationError",
    
    # Database
    "ForeignKeyConstraintError",
    
    # System
    "ConfigurationError",
    
    # Compliance
    "DataRetentionError", "PrivacyError",
    
    # HTTP exceptions
    "EnhancedHTTPException", "HTTPBadRequestError", "HTTPUnauthorizedError",
    "HTTPForbiddenError", "HTTPNotFoundError", "HTTPConflictError",
    "HTTPUnprocessableEntityError", "HTTPTooManyRequestsError",
    "HTTPInternalServerError", "HTTPServiceUnavailableError",
    
    # Utilities
    "ExceptionHandler", "ExceptionRegistry",
    
    # Legacy aliases (original)
    "PermissionDeniedError", "AccountInactiveError", "RecordNotFoundError",
    "RecordNotFoundException", "ResourceNotFoundError", "DuplicateRecordError",
    "DatabaseConnectionError", "DepartmentAccessDeniedError",
    
    # New legacy aliases for router compatibility
    "DatabaseException", "AuthenticationException", "BusinessLogicException",
    "ExternalServiceException", "SecurityException", "ComplianceException",
    "ConfigurationException", "IntegrationException", "ResourceError",
    "ResourceException", "RecordError", "RecordException", "StateError",
    "StateException", "WorkflowError", "WorkflowException", "MFAException",
    "SecurityViolationException", "RateLimitException", "ServiceError",
    "ServiceException", "APIError", "APIException"
]