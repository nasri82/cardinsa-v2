"""
Organizational access dependencies for department and unit-based access control.
This builds upon the basic authentication dependencies to provide organizational-level access control.
"""

import uuid
import logging
from typing import Optional, Annotated, List, Callable

from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.core.dependencies import CurrentActiveUser
from app.core.exceptions import (
    HTTPForbiddenError,
    DepartmentAccessDeniedError,
    ResourceAccessDeniedError,
    InsufficientPermissionsError
)
from app.services.rbac_service import RBACService
from app.models.auth.user import User

logger = logging.getLogger(__name__)


class OrganizationalAccessDependency:
    """Dependency class for organizational access control."""
    
    @staticmethod
    def get_rbac_service(db: Annotated[Session, Depends(get_db)]) -> RBACService:
        """
        Get RBAC service instance.
        
        Args:
            db: Database session
            
        Returns:
            RBACService instance
        """
        return RBACService(db)
    
    @staticmethod
    def verify_department_access(
        department_id: uuid.UUID,
        permission_code: Optional[str] = None
    ) -> Callable:
        """
        Create a dependency to verify department access.
        
        Args:
            department_id: Department ID to verify access to
            permission_code: Optional specific permission to check
            
        Returns:
            Dependency function that verifies department access
        """
        def _verify_department_access(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has access to the specified department."""
            try:
                rbac_service.require_department_access(
                    current_user.id, 
                    department_id, 
                    permission_code
                )
                logger.debug(f"User {current_user.username} granted access to department {department_id}")
                return current_user
            except DepartmentAccessDeniedError as e:
                logger.warning(f"Department access denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_department_access
    
    @staticmethod
    def verify_unit_access(
        unit_id: uuid.UUID,
        permission_code: Optional[str] = None
    ) -> Callable:
        """
        Create a dependency to verify unit access.
        
        Args:
            unit_id: Unit ID to verify access to
            permission_code: Optional specific permission to check
            
        Returns:
            Dependency function that verifies unit access
        """
        def _verify_unit_access(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has access to the specified unit."""
            try:
                rbac_service.require_unit_access(
                    current_user.id, 
                    unit_id, 
                    permission_code
                )
                logger.debug(f"User {current_user.username} granted access to unit {unit_id}")
                return current_user
            except ResourceAccessDeniedError as e:
                logger.warning(f"Unit access denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_unit_access
    
    @staticmethod
    def verify_resource_access(
        resource_type: str,
        action: str = "read",
        owner_id: Optional[uuid.UUID] = None,
        department_id: Optional[uuid.UUID] = None,
        unit_id: Optional[uuid.UUID] = None
    ) -> Callable:
        """
        Create a dependency to verify resource access.
        
        Args:
            resource_type: Type of resource
            action: Action to perform on resource
            owner_id: Optional resource owner ID
            department_id: Optional resource department ID
            unit_id: Optional resource unit ID
            
        Returns:
            Dependency function that verifies resource access
        """
        def _verify_resource_access(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has access to the specified resource."""
            try:
                rbac_service.require_resource_access(
                    current_user.id,
                    resource_type,
                    action,
                    owner_id=owner_id,
                    department_id=department_id,
                    unit_id=unit_id
                )
                logger.debug(f"User {current_user.username} granted {action} access to {resource_type}")
                return current_user
            except ResourceAccessDeniedError as e:
                logger.warning(f"Resource access denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_resource_access
    
    @staticmethod
    def verify_permission(permission_code: str) -> Callable:
        """
        Create a dependency to verify a specific permission.
        
        Args:
            permission_code: Required permission code
            
        Returns:
            Dependency function that verifies permission
        """
        def _verify_permission(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has the specified permission."""
            try:
                rbac_service.require_permission(current_user.id, permission_code)
                logger.debug(f"User {current_user.username} has permission {permission_code}")
                return current_user
            except InsufficientPermissionsError as e:
                logger.warning(f"Permission denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_permission
    
    @staticmethod
    def verify_any_permission(permission_codes: List[str]) -> Callable:
        """
        Create a dependency to verify any of the specified permissions.
        
        Args:
            permission_codes: List of permission codes (user needs any one)
            
        Returns:
            Dependency function that verifies any permission
        """
        def _verify_any_permission(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has any of the specified permissions."""
            try:
                if rbac_service.user_has_any_permission(current_user.id, permission_codes):
                    logger.debug(f"User {current_user.username} has one of permissions: {permission_codes}")
                    return current_user
                else:
                    raise InsufficientPermissionsError(f"One of: {', '.join(permission_codes)}")
            except InsufficientPermissionsError as e:
                logger.warning(f"Permission denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_any_permission
    
    @staticmethod
    def verify_all_permissions(permission_codes: List[str]) -> Callable:
        """
        Create a dependency to verify all of the specified permissions.
        
        Args:
            permission_codes: List of permission codes (user needs all)
            
        Returns:
            Dependency function that verifies all permissions
        """
        def _verify_all_permissions(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has all of the specified permissions."""
            try:
                if rbac_service.user_has_all_permissions(current_user.id, permission_codes):
                    logger.debug(f"User {current_user.username} has all permissions: {permission_codes}")
                    return current_user
                else:
                    raise InsufficientPermissionsError(f"All of: {', '.join(permission_codes)}")
            except InsufficientPermissionsError as e:
                logger.warning(f"Permission denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_all_permissions
    
    @staticmethod
    def verify_role(role_code: str) -> Callable:
        """
        Create a dependency to verify a specific role.
        
        Args:
            role_code: Required role code
            
        Returns:
            Dependency function that verifies role
        """
        def _verify_role(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has the specified role."""
            try:
                rbac_service.require_role(current_user.id, role_code)
                logger.debug(f"User {current_user.username} has role {role_code}")
                return current_user
            except InsufficientPermissionsError as e:
                logger.warning(f"Role denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_role
    
    @staticmethod
    def verify_any_role(role_codes: List[str]) -> Callable:
        """
        Create a dependency to verify any of the specified roles.
        
        Args:
            role_codes: List of role codes (user needs any one)
            
        Returns:
            Dependency function that verifies any role
        """
        def _verify_any_role(
            current_user: CurrentActiveUser,
            rbac_service: Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]
        ) -> User:
            """Verify user has any of the specified roles."""
            try:
                if rbac_service.user_has_any_role(current_user.id, role_codes):
                    logger.debug(f"User {current_user.username} has one of roles: {role_codes}")
                    return current_user
                else:
                    raise InsufficientPermissionsError(f"One of roles: {', '.join(role_codes)}")
            except InsufficientPermissionsError as e:
                logger.warning(f"Role denied for user {current_user.username}: {e}")
                raise HTTPForbiddenError(str(e))
        
        return _verify_any_role


# Convenient dependency factories

def require_permission(permission_code: str):
    """
    Convenience function to create a permission requirement dependency.
    
    Usage:
        @app.get("/users")
        def get_users(user: Annotated[User, Depends(require_permission("users.read"))]):
            ...
    """
    return OrganizationalAccessDependency.verify_permission(permission_code)


def require_any_permission(*permission_codes: str):
    """
    Convenience function to create an "any permission" requirement dependency.
    
    Usage:
        @app.get("/data")
        def get_data(user: Annotated[User, Depends(require_any_permission("data.read", "data.admin"))]):
            ...
    """
    return OrganizationalAccessDependency.verify_any_permission(list(permission_codes))


def require_all_permissions(*permission_codes: str):
    """
    Convenience function to create an "all permissions" requirement dependency.
    
    Usage:
        @app.post("/sensitive-action")
        def sensitive_action(user: Annotated[User, Depends(require_all_permissions("sensitive.write", "audit.create"))]):
            ...
    """
    return OrganizationalAccessDependency.verify_all_permissions(list(permission_codes))


def require_role(role_code: str):
    """
    Convenience function to create a role requirement dependency.
    
    Usage:
        @app.get("/admin")
        def admin_panel(user: Annotated[User, Depends(require_role("admin"))]):
            ...
    """
    return OrganizationalAccessDependency.verify_role(role_code)


def require_any_role(*role_codes: str):
    """
    Convenience function to create an "any role" requirement dependency.
    
    Usage:
        @app.get("/management")
        def management_panel(user: Annotated[User, Depends(require_any_role("manager", "supervisor"))]):
            ...
    """
    return OrganizationalAccessDependency.verify_any_role(list(role_codes))


def require_department_access(department_id: uuid.UUID, permission_code: Optional[str] = None):
    """
    Convenience function to create a department access requirement dependency.
    
    Usage:
        @app.get("/department/{dept_id}/data")
        def get_dept_data(
            dept_id: uuid.UUID,
            user: Annotated[User, Depends(require_department_access(dept_id, "data.read"))]
        ):
            ...
    """
    return OrganizationalAccessDependency.verify_department_access(department_id, permission_code)


def require_unit_access(unit_id: uuid.UUID, permission_code: Optional[str] = None):
    """
    Convenience function to create a unit access requirement dependency.
    
    Usage:
        @app.get("/unit/{unit_id}/reports")
        def get_unit_reports(
            unit_id: uuid.UUID,
            user: Annotated[User, Depends(require_unit_access(unit_id, "reports.read"))]
        ):
            ...
    """
    return OrganizationalAccessDependency.verify_unit_access(unit_id, permission_code)


def require_resource_access(
    resource_type: str,
    action: str = "read",
    owner_id: Optional[uuid.UUID] = None,
    department_id: Optional[uuid.UUID] = None,
    unit_id: Optional[uuid.UUID] = None
):
    """
    Convenience function to create a resource access requirement dependency.
    
    Usage:
        @app.get("/policies/{policy_id}")
        def get_policy(
            policy_id: uuid.UUID,
            user: Annotated[User, Depends(require_resource_access("policy", "read"))]
        ):
            ...
    """
    return OrganizationalAccessDependency.verify_resource_access(
        resource_type, action, owner_id, department_id, unit_id
    )


# Typed dependency aliases for common access patterns
RBACServiceDep = Annotated[RBACService, Depends(OrganizationalAccessDependency.get_rbac_service)]

# Department Manager Dependencies
def require_department_manager(department_id: Optional[uuid.UUID] = None):
    """Require user to be a department manager."""
    def _require_department_manager(
        current_user: CurrentActiveUser,
        rbac_service: RBACServiceDep
    ) -> User:
        if current_user.is_superuser:
            return current_user
        
        # Check if user is manager of specified department or their own department
        target_dept_id = department_id or current_user.department_id
        
        if not target_dept_id:
            raise HTTPForbiddenError("Department manager access required")
        
        # Check if user is department manager or has department management permission
        if (current_user.department_id == target_dept_id and 
            rbac_service.user_has_permission(current_user.id, "department.manage")):
            return current_user
        
        raise HTTPForbiddenError("Department manager access required")
    
    return _require_department_manager


def require_unit_manager(unit_id: Optional[uuid.UUID] = None):
    """Require user to be a unit manager."""
    def _require_unit_manager(
        current_user: CurrentActiveUser,
        rbac_service: RBACServiceDep
    ) -> User:
        if current_user.is_superuser:
            return current_user
        
        # Check if user is manager of specified unit or their own unit
        target_unit_id = unit_id or current_user.unit_id
        
        if not target_unit_id:
            raise HTTPForbiddenError("Unit manager access required")
        
        # Check if user is unit manager or has unit management permission
        if (current_user.unit_id == target_unit_id and 
            rbac_service.user_has_permission(current_user.id, "unit.manage")):
            return current_user
        
        raise HTTPForbiddenError("Unit manager access required")
    
    return _require_unit_manager