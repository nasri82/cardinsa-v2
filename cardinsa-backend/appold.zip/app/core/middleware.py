"""
Custom Middleware Components
CARDINSA Insurance Platform

This module contains custom middleware for:
- Request/Response logging
- Rate limiting
- Security headers
- Request timing
- Error handling
"""

import time
import logging
from typing import Callable, Dict, Any, Optional
from uuid import uuid4
from collections import defaultdict, deque
from datetime import datetime, timedelta

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from ..config.settings import get_settings
from .exceptions import RateLimitException

# Initialize settings and logger
settings = get_settings()
logger = logging.getLogger(__name__)


class LoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware for logging HTTP requests and responses.
    
    Features:
    - Request/response logging with timing
    - Unique request ID generation
    - User context tracking
    - Error logging
    - Performance monitoring
    """
    
    def __init__(self, app: ASGIApp):
        """Initialize logging middleware."""
        super().__init__(app)
        self.logger = logging.getLogger("app.middleware.logging")
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Process request and response with logging.
        
        Args:
            request: HTTP request
            call_next: Next middleware/route handler
            
        Returns:
            Response: HTTP response
        """
        # Generate unique request ID
        request_id = str(uuid4())
        start_time = time.time()
        
        # Add request ID to request state
        request.state.request_id = request_id
        
        # Log request start
        self.logger.info(
            f"Request started: {request.method} {request.url}",
            extra={
                "request_id": request_id,
                "method": request.method,
                "url": str(request.url),
                "client_ip": self._get_client_ip(request),
                "user_agent": request.headers.get("user-agent", ""),
                "timestamp": datetime.utcnow().isoformat(),
            }
        )
        
        try:
            # Process request
            response = await call_next(request)
            
            # Calculate response time
            process_time = time.time() - start_time
            
            # Add timing header
            response.headers["X-Process-Time"] = str(process_time)
            response.headers["X-Request-ID"] = request_id
            
            # Log successful response
            self.logger.info(
                f"Request completed: {request.method} {request.url} - {response.status_code}",
                extra={
                    "request_id": request_id,
                    "method": request.method,
                    "url": str(request.url),
                    "status_code": response.status_code,
                    "response_time": process_time,
                    "client_ip": self._get_client_ip(request),
                    "timestamp": datetime.utcnow().isoformat(),
                }
            )
            
            return response
            
        except Exception as e:
            # Calculate response time for errors
            process_time = time.time() - start_time
            
            # Log error
            self.logger.error(
                f"Request failed: {request.method} {request.url} - {str(e)}",
                extra={
                    "request_id": request_id,
                    "method": request.method,
                    "url": str(request.url),
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "response_time": process_time,
                    "client_ip": self._get_client_ip(request),
                    "timestamp": datetime.utcnow().isoformat(),
                },
                exc_info=True
            )
            
            # Re-raise the exception
            raise
    
    def _get_client_ip(self, request: Request) -> str:
        """
        Extract client IP address from request.
        
        Args:
            request: HTTP request
            
        Returns:
            str: Client IP address
        """
        # Check for forwarded headers (when behind proxy/load balancer)
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        # Fall back to direct connection IP
        if request.client:
            return request.client.host
        
        return "unknown"


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Middleware for rate limiting HTTP requests.
    
    Features:
    - Per-IP rate limiting
    - Per-user rate limiting (when authenticated)
    - Configurable time windows
    - Different limits for different endpoints
    - Graceful degradation
    """
    
    def __init__(self, app: ASGIApp):
        """Initialize rate limit middleware."""
        super().__init__(app)
        self.logger = logging.getLogger("app.middleware.ratelimit")
        
        # In-memory storage for rate limit counters
        # In production, use Redis or similar distributed cache
        self.request_counts: Dict[str, deque] = defaultdict(deque)
        
        # Rate limit settings
        self.requests_per_minute = settings.RATE_LIMIT_REQUESTS_PER_MINUTE
        self.requests_per_hour = settings.RATE_LIMIT_REQUESTS_PER_HOUR
        
        # Cleanup old entries periodically
        self.last_cleanup = datetime.utcnow()
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Process request with rate limiting.
        
        Args:
            request: HTTP request
            call_next: Next middleware/route handler
            
        Returns:
            Response: HTTP response or rate limit error
        """
        # Skip rate limiting for health checks and certain endpoints
        if self._should_skip_rate_limiting(request):
            return await call_next(request)
        
        # Get client identifier
        client_id = self._get_client_identifier(request)
        
        # Check rate limits
        if await self._is_rate_limited(client_id, request):
            # Return rate limit exceeded response
            return await self._create_rate_limit_response(client_id)
        
        # Record the request
        await self._record_request(client_id)
        
        # Proceed with request
        return await call_next(request)
    
    def _should_skip_rate_limiting(self, request: Request) -> bool:
        """
        Check if rate limiting should be skipped for this request.
        
        Args:
            request: HTTP request
            
        Returns:
            bool: True if rate limiting should be skipped
        """
        skip_paths = ["/health", "/docs", "/openapi.json", "/redoc"]
        return any(request.url.path.startswith(path) for path in skip_paths)
    
    def _get_client_identifier(self, request: Request) -> str:
        """
        Get unique identifier for the client.
        
        Args:
            request: HTTP request
            
        Returns:
            str: Client identifier
        """
        # Use user ID if authenticated
        user_id = getattr(request.state, 'user_id', None)
        if user_id:
            return f"user:{user_id}"
        
        # Fall back to IP address
        client_ip = request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
        if not client_ip:
            client_ip = request.headers.get("X-Real-IP", "")
        if not client_ip and request.client:
            client_ip = request.client.host
        
        return f"ip:{client_ip or 'unknown'}"
    
    async def _is_rate_limited(self, client_id: str, request: Request) -> bool:
        """
        Check if client is rate limited.
        
        Args:
            client_id: Client identifier
            request: HTTP request
            
        Returns:
            bool: True if client is rate limited
        """
        now = datetime.utcnow()
        
        # Clean up old entries if needed
        if (now - self.last_cleanup).seconds > 300:  # Every 5 minutes
            await self._cleanup_old_entries()
            self.last_cleanup = now
        
        # Get request history for client
        requests = self.request_counts[client_id]
        
        # Remove requests older than 1 hour
        hour_ago = now - timedelta(hours=1)
        while requests and requests[0] < hour_ago:
            requests.popleft()
        
        # Check hourly limit
        if len(requests) >= self.requests_per_hour:
            self.logger.warning(
                f"Hourly rate limit exceeded for {client_id}",
                extra={
                    "client_id": client_id,
                    "requests_count": len(requests),
                    "limit": self.requests_per_hour,
                    "window": "hour"
                }
            )
            return True
        
        # Check minute limit
        minute_ago = now - timedelta(minutes=1)
        recent_requests = sum(1 for req_time in requests if req_time > minute_ago)
        
        if recent_requests >= self.requests_per_minute:
            self.logger.warning(
                f"Minute rate limit exceeded for {client_id}",
                extra={
                    "client_id": client_id,
                    "requests_count": recent_requests,
                    "limit": self.requests_per_minute,
                    "window": "minute"
                }
            )
            return True
        
        return False
    
    async def _record_request(self, client_id: str) -> None:
        """
        Record a request for the client.
        
        Args:
            client_id: Client identifier
        """
        now = datetime.utcnow()
        self.request_counts[client_id].append(now)
    
    async def _create_rate_limit_response(self, client_id: str) -> JSONResponse:
        """
        Create rate limit exceeded response.
        
        Args:
            client_id: Client identifier
            
        Returns:
            JSONResponse: Rate limit error response
        """
        return JSONResponse(
            status_code=429,
            content={
                "error": "Rate Limit Exceeded",
                "message": "Too many requests. Please slow down and try again later.",
                "error_code": "RATE_LIMIT_EXCEEDED",
                "details": {
                    "requests_per_minute": self.requests_per_minute,
                    "requests_per_hour": self.requests_per_hour,
                },
                "timestamp": datetime.utcnow().isoformat(),
            },
            headers={
                "Retry-After": "60",
                "X-RateLimit-Limit": str(self.requests_per_minute),
                "X-RateLimit-Window": "60",
            }
        )
    
    async def _cleanup_old_entries(self) -> None:
        """Clean up old rate limit entries to prevent memory leaks."""
        cutoff_time = datetime.utcnow() - timedelta(hours=2)
        
        for client_id in list(self.request_counts.keys()):
            requests = self.request_counts[client_id]
            
            # Remove old requests
            while requests and requests[0] < cutoff_time:
                requests.popleft()
            
            # Remove empty entries
            if not requests:
                del self.request_counts[client_id]


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Middleware for adding security headers to responses.
    
    Features:
    - Standard security headers
    - Content Security Policy
    - CORS headers (complementary to FastAPI CORS middleware)
    - Security-focused headers
    """
    
    def __init__(self, app: ASGIApp):
        """Initialize security headers middleware."""
        super().__init__(app)
        self.logger = logging.getLogger("app.middleware.security")
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """
        Add security headers to response.
        
        Args:
            request: HTTP request
            call_next: Next middleware/route handler
            
        Returns:
            Response: Response with security headers
        """
        response = await call_next(request)
        
        # Add security headers
        security_headers = self._get_security_headers(request)
        
        for header, value in security_headers.items():
            response.headers[header] = value
        
        return response
    
    def _get_security_headers(self, request: Request) -> Dict[str, str]:
        """
        Get security headers to add to response.
        
        Args:
            request: HTTP request
            
        Returns:
            Dict[str, str]: Security headers
        """
        headers = {
            # Prevent clickjacking
            "X-Frame-Options": "DENY",
            
            # Prevent MIME type sniffing
            "X-Content-Type-Options": "nosniff",
            
            # Enable XSS protection
            "X-XSS-Protection": "1; mode=block",
            
            # Referrer policy
            "Referrer-Policy": "strict-origin-when-cross-origin",
            
            # Permissions policy
            "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
        }
        
        # Add HSTS for HTTPS requests
        if request.url.scheme == "https":
            headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        
        # Content Security Policy for HTML responses
        if request.url.path in ["/docs", "/redoc"] or request.url.path.endswith(".html"):
            headers["Content-Security-Policy"] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' 'unsafe-eval' cdn.jsdelivr.net; "
                "style-src 'self' 'unsafe-inline' cdn.jsdelivr.net; "
                "img-src 'self' data: cdn.jsdelivr.net; "
                "font-src 'self' cdn.jsdelivr.net"
            )
        
        return headers


# Middleware factory functions
def create_logging_middleware() -> LoggingMiddleware:
    """Create and configure logging middleware."""
    return LoggingMiddleware


def create_rate_limit_middleware() -> RateLimitMiddleware:
    """Create and configure rate limit middleware."""
    return RateLimitMiddleware


def create_security_headers_middleware() -> SecurityHeadersMiddleware:
    """Create and configure security headers middleware."""
    return SecurityHeadersMiddleware


# Export middleware classes and factory functions
__all__ = [
    "LoggingMiddleware",
    "RateLimitMiddleware", 
    "SecurityHeadersMiddleware",
    "create_logging_middleware",
    "create_rate_limit_middleware",
    "create_security_headers_middleware",
]