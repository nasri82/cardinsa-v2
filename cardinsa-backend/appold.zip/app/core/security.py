# FILE PATH: app/core/security.py
"""
Enhanced Security Utilities
CARDINSA Insurance Platform

Enterprise-grade security utilities with advanced features integrating
with MFA, Session, and Audit services for world-class security.
"""

import hashlib
import secrets
import hmac
import base64
import json
import re
import os
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple, Union
from functools import lru_cache
from dataclasses import dataclass
from enum import Enum

import pyotp
from passlib.context import CryptContext
from passlib.hash import bcrypt
import jwt
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend
import argon2

from .config import get_settings

settings = get_settings()


# ===== ENHANCED PASSWORD CONTEXT =====

class PasswordSecurity:
    """Enhanced password security with multiple algorithms and advanced policies."""
    
    # Multi-algorithm password context with secure defaults
    _pwd_context = CryptContext(
        schemes=["argon2", "bcrypt", "pbkdf2_sha256"],
        default="argon2",
        argon2__memory_cost=65536,  # 64MB
        argon2__time_cost=3,
        argon2__parallelism=2,
        bcrypt__rounds=14,  # Increased rounds
        pbkdf2_sha256__rounds=200000,  # Increased rounds
        deprecated="auto"
    )
    
    # Password strength requirements
    class Requirements:
        MIN_LENGTH = 12
        MAX_LENGTH = 128
        REQUIRE_UPPERCASE = True
        REQUIRE_LOWERCASE = True
        REQUIRE_DIGITS = True
        REQUIRE_SPECIAL = True
        MIN_UNIQUE_CHARS = 8
        MAX_REPEATED_CHARS = 2
        HISTORY_COUNT = 12
        EXPIRE_DAYS = 90
    
    @classmethod
    def hash_password(cls, password: str) -> str:
        """Enhanced password hashing with timing protection."""
        if not password:
            raise ValueError("Password cannot be empty")
        
        # Add artificial delay to prevent timing attacks
        time.sleep(0.1)
        
        return cls._pwd_context.hash(password)
    
    @classmethod
    def verify_password(cls, plain_password: str, hashed_password: str) -> bool:
        """Enhanced password verification with comprehensive protection."""
        if not plain_password or not hashed_password:
            return False
        
        try:
            # Add artificial delay for failed attempts
            result = cls._pwd_context.verify(plain_password, hashed_password)
            if not result:
                time.sleep(0.2)  # Longer delay for failed attempts
            return result
        except Exception:
            time.sleep(0.2)  # Consistent timing on errors
            return False
    
    @classmethod
    def validate_password_strength(cls, password: str, user_context: Optional[Dict] = None) -> Dict[str, Any]:
        """Comprehensive password strength validation with contextual analysis."""
        if not password:
            return {
                "valid": False,
                "score": 0,
                "strength": "invalid",
                "errors": ["Password is required"]
            }
        
        score = 0
        errors = []
        warnings = []
        requirements_met = {}
        
        # Basic requirements
        length_valid = cls.Requirements.MIN_LENGTH <= len(password) <= cls.Requirements.MAX_LENGTH
        requirements_met["length"] = length_valid
        if not length_valid:
            errors.append(f"Password must be {cls.Requirements.MIN_LENGTH}-{cls.Requirements.MAX_LENGTH} characters")
        else:
            score += 2
        
        # Character type requirements
        has_upper = bool(re.search(r'[A-Z]', password))
        has_lower = bool(re.search(r'[a-z]', password))
        has_digit = bool(re.search(r'[0-9]', password))
        has_special = bool(re.search(r'[!@#$%^&*(),.?":{}|<>_+=\-\[\]\\;\'\/~`]', password))
        
        requirements_met.update({
            "uppercase": has_upper,
            "lowercase": has_lower,
            "digits": has_digit,
            "special": has_special
        })
        
        if cls.Requirements.REQUIRE_UPPERCASE and not has_upper:
            errors.append("Password must contain uppercase letters")
        elif has_upper:
            score += 1
        
        if cls.Requirements.REQUIRE_LOWERCASE and not has_lower:
            errors.append("Password must contain lowercase letters")
        elif has_lower:
            score += 1
        
        if cls.Requirements.REQUIRE_DIGITS and not has_digit:
            errors.append("Password must contain numbers")
        elif has_digit:
            score += 1
        
        if cls.Requirements.REQUIRE_SPECIAL and not has_special:
            errors.append("Password must contain special characters")
        elif has_special:
            score += 1
        
        # Advanced validation
        unique_chars = len(set(password.lower()))
        requirements_met["unique_chars"] = unique_chars >= cls.Requirements.MIN_UNIQUE_CHARS
        if unique_chars < cls.Requirements.MIN_UNIQUE_CHARS:
            errors.append(f"Password must contain at least {cls.Requirements.MIN_UNIQUE_CHARS} unique characters")
        else:
            score += 1
        
        # Pattern analysis
        patterns = cls._analyze_patterns(password)
        if patterns["has_common_patterns"]:
            warnings.append("Avoid common patterns like '123', 'abc', or 'qwerty'")
        else:
            score += 1
        
        if patterns["has_repeated_sequences"]:
            warnings.append("Avoid repeated character sequences")
        else:
            score += 1
        
        # Dictionary and common password check
        if cls._is_common_password(password):
            errors.append("Password is too common")
        else:
            score += 2
        
        # Contextual validation
        if user_context:
            context_issues = cls._check_user_context(password, user_context)
            if context_issues:
                warnings.extend(context_issues)
            else:
                score += 1
        
        # Calculate strength
        max_score = 10
        strength_levels = {
            (0, 2): "very_weak",
            (3, 4): "weak",
            (5, 6): "moderate",
            (7, 8): "strong",
            (9, 10): "very_strong"
        }
        
        strength = "very_weak"
        for (min_score, max_score_range), level in strength_levels.items():
            if min_score <= score <= max_score_range:
                strength = level
                break
        
        # Calculate entropy
        entropy = cls._calculate_entropy(password)
        
        return {
            "valid": len(errors) == 0 and score >= 6,
            "score": score,
            "max_score": max_score,
            "strength": strength,
            "entropy": entropy,
            "requirements_met": requirements_met,
            "errors": errors,
            "warnings": warnings,
            "recommendations": cls._get_recommendations(password, score),
            "estimated_crack_time": cls._estimate_crack_time(entropy)
        }
    
    @classmethod
    def generate_secure_password(cls, length: int = 16, include_symbols: bool = True) -> str:
        """Generate cryptographically secure password."""
        if length < cls.Requirements.MIN_LENGTH:
            length = cls.Requirements.MIN_LENGTH
        
        # Character sets
        uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        lowercase = "abcdefghijklmnopqrstuvwxyz"
        digits = "0123456789"
        symbols = "!@#$%^&*()_+-=[]{}|;:,.<>?" if include_symbols else ""
        
        # Ensure at least one character from each required set
        password = [
            secrets.choice(uppercase),
            secrets.choice(lowercase),
            secrets.choice(digits)
        ]
        
        if include_symbols:
            password.append(secrets.choice(symbols))
        
        # Fill remaining length
        all_chars = uppercase + lowercase + digits + symbols
        for _ in range(length - len(password)):
            password.append(secrets.choice(all_chars))
        
        # Shuffle to avoid predictable patterns
        secrets.SystemRandom().shuffle(password)
        
        return ''.join(password)
    
    @classmethod
    def _analyze_patterns(cls, password: str) -> Dict[str, bool]:
        """Analyze password for common patterns."""
        common_patterns = [
            "123", "abc", "qwe", "asd", "zxc", "password", "admin",
            "012", "987", "654", "321", "qaz", "wsx", "edc"
        ]
        
        has_common = any(pattern in password.lower() for pattern in common_patterns)
        
        # Check for repeated sequences
        has_repeated = False
        for i in range(len(password) - 2):
            if password[i] == password[i + 1] == password[i + 2]:
                has_repeated = True
                break
        
        return {
            "has_common_patterns": has_common,
            "has_repeated_sequences": has_repeated
        }
    
    @classmethod
    def _is_common_password(cls, password: str) -> bool:
        """Check against common password lists."""
        common_passwords = {
            "password", "123456", "password123", "admin", "qwerty",
            "letmein", "welcome", "monkey", "dragon", "123456789",
            "password1", "123123", "1234567890", "abc123", "password!",
            "cardinsa", "insurance", "company", "admin123", "welcome123"
        }
        return password.lower() in common_passwords
    
    @classmethod
    def _check_user_context(cls, password: str, user_context: Dict) -> List[str]:
        """Check password against user context information."""
        issues = []
        password_lower = password.lower()
        
        # Check against user information
        for field in ["username", "email", "first_name", "last_name", "company"]:
            if field in user_context and user_context[field]:
                value = str(user_context[field]).lower()
                if value in password_lower or password_lower in value:
                    issues.append(f"Password should not contain {field}")
        
        # Check against common dates
        current_year = datetime.now().year
        for year in range(current_year - 5, current_year + 2):
            if str(year) in password:
                issues.append("Avoid using recent years")
                break
        
        return issues
    
    @classmethod
    def _calculate_entropy(cls, password: str) -> float:
        """Calculate password entropy in bits."""
        charset_size = 0
        
        if re.search(r'[a-z]', password):
            charset_size += 26
        if re.search(r'[A-Z]', password):
            charset_size += 26
        if re.search(r'[0-9]', password):
            charset_size += 10
        if re.search(r'[^a-zA-Z0-9]', password):
            charset_size += 32  # Approximate special characters
        
        if charset_size == 0:
            return 0
        
        import math
        return len(password) * math.log2(charset_size)
    
    @classmethod
    def _estimate_crack_time(cls, entropy: float) -> str:
        """Estimate time to crack password based on entropy."""
        if entropy < 30:
            return "Instantly"
        elif entropy < 40:
            return "Minutes"
        elif entropy < 50:
            return "Hours"
        elif entropy < 60:
            return "Days"
        elif entropy < 70:
            return "Years"
        else:
            return "Centuries"
    
    @classmethod
    def _get_recommendations(cls, password: str, score: int) -> List[str]:
        """Get password improvement recommendations."""
        recommendations = []
        
        if score < 6:
            recommendations.append("Use a longer password with mixed character types")
        if len(password) < 16:
            recommendations.append("Consider using a passphrase or longer password")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            recommendations.append("Add special characters for extra security")
        
        recommendations.append("Consider using a password manager")
        recommendations.append("Enable two-factor authentication")
        
        return recommendations


# ===== ENHANCED TOKEN MANAGER =====

class TokenManager:
    """Enhanced JWT token management with advanced security features."""
    
    def __init__(self):
        self.secret_key = settings.JWT_SECRET_KEY
        self.algorithm = settings.JWT_ALGORITHM
        self.issuer = settings.JWT_ISSUER
        self.audience = settings.JWT_AUDIENCE
    
    async def create_access_token(
        self,
        user_id: Union[str, int],
        permissions: Optional[List[str]] = None,
        custom_claims: Optional[Dict[str, Any]] = None,
        expires_delta: Optional[timedelta] = None
    ) -> str:
        """Create enhanced access token with comprehensive claims."""
        now = datetime.utcnow()
        expires_delta = expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        
        payload = {
            "sub": str(user_id),
            "iat": now,
            "exp": now + expires_delta,
            "nbf": now,
            "iss": self.issuer,
            "aud": self.audience,
            "jti": secrets.token_urlsafe(16),
            "type": "access_token",
            "permissions": permissions or [],
            "token_version": "2.0",
            **(custom_claims or {})
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    async def create_refresh_token(
        self,
        user_id: Union[str, int],
        device_id: Optional[str] = None,
        custom_claims: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create enhanced refresh token with device binding."""
        now = datetime.utcnow()
        expires_delta = timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
        
        payload = {
            "sub": str(user_id),
            "iat": now,
            "exp": now + expires_delta,
            "nbf": now,
            "iss": self.issuer,
            "aud": self.audience,
            "jti": secrets.token_urlsafe(32),
            "type": "refresh_token",
            "device_id": device_id,
            "token_version": "2.0",
            **(custom_claims or {})
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    async def verify_token(
        self,
        token: str,
        expected_type: str = "access_token",
        verify_permissions: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Enhanced token verification with comprehensive validation."""
        try:
            # Decode and verify signature
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                issuer=self.issuer,
                audience=self.audience,
                options={
                    "verify_signature": True,
                    "verify_exp": True,
                    "verify_nbf": True,
                    "verify_iat": True,
                    "verify_aud": True,
                    "verify_iss": True
                }
            )
            
            # Verify token type
            if payload.get("type") != expected_type:
                raise jwt.InvalidTokenError(f"Expected {expected_type}, got {payload.get('type')}")
            
            # Verify permissions if required
            if verify_permissions:
                token_permissions = set(payload.get("permissions", []))
                required_permissions = set(verify_permissions)
                if not required_permissions.issubset(token_permissions):
                    missing = required_permissions - token_permissions
                    raise jwt.InvalidTokenError(f"Missing permissions: {missing}")
            
            return payload
            
        except jwt.ExpiredSignatureError:
            raise jwt.ExpiredSignatureError("Token has expired")
        except jwt.InvalidTokenError as e:
            raise jwt.InvalidTokenError(f"Token validation failed: {e}")
    
    async def refresh_access_token(
        self,
        refresh_token: str,
        new_permissions: Optional[List[str]] = None
    ) -> Tuple[str, str]:
        """Refresh access token using refresh token with rotation."""
        # Verify refresh token
        payload = await self.verify_token(refresh_token, "refresh_token")
        
        user_id = payload["sub"]
        device_id = payload.get("device_id")
        
        # Create new tokens
        new_access_token = await self.create_access_token(
            user_id=user_id,
            permissions=new_permissions
        )
        
        new_refresh_token = await self.create_refresh_token(
            user_id=user_id,
            device_id=device_id
        )
        
        return new_access_token, new_refresh_token
    
    def decode_token_unsafe(self, token: str) -> Optional[Dict[str, Any]]:
        """Decode token without verification (for inspection only)."""
        try:
            return jwt.decode(token, options={"verify_signature": False})
        except Exception:
            return None


# ===== ENHANCED DATA ENCRYPTION =====

class DataEncryption:
    """Enhanced data encryption with key management and rotation support."""
    
    def __init__(self, key: Optional[bytes] = None, key_id: Optional[str] = None):
        """Initialize with optional key and key ID for rotation support."""
        if key:
            self.key = key
        else:
            self.key = self._get_or_generate_key()
        
        self.key_id = key_id or "default"
        self.fernet = Fernet(self.key)
    
    def _get_or_generate_key(self) -> bytes:
        """Get encryption key from settings or generate new one."""
        if hasattr(settings, 'ENCRYPTION_KEY') and settings.ENCRYPTION_KEY:
            return base64.urlsafe_b64decode(settings.ENCRYPTION_KEY)
        else:
            return Fernet.generate_key()
    
    def encrypt(self, data: Union[str, bytes], associate_data: Optional[bytes] = None) -> str:
        """Encrypt data with optional associated data."""
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        # Add metadata for key rotation
        encrypted = self.fernet.encrypt(data)
        
        # Prepend key ID for rotation support
        versioned_data = f"{self.key_id}:".encode() + encrypted
        
        return base64.urlsafe_b64encode(versioned_data).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """Decrypt data with key version support."""
        try:
            # Decode base64
            versioned_data = base64.urlsafe_b64decode(encrypted_data.encode())
            
            # Extract key ID if present
            if b':' in versioned_data:
                key_id, encrypted_bytes = versioned_data.split(b':', 1)
                # In production, would load appropriate key based on key_id
            else:
                encrypted_bytes = versioned_data
            
            decrypted = self.fernet.decrypt(encrypted_bytes)
            return decrypted.decode('utf-8')
            
        except Exception as e:
            raise ValueError(f"Decryption failed: {e}")
    
    def encrypt_dict(self, data: Dict[str, Any]) -> str:
        """Encrypt dictionary as JSON."""
        json_data = json.dumps(data, separators=(',', ':'))
        return self.encrypt(json_data)
    
    def decrypt_dict(self, encrypted_data: str) -> Dict[str, Any]:
        """Decrypt JSON dictionary."""
        json_data = self.decrypt(encrypted_data)
        return json.loads(json_data)
    
    def rotate_key(self, new_key: bytes, new_key_id: str) -> 'DataEncryption':
        """Create new encryption instance with rotated key."""
        return DataEncryption(key=new_key, key_id=new_key_id)


# ===== ENHANCED DEVICE FINGERPRINTING =====

class DeviceFingerprinting:
    """Advanced device fingerprinting and trust management."""
    
    @staticmethod
    def generate_fingerprint(
        user_agent: str,
        accept_language: str = "",
        screen_resolution: str = "",
        timezone: str = "",
        platform: str = "",
        additional_headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        """Generate comprehensive device fingerprint."""
        components = {
            "user_agent": user_agent,
            "accept_language": accept_language,
            "screen_resolution": screen_resolution,
            "timezone": timezone,
            "platform": platform
        }
        
        if additional_headers:
            components.update(additional_headers)
        
        # Create composite fingerprint
        fingerprint_string = "|".join(f"{k}:{v}" for k, v in sorted(components.items()))
        fingerprint_hash = hashlib.sha256(fingerprint_string.encode()).hexdigest()
        
        return {
            "fingerprint": fingerprint_hash,
            "components": components,
            "algorithm": "sha256",
            "version": "1.0"
        }
    
    @staticmethod
    def calculate_trust_score(
        current_fingerprint: Dict[str, str],
        known_fingerprints: List[Dict[str, str]],
        usage_history: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Calculate device trust score based on history and consistency."""
        trust_score = 0.0
        trust_factors = []
        
        # Check against known fingerprints
        if current_fingerprint["fingerprint"] in [fp["fingerprint"] for fp in known_fingerprints]:
            trust_score += 0.4
            trust_factors.append("known_device")
        
        # Analyze component consistency
        for known_fp in known_fingerprints:
            component_matches = 0
            for component, value in current_fingerprint["components"].items():
                if known_fp["components"].get(component) == value:
                    component_matches += 1
            
            similarity = component_matches / len(current_fingerprint["components"])
            if similarity > 0.8:
                trust_score += 0.2
                trust_factors.append("similar_device")
                break
        
        # Usage history factors
        if usage_history:
            if usage_history.get("successful_logins", 0) > 10:
                trust_score += 0.2
                trust_factors.append("usage_history")
            
            if usage_history.get("last_seen_days", 999) < 7:
                trust_score += 0.1
                trust_factors.append("recent_usage")
        
        # Normalize score
        trust_score = min(1.0, trust_score)
        
        trust_levels = {
            (0.0, 0.2): "untrusted",
            (0.2, 0.5): "low",
            (0.5, 0.7): "medium",
            (0.7, 0.9): "high",
            (0.9, 1.0): "verified"
        }
        
        trust_level = "untrusted"
        for (min_score, max_score), level in trust_levels.items():
            if min_score <= trust_score < max_score:
                trust_level = level
                break
        
        return {
            "trust_score": trust_score,
            "trust_level": trust_level,
            "trust_factors": trust_factors,
            "requires_verification": trust_score < 0.5
        }


# ===== RISK ASSESSMENT ENGINE =====

class RiskAssessment:
    """Advanced security risk assessment engine."""
    
    class RiskFactors:
        IP_CHANGE = 0.3
        DEVICE_CHANGE = 0.4
        LOCATION_CHANGE = 0.5
        TIME_ANOMALY = 0.2
        FAILED_ATTEMPTS = 0.6
        SUSPICIOUS_PATTERN = 0.8
        VPN_DETECTED = 0.3
        BOT_DETECTED = 1.0
    
    @classmethod
    def calculate_login_risk(
        cls,
        user_context: Dict[str, Any],
        request_context: Dict[str, Any],
        historical_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Calculate comprehensive login risk score."""
        risk_score = 0.0
        risk_factors = []
        
        # IP address analysis
        current_ip = request_context.get("ip_address")
        known_ips = historical_data.get("known_ips", []) if historical_data else []
        
        if current_ip not in known_ips:
            risk_score += cls.RiskFactors.IP_CHANGE
            risk_factors.append("new_ip_address")
        
        # Device fingerprint analysis
        current_device = request_context.get("device_fingerprint")
        known_devices = historical_data.get("known_devices", []) if historical_data else []
        
        if current_device not in known_devices:
            risk_score += cls.RiskFactors.DEVICE_CHANGE
            risk_factors.append("new_device")
        
        # Geographic location analysis
        if cls._is_unusual_location(request_context, historical_data):
            risk_score += cls.RiskFactors.LOCATION_CHANGE
            risk_factors.append("unusual_location")
        
        # Temporal analysis
        if cls._is_unusual_time(user_context, historical_data):
            risk_score += cls.RiskFactors.TIME_ANOMALY
            risk_factors.append("unusual_time")
        
        # Failed attempt analysis
        recent_failures = historical_data.get("recent_failed_attempts", 0) if historical_data else 0
        if recent_failures > 3:
            risk_score += cls.RiskFactors.FAILED_ATTEMPTS
            risk_factors.append("recent_failures")
        
        # Bot detection
        if cls._detect_bot_behavior(request_context):
            risk_score += cls.RiskFactors.BOT_DETECTED
            risk_factors.append("bot_detected")
        
        # VPN/Proxy detection
        if cls._detect_vpn_proxy(current_ip):
            risk_score += cls.RiskFactors.VPN_DETECTED
            risk_factors.append("vpn_detected")
        
        # Normalize and categorize
        risk_score = min(1.0, risk_score)
        
        risk_levels = {
            (0.0, 0.2): "low",
            (0.2, 0.5): "medium",
            (0.5, 0.8): "high",
            (0.8, 1.0): "critical"
        }
        
        risk_level = "low"
        for (min_score, max_score), level in risk_levels.items():
            if min_score <= risk_score < max_score:
                risk_level = level
                break
        
        return {
            "risk_score": risk_score,
            "risk_level": risk_level,
            "risk_factors": risk_factors,
            "requires_mfa": risk_score >= 0.3,
            "requires_additional_verification": risk_score >= 0.6,
            "should_block": risk_score >= 0.9,
            "recommended_actions": cls._get_recommended_actions(risk_level, risk_factors)
        }
    
    @classmethod
    def _is_unusual_location(cls, request_context: Dict, historical_data: Optional[Dict]) -> bool:
        """Check if location is unusual for user."""
        if not historical_data:
            return True
        
        current_location = request_context.get("location", {})
        known_locations = historical_data.get("known_locations", [])
        
        current_country = current_location.get("country")
        if not current_country:
            return False
        
        known_countries = {loc.get("country") for loc in known_locations}
        return current_country not in known_countries
    
    @classmethod
    def _is_unusual_time(cls, user_context: Dict, historical_data: Optional[Dict]) -> bool:
        """Check if access time is unusual for user."""
        if not historical_data:
            return False
        
        current_hour = datetime.utcnow().hour
        typical_hours = historical_data.get("typical_login_hours", list(range(8, 18)))
        
        return current_hour not in typical_hours
    
    @classmethod
    def _detect_bot_behavior(cls, request_context: Dict) -> bool:
        """Detect bot-like behavior patterns."""
        user_agent = request_context.get("user_agent", "").lower()
        
        bot_indicators = [
            "bot", "crawler", "spider", "scraper", "curl", "wget",
            "python", "requests", "scrapy", "phantomjs", "headless"
        ]
        
        return any(indicator in user_agent for indicator in bot_indicators)
    
    @classmethod
    def _detect_vpn_proxy(cls, ip_address: str) -> bool:
        """Detect VPN/Proxy usage (simplified implementation)."""
        # In production, use actual VPN/proxy detection service
        vpn_indicators = [
            ip_address.startswith("10."),
            ip_address.startswith("192.168."),
            ip_address.startswith("172.")
        ]
        return any(vpn_indicators)
    
    @classmethod
    def _get_recommended_actions(cls, risk_level: str, risk_factors: List[str]) -> List[str]:
        """Get recommended security actions based on risk assessment."""
        actions = []
        
        if risk_level == "critical":
            actions.extend([
                "Block login attempt",
                "Require admin approval",
                "Send security alert"
            ])
        elif risk_level == "high":
            actions.extend([
                "Require MFA verification",
                "Send security notification",
                "Review account activity"
            ])
        elif risk_level == "medium":
            actions.extend([
                "Consider MFA requirement",
                "Monitor session closely"
            ])