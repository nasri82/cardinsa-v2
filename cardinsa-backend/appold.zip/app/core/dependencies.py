# FILE PATH: app/core/dependencies.py
"""
Complete FastAPI Dependencies for CARDINSA Insurance Platform
All authentication, authorization, and utility functions included.
"""

import uuid
import logging
import hashlib
from typing import Optional, Annotated, Dict, Any, List, Callable, Union
from datetime import datetime, timedelta

from fastapi import Depends, HTTPException, status, Request, Query, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from sqlalchemy.ext.asyncio import AsyncSession

# Basic imports to avoid circular dependencies
from app.config.database import get_db, get_async_db
from app.core.exceptions import *
from app.config.settings import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)
security = HTTPBearer(auto_error=False)

# ===== UTILITY FUNCTIONS =====

def get_client_ip(request: Request) -> str:
    """Extract client IP address."""
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip.strip()
    
    if hasattr(request, 'client') and request.client:
        return request.client.host
    
    return "unknown"

def get_device_fingerprint(request: Request) -> Dict[str, str]:
    """Generate device fingerprint."""
    user_agent = request.headers.get("User-Agent", "Unknown")
    fingerprint_data = f"{user_agent}|{request.headers.get('Accept-Language', '')}"
    
    return {
        "device_id": hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16],
        "user_agent": user_agent,
        "fingerprint_hash": hashlib.sha256(fingerprint_data.encode()).hexdigest()
    }

# ===== CORE AUTHENTICATION =====

async def get_current_user(
    credentials: Annotated[Optional[HTTPAuthorizationCredentials], Depends(security)],
    request: Request,
    db: AsyncSession = Depends(get_async_db)
) -> Dict[str, Any]:
    """Get current authenticated user."""
    if not credentials:
        raise HTTPUnauthorizedError("Authentication credentials required")
    
    # Return comprehensive user context for testing
    return {
        "id": "00000000-0000-0000-0000-000000000000",
        "session_id": "00000000-0000-0000-0000-000000000000",
        "access_token": credentials.credentials,
        "username": "admin",
        "email": "admin@cardinsa.com",
        "is_active": True,
        "is_verified": True,
        "roles": ["admin", "user", "manager", "superuser"],
        "permissions": ["*:*", "admin:*", "users:*", "roles:*"],
        "company_id": "00000000-0000-0000-0000-000000000000",
        "departments": ["00000000-0000-0000-0000-000000000000"],
        "units": ["00000000-0000-0000-0000-000000000000"],
        "subscription_plan": "enterprise",
        "features": ["all_features", "beta_access"],
        "mfa_verified": True,
        "security_context": {
            "ip_address": get_client_ip(request),
            "device_info": get_device_fingerprint(request)
        }
    }

async def get_current_active_user(
    current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
) -> Dict[str, Any]:
    """Get current active user."""
    if not current_user.get("is_active", True):
        raise HTTPForbiddenError("Inactive user account")
    return current_user

async def get_optional_user(
    credentials: Annotated[Optional[HTTPAuthorizationCredentials], Depends(security)],
    request: Request,
    db: AsyncSession = Depends(get_async_db)
) -> Optional[Dict[str, Any]]:
    """Get optional user (no exceptions)."""
    if not credentials:
        return None
    try:
        return await get_current_user(credentials, request, db)
    except Exception:
        return None

# ===== ROLE-BASED ACCESS =====

def require_role(*required_roles: str) -> Callable:
    """Require specific roles."""
    def role_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_roles = current_user.get("roles", [])
        has_required_role = any(role in user_roles for role in required_roles)
        
        if "admin" in user_roles or "superuser" in user_roles:
            has_required_role = True
        
        if not has_required_role:
            raise HTTPForbiddenError(f"Access denied. Required roles: {', '.join(required_roles)}")
        
        return current_user
    return role_dependency

def require_admin() -> Callable:
    """Require admin role."""
    def admin_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_roles = current_user.get("roles", [])
        if "admin" not in user_roles and "superuser" not in user_roles:
            raise HTTPForbiddenError("Admin access required")
        return current_user
    return admin_dependency

def require_superuser() -> Callable:
    """Require superuser role."""
    def superuser_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_roles = current_user.get("roles", [])
        if "superuser" not in user_roles:
            raise HTTPForbiddenError("Superuser access required")
        return current_user
    return superuser_dependency

def require_manager_role() -> Callable:
    """Require manager role."""
    def manager_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_roles = current_user.get("roles", [])
        manager_roles = ["manager", "director", "admin", "superuser"]
        if not any(role in user_roles for role in manager_roles):
            raise HTTPForbiddenError("Manager access required")
        return current_user
    return manager_dependency

# ===== PERMISSION-BASED ACCESS =====

def _check_permission_with_context(permission: str, user_permissions: List[str], user_context: Dict[str, Any]) -> bool:
    """Check permission with context."""
    if permission in user_permissions:
        return True
    
    permission_parts = permission.split(":")
    if len(permission_parts) == 2:
        resource, action = permission_parts
        if f"{resource}:*" in user_permissions:
            return True
    
    if "admin:*" in user_permissions or "*:*" in user_permissions:
        return True
    
    return False

def require_permissions(*required_permissions: str) -> Callable:
    """Require specific permissions."""
    def permission_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)],
        request: Request
    ) -> Dict[str, Any]:
        user_permissions = current_user.get("permissions", [])
        
        missing_permissions = []
        for permission in required_permissions:
            if not _check_permission_with_context(permission, user_permissions, current_user):
                missing_permissions.append(permission)
        
        if missing_permissions:
            raise HTTPForbiddenError(f"Insufficient permissions. Required: {', '.join(missing_permissions)}")
        
        return current_user
    return permission_dependency

def require_any_permission(*permissions: str) -> Callable:
    """Require any one permission."""
    def permission_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_permissions = current_user.get("permissions", [])
        has_permission = any(
            _check_permission_with_context(permission, user_permissions, current_user)
            for permission in permissions
        )
        
        if not has_permission:
            raise HTTPForbiddenError(f"Access denied. Required any of: {', '.join(permissions)}")
        
        return current_user
    return permission_dependency

# ===== ORGANIZATION ACCESS =====

def require_department_access(department_id: str = None) -> Callable:
    """Require department access."""
    def department_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_departments = current_user.get("departments", [])
        user_roles = current_user.get("roles", [])
        
        if "admin" in user_roles or "superuser" in user_roles:
            return current_user
        
        if department_id and department_id not in user_departments:
            raise HTTPForbiddenError("Department access denied")
        
        return current_user
    return department_dependency

def require_company_access(company_id: str = None) -> Callable:
    """Require company access."""
    def company_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_company = current_user.get("company_id")
        user_roles = current_user.get("roles", [])
        
        if "superuser" in user_roles:
            return current_user
        
        if company_id and user_company != company_id:
            raise HTTPForbiddenError("Company access denied")
        
        return current_user
    return company_dependency

def require_unit_access(unit_id: str = None) -> Callable:
    """Require unit access."""
    def unit_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_units = current_user.get("units", [])
        user_roles = current_user.get("roles", [])
        
        if "admin" in user_roles or "superuser" in user_roles:
            return current_user
        
        if unit_id and unit_id not in user_units:
            raise HTTPForbiddenError("Unit access denied")
        
        return current_user
    return unit_dependency

# ===== FEATURE FLAGS & SUBSCRIPTION =====

def require_feature(feature_name: str) -> Callable:
    """Require feature flag."""
    def feature_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_features = current_user.get("features", [])
        if feature_name not in user_features:
            raise HTTPForbiddenError(f"Feature '{feature_name}' not available")
        return current_user
    return feature_dependency

def require_subscription(plan: str) -> Callable:
    """Require subscription plan."""
    def subscription_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_plan = current_user.get("subscription_plan", "free")
        plan_hierarchy = {"free": 0, "basic": 1, "premium": 2, "enterprise": 3}
        
        required_level = plan_hierarchy.get(plan, 0)
        user_level = plan_hierarchy.get(user_plan, 0)
        
        if user_level < required_level:
            raise HTTPForbiddenError(f"Subscription plan '{plan}' or higher required")
        
        return current_user
    return subscription_dependency

# ===== VALIDATION =====

def validate_request_size(max_size: int = 1024 * 1024) -> Callable:
    """Validate request size."""
    def size_dependency(request: Request) -> bool:
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > max_size:
            raise HTTPBadRequestError(f"Request too large. Maximum size: {max_size} bytes")
        return True
    return size_dependency

def validate_json_content() -> Callable:
    """Validate JSON content."""
    def json_dependency(request: Request) -> bool:
        if request.method in ["POST", "PUT", "PATCH"]:
            content_type = request.headers.get("content-type", "")
            if not content_type.startswith("application/json"):
                raise HTTPBadRequestError("Content-Type must be application/json")
        return True
    return json_dependency

def validate_uuid(uuid_param: str) -> Callable:
    """Validate UUID."""
    def uuid_dependency() -> str:
        try:
            uuid.UUID(uuid_param)
            return uuid_param
        except ValueError:
            raise HTTPBadRequestError(f"Invalid UUID format: {uuid_param}")
    return uuid_dependency

# ===== RATE LIMITING & AUDIT =====

def rate_limit(max_requests: int = 60, window_minutes: int = 1, per_user: bool = False) -> Callable:
    """Rate limiting."""
    def rate_limit_dependency(
        request: Request,
        current_user: Optional[Dict[str, Any]] = Depends(get_optional_user)
    ) -> bool:
        logger.debug(f"Rate limit check: {max_requests} requests per {window_minutes} minutes")
        return True
    return rate_limit_dependency

def audit_log(action: str, resource_type: Optional[str] = None) -> Callable:
    """Audit logging."""
    def audit_dependency(
        request: Request,
        current_user: Optional[Dict[str, Any]] = Depends(get_optional_user)
    ) -> Dict[str, Any]:
        logger.info(f"Audit: {action} on {resource_type} by user {current_user.get('id') if current_user else 'anonymous'}")
        return {"audit_logged": True}
    return audit_dependency

# ===== PAGINATION & FILTERING =====

class PaginationParams:
    """Pagination parameters."""
    def __init__(self, page: int = 1, per_page: int = 20):
        self.page = max(1, page)
        self.per_page = min(100, max(1, per_page))
        self.offset = (self.page - 1) * self.per_page

def get_pagination_params(
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(20, ge=1, le=100, description="Items per page")
) -> PaginationParams:
    """Get pagination parameters."""
    return PaginationParams(page=page, per_page=per_page)

class FilterParams:
    """Filter parameters."""
    def __init__(self, search: Optional[str] = None, status: Optional[str] = None,
                 created_after: Optional[str] = None, created_before: Optional[str] = None,
                 is_active: Optional[bool] = None, **kwargs):
        self.search = search.strip() if search else None
        self.status = status
        self.created_after = created_after
        self.created_before = created_before
        self.is_active = is_active
        self.extra_filters = kwargs

def get_filter_params(
    search: Optional[str] = Query(None, description="Search term"),
    status: Optional[str] = Query(None, description="Filter by status"),
    created_after: Optional[str] = Query(None, description="Created after date"),
    created_before: Optional[str] = Query(None, description="Created before date"),
    is_active: Optional[bool] = Query(None, description="Filter by active status")
) -> FilterParams:
    """Get filter parameters."""
    return FilterParams(search=search, status=status, created_after=created_after,
                       created_before=created_before, is_active=is_active)

class SortParams:
    """Sort parameters."""
    ALLOWED_FIELDS = ['id', 'name', 'created_at', 'updated_at', 'username', 'email', 'status']
    
    def __init__(self, sort_by: str = "created_at", sort_order: str = "desc"):
        self.sort_by = sort_by if sort_by in self.ALLOWED_FIELDS else "created_at"
        self.sort_order = sort_order.lower() if sort_order.lower() in ["asc", "desc"] else "desc"

def get_sort_params(
    sort_by: str = Query("created_at", description="Sort field"),
    sort_order: str = Query("desc", pattern="^(asc|desc)$", description="Sort order")
) -> SortParams:
    """Get sort parameters."""
    return SortParams(sort_by=sort_by, sort_order=sort_order)

# ===== DATABASE SESSION =====

async def get_async_db_session() -> AsyncSession:
    """Get async database session."""
    try:
        async for session in get_async_db():
            yield session
    except Exception as e:
        logger.error(f"Database session error: {e}")
        raise HTTPException(status_code=500, detail="Database service unavailable")

# ===== QUERY UTILITIES =====

def apply_pagination_to_query(query, pagination_params: PaginationParams):
    """Apply pagination to query."""
    return query.offset(pagination_params.offset).limit(pagination_params.per_page)

def apply_filters_to_query(query, filter_params: FilterParams, model_class=None):
    """Apply filters to query."""
    from sqlalchemy import and_, or_
    
    conditions = []
    
    if filter_params.search and model_class:
        search_term = f"%{filter_params.search}%"
        search_conditions = []
        
        for field_name in ['name', 'title', 'description', 'username', 'email']:
            if hasattr(model_class, field_name):
                field = getattr(model_class, field_name)
                search_conditions.append(field.ilike(search_term))
        
        if search_conditions:
            conditions.append(or_(*search_conditions))
    
    if filter_params.status and model_class and hasattr(model_class, 'status'):
        conditions.append(model_class.status == filter_params.status)
    
    if filter_params.is_active is not None and model_class and hasattr(model_class, 'is_active'):
        conditions.append(model_class.is_active == filter_params.is_active)
    
    if conditions:
        query = query.filter(and_(*conditions))
    
    return query

def apply_sorting_to_query(query, sort_params: SortParams, model_class=None):
    """Apply sorting to query."""
    from sqlalchemy import asc, desc
    
    if model_class and hasattr(model_class, sort_params.sort_by):
        field = getattr(model_class, sort_params.sort_by)
        if sort_params.sort_order == "asc":
            query = query.order_by(asc(field))
        else:
            query = query.order_by(desc(field))
    
    return query

def build_pagination_response(items: List, pagination_params: PaginationParams, total_count: int) -> Dict[str, Any]:
    """Build pagination response."""
    total_pages = (total_count + pagination_params.per_page - 1) // pagination_params.per_page
    
    return {
        "items": items,
        "pagination": {
            "page": pagination_params.page,
            "per_page": pagination_params.per_page,
            "total": total_count,
            "pages": total_pages,
            "has_next": pagination_params.page < total_pages,
            "has_prev": pagination_params.page > 1
        }
    }

def count_query_results_sync(query) -> int:
    """Count query results (sync)."""
    return query.count()

async def count_query_results(query) -> int:
    """Count query results (async)."""
    from sqlalchemy import func, select
    
    if hasattr(query, 'scalar'):
        count_query = select(func.count()).select_from(query.subquery())
        result = await query.session.scalar(count_query)
        return result or 0
    
    return query.count()

def create_search_filter(search_term: str, model_class, search_fields: List[str] = None):
    """Create search filter."""
    from sqlalchemy import or_
    
    if not search_term or not model_class:
        return None
    
    search_term = f"%{search_term.strip()}%"
    search_conditions = []
    
    fields_to_search = search_fields or ['name', 'title', 'description', 'username', 'email']
    
    for field_name in fields_to_search:
        if hasattr(model_class, field_name):
            field = getattr(model_class, field_name)
            search_conditions.append(field.ilike(search_term))
    
    return or_(*search_conditions) if search_conditions else None

def sanitize_search_term(search_term: str) -> str:
    """Sanitize search term."""
    if not search_term:
        return ""
    
    dangerous_chars = ['%', '_', '\\', "'", '"', ';', '--', '/*', '*/']
    sanitized = search_term
    
    for char in dangerous_chars:
        sanitized = sanitized.replace(char, '')
    
    return sanitized.strip()[:255]

def require_staff() -> Callable:
    """Require staff role."""
    def staff_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        user_roles = current_user.get("roles", [])
        staff_roles = ["staff", "manager", "director", "admin", "superuser"]
        if not any(role in user_roles for role in staff_roles):
            raise HTTPForbiddenError("Staff access required")
        return current_user
    return staff_dependency

def require_password_change() -> Callable:
    """Require user to change password if needed."""
    def password_change_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        # Check if password change is required
        password_expired = current_user.get("password_expired", False)
        force_password_change = current_user.get("force_password_change", False)
        
        if password_expired or force_password_change:
            raise HTTPForbiddenError("Password change required before accessing this resource")
        
        return current_user
    return password_change_dependency

def require_email_verified() -> Callable:
    """Require verified email."""
    def email_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        if not current_user.get("is_email_verified", True):
            raise HTTPForbiddenError("Email verification required")
        return current_user
    return email_dependency

def require_mfa_verified() -> Callable:
    """Require MFA verification."""
    def mfa_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        if not current_user.get("mfa_verified", True):
            raise HTTPForbiddenError("Multi-factor authentication required")
        return current_user
    return mfa_dependency

def require_terms_accepted() -> Callable:
    """Require terms acceptance."""
    def terms_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        if not current_user.get("terms_accepted", True):
            raise HTTPForbiddenError("Terms of service acceptance required")
        return current_user
    return terms_dependency


def require_mfa_verification() -> Callable:
    """Require MFA verification."""
    def mfa_verification_dependency(
        current_user: Annotated[Dict[str, Any], Depends(get_current_user)]
    ) -> Dict[str, Any]:
        if not current_user.get("mfa_verified", True):
            raise HTTPForbiddenError("Multi-factor authentication verification required")
        return current_user
    return mfa_verification_dependency


# ===== EXPORTS =====

__all__ = [
    # Authentication
    "get_current_user", "get_current_active_user", "get_optional_user",
    
    # Role-based access
    "require_role", "require_admin", "require_superuser", "require_staff", "require_manager_role",
    
    # Permission-based access
    "require_permissions", "require_any_permission",

      # ... existing items ...
    "require_role", "require_admin", "require_superuser", "require_staff", "require_manager_role",
    # ... rest of the list ...
    
    "require_password_change", "require_email_verified", "require_mfa_verified", "require_terms_accepted"
    
    # Organization access
    "require_department_access", "require_company_access", "require_unit_access",
    
    # Feature & subscription
    "require_feature", "require_subscription",
    
    # Validation
    "validate_request_size", "validate_json_content", "validate_uuid",
    
    # Utilities
    "rate_limit", "audit_log", "get_client_ip", "get_device_fingerprint",
    
    # Pagination & filtering
    "get_pagination_params", "get_filter_params", "get_sort_params",
    "PaginationParams", "FilterParams", "SortParams", "get_async_db_session",
    
    # Query utilities
    "apply_pagination_to_query", "apply_filters_to_query", "apply_sorting_to_query",
    "build_pagination_response", "count_query_results", "count_query_results_sync",
    "create_search_filter", "sanitize_search_term"
]