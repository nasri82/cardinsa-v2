"""
Core module for Cardinsa Insurance API.
"""

from .exceptions import (
    BaseAppException,
    ValidationError,
    ValidationException,  # Alias
    NotFoundError,
    ResourceNotFoundException,  # Alias
    AlreadyExistsError,
    PermissionDeniedError,
    AuthenticationError,
    AuthorizationError,
    AuthorizationException,  # Alias
    DatabaseError,
    ExternalServiceError,
    BusinessLogicError,
    BusinessLogicException,
    ConfigurationError,
    RateLimitError,
    HTTPNotFoundError,
    HTTPBadRequestError,
    HTTPUnauthorizedError,
    HTTPForbiddenError,
    HTTPConflictError,
    HTTPUnprocessableEntityError,
    HTTPInternalServerError,
    # Authentication specific
    InvalidCredentialsError,
    AccountLockedError,
    AccountInactiveError,
    TokenExpiredError,
    InvalidTokenError,
    MFARequiredError,
    InvalidMFACodeError,
    # Authorization specific
    InsufficientPermissionsError,
    ResourceAccessDeniedError,
    DepartmentAccessDeniedError,
    # Database specific
    RecordNotFoundError,
    DuplicateRecordError,
    ForeignKeyConstraintError,
    DatabaseConnectionError,
)

from .dependencies import (
    get_current_user,
    get_current_active_user,
    get_optional_user,
    require_permissions,
    require_role,
    require_superuser,
    require_staff,
    require_department_access,
    require_unit_access,
    require_password_change,
    require_mfa_verification,
    # Additional dependencies that will be added
    get_async_db_session,
    get_pagination_params,
    get_filter_params,
    get_sort_params,
)

__all__ = [
    # Base exceptions
    "BaseAppException",
    "ValidationError",
    "ValidationException",
    "NotFoundError", 
    "ResourceNotFoundException",
    "AlreadyExistsError",
    "PermissionDeniedError",
    "AuthenticationError",
    "AuthorizationError",
    "AuthorizationException",
    "DatabaseError",
    "ExternalServiceError",
    "BusinessLogicError",
    "BusinessLogicException",
    "ConfigurationError",
    "RateLimitError",
    # HTTP exceptions
    "HTTPNotFoundError",
    "HTTPBadRequestError",
    "HTTPUnauthorizedError",
    "HTTPForbiddenError",
    "HTTPConflictError",
    "HTTPUnprocessableEntityError",
    "HTTPInternalServerError",
    # Authentication specific
    "InvalidCredentialsError",
    "AccountLockedError", 
    "AccountInactiveError",
    "TokenExpiredError",
    "InvalidTokenError",
    "MFARequiredError",
    "InvalidMFACodeError",
    # Authorization specific
    "InsufficientPermissionsError",
    "ResourceAccessDeniedError",
    "DepartmentAccessDeniedError",
    # Database specific
    "RecordNotFoundError",
    "DuplicateRecordError",
    "ForeignKeyConstraintError", 
    "DatabaseConnectionError",
    # Dependencies
    "get_current_user",
    "get_current_active_user",
    "get_optional_user",
    "require_permissions",
    "require_role",
    "require_superuser",
    "require_staff",
    "require_department_access",
    "require_unit_access",
    "require_password_change",
    "require_mfa_verification",
    "get_async_db_session",
    "get_pagination_params",
    "get_filter_params",
    "get_sort_params",
]