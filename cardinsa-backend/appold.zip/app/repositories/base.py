"""
Base Repository Pattern Implementation
Provides common CRUD operations for all repositories
"""

import uuid
from typing import Any, Dict, List, Optional, Type, TypeVar, Generic
from abc import ABC, abstractmethod

from sqlalchemy import and_, or_, desc, asc, func
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from pydantic import BaseModel

from app.models.base import BaseModel as SQLModel
from app.core.exceptions import (
    ResourceNotFoundException,
    ValidationException,
    BusinessLogicException
)

# Type variables for generic repository
ModelType = TypeVar("ModelType", bound=SQLModel)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class IRepository(ABC, Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    """Abstract repository interface"""
    
    @abstractmethod
    async def create(self, db: Session, *, obj_in: CreateSchemaType, **kwargs) -> ModelType:
        pass
    
    @abstractmethod
    async def get(self, db: Session, id: uuid.UUID) -> Optional[ModelType]:
        pass
    
    @abstractmethod
    async def get_multi(self, db: Session, *, skip: int = 0, limit: int = 100, **kwargs) -> List[ModelType]:
        pass
    
    @abstractmethod
    async def update(self, db: Session, *, db_obj: ModelType, obj_in: UpdateSchemaType, **kwargs) -> ModelType:
        pass
    
    @abstractmethod
    async def delete(self, db: Session, *, id: uuid.UUID) -> ModelType:
        pass


class BaseRepository(IRepository[ModelType, CreateSchemaType, UpdateSchemaType]):
    """Base repository with common CRUD operations"""
    
    def __init__(self, model: Type[ModelType]):
        """
        Initialize repository with model class
        
        Args:
            model: SQLAlchemy model class
        """
        self.model = model
    
    async def create(
        self, 
        db: Session, 
        *, 
        obj_in: CreateSchemaType, 
        created_by: Optional[uuid.UUID] = None,
        company_id: Optional[uuid.UUID] = None,
        **kwargs
    ) -> ModelType:
        """
        Create new record
        
        Args:
            db: Database session
            obj_in: Pydantic schema with data
            created_by: ID of user creating the record
            company_id: Company ID for multi-tenancy
            **kwargs: Additional fields to set
        
        Returns:
            Created model instance
        
        Raises:
            ValidationException: If data validation fails
            BusinessLogicException: If business rules are violated
        """
        try:
            obj_data = obj_in.dict() if hasattr(obj_in, 'dict') else obj_in
            
            # Add audit fields if model supports them
            if hasattr(self.model, 'created_by') and created_by:
                obj_data['created_by'] = created_by
            
            if hasattr(self.model, 'company_id') and company_id:
                obj_data['company_id'] = company_id
            
            # Add any additional fields
            obj_data.update(kwargs)
            
            db_obj = self.model(**obj_data)
            db.add(db_obj)
            db.commit()
            db.refresh(db_obj)
            
            return db_obj
            
        except IntegrityError as e:
            db.rollback()
            raise ValidationException(
                message="Data integrity violation",
                details={"error": str(e.orig)}
            )
        except Exception as e:
            db.rollback()
            raise BusinessLogicException(f"Failed to create {self.model.__name__}: {str(e)}")
    
    async def get(self, db: Session, id: uuid.UUID) -> Optional[ModelType]:
        """
        Get record by ID
        
        Args:
            db: Database session
            id: Record UUID
        
        Returns:
            Model instance or None if not found
        """
        query = db.query(self.model).filter(self.model.id == id)
        
        # Filter out soft-deleted records if model supports soft delete
        if hasattr(self.model, 'archived_at'):
            query = query.filter(self.model.archived_at.is_(None))
        
        return query.first()
    
    async def get_or_404(self, db: Session, id: uuid.UUID) -> ModelType:
        """
        Get record by ID or raise 404 if not found
        
        Args:
            db: Database session
            id: Record UUID
        
        Returns:
            Model instance
        
        Raises:
            ResourceNotFoundException: If record not found
        """
        obj = await self.get(db, id)
        if not obj:
            raise ResourceNotFoundException(
                message=f"{self.model.__name__} not found",
                resource_type=self.model.__name__
            )
        return obj
    
    async def get_multi(
        self,
        db: Session,
        *,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
        search: Optional[str] = None,
        search_fields: Optional[List[str]] = None,
        sort_by: Optional[str] = None,
        sort_desc: bool = False,
        company_id: Optional[uuid.UUID] = None,
        include_archived: bool = False
    ) -> List[ModelType]:
        """
        Get multiple records with filtering, searching, and pagination
        
        Args:
            db: Database session
            skip: Number of records to skip
            limit: Maximum number of records to return
            filters: Dictionary of field filters
            search: Search term
            search_fields: Fields to search in
            sort_by: Field to sort by
            sort_desc: Sort in descending order
            company_id: Filter by company ID
            include_archived: Include soft-deleted records
        
        Returns:
            List of model instances
        """
        query = db.query(self.model)
        
        # Apply company filter for multi-tenancy
        if hasattr(self.model, 'company_id') and company_id:
            query = query.filter(self.model.company_id == company_id)
        
        # Filter out archived records unless explicitly included
        if hasattr(self.model, 'archived_at') and not include_archived:
            query = query.filter(self.model.archived_at.is_(None))
        
        # Apply filters
        if filters:
            for field, value in filters.items():
                if hasattr(self.model, field):
                    if isinstance(value, list):
                        query = query.filter(getattr(self.model, field).in_(value))
                    elif isinstance(value, dict):
                        # Range filter: {"min": 10, "max": 100}
                        if "min" in value:
                            query = query.filter(getattr(self.model, field) >= value["min"])
                        if "max" in value:
                            query = query.filter(getattr(self.model, field) <= value["max"])
                    else:
                        query = query.filter(getattr(self.model, field) == value)
        
        # Apply search
        if search and search_fields:
            search_conditions = []
            for field in search_fields:
                if hasattr(self.model, field):
                    search_conditions.append(
                        getattr(self.model, field).ilike(f"%{search}%")
                    )
            if search_conditions:
                query = query.filter(or_(*search_conditions))
        
        # Apply sorting
        if sort_by and hasattr(self.model, sort_by):
            sort_field = getattr(self.model, sort_by)
            query = query.order_by(desc(sort_field) if sort_desc else asc(sort_field))
        else:
            # Default sort by created_at descending if available
            if hasattr(self.model, 'created_at'):
                query = query.order_by(desc(self.model.created_at))
        
        # Apply pagination
        return query.offset(skip).limit(limit).all()
    
    async def count(
        self,
        db: Session,
        *,
        filters: Optional[Dict[str, Any]] = None,
        search: Optional[str] = None,
        search_fields: Optional[List[str]] = None,
        company_id: Optional[uuid.UUID] = None,
        include_archived: bool = False
    ) -> int:
        """
        Count records with filters and search
        
        Args:
            db: Database session
            filters: Dictionary of field filters
            search: Search term
            search_fields: Fields to search in
            company_id: Filter by company ID
            include_archived: Include soft-deleted records
        
        Returns:
            Total count of matching records
        """
        query = db.query(func.count(self.model.id))
        
        # Apply company filter
        if hasattr(self.model, 'company_id') and company_id:
            query = query.filter(self.model.company_id == company_id)
        
        # Filter out archived records
        if hasattr(self.model, 'archived_at') and not include_archived:
            query = query.filter(self.model.archived_at.is_(None))
        
        # Apply filters (same logic as get_multi)
        if filters:
            for field, value in filters.items():
                if hasattr(self.model, field):
                    if isinstance(value, list):
                        query = query.filter(getattr(self.model, field).in_(value))
                    elif isinstance(value, dict):
                        if "min" in value:
                            query = query.filter(getattr(self.model, field) >= value["min"])
                        if "max" in value:
                            query = query.filter(getattr(self.model, field) <= value["max"])
                    else:
                        query = query.filter(getattr(self.model, field) == value)
        
        # Apply search
        if search and search_fields:
            search_conditions = []
            for field in search_fields:
                if hasattr(self.model, field):
                    search_conditions.append(
                        getattr(self.model, field).ilike(f"%{search}%")
                    )
            if search_conditions:
                query = query.filter(or_(*search_conditions))
        
        return query.scalar()
    
    async def update(
        self,
        db: Session,
        *,
        db_obj: ModelType,
        obj_in: UpdateSchemaType,
        updated_by: Optional[uuid.UUID] = None,
        **kwargs
    ) -> ModelType:
        """
        Update existing record
        
        Args:
            db: Database session
            db_obj: Existing model instance
            obj_in: Pydantic schema with updated data
            updated_by: ID of user updating the record
            **kwargs: Additional fields to update
        
        Returns:
            Updated model instance
        
        Raises:
            ValidationException: If data validation fails
            BusinessLogicException: If business rules are violated
        """
        try:
            obj_data = obj_in.dict(exclude_unset=True) if hasattr(obj_in, 'dict') else obj_in
            
            # Add audit fields if model supports them
            if hasattr(self.model, 'updated_by') and updated_by:
                obj_data['updated_by'] = updated_by
            
            # Add any additional fields
            obj_data.update(kwargs)
            
            for field, value in obj_data.items():
                if hasattr(db_obj, field):
                    setattr(db_obj, field, value)
            
            db.commit()
            db.refresh(db_obj)
            
            return db_obj
            
        except IntegrityError as e:
            db.rollback()
            raise ValidationException(
                message="Data integrity violation",
                details={"error": str(e.orig)}
            )
        except Exception as e:
            db.rollback()
            raise BusinessLogicException(f"Failed to update {self.model.__name__}: {str(e)}")
    
    async def delete(
        self,
        db: Session,
        *,
        id: uuid.UUID,
        hard_delete: bool = False,
        deleted_by: Optional[uuid.UUID] = None
    ) -> ModelType:
        """
        Delete record (soft delete by default)
        
        Args:
            db: Database session
            id: Record UUID to delete
            hard_delete: Perform hard delete instead of soft delete
            deleted_by: ID of user deleting the record
        
        Returns:
            Deleted model instance
        
        Raises:
            ResourceNotFoundException: If record not found
            BusinessLogicException: If deletion fails
        """
        obj = await self.get_or_404(db, id)
        
        try:
            if hard_delete or not hasattr(self.model, 'archived_at'):
                # Hard delete
                db.delete(obj)
            else:
                # Soft delete
                obj.archive()
                if hasattr(self.model, 'updated_by') and deleted_by:
                    obj.updated_by = deleted_by
            
            db.commit()
            return obj
            
        except Exception as e:
            db.rollback()
            raise BusinessLogicException(f"Failed to delete {self.model.__name__}: {str(e)}")
    
    async def restore(
        self,
        db: Session,
        *,
        id: uuid.UUID,
        restored_by: Optional[uuid.UUID] = None
    ) -> ModelType:
        """
        Restore soft-deleted record
        
        Args:
            db: Database session
            id: Record UUID to restore
            restored_by: ID of user restoring the record
        
        Returns:
            Restored model instance
        
        Raises:
            ResourceNotFoundException: If record not found
            BusinessLogicException: If model doesn't support soft delete
        """
        if not hasattr(self.model, 'archived_at'):
            raise BusinessLogicException(f"{self.model.__name__} doesn't support soft delete")
        
        # Get archived record
        obj = db.query(self.model).filter(
            and_(
                self.model.id == id,
                self.model.archived_at.isnot(None)
            )
        ).first()
        
        if not obj:
            raise ResourceNotFoundException(
                message=f"Archived {self.model.__name__} not found",
                resource_type=self.model.__name__
            )
        
        try:
            obj.restore()
            if hasattr(self.model, 'updated_by') and restored_by:
                obj.updated_by = restored_by
            
            db.commit()
            db.refresh(obj)
            
            return obj
            
        except Exception as e:
            db.rollback()
            raise BusinessLogicException(f"Failed to restore {self.model.__name__}: {str(e)}")
    
    async def exists(
        self,
        db: Session,
        *,
        filters: Dict[str, Any],
        exclude_id: Optional[uuid.UUID] = None
    ) -> bool:
        """
        Check if record exists with given filters
        
        Args:
            db: Database session
            filters: Dictionary of field filters
            exclude_id: Exclude record with this ID from check
        
        Returns:
            True if record exists, False otherwise
        """
        query = db.query(self.model.id)
        
        # Apply filters
        for field, value in filters.items():
            if hasattr(self.model, field):
                query = query.filter(getattr(self.model, field) == value)
        
        # Exclude specific ID if provided
        if exclude_id:
            query = query.filter(self.model.id != exclude_id)
        
        # Filter out archived records
        if hasattr(self.model, 'archived_at'):
            query = query.filter(self.model.archived_at.is_(None))
        
        return query.first() is not None