"""
Cardinsa Insurance API - Application Main Module
This is the main FastAPI application that can be imported by uvicorn.
"""

import logging
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import with error handling
try:
    from app.config.settings import get_settings
    settings = get_settings()
    logger.info("✅ Settings loaded successfully")
except Exception as e:
    logger.error(f"❌ Settings loading failed: {e}")
    # Minimal fallback settings
    class FallbackSettings:
        APP_NAME = "Cardinsa Insurance API"
        API_VERSION = "v1"
        ENVIRONMENT = "development"
        DEBUG = True
        CORS_ORIGINS = ["*"]
        UPLOAD_PATH = "uploads"
        HEALTH_CHECK_PATH = "/health"
        is_development = True
        is_production = False
        
        def get_cors_origins(self):
            return self.CORS_ORIGINS
    
    settings = FallbackSettings()

try:
    from app.config.database import db_manager, DatabaseHealth
    database_available = True
    logger.info("✅ Database modules imported")
except Exception as e:
    logger.warning(f"⚠️ Database modules not available: {e}")
    database_available = False
    
    class MockDatabaseHealth:
        @staticmethod
        async def health_check():
            return {
                "database": {
                    "status": "unavailable",
                    "message": "Database modules not loaded",
                    "connected": False
                }
            }
    
    DatabaseHealth = MockDatabaseHealth


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    # Startup
    logger.info("🚀 Starting Cardinsa Insurance API...")
    
    # Create upload directory
    Path(settings.UPLOAD_PATH).mkdir(exist_ok=True)
    logger.info(f"📁 Upload directory ready: {settings.UPLOAD_PATH}")
    
    # Initialize database if available
    if database_available:
        try:
            db_manager.initialize()
            is_connected = await db_manager.check_connection()
            if is_connected:
                logger.info("✅ Database connected successfully")
            else:
                logger.warning("⚠️ Database connection failed")
        except Exception as e:
            logger.error(f"❌ Database initialization failed: {e}")
    
    logger.info("✅ Application startup completed")
    
    yield
    
    # Shutdown
    logger.info("🛑 Shutting down application...")
    if database_available:
        try:
            await db_manager.close_connections()
            logger.info("✅ Database connections closed")
        except Exception as e:
            logger.error(f"❌ Error closing database: {e}")


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.API_VERSION,
    description="Comprehensive Insurance Management System API",
    docs_url="/docs" if settings.is_development else None,
    redoc_url="/redoc" if settings.is_development else None,
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.get_cors_origins() if hasattr(settings, 'get_cors_origins') else ["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["*"],
)

# Add request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = datetime.utcnow()
    
    # Log request
    logger.info(f"📥 {request.method} {request.url}")
    
    # Process request
    response = await call_next(request)
    
    # Calculate duration
    duration = (datetime.utcnow() - start_time).total_seconds()
    
    # Log response
    logger.info(f"📤 {response.status_code} - {duration:.3f}s")
    
    # Add timing header
    response.headers["X-Process-Time"] = f"{duration:.3f}"
    
    return response

# Exception handlers
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "detail": "Validation error",
            "errors": exc.errors()
        }
    )

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "detail": exc.detail,
            "status_code": exc.status_code
        }
    )

# Add basic root endpoints (these are the ones you're currently seeing)
@app.get("/", tags=["Root"])
async def root():
    """Root endpoint - API information."""
    return {
        "name": "Cardinsa Insurance API",
        "version": "v1",
        "description": "Comprehensive Insurance Management System API",
        "docs": "/docs",
        "health": "/health"
    }

@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint."""
    try:
        health_data = {
            "status": "healthy",
            "version": settings.API_VERSION,
            "timestamp": datetime.utcnow().isoformat(),
            "environment": settings.ENVIRONMENT
        }
        
        if database_available:
            db_health = await DatabaseHealth.health_check()
            health_data.update(db_health)
        else:
            health_data["database"] = {
                "status": "unavailable",
                "message": "Database modules not loaded"
            }
        
        return health_data
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@app.get("/version", tags=["System"])
async def get_version():
    """Get API version information."""
    return {
        "version": settings.API_VERSION,
        "name": settings.APP_NAME,
        "environment": settings.ENVIRONMENT
    }

@app.get("/api/test", tags=["System"])
async def test_endpoint():
    """Test endpoint for API functionality."""
    return {
        "message": "API is working correctly",
        "timestamp": datetime.utcnow().isoformat(),
        "test": "success"
    }

# Import and include the v1 router
try:
    from app.api.v1.router import router as v1_router
    app.include_router(v1_router)
    logger.info("✅ V1 router included successfully")
except Exception as e:
    logger.error(f"❌ Failed to include V1 router: {e}")
    logger.info("ℹ️  API will run with basic endpoints only")

# Additional router imports (when ready)
# try:
#     from app.api.v2.router import router as v2_router
#     app.include_router(v2_router)
# except ImportError:
#     logger.info("V2 router not available")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True if settings.is_development else False,
        log_level=settings.LOG_LEVEL.lower() if hasattr(settings, 'LOG_LEVEL') else "info"
    )