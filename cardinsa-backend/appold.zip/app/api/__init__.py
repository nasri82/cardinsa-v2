"""
API package for Cardinsa Insurance API.
"""

from .v1 import v1_router

__all__ = ["v1_router"]