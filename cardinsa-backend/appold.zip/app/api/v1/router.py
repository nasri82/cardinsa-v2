"""
Main V1 API Router
Aggregates all v1 API endpoints for the Cardinsa Insurance API.
"""

from fastapi import APIRouter

# Create the main v1 router
router = APIRouter(prefix="/api/v1")

# ========================================
# PHASE 1.1: AUTHENTICATION & AUTHORIZATION (✅ COMPLETE)
# ========================================
# Import sub-routers with error handling
try:
    from .auth.auth import router as auth_router
    router.include_router(
        auth_router, 
        prefix="/auth", 
        tags=["Authentication"]
    )
except ImportError as e:
    print(f"Warning: Could not import auth router: {e}")

try:
    from .auth.users import router as users_router
    router.include_router(
        users_router, 
        tags=["User Management"]
    )
except ImportError as e:
    print(f"Warning: Could not import users router: {e}")

try:
    from .auth.roles import router as roles_router
    router.include_router(
        roles_router, 
        tags=["Role Management"]
    )
except ImportError as e:
    print(f"Warning: Could not import roles router: {e}")

# ========================================
# PHASE 1.2: COMPANY & MULTI-TENANCY (✅ COMPLETE)
# ========================================
# Add the 66 Phase 1.2 endpoints

try:
    from .companies.companies import router as companies_router
    router.include_router(
        companies_router, 
        prefix="/companies", 
        tags=["Company Management"]
    )
except ImportError as e:
    print(f"Warning: Could not import companies router: {e}")

try:
    from .companies.geography import router as geography_router
    router.include_router(
        geography_router, 
        prefix="/geography", 
        tags=["Geographic Services"]
    )
except ImportError as e:
    print(f"Warning: Could not import geography router: {e}")

try:
    from .companies.departments import router as departments_router
    router.include_router(
        departments_router, 
        prefix="/departments", 
        tags=["Department Management"]
    )
except ImportError as e:
    print(f"Warning: Could not import departments router: {e}")

try:
    from .companies.localization import router as localization_router
    router.include_router(
        localization_router, 
        prefix="/localization", 
        tags=["Localization Services"]
    )
except ImportError as e:
    print(f"Warning: Could not import localization router: {e}")

# ========================================
# SYSTEM ENDPOINTS
# ========================================

# Add health check endpoint
@router.get("/health")
async def health_check():
    """Health check endpoint for the API."""
    return {
        "status": "healthy", 
        "version": "1.0.0",
        "service": "Cardinsa Insurance API",
        "modules": {
            "phase_1_1": "Authentication & Authorization (46 endpoints)",
            "phase_1_2": "Company & Multi-Tenancy (66 endpoints)"
        }
    }

# Add a root endpoint for API info
@router.get("/")
async def api_info():
    """Get API information."""
    return {
        "name": "Cardinsa Insurance API",
        "version": "v1", 
        "description": "Comprehensive Insurance Management System API",
        "total_endpoints": 112,
        "modules": {
            "authentication": {
                "description": "User authentication, MFA, sessions, device tracking",
                "endpoints": 46,
                "prefix": "/auth"
            },
            "company_management": {
                "description": "Multi-tenant company lifecycle and configuration",
                "endpoints": 13,
                "prefix": "/companies"
            },
            "geography": {
                "description": "Global location services, address validation, risk assessment",
                "endpoints": 18,
                "prefix": "/geography"
            },
            "departments": {
                "description": "Organizational structure, hierarchy, user assignments",
                "endpoints": 20,
                "prefix": "/departments"
            },
            "localization": {
                "description": "Multi-language support, translations, cultural formatting",
                "endpoints": 15,
                "prefix": "/localization"
            }
        },
        "health_check": "/api/v1/health"
    }