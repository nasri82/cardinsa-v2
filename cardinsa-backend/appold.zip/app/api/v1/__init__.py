"""
V1 API Package for Cardinsa Insurance API.
"""

from .router import router as v1_router

__all__ = ["v1_router"]