"""
Localization API Endpoints

FastAPI routes for multi-language support, translation management,
locale configuration, and language preferences.
"""

from typing import Dict, List, Optional, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.deps import get_current_active_user, get_db
from app.core.exceptions import NotFoundError, DuplicateError, ValidationError, BusinessLogicError
from app.models.auth import User
from app.services.company import LocalizationService
from app.schemas.company import (
    LanguageCreate, LanguageUpdate, LanguageResponse, LanguageListResponse,
    TranslationCreate, TranslationUpdate, TranslationResponse,
    TranslationBulkImport, TranslationBulkImportResponse,
    TranslationSearchParams, TranslationApprovalRequest, TranslationApprovalResponse,
    LocaleResponse, LanguageSettingCreate, LanguageSettingUpdate, LanguageSettingResponse,
    TranslationStatistics, MissingTranslationsResponse,
    EffectiveLanguageRequest, EffectiveLanguageResponse,
    TranslationExportRequest, TranslationExportResponse
)

router = APIRouter(prefix="/localization", tags=["Localization"])


# Language Management Endpoints

@router.get(
    "/languages",
    response_model=LanguageListResponse,
    summary="List Languages",
    description="Get list of all languages with filtering options"
)
async def list_languages(
    active_only: bool = Query(True, description="Return only active languages"),
    supported_only: bool = Query(False, description="Return only supported languages"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> LanguageListResponse:
    """
    Get a comprehensive list of languages with metadata.
    
    **Filters:**
    - **active_only**: Languages available for use
    - **supported_only**: Languages with translation support
    
    **Returns:**
    - Complete language information
    - Translation completion percentages
    - Language statistics and counts
    """
    try:
        service = LocalizationService(db)
        languages = await service.get_all_languages(active_only, supported_only)
        
        # Get statistics
        total_count = len(languages)
        active_count = len([lang for lang in languages if lang.is_active])
        supported_count = len([lang for lang in languages if lang.is_supported])
        
        return LanguageListResponse(
            languages=[LanguageResponse.from_orm(lang) for lang in languages],
            total_count=total_count,
            active_count=active_count,
            supported_count=supported_count
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve languages: {str(e)}"
        )


@router.post(
    "/languages",
    response_model=LanguageResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create Language",
    description="Add a new language to the system"
)
async def create_language(
    language_data: LanguageCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> LanguageResponse:
    """
    Create a new language entry with complete configuration.
    
    **Features:**
    - Language metadata and classification
    - Typography and formatting settings
    - Regional and cultural information
    - Initial completion tracking setup
    """
    try:
        service = LocalizationService(db)
        language = await service.create_language(
            language_data.dict(exclude_unset=True),
            current_user.id
        )
        return LanguageResponse.from_orm(language)
        
    except DuplicateError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to create language: {str(e)}"
        )


@router.get(
    "/languages/{language_code}",
    response_model=LanguageResponse,
    summary="Get Language",
    description="Get detailed language information by code"
)
async def get_language(
    language_code: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> LanguageResponse:
    """
    Get comprehensive language information including translation statistics.
    """
    try:
        service = LocalizationService(db)
        language = await service.get_language_by_code(language_code)
        
        if not language:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Language '{language_code}' not found"
            )
        
        return LanguageResponse.from_orm(language)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve language: {str(e)}"
        )


@router.put(
    "/languages/{language_id}",
    response_model=LanguageResponse,
    summary="Update Language",
    description="Update language configuration and metadata"
)
async def update_language(
    language_id: UUID,
    language_update: LanguageUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> LanguageResponse:
    """
    Update language configuration including formatting and display settings.
    """
    try:
        service = LocalizationService(db)
        language = await service.update_language(
            language_id,
            language_update.dict(exclude_unset=True),
            current_user.id
        )
        return LanguageResponse.from_orm(language)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Language {language_id} not found"
        )
    except DuplicateError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update language: {str(e)}"
        )


# Translation Management Endpoints

@router.get(
    "/translations/{language_code}",
    response_model=Dict[str, str],
    summary="Get Translations",
    description="Get all translations for a specific language"
)
async def get_translations(
    language_code: str,
    module: Optional[str] = Query(None, description="Filter by module"),
    context: Optional[str] = Query(None, description="Filter by context"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> Dict[str, str]:
    """
    Get all approved translations for a language with optional filtering.
    
    **Filters:**
    - **module**: Filter by specific module (e.g., 'auth', 'claims')
    - **context**: Filter by context (e.g., 'button', 'title', 'message')
    
    **Use Cases:**
    - Frontend localization
    - Dynamic content generation
    - Email template localization
    - Report generation
    """
    try:
        service = LocalizationService(db)
        translations = await service.get_translations(
            language_code, module, context
        )
        return translations
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve translations: {str(e)}"
        )


@router.get(
    "/translations/{language_code}/{translation_key}",
    response_model=str,
    summary="Get Single Translation",
    description="Get a specific translation by key and language"
)
async def get_translation(
    language_code: str,
    translation_key: str,
    default: Optional[str] = Query(None, description="Default value if not found"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> str:
    """
    Get a specific translation with automatic fallback handling.
    
    **Fallback Strategy:**
    1. Return exact translation if found
    2. Return provided default value
    3. Return translation key as fallback
    """
    try:
        service = LocalizationService(db)
        translation = await service.get_translation(
            translation_key, language_code, default
        )
        return translation or translation_key
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve translation: {str(e)}"
        )


@router.post(
    "/translations",
    response_model=TranslationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create Translation",
    description="Create a new translation entry"
)
async def create_translation(
    translation_data: TranslationCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> TranslationResponse:
    """
    Create a new translation with workflow support.
    
    **Features:**
    - Automatic language key creation
    - Version management
    - Translation status workflow
    - Usage statistics tracking
    """
    try:
        service = LocalizationService(db)
        translation = await service.create_translation(
            translation_data.dict(exclude_unset=True),
            current_user.id
        )
        return TranslationResponse.from_orm(translation)
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except DuplicateError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to create translation: {str(e)}"
        )


@router.put(
    "/translations/{translation_id}",
    response_model=TranslationResponse,
    summary="Update Translation",
    description="Update an existing translation"
)
async def update_translation(
    translation_id: UUID,
    translation_update: TranslationUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> TranslationResponse:
    """
    Update translation content and metadata with version tracking.
    """
    try:
        service = LocalizationService(db)
        translation = await service.update_translation(
            translation_id,
            translation_update.dict(exclude_unset=True),
            current_user.id
        )
        return TranslationResponse.from_orm(translation)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Translation {translation_id} not found"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update translation: {str(e)}"
        )


@router.post(
    "/translations/{translation_id}/approve",
    response_model=TranslationApprovalResponse,
    summary="Approve Translation",
    description="Approve a translation for publication"
)
async def approve_translation(
    translation_id: UUID,
    approval_request: TranslationApprovalRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> TranslationApprovalResponse:
    """
    Approve a translation for use in production.
    
    **Workflow:**
    - Validates translation quality
    - Updates approval status
    - Records approver and timestamp
    - Enables translation for use
    """
    try:
        service = LocalizationService(db)
        translation = await service.approve_translation(
            translation_id,
            current_user.id,
            approval_request.comments
        )
        
        return TranslationApprovalResponse(
            translation_id=translation.id,
            previous_status="review",
            new_status=translation.translation_status,
            approved_by=current_user.id,
            approved_at=translation.approved_at,
            comments=approval_request.comments
        )
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Translation {translation_id} not found"
        )
    except BusinessLogicError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to approve translation: {str(e)}"
        )


@router.post(
    "/translations/bulk-import",
    response_model=TranslationBulkImportResponse,
    summary="Bulk Import Translations",
    description="Import multiple translations at once"
)
async def bulk_import_translations(
    import_data: TranslationBulkImport,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> TranslationBulkImportResponse:
    """
    Import multiple translations efficiently with comprehensive reporting.
    
    **Features:**
    - Batch processing for performance
    - Duplicate handling (update vs. skip)
    - Error reporting per translation
    - Transaction safety (all or nothing option)
    
    **Limits:**
    - Maximum 1000 translations per request
    - Automatic validation and error reporting
    """
    try:
        service = LocalizationService(db)
        result = await service.bulk_import_translations(
            language_code=import_data.language_code,
            translations=import_data.translations,
            module=import_data.module,
            current_user_id=current_user.id
        )
        return TranslationBulkImportResponse(**result)
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to import translations: {str(e)}"
        )


# Locale Management Endpoints

@router.get(
    "/locales",
    response_model=List[LocaleResponse],
    summary="List Locales",
    description="Get all available locales"
)
async def list_locales(
    active_only: bool = Query(True, description="Return only active locales"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[LocaleResponse]:
    """
    Get all available locales with formatting and cultural settings.
    
    **Locale Information:**
    - Currency formatting
    - Date and time formats
    - Number formatting rules
    - Cultural preferences
    """
    try:
        service = LocalizationService(db)
        locales = await service.get_all_locales(active_only)
        return [LocaleResponse.from_orm(locale) for locale in locales]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve locales: {str(e)}"
        )


@router.get(
    "/locales/{locale_code}",
    response_model=LocaleResponse,
    summary="Get Locale",
    description="Get specific locale information"
)
async def get_locale(
    locale_code: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> LocaleResponse:
    """
    Get detailed locale information for formatting and cultural adaptation.
    """
    try:
        service = LocalizationService(db)
        locale = await service.get_locale_by_code(locale_code)
        
        if not locale:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Locale '{locale_code}' not found"
            )
        
        return LocaleResponse.from_orm(locale)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve locale: {str(e)}"
        )


@router.get(
    "/languages/{language_code}/locales",
    response_model=List[LocaleResponse],
    summary="Get Locales by Language",
    description="Get all locales for a specific language"
)
async def get_locales_by_language(
    language_code: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[LocaleResponse]:
    """
    Get all available locales for a specific language.
    
    **Use Cases:**
    - Regional formatting variations
    - Currency preferences by region
    - Cultural adaptation options
    """
    try:
        service = LocalizationService(db)
        locales = await service.get_locales_by_language(language_code)
        return [LocaleResponse.from_orm(locale) for locale in locales]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve locales: {str(e)}"
        )


# Language Settings and Preferences

@router.get(
    "/users/{user_id}/language-settings",
    response_model=Optional[LanguageSettingResponse],
    summary="Get User Language Settings",
    description="Get language preferences for a specific user"
)
async def get_user_language_settings(
    user_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> Optional[LanguageSettingResponse]:
    """
    Get user-specific language preferences and settings.
    """
    try:
        service = LocalizationService(db)
        settings = await service.get_user_language_settings(user_id)
        
        if settings:
            return LanguageSettingResponse.from_orm(settings)
        return None
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve user language settings: {str(e)}"
        )


@router.post(
    "/users/{user_id}/language-settings",
    response_model=LanguageSettingResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Set User Language Settings",
    description="Set or update language preferences for a user"
)
async def set_user_language_settings(
    user_id: UUID,
    settings_data: LanguageSettingCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> LanguageSettingResponse:
    """
    Set comprehensive language preferences for a user.
    
    **Settings Include:**
    - Primary and fallback languages
    - Locale preferences
    - UI language overrides
    - Communication language preferences
    - Content and cultural preferences
    """
    try:
        service = LocalizationService(db)
        
        # Extract language preference data
        language_code = None  # Would need to resolve from language_id
        
        settings = await service.set_user_language_preference(
            user_id=user_id,
            language_code=language_code,  # Would need proper resolution
            additional_settings=settings_data.dict(exclude_unset=True)
        )
        
        return LanguageSettingResponse.from_orm(settings)
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to set user language settings: {str(e)}"
        )


@router.get(
    "/companies/{company_id}/language-settings",
    response_model=Optional[LanguageSettingResponse],
    summary="Get Company Language Settings",
    description="Get default language settings for a company"
)
async def get_company_language_settings(
    company_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> Optional[LanguageSettingResponse]:
    """
    Get company-wide default language settings.
    """
    try:
        service = LocalizationService(db)
        settings = await service.get_company_language_settings(company_id)
        
        if settings:
            return LanguageSettingResponse.from_orm(settings)
        return None
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve company language settings: {str(e)}"
        )


@router.post(
    "/effective-language",
    response_model=EffectiveLanguageResponse,
    summary="Get Effective Language",
    description="Resolve effective language for user or company"
)
async def get_effective_language(
    request: EffectiveLanguageRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> EffectiveLanguageResponse:
    """
    Resolve the effective language for a user or company with fallback logic.
    
    **Resolution Priority:**
    1. User-specific language preference
    2. Company default language
    3. System default language
    4. Provided fallback language
    
    **Returns:**
    - Effective language code
    - Source of language preference
    - Complete language and locale information
    """
    try:
        service = LocalizationService(db)
        language_code = await service.get_effective_language(
            user_id=request.user_id,
            company_id=request.company_id
        )
        
        # Get detailed language information
        language = await service.get_language_by_code(language_code)
        if not language:
            # Fallback to default
            language = await service.get_language_by_code(request.fallback_language)
        
        # Determine source
        source = "system_default"
        if request.user_id:
            user_settings = await service.get_user_language_settings(request.user_id)
            if user_settings:
                source = "user_preference"
        elif request.company_id:
            company_settings = await service.get_company_language_settings(request.company_id)
            if company_settings:
                source = "company_default"
        
        # Get locale information
        locales = await service.get_locales_by_language(language_code)
        locale_info = locales[0] if locales else None
        
        return EffectiveLanguageResponse(
            effective_language_code=language_code,
            source=source,
            language_info=LanguageResponse.from_orm(language),
            locale_info=LocaleResponse.from_orm(locale_info) if locale_info else None
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to resolve effective language: {str(e)}"
        )


# Translation Analytics and Management

@router.get(
    "/statistics",
    response_model=TranslationStatistics,
    summary="Get Translation Statistics",
    description="Get comprehensive translation statistics"
)
async def get_translation_statistics(
    language_code: Optional[str] = Query(None, description="Filter by specific language"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> TranslationStatistics:
    """
    Get comprehensive translation statistics and completion metrics.
    
    **Global Statistics:** (when language_code is None)
    - Statistics for all supported languages
    - Overall completion percentages
    - Translation quality metrics
    
    **Language-Specific Statistics:** (when language_code provided)
    - Detailed statistics for specific language
    - Translation status breakdown
    - Quality and completion metrics
    """
    try:
        service = LocalizationService(db)
        statistics = await service.get_translation_statistics(language_code)
        return TranslationStatistics(**statistics)
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve translation statistics: {str(e)}"
        )


@router.get(
    "/missing-translations/{language_code}",
    response_model=MissingTranslationsResponse,
    summary="Get Missing Translations",
    description="Get translation keys that need translation for a language"
)
async def get_missing_translations(
    language_code: str,
    module: Optional[str] = Query(None, description="Filter by module"),
    limit: int = Query(100, ge=1, le=500, description="Maximum results"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> MissingTranslationsResponse:
    """
    Get translation keys that are missing or need translation for a specific language.
    
    **Features:**
    - Priority-based ordering
    - Usage frequency weighting
    - Module-specific filtering
    - Comprehensive key metadata
    
    **Use Cases:**
    - Translation planning and prioritization
    - Translator task assignment
    - Completion tracking
    - Quality assurance
    """
    try:
        service = LocalizationService(db)
        missing_keys = await service.get_missing_translations(
            language_code, module, limit
        )
        
        missing_data = [
            {
                "key_name": key.key_name,
                "context": key.context,
                "module": key.module,
                "translation_priority": key.translation_priority,
                "usage_count": key.usage_count,
                "description": key.description
            }
            for key in missing_keys
        ]
        
        return MissingTranslationsResponse(
            language_code=language_code,
            total_missing=len(missing_keys),
            missing_keys=missing_data
        )
        
    except NotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve missing translations: {str(e)}"
        )


# Search and Export Endpoints

@router.post(
    "/translations/search",
    response_model=List[TranslationResponse],
    summary="Search Translations",
    description="Search translations with advanced filtering"
)
async def search_translations(
    search_params: TranslationSearchParams,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[TranslationResponse]:
    """
    Advanced translation search with comprehensive filtering options.
    
    **Search Capabilities:**
    - Text search in keys and values
    - Module and context filtering
    - Status-based filtering
    - Multi-language search
    - Flexible sorting options
    """
    # This would need to be implemented in the service layer
    # For now, return a placeholder response
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Translation search functionality will be implemented in next phase"
    )


@router.post(
    "/translations/export",
    response_model=TranslationExportResponse,
    summary="Export Translations",
    description="Export translations in various formats"
)
async def export_translations(
    export_request: TranslationExportRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> TranslationExportResponse:
    """
    Export translations in multiple formats for external use.
    
    **Supported Formats:**
    - JSON: Hierarchical and flat structures
    - CSV: Spreadsheet-compatible format
    - XLSX: Excel workbook format
    - PO: Gettext format for developer tools
    - XLIFF: Translation industry standard
    
    **Features:**
    - Multi-language export
    - Module-specific filtering
    - Metadata inclusion options
    - Secure download links
    """
    # This would need to be implemented in the service layer
    # For now, return a placeholder response
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Translation export functionality will be implemented in next phase"
    )