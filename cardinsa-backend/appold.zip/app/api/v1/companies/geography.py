"""
Geographic Data API Endpoints

FastAPI routes for geographic data management, location services,
address validation, and geographic analytics.
"""

from decimal import Decimal
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.deps import get_current_active_user, get_db
from app.core.exceptions import NotFoundError, ValidationError
from app.models.auth import User
from app.services.company import GeographyService
from app.schemas.company import (
    CountryResponse, RegionResponse, CityResponse, StateResponse,
    AddressValidationRequest, AddressValidationResponse,
    GeocodingResponse, LocationRiskAssessment,
    GeographicStatistics, ServiceCoverageResponse,
    DistanceCalculationRequest, DistanceCalculationResponse,
    NearbySearchResponse, CoordinateSearch
)

router = APIRouter(prefix="/geography", tags=["Geographic Data"])


# Country Endpoints

@router.get(
    "/countries",
    response_model=List[CountryResponse],
    summary="List Countries",
    description="Get list of countries with optional filtering"
)
async def list_countries(
    active_only: bool = Query(True, description="Return only active countries"),
    supported_only: bool = Query(False, description="Return only supported countries"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[CountryResponse]:
    """
    Get a list of countries with optional filtering.
    
    **Filters:**
    - **active_only**: Only countries marked as active
    - **supported_only**: Only countries where insurance services are provided
    
    **Returns:**
    - Complete country information including ISO codes
    - Geographic and regulatory data
    - Insurance market information
    - Risk ratings and compliance status
    """
    try:
        service = GeographyService(db)
        countries = await service.get_all_countries(
            active_only=active_only,
            supported_only=supported_only
        )
        return [CountryResponse.from_orm(country) for country in countries]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve countries: {str(e)}"
        )


@router.get(
    "/countries/{iso_code}",
    response_model=CountryResponse,
    summary="Get Country by ISO Code",
    description="Get country information by ISO 2 or 3 letter code"
)
async def get_country_by_iso(
    iso_code: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CountryResponse:
    """
    Get detailed country information by ISO code.
    
    **Supported Formats:**
    - ISO 2-letter codes (e.g., 'US', 'GB', 'FR')
    - ISO 3-letter codes (e.g., 'USA', 'GBR', 'FRA')
    
    **Returns:**
    - Complete country profile
    - Insurance regulatory information
    - Market data and risk ratings
    """
    try:
        service = GeographyService(db)
        country = await service.get_country_by_iso(iso_code)
        
        if not country:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Country with ISO code '{iso_code}' not found"
            )
        
        return CountryResponse.from_orm(country)
        
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve country: {str(e)}"
        )


@router.get(
    "/countries/search/{search_term}",
    response_model=List[CountryResponse],
    summary="Search Countries",
    description="Search countries by name"
)
async def search_countries(
    search_term: str,
    limit: int = Query(10, ge=1, le=50, description="Maximum results"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[CountryResponse]:
    """
    Search countries by name with fuzzy matching.
    
    **Features:**
    - Searches both English and local names
    - Case-insensitive matching
    - Partial name matching
    - Relevance-based ordering
    """
    try:
        service = GeographyService(db)
        countries = await service.search_countries(search_term, limit)
        return [CountryResponse.from_orm(country) for country in countries]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to search countries: {str(e)}"
        )


@router.get(
    "/countries/region/{region_name}",
    response_model=List[CountryResponse],
    summary="Get Countries by Region",
    description="Get countries in a specific geographic region"
)
async def get_countries_by_region(
    region_name: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[CountryResponse]:
    """
    Get all countries in a specific geographic region.
    
    **Common Regions:**
    - North America, South America
    - Europe, Asia, Africa, Oceania
    - Middle East, Caribbean
    """
    try:
        service = GeographyService(db)
        countries = await service.get_countries_by_region(region_name)
        return [CountryResponse.from_orm(country) for country in countries]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve countries by region: {str(e)}"
        )


# Region Endpoints

@router.get(
    "/countries/{country_id}/regions",
    response_model=List[RegionResponse],
    summary="Get Regions by Country",
    description="Get all regions (states/provinces) for a specific country"
)
async def get_regions_by_country(
    country_id: UUID,
    active_only: bool = Query(True, description="Return only active regions"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[RegionResponse]:
    """
    Get all administrative regions for a specific country.
    
    **Region Types:**
    - States (US)
    - Provinces (Canada, China)
    - Counties (UK)
    - Departments (France)
    - Länder (Germany)
    """
    try:
        service = GeographyService(db)
        regions = await service.get_regions_by_country(country_id, active_only)
        return [RegionResponse.from_orm(region) for region in regions]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve regions: {str(e)}"
        )


@router.get(
    "/countries/{country_id}/regions/search/{search_term}",
    response_model=List[RegionResponse],
    summary="Search Regions",
    description="Search regions within a country"
)
async def search_regions(
    country_id: UUID,
    search_term: str,
    limit: int = Query(10, ge=1, le=50, description="Maximum results"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[RegionResponse]:
    """
    Search administrative regions within a specific country.
    """
    try:
        service = GeographyService(db)
        regions = await service.search_regions(country_id, search_term, limit)
        return [RegionResponse.from_orm(region) for region in regions]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to search regions: {str(e)}"
        )


@router.get(
    "/regions/{country_id}/{region_code}",
    response_model=RegionResponse,
    summary="Get Region by Code",
    description="Get region by country and region code"
)
async def get_region_by_code(
    country_id: UUID,
    region_code: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> RegionResponse:
    """
    Get region information by country ID and region code.
    
    **Examples:**
    - US: 'CA' for California, 'NY' for New York
    - Canada: 'ON' for Ontario, 'BC' for British Columbia
    """
    try:
        service = GeographyService(db)
        region = await service.get_region_by_code(country_id, region_code)
        
        if not region:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Region with code '{region_code}' not found"
            )
        
        return RegionResponse.from_orm(region)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve region: {str(e)}"
        )


# City Endpoints

@router.get(
    "/regions/{region_id}/cities",
    response_model=List[CityResponse],
    summary="Get Cities by Region",
    description="Get all cities for a specific region"
)
async def get_cities_by_region(
    region_id: UUID,
    active_only: bool = Query(True, description="Return only active cities"),
    major_cities_only: bool = Query(False, description="Return only major cities"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[CityResponse]:
    """
    Get all cities within a specific region.
    
    **Filters:**
    - **major_cities_only**: Return only cities marked as major cities
    - **active_only**: Return only active cities
    """
    try:
        service = GeographyService(db)
        cities = await service.get_cities_by_region(
            region_id, active_only, major_cities_only
        )
        return [CityResponse.from_orm(city) for city in cities]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve cities: {str(e)}"
        )


@router.get(
    "/countries/{country_id}/cities",
    response_model=List[CityResponse],
    summary="Get Cities by Country",
    description="Get cities for a specific country"
)
async def get_cities_by_country(
    country_id: UUID,
    active_only: bool = Query(True, description="Return only active cities"),
    major_cities_only: bool = Query(False, description="Return only major cities"),
    limit: int = Query(100, ge=1, le=500, description="Maximum results"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[CityResponse]:
    """
    Get cities within a specific country, ordered by population.
    """
    try:
        service = GeographyService(db)
        cities = await service.get_cities_by_country(
            country_id, active_only, major_cities_only, limit
        )
        return [CityResponse.from_orm(city) for city in cities]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve cities: {str(e)}"
        )


@router.get(
    "/cities/search",
    response_model=List[CityResponse],
    summary="Search Cities",
    description="Search cities with optional geographic filtering"
)
async def search_cities(
    search_term: str = Query(..., min_length=1, description="Search term"),
    country_id: Optional[UUID] = Query(None, description="Filter by country"),
    region_id: Optional[UUID] = Query(None, description="Filter by region"),
    limit: int = Query(20, ge=1, le=100, description="Maximum results"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[CityResponse]:
    """
    Search cities globally or within specific geographic boundaries.
    
    **Features:**
    - Global city search or country/region-specific
    - Population-weighted relevance
    - Major cities prioritized
    - Multiple language name matching
    """
    try:
        service = GeographyService(db)
        cities = await service.search_cities(
            search_term, country_id, region_id, limit
        )
        return [CityResponse.from_orm(city) for city in cities]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to search cities: {str(e)}"
        )


@router.post(
    "/cities/nearby",
    response_model=NearbySearchResponse,
    summary="Find Nearby Cities",
    description="Find cities near given coordinates"
)
async def find_nearby_cities(
    search_request: CoordinateSearch,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> NearbySearchResponse:
    """
    Find cities within a specified radius of given coordinates.
    
    **Use Cases:**
    - Location-based services
    - Risk assessment by proximity
    - Coverage area analysis
    - Customer location mapping
    """
    try:
        service = GeographyService(db)
        nearby_cities = await service.get_cities_near_coordinates(
            latitude=search_request.latitude,
            longitude=search_request.longitude,
            radius_km=search_request.radius_km,
            limit=search_request.limit
        )
        
        results = [
            {
                "city": CityResponse.from_orm(city),
                "distance_km": distance
            }
            for city, distance in nearby_cities
        ]
        
        return NearbySearchResponse(
            search_coordinates={
                "latitude": search_request.latitude,
                "longitude": search_request.longitude
            },
            radius_km=search_request.radius_km,
            results=results,
            total_found=len(results)
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to find nearby cities: {str(e)}"
        )


# State Endpoints

@router.get(
    "/countries/{country_id}/states",
    response_model=List[StateResponse],
    summary="Get States by Country",
    description="Get states/provinces with insurance regulatory information"
)
async def get_states_by_country(
    country_id: UUID,
    active_only: bool = Query(True, description="Return only active states"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[StateResponse]:
    """
    Get states/provinces for a country with insurance regulatory data.
    
    **Includes:**
    - Insurance regulatory authorities
    - Licensing requirements
    - Tax rates and compliance status
    - Legal and regulatory frameworks
    """
    try:
        service = GeographyService(db)
        states = await service.get_states_by_country(country_id, active_only)
        return [StateResponse.from_orm(state) for state in states]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve states: {str(e)}"
        )


@router.get(
    "/countries/{country_id}/states/licensed",
    response_model=List[StateResponse],
    summary="Get Licensed States",
    description="Get states where insurance licenses are held"
)
async def get_licensed_states(
    country_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> List[StateResponse]:
    """
    Get states where the company holds active insurance licenses.
    
    **Use Cases:**
    - Operational coverage verification
    - Compliance reporting
    - Business expansion planning
    - Regulatory requirement checking
    """
    try:
        service = GeographyService(db)
        states = await service.get_licensed_states(country_id)
        return [StateResponse.from_orm(state) for state in states]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve licensed states: {str(e)}"
        )


@router.get(
    "/states/{country_id}/{state_code}",
    response_model=StateResponse,
    summary="Get State by Code",
    description="Get state information by country and state code"
)
async def get_state_by_code(
    country_id: UUID,
    state_code: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> StateResponse:
    """
    Get detailed state information including regulatory framework.
    """
    try:
        service = GeographyService(db)
        state = await service.get_state_by_code(country_id, state_code)
        
        if not state:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"State with code '{state_code}' not found"
            )
        
        return StateResponse.from_orm(state)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve state: {str(e)}"
        )


# Address Validation and Geocoding

@router.post(
    "/addresses/validate",
    response_model=AddressValidationResponse,
    summary="Validate Address",
    description="Validate and standardize an address"
)
async def validate_address(
    address_request: AddressValidationRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> AddressValidationResponse:
    """
    Validate and standardize an address with confidence scoring.
    
    **Features:**
    - Address format validation
    - Postal code verification
    - City and region matching
    - Standardization of address components
    - Confidence scoring (0.0 to 1.0)
    - Suggestions for invalid addresses
    
    **Use Cases:**
    - Customer address verification
    - Risk assessment preparation
    - Compliance and regulatory requirements
    - Data quality improvement
    """
    try:
        service = GeographyService(db)
        validation_result = await service.validate_address(
            address_request.dict()
        )
        return AddressValidationResponse(**validation_result)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to validate address: {str(e)}"
        )


@router.post(
    "/addresses/geocode",
    response_model=Optional[GeocodingResponse],
    summary="Geocode Address",
    description="Get coordinates for an address"
)
async def geocode_address(
    address_request: AddressValidationRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> Optional[GeocodingResponse]:
    """
    Convert an address to geographic coordinates.
    
    **Accuracy Levels:**
    - **city_level**: Coordinates at city center
    - **region_level**: Coordinates at region center
    - **country_level**: Coordinates at country center
    
    **Data Sources:**
    - Internal geographic database
    - Validated city/region coordinates
    """
    try:
        service = GeographyService(db)
        geocoding_result = await service.geocode_address(
            address_request.dict()
        )
        
        if geocoding_result:
            return GeocodingResponse(**geocoding_result)
        
        return None
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to geocode address: {str(e)}"
        )


# Risk Assessment and Analytics

@router.post(
    "/risk-assessment",
    response_model=LocationRiskAssessment,
    summary="Location Risk Assessment",
    description="Get risk assessment for a specific location"
)
async def get_location_risk_assessment(
    latitude: Decimal = Query(..., ge=-90, le=90, description="Latitude coordinate"),
    longitude: Decimal = Query(..., ge=-180, le=180, description="Longitude coordinate"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> LocationRiskAssessment:
    """
    Get comprehensive risk assessment for a specific location.
    
    **Risk Factors Analyzed:**
    - Crime rates and security risks
    - Natural disaster exposure
    - Traffic accident rates
    - Healthcare quality and availability
    - Economic stability indicators
    
    **Risk Score:** 0.0 (lowest risk) to 1.0 (highest risk)
    
    **Use Cases:**
    - Insurance pricing adjustments
    - Policy underwriting decisions
    - Risk management strategies
    - Customer education and recommendations
    """
    try:
        service = GeographyService(db)
        risk_assessment = await service.get_risk_assessment_by_location(
            latitude, longitude
        )
        return LocationRiskAssessment(**risk_assessment)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to get risk assessment: {str(e)}"
        )


@router.get(
    "/statistics",
    response_model=GeographicStatistics,
    summary="Geographic Statistics",
    description="Get geographic data statistics"
)
async def get_geographic_statistics(
    country_id: Optional[UUID] = Query(None, description="Filter by specific country"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> GeographicStatistics:
    """
    Get comprehensive geographic data statistics.
    
    **Global Statistics:** (when country_id is None)
    - Total countries, regions, cities
    - Supported vs. total counts
    - Coverage area metrics
    
    **Country-Specific Statistics:** (when country_id provided)
    - Regions and cities within country
    - Licensed states
    - Service coverage details
    """
    try:
        service = GeographyService(db)
        statistics = await service.get_geographic_statistics(country_id)
        return GeographicStatistics(**statistics)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to get geographic statistics: {str(e)}"
        )


@router.get(
    "/service-coverage",
    response_model=ServiceCoverageResponse,
    summary="Service Coverage Areas",
    description="Get areas where insurance services are available"
)
async def get_service_coverage(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> ServiceCoverageResponse:
    """
    Get comprehensive service coverage information.
    
    **Includes:**
    - Countries with active operations
    - Supported regions within each country
    - Cities with service coverage
    - Coverage levels (partial, full)
    
    **Use Cases:**
    - Customer eligibility verification
    - Sales territory planning
    - Business expansion analysis
    - Compliance reporting
    """
    try:
        service = GeographyService(db)
        coverage_data = await service.get_service_coverage_areas()
        return ServiceCoverageResponse(**coverage_data)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to get service coverage: {str(e)}"
        )


# Distance and Coordinate Utilities

@router.post(
    "/distance/calculate",
    response_model=DistanceCalculationResponse,
    summary="Calculate Distance",
    description="Calculate distance between two coordinates"
)
async def calculate_distance(
    distance_request: DistanceCalculationRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> DistanceCalculationResponse:
    """
    Calculate distance between two geographic coordinates using the Haversine formula.
    
    **Use Cases:**
    - Provider network distance calculations
    - Travel distance for claims assessment
    - Service area radius calculations
    - Geographic pricing factor adjustments
    """
    try:
        service = GeographyService(db)
        distance_km = await service.calculate_distance(
            distance_request.origin_latitude,
            distance_request.origin_longitude,
            distance_request.destination_latitude,
            distance_request.destination_longitude
        )
        
        # Convert to miles
        distance_miles = distance_km * Decimal("0.621371")
        
        return DistanceCalculationResponse(
            distance_km=distance_km,
            distance_miles=distance_miles
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to calculate distance: {str(e)}"
        )


@router.get(
    "/timezone",
    response_model=Optional[str],
    summary="Get Timezone by Coordinates",
    description="Get timezone for given coordinates"
)
async def get_timezone_by_coordinates(
    latitude: Decimal = Query(..., ge=-90, le=90, description="Latitude coordinate"),
    longitude: Decimal = Query(..., ge=-180, le=180, description="Longitude coordinate"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> Optional[str]:
    """
    Get timezone information for specific coordinates.
    
    **Resolution Strategy:**
    1. Find nearest city with timezone data
    2. Fall back to region-level timezone
    3. Fall back to country-level timezone
    
    **Use Cases:**
    - User interface localization
    - Scheduling and appointment systems
    - Time-sensitive notifications
    - Business hours calculations
    """
    try:
        service = GeographyService(db)
        timezone = await service.get_timezone_by_coordinates(latitude, longitude)
        return timezone
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to get timezone: {str(e)}"
        )