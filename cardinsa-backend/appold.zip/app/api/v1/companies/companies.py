"""
Company Management API Endpoints

FastAPI routes for company management, system configuration,
and company lifecycle operations.
"""

from typing import Dict, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.deps import get_current_active_user, get_db
from app.core.exceptions import NotFoundError, DuplicateError, BusinessLogicError, UnauthorizedError
from app.models.auth import User
from app.services.company import CompanyService
from app.schemas.company import (
    CompanyCreate, CompanyUpdate, CompanyResponse, CompanyListResponse,
    CompanySearchParams, CompanyStatistics,
    SystemConfigurationUpdate, SystemConfigurationResponse
)

router = APIRouter(prefix="/companies", tags=["Company Management"])


@router.post(
    "/",
    response_model=CompanyResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create Company",
    description="Create a new company with optional admin user setup"
)
async def create_company(
    company_data: CompanyCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyResponse:
    """
    Create a new company with the following features:
    - Complete company setup with validation
    - Optional admin user creation
    - Default system configuration
    - Multi-tenant data isolation
    """
    try:
        service = CompanyService(db)
        company, admin_user = await service.create_company(
            company_data=company_data.dict(exclude_unset=True),
            admin_user_data=company_data.admin_user,
            current_user_id=current_user.id
        )
        return CompanyResponse.from_orm(company)
    
    except DuplicateError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to create company: {str(e)}"
        )


@router.get(
    "/",
    response_model=CompanyListResponse,
    summary="List Companies",
    description="Get paginated list of companies with search and filtering"
)
async def list_companies(
    # Search parameters
    name: str = Query(None, description="Search by company name"),
    code: str = Query(None, description="Search by company code"),
    status: str = Query(None, description="Filter by company status"),
    subscription_tier: str = Query(None, description="Filter by subscription tier"),
    country_id: UUID = Query(None, description="Filter by country"),
    
    # Pagination
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(50, ge=1, le=200, description="Page size"),
    
    # Sorting
    sort_by: str = Query("company_name", description="Sort field"),
    sort_order: str = Query("asc", regex="^(asc|desc)$", description="Sort order"),
    
    # Dependencies
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyListResponse:
    """
    Get a paginated list of companies with advanced search and filtering capabilities.
    
    **Features:**
    - Text search in company name and code
    - Status and subscription tier filtering
    - Geographic filtering by country
    - Flexible sorting options
    - Pagination with metadata
    """
    try:
        service = CompanyService(db)
        
        # Build search parameters
        search_params = CompanySearchParams(
            name=name,
            code=code,
            status=status,
            subscription_tier=subscription_tier,
            country_id=country_id,
            sort_by=sort_by,
            sort_order=sort_order
        ).dict(exclude_unset=True)
        
        result = await service.search_companies(
            search_params=search_params,
            current_user_id=current_user.id,
            page=page,
            page_size=page_size
        )
        
        return CompanyListResponse(
            companies=[CompanyResponse.from_orm(company) for company in result["companies"]],
            **result["pagination"]
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve companies: {str(e)}"
        )


@router.get(
    "/{company_id}",
    response_model=CompanyResponse,
    summary="Get Company",
    description="Get detailed information about a specific company"
)
async def get_company(
    company_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyResponse:
    """
    Get detailed information about a specific company.
    
    **Returns:**
    - Complete company information
    - Configuration details
    - Status and operational data
    - Financial and billing information
    """
    try:
        service = CompanyService(db)
        company = await service.get_by_id(company_id)
        
        if not company:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Company {company_id} not found"
            )
        
        return CompanyResponse.from_orm(company)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve company: {str(e)}"
        )


@router.put(
    "/{company_id}",
    response_model=CompanyResponse,
    summary="Update Company",
    description="Update company information and settings"
)
async def update_company(
    company_id: UUID,
    company_update: CompanyUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyResponse:
    """
    Update company information with comprehensive validation.
    
    **Features:**
    - Partial updates (only provided fields are updated)
    - Business rule validation
    - Duplicate checking for unique fields
    - Audit trail maintenance
    """
    try:
        service = CompanyService(db)
        company = await service.update_company(
            company_id=company_id,
            update_data=company_update.dict(exclude_unset=True),
            current_user_id=current_user.id
        )
        return CompanyResponse.from_orm(company)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Company {company_id} not found"
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except DuplicateError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update company: {str(e)}"
        )


@router.delete(
    "/{company_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete Company",
    description="Soft delete a company (archive)"
)
async def delete_company(
    company_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Soft delete (archive) a company.
    
    **Important:**
    - This is a soft delete operation
    - Company data is archived, not permanently deleted
    - All related data is also archived
    - Operation requires admin privileges
    """
    try:
        service = CompanyService(db)
        await service.delete(company_id, current_user.id)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Company {company_id} not found"
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to delete company: {str(e)}"
        )


@router.get(
    "/{company_id}/statistics",
    response_model=CompanyStatistics,
    summary="Get Company Statistics",
    description="Get comprehensive statistics and metrics for a company"
)
async def get_company_statistics(
    company_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyStatistics:
    """
    Get comprehensive statistics and analytics for a company.
    
    **Includes:**
    - User statistics (total, active, login metrics)
    - Organizational statistics (departments, units)
    - Feature usage and limits
    - Operational metrics
    - Performance indicators
    """
    try:
        service = CompanyService(db)
        statistics = await service.get_company_statistics(company_id)
        return CompanyStatistics(**statistics)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Company {company_id} not found"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve company statistics: {str(e)}"
        )


@router.post(
    "/{company_id}/activate",
    response_model=CompanyResponse,
    summary="Activate Company",
    description="Activate a company and complete onboarding"
)
async def activate_company(
    company_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyResponse:
    """
    Activate a company and complete the onboarding process.
    
    **Prerequisites:**
    - Company must have required information completed
    - At least one admin user must be assigned
    - System configuration must be validated
    
    **Actions:**
    - Sets company status to 'active'
    - Marks onboarding as 'completed'
    - Records go-live date
    - Enables operational features
    """
    try:
        service = CompanyService(db)
        company = await service.activate_company(
            company_id=company_id,
            current_user_id=current_user.id
        )
        return CompanyResponse.from_orm(company)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Company {company_id} not found"
        )
    except BusinessLogicError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to activate company: {str(e)}"
        )


@router.post(
    "/{company_id}/suspend",
    response_model=CompanyResponse,
    summary="Suspend Company",
    description="Suspend a company with reason"
)
async def suspend_company(
    company_id: UUID,
    reason: str = Query(..., min_length=1, max_length=500, description="Suspension reason"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyResponse:
    """
    Suspend a company operations.
    
    **Effects:**
    - Sets company status to 'suspended'
    - Disables operational features
    - Maintains data access for resolution
    - Records suspension reason and timestamp
    
    **Note:** This action requires admin privileges and should be used carefully.
    """
    try:
        service = CompanyService(db)
        company = await service.suspend_company(
            company_id=company_id,
            reason=reason,
            current_user_id=current_user.id
        )
        return CompanyResponse.from_orm(company)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Company {company_id} not found"
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to suspend company: {str(e)}"
        )


# System Configuration Endpoints

@router.get(
    "/{company_id}/configuration",
    response_model=SystemConfigurationResponse,
    summary="Get System Configuration",
    description="Get system configuration for a company"
)
async def get_system_configuration(
    company_id: UUID,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> SystemConfigurationResponse:
    """
    Get complete system configuration for a company.
    
    **Configuration Categories:**
    - Authentication & Security settings
    - Localization preferences
    - Business rules and workflows
    - Insurance-specific settings
    - Financial and billing configuration
    - Communication settings
    - Integration configuration
    - UI/UX customization
    """
    try:
        service = CompanyService(db)
        config = await service.get_system_configuration(company_id)
        return SystemConfigurationResponse.from_orm(config)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"System configuration for company {company_id} not found"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve system configuration: {str(e)}"
        )


@router.put(
    "/{company_id}/configuration",
    response_model=SystemConfigurationResponse,
    summary="Update System Configuration",
    description="Update system configuration for a company"
)
async def update_system_configuration(
    company_id: UUID,
    config_update: SystemConfigurationUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> SystemConfigurationResponse:
    """
    Update system configuration for a company.
    
    **Features:**
    - Partial updates (only provided categories are updated)
    - Configuration validation
    - Version tracking
    - Audit trail maintenance
    - Real-time application of changes
    
    **Configuration Categories:**
    - Password policies and security settings
    - Default languages and localization
    - Business rules and approval workflows
    - Insurance settings (policies, claims, underwriting)
    - Financial settings (currency, tax, billing)
    - Communication preferences
    - API and integration settings
    - Performance and feature flags
    """
    try:
        service = CompanyService(db)
        config = await service.update_system_configuration(
            company_id=company_id,
            config_updates=config_update.dict(exclude_unset=True),
            current_user_id=current_user.id
        )
        return SystemConfigurationResponse.from_orm(config)
        
    except NotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Company {company_id} not found"
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update system configuration: {str(e)}"
        )


@router.get(
    "/code/{company_code}",
    response_model=CompanyResponse,
    summary="Get Company by Code",
    description="Get company information by company code"
)
async def get_company_by_code(
    company_code: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
) -> CompanyResponse:
    """
    Get company information using the company code.
    
    **Use Cases:**
    - Quick company lookup
    - Integration with external systems
    - User-friendly company identification
    """
    try:
        service = CompanyService(db)
        company = await service.get_company_by_code(company_code)
        
        if not company:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Company with code '{company_code}' not found"
            )
        
        return CompanyResponse.from_orm(company)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to retrieve company: {str(e)}"
        )