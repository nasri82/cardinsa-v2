"""
Company & Multi-Tenancy API Package

This package contains all FastAPI routers for company management,
multi-tenancy operations, geographic data, localization,
and organizational structure endpoints.

Phase 1.2: Company & Multi-Tenancy API Endpoints
- Company management and system configuration endpoints
- Geographic data and location service endpoints
- Localization and translation management endpoints
- Department and organizational structure endpoints
"""

from fastapi import APIRouter

# Import all routers
from .companies import router as companies_router
from .geography import router as geography_router
from .localization import router as localization_router
from .departments import router as departments_router

# Create main company router
company_router = APIRouter(prefix="/company", tags=["Company & Multi-Tenancy"])

# Include all sub-routers
company_router.include_router(companies_router)
company_router.include_router(geography_router)
company_router.include_router(localization_router)
company_router.include_router(departments_router)

__all__ = [
    "company_router",
    "companies_router",
    "geography_router",
    "localization_router",
    "departments_router"
]