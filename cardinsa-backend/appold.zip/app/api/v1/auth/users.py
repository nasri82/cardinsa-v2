"""
User Management API Endpoints
CARDINSA Insurance Platform

This module provides user management CRUD endpoints:
- GET /users - List users with pagination and filtering
- POST /users - Create new user
- GET /users/{id} - Get specific user
- PUT /users/{id} - Update user (full update)
- PATCH /users/{id} - Update user (partial update)  
- DELETE /users/{id} - Delete user (soft delete)
- POST /users/{id}/restore - Restore deleted user
- GET /users/search - Search users
- PATCH /users/{id}/password - Change user password
- PATCH /users/{id}/preferences - Update user preferences
- POST /users/{id}/unlock - Unlock user account
- POST /users/{id}/verify-email - Verify user email
- GET /users/{id}/profile - Get user profile
- GET /users/{id}/public - Get public user info
- GET /users/{id}/permissions - Get user permissions
"""

import uuid
import logging
from typing import Dict, Any, List, Optional

from fastapi import APIRouter, Depends, HTTPException, status, Query, Path
from sqlalchemy.ext.asyncio import AsyncSession

from ....core.dependencies import (
    get_async_db_session,
    get_current_user,
    get_pagination_params,
    get_filter_params,
    get_sort_params,
    require_permissions
)
from ....core.exceptions import (
    ValidationException,
    BusinessLogicException,
    ResourceNotFoundException,
    AuthorizationException
)
from ....schemas.auth.user import (
    UserResponse,
    UserCreate,
    UserUpdate,
    UserProfile,
    UserPublic,
    UserPreferences,
    UserPasswordChange
)
from ....schemas.base import (
    PaginatedResponse,
    PaginationParams,
    FilterParams,
    SortParams,
    SuccessResponse,
    ErrorResponse
)
from ....services.auth.user_service import UserService

# Initialize router
router = APIRouter(
    prefix="/users",
    tags=["User Management"],
    responses={
        401: {"model": ErrorResponse, "description": "Authentication required"},
        403: {"model": ErrorResponse, "description": "Insufficient permissions"},
        404: {"model": ErrorResponse, "description": "User not found"},
        422: {"model": ErrorResponse, "description": "Validation error"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    }
)

# Initialize logger
logger = logging.getLogger(__name__)


@router.get(
    "/",
    response_model=PaginatedResponse[UserResponse],
    summary="List Users",
    description="Get paginated list of users with filtering and sorting",
    dependencies=[Depends(require_permissions("user:read"))]
)
async def list_users(
    pagination: PaginationParams = Depends(get_pagination_params),
    filters: FilterParams = Depends(get_filter_params),
    sort: SortParams = Depends(get_sort_params),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> PaginatedResponse[UserResponse]:
    """Get paginated list of users with filtering and sorting."""
    try:
        user_service = UserService(db)
        
        result = await user_service.list(
            pagination=pagination,
            filters=filters,
            sort=sort
        )
        
        user_responses = []
        for user in result.items:
            user_data = user.to_dict()
            user_data["display_name"] = user.display_name
            user_data["is_locked"] = user.is_locked
            user_data["can_login"] = user.can_login
            user_data["permissions"] = user.get_permissions()
            user_responses.append(UserResponse(**user_data))
        
        return PaginatedResponse(
            items=user_responses,
            pagination=result.pagination
        )
        
    except Exception as e:
        logger.error(f"Error listing users: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve users"
        )


@router.post(
    "/",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create User",
    description="Create a new user account",
    dependencies=[Depends(require_permissions("user:create"))]
)
async def create_user(
    user_data: UserCreate,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserResponse:
    """Create a new user account."""
    try:
        user_service = UserService(db)
        
        user = await user_service.create(
            obj_in=user_data,
            current_user_id=uuid.UUID(current_user["id"])
        )
        
        user_data_dict = user.to_dict()
        user_data_dict["display_name"] = user.display_name
        user_data_dict["is_locked"] = user.is_locked
        user_data_dict["can_login"] = user.can_login
        user_data_dict["permissions"] = user.get_permissions()
        
        logger.info(f"User created: {user.email} by {current_user['id']}")
        
        return UserResponse(**user_data_dict)
        
    except ValidationException as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "Validation Error", "message": str(e)}
        )
    except BusinessLogicException as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "Business Logic Error", "message": str(e)}
        )
    except Exception as e:
        logger.error(f"Error creating user: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create user"
        )


@router.get(
    "/{user_id}",
    response_model=UserResponse,
    summary="Get User",
    description="Get specific user by ID",
    dependencies=[Depends(require_permissions("user:read"))]
)
async def get_user(
    user_id: uuid.UUID = Path(..., description="User ID"),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session),
    include_archived: bool = Query(False, description="Include archived users")
) -> UserResponse:
    """Get user by ID."""
    try:
        user_service = UserService(db)
        
        user = await user_service.get(user_id, include_archived=include_archived)
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"error": "User Not Found", "message": f"User with ID {user_id} not found"}
            )
        
        user_data = user.to_dict()
        user_data["display_name"] = user.display_name
        user_data["is_locked"] = user.is_locked
        user_data["can_login"] = user.can_login
        user_data["permissions"] = user.get_permissions()
        
        return UserResponse(**user_data)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve user"
        )


@router.patch(
    "/{user_id}",
    response_model=UserResponse,
    summary="Update User",
    description="Update user information (partial update)",
    dependencies=[Depends(require_permissions("user:update"))]
)
async def update_user(
    user_id: uuid.UUID = Path(..., description="User ID"),
    user_update: UserUpdate = None,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserResponse:
    """Update user information."""
    try:
        user_service = UserService(db)
        
        user = await user_service.update(
            id=user_id,
            obj_in=user_update,
            current_user_id=uuid.UUID(current_user["id"])
        )
        
        user_data = user.to_dict()
        user_data["display_name"] = user.display_name
        user_data["is_locked"] = user.is_locked
        user_data["can_login"] = user.can_login
        user_data["permissions"] = user.get_permissions()
        
        return UserResponse(**user_data)
        
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "User Not Found", "message": f"User with ID {user_id} not found"}
        )
    except ValidationException as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "Validation Error", "message": str(e)}
        )
    except BusinessLogicException as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "Business Logic Error", "message": str(e)}
        )
    except Exception as e:
        logger.error(f"Error updating user: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update user"
        )


@router.delete(
    "/{user_id}",
    response_model=SuccessResponse,
    summary="Delete User",
    description="Delete user account (soft delete)",
    dependencies=[Depends(require_permissions("user:delete"))]
)
async def delete_user(
    user_id: uuid.UUID = Path(..., description="User ID"),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session),
    hard_delete: bool = Query(False, description="Perform hard delete (permanent)")
) -> SuccessResponse:
    """Delete user account."""
    try:
        user_service = UserService(db)
        
        success = await user_service.delete(
            id=user_id,
            current_user_id=uuid.UUID(current_user["id"]),
            soft_delete=not hard_delete
        )
        
        if success:
            delete_type = "permanently deleted" if hard_delete else "archived"
            return SuccessResponse(
                message=f"User has been {delete_type} successfully",
                data={"user_id": str(user_id), "hard_delete": hard_delete}
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete user"
            )
            
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "User Not Found", "message": f"User with ID {user_id} not found"}
        )
    except BusinessLogicException as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "Business Logic Error", "message": str(e)}
        )
    except Exception as e:
        logger.error(f"Error deleting user: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete user"
        )


@router.post(
    "/{user_id}/restore",
    response_model=UserResponse,
    summary="Restore User",
    description="Restore soft-deleted user account",
    dependencies=[Depends(require_permissions("user:create"))]
)
async def restore_user(
    user_id: uuid.UUID = Path(..., description="User ID"),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserResponse:
    """Restore a soft-deleted user account."""
    try:
        user_service = UserService(db)
        
        user = await user_service.restore(
            id=user_id,
            current_user_id=uuid.UUID(current_user["id"])
        )
        
        user_data = user.to_dict()
        user_data["display_name"] = user.display_name
        user_data["is_locked"] = user.is_locked
        user_data["can_login"] = user.can_login
        user_data["permissions"] = user.get_permissions()
        
        return UserResponse(**user_data)
        
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "User Not Found", "message": f"User with ID {user_id} not found"}
        )
    except BusinessLogicException as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "Business Logic Error", "message": str(e)}
        )
    except Exception as e:
        logger.error(f"Error restoring user: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to restore user"
        )


@router.get(
    "/search",
    response_model=PaginatedResponse[UserResponse],
    summary="Search Users",
    description="Search users by name or email",
    dependencies=[Depends(require_permissions("user:read"))]
)
async def search_users(
    q: str = Query(..., description="Search query", min_length=1),
    pagination: PaginationParams = Depends(get_pagination_params),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session),
    include_archived: bool = Query(False, description="Include archived users")
) -> PaginatedResponse[UserResponse]:
    """Search users by name or email."""
    try:
        user_service = UserService(db)
        
        result = await user_service.search_users(
            search_term=q,
            pagination=pagination,
            include_archived=include_archived
        )
        
        user_responses = []
        for user in result.items:
            user_data = user.to_dict()
            user_data["display_name"] = user.display_name
            user_data["is_locked"] = user.is_locked
            user_data["can_login"] = user.can_login
            user_data["permissions"] = user.get_permissions()
            user_responses.append(UserResponse(**user_data))
        
        return PaginatedResponse(
            items=user_responses,
            pagination=result.pagination
        )
        
    except Exception as e:
        logger.error(f"Error searching users: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search users"
        )


@router.patch(
    "/{user_id}/password",
    response_model=SuccessResponse,
    summary="Change User Password",
    description="Change user's password"
)
async def change_user_password(
    user_id: uuid.UUID = Path(..., description="User ID"),
    password_change: UserPasswordChange = None,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> SuccessResponse:
    """Change user's password."""
    try:
        user_service = UserService(db)
        
        # Check permissions
        current_user_id = uuid.UUID(current_user["id"])
        if str(user_id) != current_user["id"] and not current_user.get("is_superuser", False):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only change your own password"
            )
        
        success = await user_service.change_password(
            user_id=user_id,
            password_change=password_change,
            current_user_id=current_user_id
        )
        
        if success:
            return SuccessResponse(
                message="Password changed successfully",
                data={"user_id": str(user_id)}
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to change password"
            )
            
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    except AuthenticationException as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "Authentication Failed", "message": str(e)}
        )
    except ValidationException as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"error": "Validation Error", "message": str(e)}
        )
    except Exception as e:
        logger.error(f"Error changing password: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to change password"
        )


@router.patch(
    "/{user_id}/preferences",
    response_model=UserResponse,
    summary="Update User Preferences",
    description="Update user preferences and settings"
)
async def update_user_preferences(
    user_id: uuid.UUID = Path(..., description="User ID"),
    preferences: UserPreferences = None,
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserResponse:
    """Update user preferences."""
    try:
        user_service = UserService(db)
        
        # Check permissions
        current_user_id = uuid.UUID(current_user["id"])
        if str(user_id) != current_user["id"] and not current_user.get("is_superuser", False):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only update your own preferences"
            )
        
        user = await user_service.update_preferences(
            user_id=user_id,
            preferences=preferences,
            current_user_id=current_user_id
        )
        
        user_data = user.to_dict()
        user_data["display_name"] = user.display_name
        user_data["is_locked"] = user.is_locked
        user_data["can_login"] = user.can_login
        user_data["permissions"] = user.get_permissions()
        
        return UserResponse(**user_data)
        
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    except Exception as e:
        logger.error(f"Error updating preferences: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update preferences"
        )


@router.post(
    "/{user_id}/unlock",
    response_model=UserResponse,
    summary="Unlock User Account",
    description="Unlock locked user account",
    dependencies=[Depends(require_permissions("user:update"))]
)
async def unlock_user_account(
    user_id: uuid.UUID = Path(..., description="User ID"),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserResponse:
    """Unlock a locked user account."""
    try:
        user_service = UserService(db)
        
        user = await user_service.unlock_user(
            user_id=user_id,
            unlocked_by=uuid.UUID(current_user["id"])
        )
        
        user_data = user.to_dict()
        user_data["display_name"] = user.display_name
        user_data["is_locked"] = user.is_locked
        user_data["can_login"] = user.can_login
        user_data["permissions"] = user.get_permissions()
        
        return UserResponse(**user_data)
        
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    except Exception as e:
        logger.error(f"Error unlocking user: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to unlock user"
        )


@router.post(
    "/{user_id}/verify-email",
    response_model=UserResponse,
    summary="Verify User Email",
    description="Mark user's email as verified",
    dependencies=[Depends(require_permissions("user:update"))]
)
async def verify_user_email(
    user_id: uuid.UUID = Path(..., description="User ID"),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserResponse:
    """Manually verify user's email address."""
    try:
        user_service = UserService(db)
        
        user = await user_service.verify_email(
            user_id=user_id,
            verified_by=uuid.UUID(current_user["id"])
        )
        
        user_data = user.to_dict()
        user_data["display_name"] = user.display_name
        user_data["is_locked"] = user.is_locked
        user_data["can_login"] = user.can_login
        user_data["permissions"] = user.get_permissions()
        
        return UserResponse(**user_data)
        
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    except Exception as e:
        logger.error(f"Error verifying email: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to verify email"
        )


@router.get(
    "/{user_id}/profile",
    response_model=UserProfile,
    summary="Get User Profile",
    description="Get user profile information (subset of user data)"
)
async def get_user_profile(
    user_id: uuid.UUID = Path(..., description="User ID"),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserProfile:
    """Get user profile information."""
    try:
        user_service = UserService(db)
        
        # Check permissions
        current_user_id = current_user["id"]
        if str(user_id) != current_user_id:
            user_permissions = current_user.get("permissions", [])
            if "user:read" not in user_permissions and not current_user.get("is_superuser", False):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Insufficient permissions to view this profile"
                )
        
        user = await user_service.get_or_404(user_id)
        
        profile_data = {
            "id": user.id,
            "email": user.email,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "display_name": user.display_name,
            "avatar_url": user.avatar_url,
            "bio": user.bio,
            "timezone": user.timezone,
            "language": user.language,
            "is_verified": user.is_verified
        }
        
        return UserProfile(**profile_data)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user profile: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get user profile"
        )


@router.get(
    "/{user_id}/public",
    response_model=UserPublic,
    summary="Get Public User Info",
    description="Get public user information (minimal data)"
)
async def get_public_user_info(
    user_id: uuid.UUID = Path(..., description="User ID"),
    db: AsyncSession = Depends(get_async_db_session)
) -> UserPublic:
    """Get public user information."""
    try:
        user_service = UserService(db)
        
        user = await user_service.get_or_404(user_id)
        
        if not user.is_active or user.is_archived:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        public_data = {
            "id": user.id,
            "display_name": user.display_name,
            "avatar_url": user.avatar_url,
            "bio": user.bio
        }
        
        return UserPublic(**public_data)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting public user info: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get public user information"
        )


@router.get(
    "/{user_id}/permissions",
    response_model=Dict[str, Any],
    summary="Get User Permissions",
    description="Get user's effective permissions",
    dependencies=[Depends(require_permissions("user:read"))]
)
async def get_user_permissions(
    user_id: uuid.UUID = Path(..., description="User ID"),
    current_user: Dict[str, Any] = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_db_session),
    company_id: Optional[uuid.UUID] = Query(None, description="Company context for permissions")
) -> Dict[str, Any]:
    """Get user's effective permissions."""
    try:
        user_service = UserService(db)
        
        permissions = await user_service.get_user_permissions(
            user_id=user_id,
            company_id=company_id
        )
        
        user = await user_service.get_or_404(user_id)
        
        return {
            "user_id": str(user_id),
            "permissions": permissions,
            "roles": [role.name for role in user.roles] if user.roles else [],
            "is_superuser": user.is_superuser,
            "company_id": str(company_id) if company_id else None,
            "total_permissions": len(permissions)
        }
        
    except ResourceNotFoundException:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    except Exception as e:
        logger.error(f"Error getting user permissions: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get user permissions"
        )


# Export the router
__all__ = ["router"]