"""
Authentication API package.
"""

try:
    from .auth import router as auth_router
except ImportError as e:
    print(f"Warning: Could not import auth router: {e}")
    # Create a minimal fallback router
    from fastapi import APIRouter
    auth_router = APIRouter()
    
    @auth_router.get("/status")
    async def auth_status():
        return {"status": "auth module not fully loaded"}

try:
    from .users import router as users_router
except ImportError as e:
    print(f"Warning: Could not import users router: {e}")
    from fastapi import APIRouter
    users_router = APIRouter()
    
    @users_router.get("/status")
    async def users_status():
        return {"status": "users module not fully loaded"}

try:
    from .roles import router as roles_router
except ImportError as e:
    print(f"Warning: Could not import roles router: {e}")
    from fastapi import APIRouter
    roles_router = APIRouter()
    
    @roles_router.get("/status")
    async def roles_status():
        return {"status": "roles module not fully loaded"}

__all__ = ["auth_router", "users_router", "roles_router"]