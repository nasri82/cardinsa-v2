"""
CARDINSA Insurance Backend Application Package
"""

__version__ = "1.0.0"
__title__ = "CARDINSA Insurance Backend"
__description__ = "Comprehensive Insurance Management Platform"
__author__ = "CARDINSA Team"

# Package metadata
__all__ = [
    "__version__",
    "__title__",
    "__description__",
    "__author__",
]