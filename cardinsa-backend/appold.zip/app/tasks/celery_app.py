# app/tasks/celery_app.py
from celery import Celery
from app.config.settings import get_settings

settings = get_settings()

celery_app = Celery(
    "cardinsa",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=[
        "app.tasks.email_tasks",
        "app.tasks.billing_tasks",
        "app.tasks.underwriting_tasks",
        "app.tasks.analytics_tasks",
    ]
)