"""
Company Service

Business logic for company management, multi-tenant operations,
system configuration, and company lifecycle management.
"""

import logging
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional, Dict, Any, List, Tuple
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, select, update, delete
from sqlalchemy.exc import IntegrityError

from app.models.company import Company, SystemConfiguration
from app.models.auth import User
from app.core.exceptions import (
    ValidationError, NotFoundError, DuplicateError,
    BusinessLogicError, UnauthorizedError
)
from app.services.base import BaseService

logger = logging.getLogger(__name__)


class CompanyService(BaseService[Company]):
    """
    Company Service
    
    Handles all company-related operations including creation, configuration,
    multi-tenant data management, and company lifecycle operations.
    """
    
    def __init__(self, db: Session):
        super().__init__(Company, db)
        self.db = db
    
    async def create_company(
        self,
        company_data: Dict[str, Any],
        admin_user_data: Optional[Dict[str, Any]] = None,
        current_user_id: Optional[UUID] = None
    ) -> Tuple[Company, Optional[User]]:
        """
        Create a new company with optional admin user
        
        Args:
            company_data: Company information
            admin_user_data: Admin user information (optional)
            current_user_id: ID of user creating the company
            
        Returns:
            Tuple of (Company, Admin User or None)
            
        Raises:
            ValidationError: If data validation fails
            DuplicateError: If company already exists
            BusinessLogicError: If business rules are violated
        """
        try:
            # Validate company data
            self._validate_company_data(company_data)
            
            # Check for duplicates
            await self._check_company_duplicates(company_data)
            
            # Generate company code if not provided
            if not company_data.get("company_code"):
                company_data["company_code"] = await self._generate_company_code(
                    company_data["company_name"]
                )
            
            # Set default values
            company_data.update({
                "onboarding_status": "in_progress",
                "company_status": "active",
                "setup_date": datetime.utcnow(),
                "created_by": current_user_id
            })
            
            # Create company
            company = Company(**company_data)
            self.db.add(company)
            self.db.flush()  # Get the ID without committing
            
            # Create system configuration
            await self._create_default_system_configuration(company.id, current_user_id)
            
            # Create admin user if provided
            admin_user = None
            if admin_user_data:
                admin_user = await self._create_company_admin(
                    company.id, 
                    admin_user_data, 
                    current_user_id
                )
            
            self.db.commit()
            
            logger.info(f"Company created successfully: {company.id}")
            return company, admin_user
            
        except IntegrityError as e:
            self.db.rollback()
            logger.error(f"Database integrity error creating company: {e}")
            raise DuplicateError("Company with this information already exists")
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error creating company: {e}")
            raise
    
    async def get_company_by_code(self, company_code: str) -> Optional[Company]:
        """
        Get company by company code
        
        Args:
            company_code: Unique company code
            
        Returns:
            Company if found, None otherwise
        """
        return self.db.query(Company).filter(
            Company.company_code == company_code,
            Company.archived_at.is_(None)
        ).first()
    
    async def update_company(
        self,
        company_id: UUID,
        update_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Company:
        """
        Update company information
        
        Args:
            company_id: Company ID to update
            update_data: Updated company data
            current_user_id: ID of user making the update
            
        Returns:
            Updated company
            
        Raises:
            NotFoundError: If company not found
            ValidationError: If data validation fails
            UnauthorizedError: If user lacks permission
        """
        try:
            # Get company
            company = await self.get_by_id(company_id)
            if not company:
                raise NotFoundError(f"Company {company_id} not found")
            
            # Validate permissions
            await self._validate_company_access(company_id, current_user_id, "update")
            
            # Validate update data
            self._validate_company_update_data(update_data, company)
            
            # Check for conflicts on unique fields
            if "company_code" in update_data and update_data["company_code"] != company.company_code:
                await self._check_company_code_availability(update_data["company_code"], company_id)
            
            # Update company
            for field, value in update_data.items():
                if hasattr(company, field):
                    setattr(company, field, value)
            
            company.updated_by = current_user_id
            company.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"Company updated successfully: {company_id}")
            return company
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error updating company {company_id}: {e}")
            raise
    
    async def get_system_configuration(self, company_id: UUID) -> SystemConfiguration:
        """
        Get system configuration for a company
        
        Args:
            company_id: Company ID
            
        Returns:
            System configuration
            
        Raises:
            NotFoundError: If configuration not found
        """
        config = self.db.query(SystemConfiguration).filter(
            SystemConfiguration.company_id == company_id,
            SystemConfiguration.archived_at.is_(None)
        ).first()
        
        if not config:
            raise NotFoundError(f"System configuration for company {company_id} not found")
        
        return config
    
    async def update_system_configuration(
        self,
        company_id: UUID,
        config_updates: Dict[str, Any],
        current_user_id: UUID
    ) -> SystemConfiguration:
        """
        Update system configuration for a company
        
        Args:
            company_id: Company ID
            config_updates: Configuration updates
            current_user_id: ID of user making the update
            
        Returns:
            Updated system configuration
            
        Raises:
            NotFoundError: If configuration not found
            UnauthorizedError: If user lacks permission
            ValidationError: If data validation fails
        """
        try:
            # Validate permissions
            await self._validate_company_access(company_id, current_user_id, "configure")
            
            # Get configuration
            config = await self.get_system_configuration(company_id)
            
            # Validate configuration updates
            self._validate_configuration_updates(config_updates)
            
            # Update configuration
            for category, settings in config_updates.items():
                if hasattr(config, category):
                    current_settings = getattr(config, category) or {}
                    if isinstance(settings, dict):
                        current_settings.update(settings)
                        setattr(config, category, current_settings)
                    else:
                        setattr(config, category, settings)
            
            config.updated_by = current_user_id
            config.updated_at = datetime.utcnow()
            config.last_configuration_update = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"System configuration updated for company: {company_id}")
            return config
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error updating system configuration for company {company_id}: {e}")
            raise
    
    async def get_company_statistics(self, company_id: UUID) -> Dict[str, Any]:
        """
        Get comprehensive statistics for a company
        
        Args:
            company_id: Company ID
            
        Returns:
            Dictionary containing company statistics
        """
        # Get basic company info
        company = await self.get_by_id(company_id)
        if not company:
            raise NotFoundError(f"Company {company_id} not found")
        
        # Get user statistics
        user_stats = self.db.query(
            func.count(User.id).label("total_users"),
            func.count(User.id).filter(User.is_active == True).label("active_users"),
            func.count(User.id).filter(User.last_login.isnot(None)).label("users_with_logins")
        ).filter(User.company_id == company_id).first()
        
        # Get department statistics
        from app.models.company import Department
        dept_stats = self.db.query(
            func.count(Department.id).label("total_departments"),
            func.count(Department.id).filter(Department.department_status == "active").label("active_departments")
        ).filter(Department.company_id == company_id).first()
        
        # Calculate company age
        setup_date = company.setup_date or company.created_at
        company_age_days = (datetime.utcnow() - setup_date).days if setup_date else 0
        
        return {
            "company_info": {
                "id": str(company.id),
                "name": company.company_name,
                "code": company.company_code,
                "status": company.company_status,
                "subscription_tier": company.subscription_tier,
                "setup_date": setup_date,
                "company_age_days": company_age_days,
                "last_activity": company.last_activity_date
            },
            "user_statistics": {
                "total_users": user_stats.total_users or 0,
                "active_users": user_stats.active_users or 0,
                "users_with_logins": user_stats.users_with_logins or 0
            },
            "organizational_statistics": {
                "total_departments": dept_stats.total_departments or 0,
                "active_departments": dept_stats.active_departments or 0
            },
            "features": {
                "enabled_features": company.enabled_features or [],
                "feature_limits": company.feature_limits or {}
            }
        }
    
    async def activate_company(self, company_id: UUID, current_user_id: UUID) -> Company:
        """
        Activate a company and complete onboarding
        
        Args:
            company_id: Company ID to activate
            current_user_id: ID of user performing activation
            
        Returns:
            Activated company
        """
        try:
            company = await self.get_by_id(company_id)
            if not company:
                raise NotFoundError(f"Company {company_id} not found")
            
            # Validate permissions
            await self._validate_company_access(company_id, current_user_id, "activate")
            
            # Check prerequisites for activation
            await self._validate_activation_prerequisites(company)
            
            # Activate company
            company.company_status = "active"
            company.onboarding_status = "completed"
            company.go_live_date = datetime.utcnow()
            company.updated_by = current_user_id
            company.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"Company activated successfully: {company_id}")
            return company
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error activating company {company_id}: {e}")
            raise
    
    async def suspend_company(
        self,
        company_id: UUID,
        reason: str,
        current_user_id: UUID
    ) -> Company:
        """
        Suspend a company
        
        Args:
            company_id: Company ID to suspend
            reason: Reason for suspension
            current_user_id: ID of user performing suspension
            
        Returns:
            Suspended company
        """
        try:
            company = await self.get_by_id(company_id)
            if not company:
                raise NotFoundError(f"Company {company_id} not found")
            
            # Validate permissions
            await self._validate_company_access(company_id, current_user_id, "suspend")
            
            # Suspend company
            company.company_status = "suspended"
            company.updated_by = current_user_id
            company.updated_at = datetime.utcnow()
            
            # Add suspension note
            suspension_note = f"Suspended on {datetime.utcnow().isoformat()} by user {current_user_id}. Reason: {reason}"
            company.notes = f"{company.notes}\n{suspension_note}" if company.notes else suspension_note
            
            self.db.commit()
            
            logger.warning(f"Company suspended: {company_id}, Reason: {reason}")
            return company
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error suspending company {company_id}: {e}")
            raise
    
    async def search_companies(
        self,
        search_params: Dict[str, Any],
        current_user_id: UUID,
        page: int = 1,
        page_size: int = 50
    ) -> Dict[str, Any]:
        """
        Search companies with filters and pagination
        
        Args:
            search_params: Search and filter parameters
            current_user_id: ID of user performing search
            page: Page number (1-based)
            page_size: Number of items per page
            
        Returns:
            Dictionary containing search results and metadata
        """
        # Build base query
        query = self.db.query(Company).filter(Company.archived_at.is_(None))
        
        # Apply filters
        if search_params.get("name"):
            query = query.filter(Company.company_name.ilike(f"%{search_params['name']}%"))
        
        if search_params.get("code"):
            query = query.filter(Company.company_code.ilike(f"%{search_params['code']}%"))
        
        if search_params.get("status"):
            query = query.filter(Company.company_status == search_params["status"])
        
        if search_params.get("subscription_tier"):
            query = query.filter(Company.subscription_tier == search_params["subscription_tier"])
        
        if search_params.get("country_id"):
            query = query.filter(Company.primary_country_id == search_params["country_id"])
        
        # Date filters
        if search_params.get("created_after"):
            query = query.filter(Company.created_at >= search_params["created_after"])
        
        if search_params.get("created_before"):
            query = query.filter(Company.created_at <= search_params["created_before"])
        
        # Get total count
        total_count = query.count()
        
        # Apply pagination and sorting
        offset = (page - 1) * page_size
        sort_field = search_params.get("sort_by", "company_name")
        sort_order = search_params.get("sort_order", "asc")
        
        if hasattr(Company, sort_field):
            sort_column = getattr(Company, sort_field)
            if sort_order.lower() == "desc":
                sort_column = sort_column.desc()
            query = query.order_by(sort_column)
        
        companies = query.offset(offset).limit(page_size).all()
        
        return {
            "companies": companies,
            "pagination": {
                "page": page,
                "page_size": page_size,
                "total_count": total_count,
                "total_pages": (total_count + page_size - 1) // page_size,
                "has_next": page * page_size < total_count,
                "has_previous": page > 1
            },
            "search_params": search_params
        }
    
    # Private helper methods
    
    def _validate_company_data(self, company_data: Dict[str, Any]) -> None:
        """Validate company creation data"""
        required_fields = ["company_name", "legal_name"]
        
        for field in required_fields:
            if not company_data.get(field):
                raise ValidationError(f"Field '{field}' is required")
        
        # Validate email format
        if company_data.get("primary_email"):
            import re
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            if not re.match(email_pattern, company_data["primary_email"]):
                raise ValidationError("Invalid email format")
        
        # Validate currency code
        if company_data.get("base_currency"):
            valid_currencies = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY"]
            if company_data["base_currency"] not in valid_currencies:
                raise ValidationError(f"Unsupported currency: {company_data['base_currency']}")
    
    async def _check_company_duplicates(self, company_data: Dict[str, Any]) -> None:
        """Check for duplicate companies"""
        # Check company name
        existing = self.db.query(Company).filter(
            Company.company_name == company_data["company_name"],
            Company.archived_at.is_(None)
        ).first()
        
        if existing:
            raise DuplicateError(f"Company with name '{company_data['company_name']}' already exists")
        
        # Check registration number
        if company_data.get("registration_number"):
            existing = self.db.query(Company).filter(
                Company.registration_number == company_data["registration_number"],
                Company.archived_at.is_(None)
            ).first()
            
            if existing:
                raise DuplicateError(f"Company with registration number '{company_data['registration_number']}' already exists")
    
    async def _generate_company_code(self, company_name: str) -> str:
        """Generate unique company code from company name"""
        import re
        
        # Clean company name and create base code
        clean_name = re.sub(r'[^a-zA-Z0-9\s]', '', company_name)
        words = clean_name.split()
        
        if len(words) >= 2:
            base_code = ''.join(word[:2].upper() for word in words[:3])
        else:
            base_code = clean_name[:6].upper()
        
        # Ensure uniqueness
        counter = 1
        company_code = base_code
        
        while True:
            existing = self.db.query(Company).filter(
                Company.company_code == company_code,
                Company.archived_at.is_(None)
            ).first()
            
            if not existing:
                break
            
            company_code = f"{base_code}{counter:02d}"
            counter += 1
            
            if counter > 99:
                # Fallback to timestamp-based code
                import time
                company_code = f"{base_code[:4]}{int(time.time()) % 10000:04d}"
                break
        
        return company_code
    
    async def _create_default_system_configuration(
        self,
        company_id: UUID,
        created_by: Optional[UUID]
    ) -> SystemConfiguration:
        """Create default system configuration for new company"""
        default_config = {
            "company_id": company_id,
            "created_by": created_by,
            "password_policy": {
                "min_length": 12,
                "require_uppercase": True,
                "require_lowercase": True,
                "require_numbers": True,
                "require_symbols": True,
                "max_age_days": 90
            },
            "session_settings": {
                "session_timeout_minutes": 480,
                "max_concurrent_sessions": 5,
                "require_device_verification": True
            },
            "mfa_requirements": {
                "required_for_admin": True,
                "required_for_all": False,
                "allowed_methods": ["totp", "sms", "email"]
            },
            "security_settings": {
                "lockout_threshold": 5,
                "lockout_duration_minutes": 30,
                "require_password_change_on_first_login": True
            }
        }
        
        config = SystemConfiguration(**default_config)
        self.db.add(config)
        return config
    
    async def _create_company_admin(
        self,
        company_id: UUID,
        admin_data: Dict[str, Any],
        created_by: Optional[UUID]
    ) -> User:
        """Create admin user for new company"""
        # This would integrate with user service
        # For now, return None as placeholder
        return None
    
    async def _validate_company_access(
        self,
        company_id: UUID,
        user_id: UUID,
        action: str
    ) -> None:
        """Validate user has permission to perform action on company"""
        # Implementation would check user permissions
        # For now, pass validation
        pass
    
    def _validate_company_update_data(
        self,
        update_data: Dict[str, Any],
        company: Company
    ) -> None:
        """Validate company update data"""
        # Prevent changing critical fields inappropriately
        protected_fields = ["company_code"]
        
        for field in protected_fields:
            if field in update_data and field == "company_code":
                # Special validation for company code changes
                if company.company_status != "pending_setup":
                    raise ValidationError("Company code cannot be changed after setup")
    
    async def _check_company_code_availability(
        self,
        company_code: str,
        exclude_company_id: Optional[UUID] = None
    ) -> None:
        """Check if company code is available"""
        query = self.db.query(Company).filter(
            Company.company_code == company_code,
            Company.archived_at.is_(None)
        )
        
        if exclude_company_id:
            query = query.filter(Company.id != exclude_company_id)
        
        existing = query.first()
        if existing:
            raise DuplicateError(f"Company code '{company_code}' is already in use")
    
    def _validate_configuration_updates(self, config_updates: Dict[str, Any]) -> None:
        """Validate system configuration updates"""
        # Validate password policy
        if "password_policy" in config_updates:
            policy = config_updates["password_policy"]
            if policy.get("min_length", 0) < 8:
                raise ValidationError("Minimum password length must be at least 8 characters")
        
        # Validate session settings
        if "session_settings" in config_updates:
            settings = config_updates["session_settings"]
            if settings.get("session_timeout_minutes", 0) < 5:
                raise ValidationError("Session timeout must be at least 5 minutes")
    
    async def _validate_activation_prerequisites(self, company: Company) -> None:
        """Validate company can be activated"""
        if company.company_status == "active":
            raise BusinessLogicError("Company is already active")
        
        if not company.primary_email:
            raise ValidationError("Primary email is required for activation")
        
        # Check if company has at least one admin user
        admin_count = self.db.query(User).filter(
            User.company_id == company.id,
            User.is_active == True
        ).count()
        
        if admin_count == 0:
            raise ValidationError("Company must have at least one active admin user for activation")