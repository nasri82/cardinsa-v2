"""
Localization Service

Business logic for multi-language support, translation management,
locale configuration, and language preferences.
"""

import logging
from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, List, Tuple
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, select, update, delete
from sqlalchemy.exc import IntegrityError

from app.models.company import Language, Translation, Locale, LanguageKey, LanguageSetting
from app.models.auth import User
from app.models.company import Company
from app.core.exceptions import (
    ValidationError, NotFoundError, DuplicateError,
    BusinessLogicError, UnauthorizedError
)
from app.services.base import BaseService

logger = logging.getLogger(__name__)


class LocalizationService:
    """
    Localization Service
    
    Handles all localization operations including language management,
    translation services, locale configuration, and user preferences.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    # Language Management
    
    async def get_all_languages(
        self,
        active_only: bool = True,
        supported_only: bool = False
    ) -> List[Language]:
        """
        Get all languages with optional filtering
        
        Args:
            active_only: Return only active languages
            supported_only: Return only supported languages
            
        Returns:
            List of languages ordered by priority
        """
        query = self.db.query(Language)
        
        if active_only:
            query = query.filter(Language.is_active == True)
        
        if supported_only:
            query = query.filter(Language.is_supported == True)
        
        return query.order_by(
            Language.display_priority.asc(),
            Language.language_name
        ).all()
    
    async def get_language_by_code(self, language_code: str) -> Optional[Language]:
        """
        Get language by language code
        
        Args:
            language_code: Language code (e.g., 'en', 'fr', 'ar')
            
        Returns:
            Language if found, None otherwise
        """
        return self.db.query(Language).filter(
            Language.language_code == language_code,
            Language.is_active == True
        ).first()
    
    async def create_language(
        self,
        language_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Language:
        """
        Create a new language
        
        Args:
            language_data: Language information
            current_user_id: ID of user creating the language
            
        Returns:
            Created language
            
        Raises:
            ValidationError: If data validation fails
            DuplicateError: If language already exists
        """
        try:
            # Validate language data
            self._validate_language_data(language_data)
            
            # Check for duplicates
            await self._check_language_duplicates(language_data)
            
            # Set defaults
            language_data.update({
                "created_by": current_user_id,
                "is_active": language_data.get("is_active", True),
                "is_supported": language_data.get("is_supported", False),
                "completion_percentage": Decimal("0.0")
            })
            
            # Create language
            language = Language(**language_data)
            self.db.add(language)
            self.db.commit()
            
            logger.info(f"Language created: {language.language_code}")
            return language
            
        except IntegrityError as e:
            self.db.rollback()
            logger.error(f"Database integrity error creating language: {e}")
            raise DuplicateError("Language with this code already exists")
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error creating language: {e}")
            raise
    
    async def update_language(
        self,
        language_id: UUID,
        update_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Language:
        """
        Update language information
        
        Args:
            language_id: Language ID to update
            update_data: Updated language data
            current_user_id: ID of user making the update
            
        Returns:
            Updated language
            
        Raises:
            NotFoundError: If language not found
            ValidationError: If data validation fails
        """
        try:
            # Get language
            language = self.db.query(Language).filter(
                Language.id == language_id,
                Language.archived_at.is_(None)
            ).first()
            
            if not language:
                raise NotFoundError(f"Language {language_id} not found")
            
            # Validate update data
            if "language_code" in update_data and update_data["language_code"] != language.language_code:
                await self._check_language_code_availability(update_data["language_code"], language_id)
            
            # Update language
            for field, value in update_data.items():
                if hasattr(language, field):
                    setattr(language, field, value)
            
            language.updated_by = current_user_id
            language.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"Language updated: {language.language_code}")
            return language
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error updating language {language_id}: {e}")
            raise
    
    # Translation Management
    
    async def get_translations(
        self,
        language_code: str,
        module: Optional[str] = None,
        context: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Get translations for a language
        
        Args:
            language_code: Language code
            module: Optional module filter
            context: Optional context filter
            
        Returns:
            Dictionary of translation key-value pairs
        """
        language = await self.get_language_by_code(language_code)
        if not language:
            raise NotFoundError(f"Language {language_code} not found")
        
        query = self.db.query(Translation).filter(
            Translation.language_id == language.id,
            Translation.translation_status.in_(["approved", "published"]),
            Translation.archived_at.is_(None)
        )
        
        if module:
            query = query.filter(Translation.module == module)
        
        if context:
            query = query.filter(Translation.context == context)
        
        translations = query.all()
        
        return {
            translation.translation_key: translation.translation_value
            for translation in translations
        }
    
    async def get_translation(
        self,
        key: str,
        language_code: str,
        default: Optional[str] = None
    ) -> Optional[str]:
        """
        Get a specific translation
        
        Args:
            key: Translation key
            language_code: Language code
            default: Default value if translation not found
            
        Returns:
            Translation value or default
        """
        language = await self.get_language_by_code(language_code)
        if not language:
            return default
        
        translation = self.db.query(Translation).filter(
            Translation.translation_key == key,
            Translation.language_id == language.id,
            Translation.translation_status.in_(["approved", "published"]),
            Translation.archived_at.is_(None)
        ).first()
        
        if translation:
            # Update usage statistics
            translation.usage_count += 1
            translation.last_used = datetime.utcnow()
            self.db.commit()
            
            return translation.translation_value
        
        return default
    
    async def create_translation(
        self,
        translation_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Translation:
        """
        Create a new translation
        
        Args:
            translation_data: Translation information
            current_user_id: ID of user creating the translation
            
        Returns:
            Created translation
            
        Raises:
            ValidationError: If data validation fails
            NotFoundError: If language not found
        """
        try:
            # Validate translation data
            self._validate_translation_data(translation_data)
            
            # Get language
            language = await self.get_language_by_code(translation_data["language_code"])
            if not language:
                raise NotFoundError(f"Language {translation_data['language_code']} not found")
            
            # Create or update language key
            await self._ensure_language_key_exists(
                translation_data["translation_key"],
                translation_data.get("context"),
                translation_data.get("module"),
                current_user_id
            )
            
            # Check for existing translation
            existing = self.db.query(Translation).filter(
                Translation.translation_key == translation_data["translation_key"],
                Translation.language_id == language.id,
                Translation.archived_at.is_(None)
            ).first()
            
            if existing:
                # Create new version
                version = existing.version + 1
                existing.previous_version_id = existing.id
            else:
                version = 1
            
            # Prepare translation data
            translation_data.update({
                "language_id": language.id,
                "translator_id": current_user_id,
                "translated_at": datetime.utcnow(),
                "version": version,
                "character_count": len(translation_data["translation_value"]),
                "word_count": len(translation_data["translation_value"].split())
            })
            
            # Create translation
            translation = Translation(**translation_data)
            self.db.add(translation)
            self.db.commit()
            
            # Update language completion percentage
            await self._update_language_completion(language.id)
            
            logger.info(f"Translation created: {translation_data['translation_key']} for {language.language_code}")
            return translation
            
        except IntegrityError as e:
            self.db.rollback()
            logger.error(f"Database integrity error creating translation: {e}")
            raise DuplicateError("Translation already exists")
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error creating translation: {e}")
            raise
    
    async def update_translation(
        self,
        translation_id: UUID,
        update_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Translation:
        """
        Update a translation
        
        Args:
            translation_id: Translation ID to update
            update_data: Updated translation data
            current_user_id: ID of user making the update
            
        Returns:
            Updated translation
        """
        try:
            # Get translation
            translation = self.db.query(Translation).filter(
                Translation.id == translation_id,
                Translation.archived_at.is_(None)
            ).first()
            
            if not translation:
                raise NotFoundError(f"Translation {translation_id} not found")
            
            # Update translation
            for field, value in update_data.items():
                if hasattr(translation, field):
                    setattr(translation, field, value)
            
            # Update metadata
            if "translation_value" in update_data:
                translation.character_count = len(update_data["translation_value"])
                translation.word_count = len(update_data["translation_value"].split())
            
            translation.updated_by = current_user_id
            translation.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            # Update language completion percentage
            await self._update_language_completion(translation.language_id)
            
            logger.info(f"Translation updated: {translation.translation_key}")
            return translation
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error updating translation {translation_id}: {e}")
            raise
    
    async def approve_translation(
        self,
        translation_id: UUID,
        approver_id: UUID,
        comments: Optional[str] = None
    ) -> Translation:
        """
        Approve a translation
        
        Args:
            translation_id: Translation ID to approve
            approver_id: ID of user approving the translation
            comments: Optional approval comments
            
        Returns:
            Approved translation
        """
        try:
            translation = self.db.query(Translation).filter(
                Translation.id == translation_id,
                Translation.archived_at.is_(None)
            ).first()
            
            if not translation:
                raise NotFoundError(f"Translation {translation_id} not found")
            
            if translation.translation_status == "approved":
                raise BusinessLogicError("Translation is already approved")
            
            # Approve translation
            translation.translation_status = "approved"
            translation.approved_by = approver_id
            translation.approved_at = datetime.utcnow()
            
            if comments:
                translation.reviewer_comments = comments
            
            self.db.commit()
            
            logger.info(f"Translation approved: {translation.translation_key}")
            return translation
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error approving translation {translation_id}: {e}")
            raise
    
    async def bulk_import_translations(
        self,
        language_code: str,
        translations: Dict[str, str],
        module: Optional[str] = None,
        current_user_id: UUID = None
    ) -> Dict[str, Any]:
        """
        Import multiple translations at once
        
        Args:
            language_code: Target language code
            translations: Dictionary of key-value translations
            module: Optional module for all translations
            current_user_id: ID of user importing translations
            
        Returns:
            Import result summary
        """
        result = {
            "imported": 0,
            "updated": 0,
            "errors": 0,
            "details": []
        }
        
        language = await self.get_language_by_code(language_code)
        if not language:
            raise NotFoundError(f"Language {language_code} not found")
        
        for key, value in translations.items():
            try:
                translation_data = {
                    "translation_key": key,
                    "language_code": language_code,
                    "translation_value": value,
                    "module": module,
                    "translation_status": "draft"
                }
                
                # Check if translation exists
                existing = self.db.query(Translation).filter(
                    Translation.translation_key == key,
                    Translation.language_id == language.id,
                    Translation.archived_at.is_(None)
                ).first()
                
                if existing:
                    # Update existing
                    existing.translation_value = value
                    existing.updated_by = current_user_id
                    existing.updated_at = datetime.utcnow()
                    result["updated"] += 1
                else:
                    # Create new
                    await self.create_translation(translation_data, current_user_id)
                    result["imported"] += 1
                
            except Exception as e:
                result["errors"] += 1
                result["details"].append(f"Error importing '{key}': {str(e)}")
                logger.error(f"Error importing translation '{key}': {e}")
        
        # Update language completion
        await self._update_language_completion(language.id)
        
        return result
    
    # Locale Management
    
    async def get_all_locales(self, active_only: bool = True) -> List[Locale]:
        """
        Get all locales
        
        Args:
            active_only: Return only active locales
            
        Returns:
            List of locales
        """
        query = self.db.query(Locale)
        
        if active_only:
            query = query.filter(Locale.is_active == True)
        
        return query.order_by(Locale.usage_priority, Locale.locale_name).all()
    
    async def get_locale_by_code(self, locale_code: str) -> Optional[Locale]:
        """
        Get locale by locale code
        
        Args:
            locale_code: Locale code (e.g., 'en_US', 'fr_FR')
            
        Returns:
            Locale if found, None otherwise
        """
        return self.db.query(Locale).filter(
            Locale.locale_code == locale_code,
            Locale.is_active == True
        ).first()
    
    async def get_locales_by_language(self, language_code: str) -> List[Locale]:
        """
        Get locales for a specific language
        
        Args:
            language_code: Language code
            
        Returns:
            List of locales for the language
        """
        language = await self.get_language_by_code(language_code)
        if not language:
            return []
        
        return self.db.query(Locale).filter(
            Locale.language_id == language.id,
            Locale.is_active == True
        ).order_by(Locale.usage_priority).all()
    
    # Language Settings and Preferences
    
    async def get_user_language_settings(self, user_id: UUID) -> Optional[LanguageSetting]:
        """
        Get language settings for a user
        
        Args:
            user_id: User ID
            
        Returns:
            User language settings if found
        """
        return self.db.query(LanguageSetting).filter(
            LanguageSetting.user_id == user_id,
            LanguageSetting.is_active == True,
            LanguageSetting.archived_at.is_(None)
        ).first()
    
    async def get_company_language_settings(self, company_id: UUID) -> Optional[LanguageSetting]:
        """
        Get language settings for a company
        
        Args:
            company_id: Company ID
            
        Returns:
            Company language settings if found
        """
        return self.db.query(LanguageSetting).filter(
            LanguageSetting.company_id == company_id,
            LanguageSetting.is_active == True,
            LanguageSetting.archived_at.is_(None)
        ).first()
    
    async def set_user_language_preference(
        self,
        user_id: UUID,
        language_code: str,
        locale_code: Optional[str] = None,
        additional_settings: Optional[Dict[str, Any]] = None
    ) -> LanguageSetting:
        """
        Set language preference for a user
        
        Args:
            user_id: User ID
            language_code: Preferred language code
            locale_code: Optional locale code
            additional_settings: Additional language settings
            
        Returns:
            Updated or created language settings
        """
        try:
            # Get language
            language = await self.get_language_by_code(language_code)
            if not language:
                raise NotFoundError(f"Language {language_code} not found")
            
            # Get or create language settings
            settings = await self.get_user_language_settings(user_id)
            
            if settings:
                # Update existing
                settings.preferred_language_id = language.id
                settings.preferred_locale = locale_code
                settings.last_language_change = datetime.utcnow()
                settings.updated_at = datetime.utcnow()
            else:
                # Create new
                settings_data = {
                    "user_id": user_id,
                    "preferred_language_id": language.id,
                    "preferred_locale": locale_code,
                    "last_language_change": datetime.utcnow()
                }
                
                if additional_settings:
                    settings_data.update(additional_settings)
                
                settings = LanguageSetting(**settings_data)
                self.db.add(settings)
            
            # Apply additional settings
            if additional_settings:
                for field, value in additional_settings.items():
                    if hasattr(settings, field):
                        setattr(settings, field, value)
            
            self.db.commit()
            
            logger.info(f"User language preference updated: {user_id} -> {language_code}")
            return settings
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error setting user language preference: {e}")
            raise
    
    async def get_effective_language(
        self,
        user_id: Optional[UUID] = None,
        company_id: Optional[UUID] = None
    ) -> str:
        """
        Get effective language for a user or company
        
        Args:
            user_id: Optional user ID
            company_id: Optional company ID
            
        Returns:
            Effective language code
        """
        # Try user preference first
        if user_id:
            user_settings = await self.get_user_language_settings(user_id)
            if user_settings and user_settings.language:
                return user_settings.language.language_code
        
        # Try company preference
        if company_id:
            company_settings = await self.get_company_language_settings(company_id)
            if company_settings and company_settings.language:
                return company_settings.language.language_code
        
        # Default to English
        return "en"
    
    # Translation Analytics and Management
    
    async def get_translation_statistics(
        self,
        language_code: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get translation statistics
        
        Args:
            language_code: Optional language filter
            
        Returns:
            Translation statistics
        """
        stats = {}
        
        # Overall statistics
        total_keys = self.db.query(func.count(LanguageKey.id)).scalar()
        
        # Language-specific statistics
        if language_code:
            language = await self.get_language_by_code(language_code)
            if not language:
                raise NotFoundError(f"Language {language_code} not found")
            
            translation_stats = self.db.query(
                func.count(Translation.id).label("total"),
                func.count(Translation.id).filter(Translation.translation_status == "approved").label("approved"),
                func.count(Translation.id).filter(Translation.translation_status == "draft").label("draft"),
                func.count(Translation.id).filter(Translation.translation_status == "review").label("review")
            ).filter(Translation.language_id == language.id).first()
            
            completion_percentage = (translation_stats.approved / total_keys * 100) if total_keys > 0 else 0
            
            stats = {
                "language": language_code,
                "total_keys": total_keys,
                "translated": translation_stats.total or 0,
                "approved": translation_stats.approved or 0,
                "draft": translation_stats.draft or 0,
                "review": translation_stats.review or 0,
                "completion_percentage": round(completion_percentage, 2)
            }
        else:
            # All languages statistics
            languages = await self.get_all_languages(supported_only=True)
            stats["languages"] = []
            
            for language in languages:
                lang_stats = self.db.query(
                    func.count(Translation.id).label("total"),
                    func.count(Translation.id).filter(Translation.translation_status == "approved").label("approved")
                ).filter(Translation.language_id == language.id).first()
                
                completion = (lang_stats.approved / total_keys * 100) if total_keys > 0 else 0
                
                stats["languages"].append({
                    "code": language.language_code,
                    "name": language.language_name,
                    "translated": lang_stats.total or 0,
                    "approved": lang_stats.approved or 0,
                    "completion_percentage": round(completion, 2)
                })
            
            stats["total_keys"] = total_keys
        
        return stats
    
    async def get_missing_translations(
        self,
        language_code: str,
        module: Optional[str] = None,
        limit: int = 100
    ) -> List[LanguageKey]:
        """
        Get translation keys that are missing for a language
        
        Args:
            language_code: Language code
            module: Optional module filter
            limit: Maximum number of results
            
        Returns:
            List of missing translation keys
        """
        language = await self.get_language_by_code(language_code)
        if not language:
            raise NotFoundError(f"Language {language_code} not found")
        
        # Get all keys that don't have approved translations
        subquery = self.db.query(Translation.translation_key).filter(
            Translation.language_id == language.id,
            Translation.translation_status == "approved"
        ).subquery()
        
        query = self.db.query(LanguageKey).filter(
            LanguageKey.is_deprecated == False,
            ~LanguageKey.key_name.in_(select(subquery.c.translation_key))
        )
        
        if module:
            query = query.filter(LanguageKey.module == module)
        
        return query.order_by(
            LanguageKey.translation_priority.desc(),
            LanguageKey.usage_count.desc()
        ).limit(limit).all()
    
    # Private helper methods
    
    def _validate_language_data(self, language_data: Dict[str, Any]) -> None:
        """Validate language creation data"""
        required_fields = ["language_code", "language_name", "native_name"]
        
        for field in required_fields:
            if not language_data.get(field):
                raise ValidationError(f"Field '{field}' is required")
        
        # Validate language code format
        language_code = language_data["language_code"]
        if not language_code.isalpha() or len(language_code) not in [2, 3]:
            raise ValidationError("Language code must be 2 or 3 letters")
        
        # Validate text direction
        if language_data.get("text_direction") not in ["ltr", "rtl"]:
            language_data["text_direction"] = "ltr"
    
    async def _check_language_duplicates(self, language_data: Dict[str, Any]) -> None:
        """Check for duplicate languages"""
        existing = self.db.query(Language).filter(
            Language.language_code == language_data["language_code"],
            Language.archived_at.is_(None)
        ).first()
        
        if existing:
            raise DuplicateError(f"Language with code '{language_data['language_code']}' already exists")
    
    async def _check_language_code_availability(
        self,
        language_code: str,
        exclude_language_id: Optional[UUID] = None
    ) -> None:
        """Check if language code is available"""
        query = self.db.query(Language).filter(
            Language.language_code == language_code,
            Language.archived_at.is_(None)
        )
        
        if exclude_language_id:
            query = query.filter(Language.id != exclude_language_id)
        
        existing = query.first()
        if existing:
            raise DuplicateError(f"Language code '{language_code}' is already in use")
    
    def _validate_translation_data(self, translation_data: Dict[str, Any]) -> None:
        """Validate translation data"""
        required_fields = ["translation_key", "translation_value"]
        
        for field in required_fields:
            if not translation_data.get(field):
                raise ValidationError(f"Field '{field}' is required")
        
        # Validate translation key format
        key = translation_data["translation_key"]
        if not key.replace("_", "").replace(".", "").replace("-", "").isalnum():
            raise ValidationError("Translation key can only contain letters, numbers, dots, hyphens, and underscores")
    
    async def _ensure_language_key_exists(
        self,
        key_name: str,
        context: Optional[str],
        module: Optional[str],
        user_id: UUID
    ) -> LanguageKey:
        """Ensure language key exists, create if not"""
        language_key = self.db.query(LanguageKey).filter(
            LanguageKey.key_name == key_name
        ).first()
        
        if not language_key:
            key_data = {
                "key_name": key_name,
                "context": context,
                "module": module,
                "created_by": user_id,
                "usage_count": 0,
                "first_used": datetime.utcnow()
            }
            
            language_key = LanguageKey(**key_data)
            self.db.add(language_key)
            self.db.flush()
        
        # Update usage statistics
        language_key.usage_count += 1
        language_key.last_used = datetime.utcnow()
        
        return language_key
    
    async def _update_language_completion(self, language_id: UUID) -> None:
        """Update completion percentage for a language"""
        # Get total keys
        total_keys = self.db.query(func.count(LanguageKey.id)).filter(
            LanguageKey.is_deprecated == False
        ).scalar()
        
        if total_keys == 0:
            return
        
        # Get approved translations for this language
        approved_count = self.db.query(func.count(Translation.id)).filter(
            Translation.language_id == language_id,
            Translation.translation_status == "approved"
        ).scalar()
        
        # Calculate completion percentage
        completion = Decimal(str((approved_count / total_keys) * 100))
        
        # Update language
        language = self.db.query(Language).filter(Language.id == language_id).first()
        if language:
            language.completion_percentage = completion
            language.last_translation_update = datetime.utcnow()