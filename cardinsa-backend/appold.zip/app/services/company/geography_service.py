"""
Geography Service

Business logic for geographic data management, location services,
address validation, and geographic-based operations.
"""

import logging
from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, List, Tuple
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, select, text
from sqlalchemy.exc import IntegrityError

from app.models.company import Country, Region, City, State
from app.core.exceptions import (
    ValidationError, NotFoundError, DuplicateError,
    BusinessLogicError
)
from app.services.base import BaseService

logger = logging.getLogger(__name__)


class GeographyService:
    """
    Geography Service
    
    Handles all geographic data operations including country/region/city management,
    address validation, location-based services, and geographic analytics.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    # Country Management
    
    async def get_all_countries(
        self,
        active_only: bool = True,
        supported_only: bool = False
    ) -> List[Country]:
        """
        Get all countries with optional filtering
        
        Args:
            active_only: Return only active countries
            supported_only: Return only countries where we provide services
            
        Returns:
            List of countries
        """
        query = self.db.query(Country)
        
        if active_only:
            query = query.filter(Country.is_active == True)
        
        if supported_only:
            query = query.filter(Country.is_supported == True)
        
        return query.order_by(Country.country_name).all()
    
    async def get_country_by_iso(self, iso_code: str) -> Optional[Country]:
        """
        Get country by ISO code (2 or 3 letter)
        
        Args:
            iso_code: ISO 2 or 3 letter country code
            
        Returns:
            Country if found, None otherwise
        """
        if len(iso_code) == 2:
            return self.db.query(Country).filter(
                Country.iso_alpha_2 == iso_code.upper(),
                Country.is_active == True
            ).first()
        elif len(iso_code) == 3:
            return self.db.query(Country).filter(
                Country.iso_alpha_3 == iso_code.upper(),
                Country.is_active == True
            ).first()
        else:
            raise ValidationError("ISO code must be 2 or 3 characters")
    
    async def search_countries(
        self,
        search_term: str,
        limit: int = 10
    ) -> List[Country]:
        """
        Search countries by name
        
        Args:
            search_term: Search term to match against country names
            limit: Maximum number of results
            
        Returns:
            List of matching countries
        """
        return self.db.query(Country).filter(
            or_(
                Country.country_name.ilike(f"%{search_term}%"),
                Country.country_name_local.ilike(f"%{search_term}%")
            ),
            Country.is_active == True
        ).order_by(Country.country_name).limit(limit).all()
    
    async def get_countries_by_region(self, region_name: str) -> List[Country]:
        """
        Get countries by geographic region
        
        Args:
            region_name: Geographic region name
            
        Returns:
            List of countries in the region
        """
        return self.db.query(Country).filter(
            Country.region == region_name,
            Country.is_active == True
        ).order_by(Country.country_name).all()
    
    # Region Management
    
    async def get_regions_by_country(
        self,
        country_id: UUID,
        active_only: bool = True
    ) -> List[Region]:
        """
        Get all regions for a specific country
        
        Args:
            country_id: Country ID
            active_only: Return only active regions
            
        Returns:
            List of regions
        """
        query = self.db.query(Region).filter(Region.country_id == country_id)
        
        if active_only:
            query = query.filter(Region.is_active == True)
        
        return query.order_by(Region.region_name).all()
    
    async def get_region_by_code(
        self,
        country_id: UUID,
        region_code: str
    ) -> Optional[Region]:
        """
        Get region by country and region code
        
        Args:
            country_id: Country ID
            region_code: Region code
            
        Returns:
            Region if found, None otherwise
        """
        return self.db.query(Region).filter(
            Region.country_id == country_id,
            Region.region_code == region_code,
            Region.is_active == True
        ).first()
    
    async def search_regions(
        self,
        country_id: UUID,
        search_term: str,
        limit: int = 10
    ) -> List[Region]:
        """
        Search regions within a country
        
        Args:
            country_id: Country ID to search within
            search_term: Search term
            limit: Maximum number of results
            
        Returns:
            List of matching regions
        """
        return self.db