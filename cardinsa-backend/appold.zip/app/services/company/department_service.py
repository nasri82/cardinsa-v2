"""
Department Service

Business logic for organizational structure management, including
departments, units, user assignments, and hierarchical operations.
"""

import logging
from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, List, Tuple
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, select, update, delete
from sqlalchemy.exc import IntegrityError

from app.models.company import Department, Unit
from app.models.auth import User
from app.core.exceptions import (
    ValidationError, NotFoundError, DuplicateError,
    BusinessLogicError, UnauthorizedError
)
from app.services.base import BaseService

logger = logging.getLogger(__name__)


class DepartmentService:
    """
    Department Service
    
    Handles all organizational structure operations including department
    and unit management, user assignments, and hierarchical operations.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    # Department Management
    
    async def create_department(
        self,
        department_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Department:
        """
        Create a new department
        
        Args:
            department_data: Department information
            current_user_id: ID of user creating the department
            
        Returns:
            Created department
            
        Raises:
            ValidationError: If data validation fails
            DuplicateError: If department already exists
            BusinessLogicError: If business rules are violated
        """
        try:
            # Validate department data
            self._validate_department_data(department_data)
            
            # Check for duplicates
            await self._check_department_duplicates(department_data)
            
            # Validate parent department if specified
            if department_data.get("parent_department_id"):
                await self._validate_parent_department(
                    department_data["parent_department_id"],
                    department_data["company_id"]
                )
            
            # Generate department code if not provided
            if not department_data.get("department_code"):
                department_data["department_code"] = await self._generate_department_code(
                    department_data["department_name"],
                    department_data["company_id"]
                )
            
            # Calculate department level and path
            level, path = await self._calculate_department_hierarchy(
                department_data.get("parent_department_id")
            )
            
            # Set defaults
            department_data.update({
                "created_by": current_user_id,
                "department_level": level,
                "department_status": "active",
                "current_headcount": 0
            })
            
            # Create department
            department = Department(**department_data)
            self.db.add(department)
            self.db.flush()  # Get the ID
            
            # Update department path with actual ID
            department.department_path = f"{path}{department.id}/"
            
            self.db.commit()
            
            logger.info(f"Department created: {department.department_name} ({department.id})")
            return department
            
        except IntegrityError as e:
            self.db.rollback()
            logger.error(f"Database integrity error creating department: {e}")
            raise DuplicateError("Department with this code already exists")
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error creating department: {e}")
            raise
    
    async def get_department_by_id(self, department_id: UUID) -> Optional[Department]:
        """
        Get department by ID
        
        Args:
            department_id: Department ID
            
        Returns:
            Department if found, None otherwise
        """
        return self.db.query(Department).filter(
            Department.id == department_id,
            Department.archived_at.is_(None)
        ).first()
    
    async def get_departments_by_company(
        self,
        company_id: UUID,
        active_only: bool = True,
        include_hierarchy: bool = False
    ) -> List[Department]:
        """
        Get departments by company
        
        Args:
            company_id: Company ID
            active_only: Return only active departments
            include_hierarchy: Include hierarchical structure
            
        Returns:
            List of departments
        """
        query = self.db.query(Department).filter(
            Department.company_id == company_id,
            Department.archived_at.is_(None)
        )
        
        if active_only:
            query = query.filter(Department.department_status == "active")
        
        if include_hierarchy:
            # Order by level and path for hierarchical display
            departments = query.order_by(
                Department.department_level,
                Department.department_path
            ).all()
        else:
            departments = query.order_by(Department.department_name).all()
        
        return departments
    
    async def get_department_hierarchy(
        self,
        company_id: UUID,
        root_department_id: Optional[UUID] = None
    ) -> Dict[str, Any]:
        """
        Get department hierarchy tree
        
        Args:
            company_id: Company ID
            root_department_id: Optional root department to start from
            
        Returns:
            Hierarchical department tree
        """
        # Get all departments
        query = self.db.query(Department).filter(
            Department.company_id == company_id,
            Department.department_status == "active",
            Department.archived_at.is_(None)
        )
        
        if root_department_id:
            # Get departments under the specified root
            root_dept = await self.get_department_by_id(root_department_id)
            if root_dept:
                query = query.filter(
                    Department.department_path.like(f"{root_dept.department_path}%")
                )
        
        departments = query.order_by(Department.department_level, Department.department_name).all()
        
        # Build hierarchy tree
        return self._build_department_tree(departments, root_department_id)
    
    async def update_department(
        self,
        department_id: UUID,
        update_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Department:
        """
        Update department information
        
        Args:
            department_id: Department ID to update
            update_data: Updated department data
            current_user_id: ID of user making the update
            
        Returns:
            Updated department
            
        Raises:
            NotFoundError: If department not found
            ValidationError: If data validation fails
            BusinessLogicError: If business rules are violated
        """
        try:
            # Get department
            department = await self.get_department_by_id(department_id)
            if not department:
                raise NotFoundError(f"Department {department_id} not found")
            
            # Validate update data
            self._validate_department_update_data(update_data, department)
            
            # Handle parent department change
            if "parent_department_id" in update_data:
                await self._handle_parent_change(department, update_data["parent_department_id"])
            
            # Update department
            for field, value in update_data.items():
                if hasattr(department, field) and field not in ["department_path", "department_level"]:
                    setattr(department, field, value)
            
            department.updated_by = current_user_id
            department.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"Department updated: {department.department_name}")
            return department
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error updating department {department_id}: {e}")
            raise
    
    async def assign_head_of_department(
        self,
        department_id: UUID,
        user_id: UUID,
        current_user_id: UUID
    ) -> Department:
        """
        Assign head of department
        
        Args:
            department_id: Department ID
            user_id: User ID to assign as head
            current_user_id: ID of user making the assignment
            
        Returns:
            Updated department
        """
        try:
            department = await self.get_department_by_id(department_id)
            if not department:
                raise NotFoundError(f"Department {department_id} not found")
            
            # Validate user belongs to the company
            user = self.db.query(User).filter(
                User.id == user_id,
                User.company_id == department.company_id,
                User.is_active == True
            ).first()
            
            if not user:
                raise ValidationError("User not found or not in the same company")
            
            # Update department head
            department.head_of_department_id = user_id
            department.updated_by = current_user_id
            department.updated_at = datetime.utcnow()
            
            self.db.commit()
            
            logger.info(f"Head of department assigned: {user_id} to {department_id}")
            return department
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Error assigning head of department: {e}")
            raise
    
    # Unit Management
    
    async def create_unit(
        self,
        unit_data: Dict[str, Any],
        current_user_id: UUID
    ) -> Unit:
        """
        Create a new unit within a department
        
        Args:
            unit_data: Unit information
            current_user_id: ID of user creating the unit
            
        Returns:
            Created unit
            
        Raises:
            ValidationError: If data validation fails
            NotFoundError: If department not found
            DuplicateError: If unit already exists
        """