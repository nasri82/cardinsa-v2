"""
Base Service Classes for CARDINSA Insurance Platform

This module provides base service classes that establish patterns for:
- Business logic layer structure
- Database operation management
- Transaction handling
- Error management
- Logging and audit trails
- Common CRUD operations
- Validation and authorization
"""

import uuid
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type, TypeVar, Generic, Union, Tuple
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, select, update, delete, func
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from ..models.base import BaseModel, CompanyIsolatedModel
from ..schemas.base import (
    BaseSchema,
    BaseCreateSchema, 
    BaseUpdateSchema,
    PaginationParams,
    PaginationInfo,
    PaginatedResponse,
    FilterParams,
    SortParams
)
from ..core.exceptions import (
    BusinessLogicException,
    ValidationException,
    ResourceNotFoundException,
    DatabaseException
)
from ..core.dependencies import (
    apply_pagination_to_query,
    apply_sorting_to_query,
    apply_filters_to_query
)

# Type variables for generic service classes
ModelType = TypeVar("ModelType", bound=BaseModel)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseCreateSchema)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseUpdateSchema)
SchemaType = TypeVar("SchemaType", bound=BaseSchema)

# Initialize logger
logger = logging.getLogger(__name__)


class BaseService(ABC, Generic[ModelType, CreateSchemaType, UpdateSchemaType, SchemaType]):
    """
    Abstract base service class that provides common business logic patterns.
    
    This class establishes the structure for all business services including:
    - CRUD operations
    - Transaction management
    - Validation
    - Authorization
    - Audit logging
    """
    
    def __init__(self, model: Type[ModelType], db_session: AsyncSession):
        """
        Initialize the base service.
        
        Args:
            model: SQLAlchemy model class
            db_session: Database session
        """
        self.model = model
        self.db = db_session
        self.logger = logging.getLogger(f"{self.__class__.__module__}.{self.__class__.__name__}")
    
    @property
    @abstractmethod
    def entity_name(self) -> str:
        """Name of the entity for logging and error messages."""
        pass
    
    async def create(
        self,
        obj_in: CreateSchemaType,
        current_user_id: Optional[uuid.UUID] = None,
        company_id: Optional[uuid.UUID] = None,
        **kwargs
    ) -> ModelType:
        """
        Create a new entity.
        
        Args:
            obj_in: Input data for creating the entity
            current_user_id: ID of the user creating the entity
            company_id: Company ID for multi-tenant isolation
            **kwargs: Additional fields to set on the model
            
        Returns:
            ModelType: Created entity
            
        Raises:
            ValidationException: If input data is invalid
            BusinessLogicException: If business rules are violated
            DatabaseException: If database operation fails
        """
        try:
            # Convert Pydantic model to dict
            create_data = obj_in.dict(exclude_unset=True)
            
            # Add audit fields
            if current_user_id:
                create_data["created_by"] = current_user_id
                create_data["updated_by"] = current_user_id
            
            # Add company isolation if model supports it
            if company_id and issubclass(self.model, CompanyIsolatedModel):
                create_data["company_id"] = company_id
            
            # Add any additional kwargs
            create_data.update(kwargs)
            
            # Perform pre-creation validation
            await self._validate_create(create_data, current_user_id)
            
            # Create the model instance
            db_obj = self.model(**create_data)
            
            # Add to session and flush to get ID
            self.db.add(db_obj)
            await self.db.flush()
            
            # Perform post-creation actions
            await self._post_create_actions(db_obj, current_user_id)
            
            # Commit the transaction
            await self.db.commit()
            await self.db.refresh(db_obj)
            
            self.logger.info(
                f"Created {self.entity_name}",
                extra={
                    "entity_id": str(db_obj.id),
                    "created_by": str(current_user_id) if current_user_id else None,
                    "company_id": str(company_id) if company_id else None
                }
            )
            
            return db_obj
            
        except IntegrityError as e:
            await self.db.rollback()
            self.logger.error(f"Integrity error creating {self.entity_name}: {str(e)}")
            raise BusinessLogicException(f"Failed to create {self.entity_name}: constraint violation")
        
        except SQLAlchemyError as e:
            await self.db.rollback()
            self.logger.error(f"Database error creating {self.entity_name}: {str(e)}")
            raise DatabaseException(f"Database operation failed", operation="CREATE", table=self.model.__tablename__)
        
        except Exception as e:
            await self.db.rollback()
            self.logger.error(f"Unexpected error creating {self.entity_name}: {str(e)}")
            raise BusinessLogicException(f"Failed to create {self.entity_name}: {str(e)}")
    
    async def get(
        self,
        id: uuid.UUID,
        company_id: Optional[uuid.UUID] = None,
        include_archived: bool = False
    ) -> Optional[ModelType]:
        """
        Get an entity by ID.
        
        Args:
            id: Entity ID
            company_id: Company ID for multi-tenant filtering
            include_archived: Include archived (soft-deleted) records
            
        Returns:
            Optional[ModelType]: Found entity or None
        """
        try:
            query = select(self.model).where(self.model.id == id)
            
            # Apply company filtering if model supports it
            if company_id and issubclass(self.model, CompanyIsolatedModel):
                query = query.where(self.model.company_id == company_id)
            
            # Apply archived filtering
            if not include_archived and hasattr(self.model, 'archived_at'):
                query = query.where(self.model.archived_at.is_(None))
            
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
            
        except SQLAlchemyError as e:
            self.logger.error(f"Database error getting {self.entity_name}: {str(e)}")
            raise DatabaseException(f"Database operation failed", operation="SELECT", table=self.model.__tablename__)
    
    async def get_or_404(
        self,
        id: uuid.UUID,
        company_id: Optional[uuid.UUID] = None,
        include_archived: bool = False
    ) -> ModelType:
        """
        Get an entity by ID or raise 404 if not found.
        
        Args:
            id: Entity ID
            company_id: Company ID for multi-tenant filtering
            include_archived: Include archived records
            
        Returns:
            ModelType: Found entity
            
        Raises:
            ResourceNotFoundException: If entity not found
        """
        entity = await self.get(id, company_id, include_archived)
        if not entity:
            raise ResourceNotFoundException(
                f"{self.entity_name} not found",
                resource_type=self.entity_name.lower(),
                resource_id=str(id)
            )
        return entity
    
    async def list(
        self,
        pagination: Optional[PaginationParams] = None,
        filters: Optional[FilterParams] = None,
        sort: Optional[SortParams] = None,
        company_id: Optional[uuid.UUID] = None
    ) -> PaginatedResponse[SchemaType]:
        """
        List entities with pagination, filtering, and sorting.
        
        Args:
            pagination: Pagination parameters
            filters: Filter parameters
            sort: Sort parameters
            company_id: Company ID for multi-tenant filtering
            
        Returns:
            PaginatedResponse[SchemaType]: Paginated list of entities
        """
        try:
            # Build base query
            query = select(self.model)
            
            # Apply company filtering if model supports it
            if company_id and issubclass(self.model, CompanyIsolatedModel):
                query = query.where(self.model.company_id == company_id)
            
            # Apply filters
            if filters:
                query = apply_filters_to_query(query, self.model, filters)
                # Apply entity-specific filters
                query = await self._apply_custom_filters(query, filters)
            
            # Get total count before pagination
            count_query = select(func.count()).select_from(query.subquery())
            total_result = await self.db.execute(count_query)
            total = total_result.scalar()
            
            # Apply sorting
            if sort:
                query = apply_sorting_to_query(query, self.model, sort)
            else:
                # Default sorting by created_at desc
                query = query.order_by(self.model.created_at.desc())
            
            # Apply pagination
            if pagination:
                query = apply_pagination_to_query(query, pagination)
            else:
                pagination = PaginationParams(page=1, size=20)
            
            # Execute query
            result = await self.db.execute(query)
            entities = result.scalars().all()
            
            # Calculate pagination info
            pages = (total + pagination.size - 1) // pagination.size
            pagination_info = PaginationInfo(
                page=pagination.page,
                size=pagination.size,
                total=total,
                pages=pages,
                has_next=pagination.page < pages,
                has_prev=pagination.page > 1
            )
            
            return PaginatedResponse(
                items=entities,
                pagination=pagination_info
            )
            
        except SQLAlchemyError as e:
            self.logger.error(f"Database error listing {self.entity_name}: {str(e)}")
            raise DatabaseException(f"Database operation failed", operation="SELECT", table=self.model.__tablename__)
    
    async def update(
        self,
        id: uuid.UUID,
        obj_in: UpdateSchemaType,
        current_user_id: Optional[uuid.UUID] = None,
        company_id: Optional[uuid.UUID] = None
    ) -> ModelType:
        """
        Update an entity.
        
        Args:
            id: Entity ID to update
            obj_in: Update data
            current_user_id: ID of the user updating the entity
            company_id: Company ID for multi-tenant filtering
            
        Returns:
            ModelType: Updated entity
            
        Raises:
            ResourceNotFoundException: If entity not found
            ValidationException: If input data is invalid
            BusinessLogicException: If business rules are violated
        """
        try:
            # Get existing entity
            db_obj = await self.get_or_404(id, company_id)
            
            # Convert update data to dict, excluding unset fields
            update_data = obj_in.dict(exclude_unset=True)
            
            # Add audit fields
            if current_user_id:
                update_data["updated_by"] = current_user_id
            
            # Perform pre-update validation
            await self._validate_update(db_obj, update_data, current_user_id)
            
            # Apply updates
            for field, value in update_data.items():
                if hasattr(db_obj, field):
                    setattr(db_obj, field, value)
            
            # Perform post-update actions
            await self._post_update_actions(db_obj, current_user_id)
            
            # Commit the transaction
            await self.db.commit()
            await self.db.refresh(db_obj)
            
            self.logger.info(
                f"Updated {self.entity_name}",
                extra={
                    "entity_id": str(db_obj.id),
                    "updated_by": str(current_user_id) if current_user_id else None,
                    "updated_fields": list(update_data.keys())
                }
            )
            
            return db_obj
            
        except (ResourceNotFoundException, ValidationException, BusinessLogicException):
            await self.db.rollback()
            raise
        
        except IntegrityError as e:
            await self.db.rollback()
            self.logger.error(f"Integrity error updating {self.entity_name}: {str(e)}")
            raise BusinessLogicException(f"Failed to update {self.entity_name}: constraint violation")
        
        except SQLAlchemyError as e:
            await self.db.rollback()
            self.logger.error(f"Database error updating {self.entity_name}: {str(e)}")
            raise DatabaseException(f"Database operation failed", operation="UPDATE", table=self.model.__tablename__)
    
    async def delete(
        self,
        id: uuid.UUID,
        current_user_id: Optional[uuid.UUID] = None,
        company_id: Optional[uuid.UUID] = None,
        soft_delete: bool = True
    ) -> bool:
        """
        Delete an entity (soft delete by default).
        
        Args:
            id: Entity ID to delete
            current_user_id: ID of the user deleting the entity
            company_id: Company ID for multi-tenant filtering
            soft_delete: Use soft delete (archive) instead of hard delete
            
        Returns:
            bool: True if deleted successfully
            
        Raises:
            ResourceNotFoundException: If entity not found
            BusinessLogicException: If deletion is not allowed
        """
        try:
            # Get existing entity
            db_obj = await self.get_or_404(id, company_id)
            
            # Perform pre-deletion validation
            await self._validate_delete(db_obj, current_user_id)
            
            if soft_delete and hasattr(db_obj, 'archive'):
                # Soft delete (archive)
                db_obj.archive(current_user_id)
                delete_type = "archived"
            else:
                # Hard delete
                await self.db.delete(db_obj)
                delete_type = "deleted"
            
            # Perform post-deletion actions
            await self._post_delete_actions(db_obj, current_user_id, soft_delete)
            
            # Commit the transaction
            await self.db.commit()
            
            self.logger.info(
                f"{delete_type.title()} {self.entity_name}",
                extra={
                    "entity_id": str(id),
                    "deleted_by": str(current_user_id) if current_user_id else None,
                    "soft_delete": soft_delete
                }
            )
            
            return True
            
        except (ResourceNotFoundException, BusinessLogicException):
            await self.db.rollback()
            raise
        
        except SQLAlchemyError as e:
            await self.db.rollback()
            self.logger.error(f"Database error deleting {self.entity_name}: {str(e)}")
            raise DatabaseException(f"Database operation failed", operation="DELETE", table=self.model.__tablename__)
    
    async def restore(
        self,
        id: uuid.UUID,
        current_user_id: Optional[uuid.UUID] = None,
        company_id: Optional[uuid.UUID] = None
    ) -> ModelType:
        """
        Restore a soft-deleted entity.
        
        Args:
            id: Entity ID to restore
            current_user_id: ID of the user restoring the entity
            company_id: Company ID for multi-tenant filtering
            
        Returns:
            ModelType: Restored entity
            
        Raises:
            ResourceNotFoundException: If entity not found
            BusinessLogicException: If entity is not archived
        """
        try:
            # Get archived entity
            db_obj = await self.get_or_404(id, company_id, include_archived=True)
            
            if not hasattr(db_obj, 'restore'):
                raise BusinessLogicException(f"{self.entity_name} does not support soft delete/restore")
            
            if not db_obj.is_archived:
                raise BusinessLogicException(f"{self.entity_name} is not archived")
            
            # Restore the entity
            db_obj.restore(current_user_id)
            
            # Commit the transaction
            await self.db.commit()
            await self.db.refresh(db_obj)
            
            self.logger.info(
                f"Restored {self.entity_name}",
                extra={
                    "entity_id": str(id),
                    "restored_by": str(current_user_id) if current_user_id else None
                }
            )
            
            return db_obj
            
        except (ResourceNotFoundException, BusinessLogicException):
            await self.db.rollback()
            raise
        
        except SQLAlchemyError as e:
            await self.db.rollback()
            self.logger.error(f"Database error restoring {self.entity_name}: {str(e)}")
            raise DatabaseException(f"Database operation failed", operation="UPDATE", table=self.model.__tablename__)
    
    # Hook methods for customization in child classes
    async def _validate_create(
        self,
        create_data: Dict[str, Any],
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Perform custom validation before creating an entity.
        Override in child classes to add specific validation logic.
        """
        pass
    
    async def _validate_update(
        self,
        db_obj: ModelType,
        update_data: Dict[str, Any],
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Perform custom validation before updating an entity.
        Override in child classes to add specific validation logic.
        """
        pass
    
    async def _validate_delete(
        self,
        db_obj: ModelType,
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Perform custom validation before deleting an entity.
        Override in child classes to add specific validation logic.
        """
        pass
    
    async def _post_create_actions(
        self,
        db_obj: ModelType,
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Perform actions after creating an entity.
        Override in child classes to add specific post-creation logic.
        """
        pass
    
    async def _post_update_actions(
        self,
        db_obj: ModelType,
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Perform actions after updating an entity.
        Override in child classes to add specific post-update logic.
        """
        pass
    
    async def _post_delete_actions(
        self,
        db_obj: ModelType,
        current_user_id: Optional[uuid.UUID],
        soft_delete: bool
    ) -> None:
        """
        Perform actions after deleting an entity.
        Override in child classes to add specific post-deletion logic.
        """
        pass
    
    async def _apply_custom_filters(self, query, filters: FilterParams):
        """
        Apply entity-specific filters to the query.
        Override in child classes to add custom filtering logic.
        """
        return query


class CompanyIsolatedService(BaseService[ModelType, CreateSchemaType, UpdateSchemaType, SchemaType]):
    """
    Base service for company-isolated entities (multi-tenant).
    Automatically applies company filtering to all operations.
    """
    
    def __init__(self, model: Type[ModelType], db_session: AsyncSession, company_id: uuid.UUID):
        """
        Initialize the company-isolated service.
        
        Args:
            model: SQLAlchemy model class
            db_session: Database session
            company_id: Company ID for filtering
        """
        super().__init__(model, db_session)
        self.company_id = company_id
        
        # Ensure model supports company isolation
        if not issubclass(model, CompanyIsolatedModel):
            raise ValueError(f"Model {model.__name__} does not support company isolation")
    
    async def create(
        self,
        obj_in: CreateSchemaType,
        current_user_id: Optional[uuid.UUID] = None,
        **kwargs
    ) -> ModelType:
        """Create entity with automatic company isolation."""
        return await super().create(
            obj_in=obj_in,
            current_user_id=current_user_id,
            company_id=self.company_id,
            **kwargs
        )
    
    async def get(
        self,
        id: uuid.UUID,
        include_archived: bool = False
    ) -> Optional[ModelType]:
        """Get entity with automatic company filtering."""
        return await super().get(id, self.company_id, include_archived)
    
    async def get_or_404(
        self,
        id: uuid.UUID,
        include_archived: bool = False
    ) -> ModelType:
        """Get entity or 404 with automatic company filtering."""
        return await super().get_or_404(id, self.company_id, include_archived)
    
    async def list(
        self,
        pagination: Optional[PaginationParams] = None,
        filters: Optional[FilterParams] = None,
        sort: Optional[SortParams] = None
    ) -> PaginatedResponse[SchemaType]:
        """List entities with automatic company filtering."""
        return await super().list(pagination, filters, sort, self.company_id)
    
    async def update(
        self,
        id: uuid.UUID,
        obj_in: UpdateSchemaType,
        current_user_id: Optional[uuid.UUID] = None
    ) -> ModelType:
        """Update entity with automatic company filtering."""
        return await super().update(id, obj_in, current_user_id, self.company_id)
    
    async def delete(
        self,
        id: uuid.UUID,
        current_user_id: Optional[uuid.UUID] = None,
        soft_delete: bool = True
    ) -> bool:
        """Delete entity with automatic company filtering."""
        return await super().delete(id, current_user_id, self.company_id, soft_delete)
    
    async def restore(
        self,
        id: uuid.UUID,
        current_user_id: Optional[uuid.UUID] = None
    ) -> ModelType:
        """Restore entity with automatic company filtering."""
        return await super().restore(id, current_user_id, self.company_id)


# Export all service classes
__all__ = [
    "BaseService",
    "CompanyIsolatedService",
    "ModelType",
    "CreateSchemaType",
    "UpdateSchemaType", 
    "SchemaType",
]