"""
Audit Service

Enterprise security event logging and monitoring for Cardinsa Insurance API.
Handles comprehensive audit trails, security monitoring, and compliance reporting.
"""

from typing import Dict, List, Optional, Any, Union
from uuid import UUID, uuid4
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func, text
from enum import Enum
import json
import asyncio
from dataclasses import dataclass

from app.core.exceptions import AuditException
from app.models.auth.user import User, AuditLog, SecurityEvent, UserLoginLog
from app.config.settings import get_settings

settings = get_settings()


class EventSeverity(str, Enum):
    """Security event severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class EventCategory(str, Enum):
    """Security event categories"""
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    SESSION_MANAGEMENT = "session_management"
    USER_MANAGEMENT = "user_management"
    DATA_ACCESS = "data_access"
    SYSTEM_SECURITY = "system_security"
    COMPLIANCE = "compliance"
    FRAUD_DETECTION = "fraud_detection"


@dataclass
class AuditEvent:
    """Audit event data structure"""
    event_type: str
    user_id: Optional[UUID]
    session_id: Optional[UUID]
    ip_address: Optional[str]
    user_agent: Optional[str]
    details: Dict[str, Any]
    severity: EventSeverity
    category: EventCategory
    resource_type: Optional[str] = None
    resource_id: Optional[str] = None
    outcome: str = "success"
    timestamp: Optional[datetime] = None


class AuditService:
    """Enterprise Security Audit Service"""

    def __init__(self, db: Session):
        self.db = db
        
        # Audit configuration
        self.retention_days = 2555  # 7 years for compliance
        self.critical_event_retention_days = 3650  # 10 years for critical events
        self.max_events_per_batch = 1000
        
        # Real-time monitoring
        self.enable_real_time_monitoring = True
        self.alert_thresholds = {
            "failed_logins_per_hour": 10,
            "privilege_escalations_per_day": 5,
            "data_exports_per_hour": 20,
            "suspicious_activities_per_hour": 15
        }

    async def log_event(
        self,
        event_type: str,
        user_id: Optional[UUID] = None,
        session_id: Optional[UUID] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        severity: Union[EventSeverity, str] = EventSeverity.INFO,
        category: Union[EventCategory, str] = EventCategory.SYSTEM_SECURITY,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        outcome: str = "success"
    ) -> UUID:
        """
        Log a security audit event
        
        Args:
            event_type: Type of event (e.g., 'user_login', 'password_change')
            user_id: User who performed the action
            session_id: Session ID if applicable
            ip_address: Client IP address
            user_agent: Client user agent
            details: Additional event details
            severity: Event severity level
            category: Event category
            resource_type: Type of resource affected
            resource_id: ID of resource affected
            outcome: Event outcome (success, failure, etc.)
            
        Returns:
            UUID of created audit log entry
            
        Raises:
            AuditException: If logging fails
        """
        try:
            # Create audit event
            audit_event = AuditEvent(
                event_type=event_type,
                user_id=user_id,
                session_id=session_id,
                ip_address=ip_address,
                user_agent=user_agent,
                details=details or {},
                severity=EventSeverity(severity) if isinstance(severity, str) else severity,
                category=EventCategory(category) if isinstance(category, str) else category,
                resource_type=resource_type,
                resource_id=resource_id,
                outcome=outcome,
                timestamp=datetime.utcnow()
            )
            
            # Create audit log record
            audit_log = AuditLog(
                id=uuid4(),
                event_type=audit_event.event_type,
                user_id=audit_event.user_id,
                session_id=audit_event.session_id,
                ip_address=audit_event.ip_address,
                user_agent=audit_event.user_agent,
                event_details=audit_event.details,
                severity=audit_event.severity.value,
                category=audit_event.category.value,
                resource_type=audit_event.resource_type,
                resource_id=audit_event.resource_id,
                outcome=audit_event.outcome,
                timestamp=audit_event.timestamp,
                created_at=datetime.utcnow()
            )
            
            self.db.add(audit_log)
            
            # Create security event for high-severity events
            if audit_event.severity in [EventSeverity.CRITICAL, EventSeverity.HIGH]:
                await self._create_security_event(audit_event, audit_log.id)
            
            self.db.commit()
            
            # Real-time monitoring
            if self.enable_real_time_monitoring:
                await self._check_real_time_alerts(audit_event)
            
            return audit_log.id
            
        except Exception as e:
            self.db.rollback()
            raise AuditException(f"Failed to log audit event: {str(e)}")

    async def log_authentication_event(
        self,
        event_type: str,
        user_id: UUID,
        ip_address: str,
        user_agent: str,
        outcome: str = "success",
        mfa_used: bool = False,
        device_fingerprint: Optional[str] = None,
        failure_reason: Optional[str] = None,
        session_id: Optional[UUID] = None
    ) -> UUID:
        """
        Log authentication-specific event
        
        Args:
            event_type: Authentication event type
            user_id: User ID
            ip_address: Client IP
            user_agent: Client user agent
            outcome: Event outcome
            mfa_used: Whether MFA was used
            device_fingerprint: Device fingerprint
            failure_reason: Reason for failure (if applicable)
            session_id: Session ID if successful
            
        Returns:
            UUID of audit log entry
        """
        details = {
            "mfa_used": mfa_used,
            "device_fingerprint": device_fingerprint,
            "failure_reason": failure_reason
        }
        
        severity = EventSeverity.MEDIUM if outcome == "success" else EventSeverity.HIGH
        
        return await self.log_event(
            event_type=event_type,
            user_id=user_id,
            session_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent,
            details=details,
            severity=severity,
            category=EventCategory.AUTHENTICATION,
            outcome=outcome
        )

    async def log_data_access_event(
        self,
        user_id: UUID,
        resource_type: str,
        resource_id: str,
        action: str,
        ip_address: str,
        session_id: Optional[UUID] = None,
        data_sensitivity: str = "normal",
        record_count: Optional[int] = None,
        query_details: Optional[Dict[str, Any]] = None
    ) -> UUID:
        """
        Log data access event for compliance
        
        Args:
            user_id: User accessing data
            resource_type: Type of resource (table, report, etc.)
            resource_id: Specific resource identifier
            action: Action performed (read, write, delete, export)
            ip_address: Client IP
            session_id: Session ID
            data_sensitivity: Data sensitivity level
            record_count: Number of records accessed
            query_details: Query or filter details
            
        Returns:
            UUID of audit log entry
        """
        details = {
            "action": action,
            "data_sensitivity": data_sensitivity,
            "record_count": record_count,
            "query_details": query_details
        }
        
        # Determine severity based on sensitivity and action
        severity = EventSeverity.HIGH if data_sensitivity == "sensitive" else EventSeverity.MEDIUM
        if action in ["export", "delete"] and data_sensitivity == "sensitive":
            severity = EventSeverity.CRITICAL
        
        return await self.log_event(
            event_type=f"data_{action}",
            user_id=user_id,
            session_id=session_id,
            ip_address=ip_address,
            details=details,
            severity=severity,
            category=EventCategory.DATA_ACCESS,
            resource_type=resource_type,
            resource_id=resource_id
        )

    async def log_privilege_change(
        self,
        admin_user_id: UUID,
        target_user_id: UUID,
        old_roles: List[str],
        new_roles: List[str],
        ip_address: str,
        session_id: UUID,
        reason: Optional[str] = None
    ) -> UUID:
        """
        Log privilege/role changes
        
        Args:
            admin_user_id: User making the change
            target_user_id: User whose privileges are changing
            old_roles: Previous roles
            new_roles: New roles
            ip_address: Admin's IP address
            session_id: Admin's session ID
            reason: Reason for change
            
        Returns:
            UUID of audit log entry
        """
        details = {
            "target_user_id": str(target_user_id),
            "old_roles": old_roles,
            "new_roles": new_roles,
            "reason": reason,
            "privilege_escalation": len(new_roles) > len(old_roles)
        }
        
        return await self.log_event(
            event_type="privilege_change",
            user_id=admin_user_id,
            session_id=session_id,
            ip_address=ip_address,
            details=details,
            severity=EventSeverity.HIGH,
            category=EventCategory.AUTHORIZATION,
            resource_type="user",
            resource_id=str(target_user_id)
        )

    async def get_audit_trail(
        self,
        user_id: Optional[UUID] = None,
        event_type: Optional[str] = None,
        category: Optional[EventCategory] = None,
        severity: Optional[EventSeverity] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Retrieve audit trail with filters
        
        Args:
            user_id: Filter by user ID
            event_type: Filter by event type
            category: Filter by event category
            severity: Filter by severity
            start_date: Start date for time range
            end_date: End date for time range
            resource_type: Filter by resource type
            resource_id: Filter by resource ID
            limit: Maximum records to return
            offset: Pagination offset
            
        Returns:
            Dict containing audit records and metadata
        """
        try:
            # Build query
            query = self.db.query(AuditLog)
            
            # Apply filters
            if user_id:
                query = query.filter(AuditLog.user_id == user_id)
            if event_type:
                query = query.filter(AuditLog.event_type == event_type)
            if category:
                query = query.filter(AuditLog.category == category.value)
            if severity:
                query = query.filter(AuditLog.severity == severity.value)
            if start_date:
                query = query.filter(AuditLog.timestamp >= start_date)
            if end_date:
                query = query.filter(AuditLog.timestamp <= end_date)
            if resource_type:
                query = query.filter(AuditLog.resource_type == resource_type)
            if resource_id:
                query = query.filter(AuditLog.resource_id == resource_id)
            
            # Get total count
            total_count = query.count()
            
            # Apply pagination and ordering
            audit_logs = query.order_by(desc(AuditLog.timestamp)).limit(limit).offset(offset).all()
            
            # Format results
            records = []
            for log in audit_logs:
                record = {
                    "id": log.id,
                    "event_type": log.event_type,
                    "user_id": log.user_id,
                    "session_id": log.session_id,
                    "ip_address": log.ip_address,
                    "user_agent": log.user_agent,
                    "event_details": log.event_details,
                    "severity": log.severity,
                    "category": log.category,
                    "resource_type": log.resource_type,
                    "resource_id": log.resource_id,
                    "outcome": log.outcome,
                    "timestamp": log.timestamp.isoformat(),
                    "created_at": log.created_at.isoformat()
                }
                
                # Add user information if available
                if log.user_id:
                    user = self.db.query(User).filter(User.id == log.user_id).first()
                    if user:
                        record["user_info"] = {
                            "username": user.username,
                            "email": user.email,
                            "first_name": user.first_name,
                            "last_name": user.last_name
                        }
                
                records.append(record)
            
            return {
                "records": records,
                "total_count": total_count,
                "limit": limit,
                "offset": offset,
                "has_more": total_count > (offset + limit)
            }
            
        except Exception as e:
            raise AuditException(f"Failed to retrieve audit trail: {str(e)}")

    async def get_security_events(
        self,
        severity: Optional[EventSeverity] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        is_resolved: Optional[bool] = None,
        limit: int = 50,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Get security events (high-severity audit events)
        
        Args:
            severity: Filter by severity
            start_date: Start date filter
            end_date: End date filter
            is_resolved: Filter by resolution status
            limit: Maximum records to return
            offset: Pagination offset
            
        Returns:
            Dict containing security events and metadata
        """
        try:
            query = self.db.query(SecurityEvent)
            
            if severity:
                query = query.filter(SecurityEvent.severity == severity.value)
            if start_date:
                query = query.filter(SecurityEvent.detected_at >= start_date)
            if end_date:
                query = query.filter(SecurityEvent.detected_at <= end_date)
            if is_resolved is not None:
                query = query.filter(SecurityEvent.is_resolved == is_resolved)
            
            total_count = query.count()
            events = query.order_by(desc(SecurityEvent.detected_at)).limit(limit).offset(offset).all()
            
            records = []
            for event in events:
                record = {
                    "id": event.id,
                    "audit_log_id": event.audit_log_id,
                    "event_type": event.event_type,
                    "severity": event.severity,
                    "description": event.description,
                    "detected_at": event.detected_at.isoformat(),
                    "is_resolved": event.is_resolved,
                    "resolved_at": event.resolved_at.isoformat() if event.resolved_at else None,
                    "resolved_by": event.resolved_by,
                    "resolution_notes": event.resolution_notes,
                    "automated_response": event.automated_response
                }
                records.append(record)
            
            return {
                "events": records,
                "total_count": total_count,
                "limit": limit,
                "offset": offset,
                "unresolved_count": query.filter(SecurityEvent.is_resolved == False).count()
            }
            
        except Exception as e:
            raise AuditException(f"Failed to retrieve security events: {str(e)}")

    async def resolve_security_event(
        self,
        event_id: UUID,
        resolved_by: UUID,
        resolution_notes: str
    ) -> Dict[str, Any]:
        """
        Mark a security event as resolved
        
        Args:
            event_id: Security event ID
            resolved_by: User ID who resolved the event
            resolution_notes: Notes about the resolution
            
        Returns:
            Dict with resolution status
        """
        try:
            security_event = self.db.query(SecurityEvent).filter(
                SecurityEvent.id == event_id
            ).first()
            
            if not security_event:
                raise AuditException("Security event not found")
            
            security_event.is_resolved = True
            security_event.resolved_at = datetime.utcnow()
            security_event.resolved_by = resolved_by
            security_event.resolution_notes = resolution_notes
            
            self.db.commit()
            
            # Log the resolution
            await self.log_event(
                event_type="security_event_resolved",
                user_id=resolved_by,
                details={
                    "security_event_id": str(event_id),
                    "resolution_notes": resolution_notes
                },
                severity=EventSeverity.MEDIUM,
                category=EventCategory.SYSTEM_SECURITY
            )
            
            return {
                "resolved": True,
                "event_id": event_id,
                "resolved_at": security_event.resolved_at.isoformat(),
                "resolved_by": resolved_by
            }
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, AuditException):
                raise
            raise AuditException(f"Failed to resolve security event: {str(e)}")

    async def generate_compliance_report(
        self,
        start_date: datetime,
        end_date: datetime,
        report_type: str = "full"
    ) -> Dict[str, Any]:
        """
        Generate compliance audit report
        
        Args:
            start_date: Report start date
            end_date: Report end date
            report_type: Type of report (full, summary, authentication, data_access)
            
        Returns:
            Dict containing compliance report data
        """
        try:
            # Base query for the time period
            base_query = self.db.query(AuditLog).filter(
                and_(
                    AuditLog.timestamp >= start_date,
                    AuditLog.timestamp <= end_date
                )
            )
            
            # Generate report sections
            report = {
                "report_id": str(uuid4()),
                "report_type": report_type,
                "period": {
                    "start_date": start_date.isoformat(),
                    "end_date": end_date.isoformat()
                },
                "generated_at": datetime.utcnow().isoformat(),
                "summary": await self._generate_report_summary(base_query),
                "authentication_events": await self._get_authentication_summary(base_query),
                "data_access_events": await self._get_data_access_summary(base_query),
                "security_incidents": await self._get_security_incidents_summary(start_date, end_date),
                "user_activity": await self._get_user_activity_summary(base_query),
                "compliance_metrics": await self._calculate_compliance_metrics(base_query)
            }
            
            # Add detailed sections based on report type
            if report_type == "full":
                report["detailed_events"] = await self._get_detailed_events(base_query)
                report["privilege_changes"] = await self._get_privilege_changes(base_query)
                report["failed_access_attempts"] = await self._get_failed_attempts(base_query)
            
            return report
            
        except Exception as e:
            raise AuditException(f"Failed to generate compliance report: {str(e)}")

    async def cleanup_old_audit_logs(self) -> Dict[str, int]:
        """
        Clean up old audit logs based on retention policy
        
        Returns:
            Dict with cleanup statistics
        """
        try:
            now = datetime.utcnow()
            
            # Regular retention cutoff
            regular_cutoff = now - timedelta(days=self.retention_days)
            
            # Critical events retention cutoff
            critical_cutoff = now - timedelta(days=self.critical_event_retention_days)
            
            # Delete regular events beyond retention period
            regular_deleted = self.db.query(AuditLog).filter(
                and_(
                    AuditLog.timestamp < regular_cutoff,
                    AuditLog.severity.in_([EventSeverity.INFO.value, EventSeverity.LOW.value, EventSeverity.MEDIUM.value])
                )
            ).delete()
            
            # Delete critical events beyond extended retention period
            critical_deleted = self.db.query(AuditLog).filter(
                and_(
                    AuditLog.timestamp < critical_cutoff,
                    AuditLog.severity.in_([EventSeverity.HIGH.value, EventSeverity.CRITICAL.value])
                )
            ).delete()
            
            # Clean up resolved security events older than 1 year
            security_events_cutoff = now - timedelta(days=365)
            security_events_deleted = self.db.query(SecurityEvent).filter(
                and_(
                    SecurityEvent.detected_at < security_events_cutoff,
                    SecurityEvent.is_resolved == True
                )
            ).delete()
            
            self.db.commit()
            
            return {
                "regular_audit_logs_deleted": regular_deleted,
                "critical_audit_logs_deleted": critical_deleted,
                "security_events_deleted": security_events_deleted,
                "cleanup_date": now.isoformat()
            }
            
        except Exception as e:
            self.db.rollback()
            raise AuditException(f"Failed to cleanup audit logs: {str(e)}")

    # Private helper methods
    
    async def _create_security_event(self, audit_event: AuditEvent, audit_log_id: UUID) -> None:
        """Create security event for high-severity audit events"""
        try:
            description = self._generate_security_event_description(audit_event)
            
            security_event = SecurityEvent(
                id=uuid4(),
                audit_log_id=audit_log_id,
                event_type=audit_event.event_type,
                severity=audit_event.severity.value,
                description=description,
                detected_at=audit_event.timestamp,
                is_resolved=False,
                automated_response=self._get_automated_response(audit_event)
            )
            
            self.db.add(security_event)
            
        except Exception as e:
            # Don't fail the audit log if security event creation fails
            pass

    def _generate_security_event_description(self, audit_event: AuditEvent) -> str:
        """Generate human-readable description for security event"""
        descriptions = {
            "failed_login": f"Multiple failed login attempts from IP {audit_event.ip_address}",
            "privilege_escalation": "User privileges were elevated",
            "suspicious_data_access": "Unusual data access pattern detected",
            "session_hijacking": "Potential session hijacking attempt detected",
            "brute_force_attack": "Brute force attack pattern detected",
        }
        
        return descriptions.get(audit_event.event_type, f"Security event: {audit_event.event_type}")

    def _get_automated_response(self, audit_event: AuditEvent) -> Optional[str]:
        """Determine if automated response was triggered"""
        if audit_event.event_type == "failed_login" and audit_event.severity == EventSeverity.CRITICAL:
            return "account_locked"
        elif audit_event.event_type == "brute_force_attack":
            return "ip_blocked"
        
        return None

    async def _check_real_time_alerts(self, audit_event: AuditEvent) -> None:
        """Check if event triggers real-time alerts"""
        try:
            if audit_event.severity == EventSeverity.CRITICAL:
                await self._trigger_critical_alert(audit_event)
            
            # Check for patterns that require immediate attention
            if audit_event.event_type == "failed_login":
                await self._check_failed_login_pattern(audit_event)
            elif audit_event.event_type == "privilege_change":
                await self._check_privilege_escalation_pattern(audit_event)
            
        except Exception:
            # Don't fail audit logging for alert issues
            pass

    async def _trigger_critical_alert(self, audit_event: AuditEvent) -> None:
        """Trigger critical security alert"""
        # Implementation would integrate with alerting system
        # For now, we'll log it as a high-priority security event
        pass

    async def _check_failed_login_pattern(self, audit_event: AuditEvent) -> None:
        """Check for failed login patterns"""
        if not audit_event.user_id:
            return
        
        # Check failed logins in the last hour
        one_hour_ago = datetime.utcnow() - timedelta(hours=1)
        failed_count = self.db.query(AuditLog).filter(
            and_(
                AuditLog.user_id == audit_event.user_id,
                AuditLog.event_type == "failed_login",
                AuditLog.timestamp >= one_hour_ago
            )
        ).count()
        
        if failed_count >= self.alert_thresholds["failed_logins_per_hour"]:
            await self.log_event(
                event_type="excessive_failed_logins",
                user_id=audit_event.user_id,
                ip_address=audit_event.ip_address,
                details={"failed_count": failed_count, "time_window": "1_hour"},
                severity=EventSeverity.CRITICAL,
                category=EventCategory.FRAUD_DETECTION
            )

    async def _check_privilege_escalation_pattern(self, audit_event: AuditEvent) -> None:
        """Check for privilege escalation patterns"""
        one_day_ago = datetime.utcnow() - timedelta(days=1)
        escalation_count = self.db.query(AuditLog).filter(
            and_(
                AuditLog.event_type == "privilege_change",
                AuditLog.timestamp >= one_day_ago,
                AuditLog.event_details.op('->>')('privilege_escalation').astext == 'true'
            )
        ).count()
        
        if escalation_count >= self.alert_thresholds["privilege_escalations_per_day"]:
            await self.log_event(
                event_type="excessive_privilege_escalations",
                details={"escalation_count": escalation_count, "time_window": "1_day"},
                severity=EventSeverity.HIGH,
                category=EventCategory.AUTHORIZATION
            )

    async def _generate_report_summary(self, base_query) -> Dict[str, Any]:
        """Generate summary statistics for compliance report"""
        total_events = base_query.count()
        
        # Count by severity
        severity_counts = {}
        for severity in EventSeverity:
            count = base_query.filter(AuditLog.severity == severity.value).count()
            severity_counts[severity.value] = count
        
        # Count by category
        category_counts = {}
        for category in EventCategory:
            count = base_query.filter(AuditLog.category == category.value).count()
            category_counts[category.value] = count
        
        # Count by outcome
        success_count = base_query.filter(AuditLog.outcome == "success").count()
        failure_count = base_query.filter(AuditLog.outcome == "failure").count()
        
        return {
            "total_events": total_events,
            "severity_breakdown": severity_counts,
            "category_breakdown": category_counts,
            "outcome_breakdown": {
                "success": success_count,
                "failure": failure_count,
                "other": total_events - success_count - failure_count
            }
        }

    async def _get_authentication_summary(self, base_query) -> Dict[str, Any]:
        """Get authentication events summary"""
        auth_query = base_query.filter(AuditLog.category == EventCategory.AUTHENTICATION.value)
        
        total_auth_events = auth_query.count()
        successful_logins = auth_query.filter(
            and_(AuditLog.event_type == "user_login", AuditLog.outcome == "success")
        ).count()
        failed_logins = auth_query.filter(
            and_(AuditLog.event_type == "user_login", AuditLog.outcome == "failure")
        ).count()
        mfa_events = auth_query.filter(
            AuditLog.event_details.op('->>')('mfa_used').astext == 'true'
        ).count()
        
        return {
            "total_authentication_events": total_auth_events,
            "successful_logins": successful_logins,
            "failed_logins": failed_logins,
            "mfa_usage": mfa_events,
            "success_rate": (successful_logins / (successful_logins + failed_logins)) * 100 if (successful_logins + failed_logins) > 0 else 0
        }

    async def _get_data_access_summary(self, base_query) -> Dict[str, Any]:
        """Get data access events summary"""
        data_query = base_query.filter(AuditLog.category == EventCategory.DATA_ACCESS.value)
        
        total_data_events = data_query.count()
        read_events = data_query.filter(AuditLog.event_type == "data_read").count()
        write_events = data_query.filter(AuditLog.event_type == "data_write").count()
        export_events = data_query.filter(AuditLog.event_type == "data_export").count()
        delete_events = data_query.filter(AuditLog.event_type == "data_delete").count()
        
        return {
            "total_data_access_events": total_data_events,
            "read_operations": read_events,
            "write_operations": write_events,
            "export_operations": export_events,
            "delete_operations": delete_events
        }

    async def _get_security_incidents_summary(self, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Get security incidents summary"""
        incidents_query = self.db.query(SecurityEvent).filter(
            and_(
                SecurityEvent.detected_at >= start_date,
                SecurityEvent.detected_at <= end_date
            )
        )
        
        total_incidents = incidents_query.count()
        resolved_incidents = incidents_query.filter(SecurityEvent.is_resolved == True).count()
        critical_incidents = incidents_query.filter(SecurityEvent.severity == EventSeverity.CRITICAL.value).count()
        
        return {
            "total_security_incidents": total_incidents,
            "resolved_incidents": resolved_incidents,
            "pending_incidents": total_incidents - resolved_incidents,
            "critical_incidents": critical_incidents,
            "resolution_rate": (resolved_incidents / total_incidents) * 100 if total_incidents > 0 else 0
        }

    async def _get_user_activity_summary(self, base_query) -> Dict[str, Any]:
        """Get user activity summary"""
        # Count unique users
        unique_users = base_query.distinct(AuditLog.user_id).filter(
            AuditLog.user_id.isnot(None)
        ).count()
        
        # Most active users
        user_activity = self.db.query(
            AuditLog.user_id,
            func.count(AuditLog.id).label('event_count')
        ).filter(
            AuditLog.user_id.isnot(None)
        ).group_by(AuditLog.user_id).order_by(desc('event_count')).limit(10).all()
        
        return {
            "unique_active_users": unique_users,
            "most_active_users": [
                {"user_id": str(user_id), "event_count": count}
                for user_id, count in user_activity
            ]
        }

    async def _calculate_compliance_metrics(self, base_query) -> Dict[str, Any]:
        """Calculate compliance-specific metrics"""
        # Failed access attempts
        failed_access = base_query.filter(
            and_(
                AuditLog.category == EventCategory.AUTHORIZATION.value,
                AuditLog.outcome == "failure"
            )
        ).count()
        
        # Data export activities
        data_exports = base_query.filter(AuditLog.event_type == "data_export").count()
        
        # Privilege changes
        privilege_changes = base_query.filter(AuditLog.event_type == "privilege_change").count()
        
        return {
            "failed_access_attempts": failed_access,
            "data_export_events": data_exports,
            "privilege_modifications": privilege_changes,
            "compliance_score": self._calculate_compliance_score(base_query)
        }

    def _calculate_compliance_score(self, base_query) -> float:
        """Calculate overall compliance score (0-100)"""
        total_events = base_query.count()
        if total_events == 0:
            return 100.0
        
        # Factors that reduce compliance score
        failed_events = base_query.filter(AuditLog.outcome == "failure").count()
        critical_events = base_query.filter(AuditLog.severity == EventSeverity.CRITICAL.value).count()
        
        # Base score
        score = 100.0
        
        # Reduce score for failures and critical events
        failure_penalty = (failed_events / total_events) * 20  # Max 20 point penalty
        critical_penalty = (critical_events / total_events) * 30  # Max 30 point penalty
        
        score = max(0.0, score - failure_penalty - critical_penalty)
        
        return round(score, 2)

    async def _get_detailed_events(self, base_query) -> List[Dict[str, Any]]:
        """Get detailed events for full reports"""
        events = base_query.order_by(desc(AuditLog.timestamp)).limit(1000).all()
        
        return [
            {
                "timestamp": event.timestamp.isoformat(),
                "event_type": event.event_type,
                "user_id": str(event.user_id) if event.user_id else None,
                "severity": event.severity,
                "category": event.category,
                "outcome": event.outcome,
                "ip_address": event.ip_address,
                "details": event.event_details
            }
            for event in events
        ]

    async def _get_privilege_changes(self, base_query) -> List[Dict[str, Any]]:
        """Get privilege change events"""
        changes = base_query.filter(AuditLog.event_type == "privilege_change").all()
        
        return [
            {
                "timestamp": change.timestamp.isoformat(),
                "admin_user_id": str(change.user_id),
                "target_user_id": change.event_details.get("target_user_id"),
                "old_roles": change.event_details.get("old_roles", []),
                "new_roles": change.event_details.get("new_roles", []),
                "reason": change.event_details.get("reason"),
                "ip_address": change.ip_address
            }
            for change in changes
        ]

    async def _get_failed_attempts(self, base_query) -> List[Dict[str, Any]]:
        """Get failed access attempts"""
        failed = base_query.filter(AuditLog.outcome == "failure").limit(500).all()
        
        return [
            {
                "timestamp": attempt.timestamp.isoformat(),
                "event_type": attempt.event_type,
                "user_id": str(attempt.user_id) if attempt.user_id else None,
                "ip_address": attempt.ip_address,
                "failure_reason": attempt.event_details.get("failure_reason"),
                "resource_type": attempt.resource_type,
                "resource_id": attempt.resource_id
            }
            for attempt in failed
        ]