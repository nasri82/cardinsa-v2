"""
Authentication service for user login, logout, and basic auth operations.
"""

import uuid
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.core.exceptions import (
    InvalidCredentialsError,
    AccountLockedError,
    AccountInactiveError,
    TokenExpiredError,
    InvalidTokenError,
    AuthenticationError,
    RecordNotFoundError
)
from app.core.security import (
    verify_password, 
    hash_password, 
    create_access_token, 
    create_refresh_token,
    verify_token,
    generate_secure_token
)
from app.models.auth.user import User, UserPassword, UserLoginLog, Session as UserSession
from app.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class AuthService:
    """Service class for authentication operations."""
    
    def __init__(self, db: Session):
        self.db = db
    
    def authenticate_user(self, username_or_email: str, password: str) -> Optional[User]:
        """
        Authenticate a user with username/email and password.
        
        Args:
            username_or_email: Username or email address
            password: Plain text password
            
        Returns:
            User object if authentication successful, None otherwise
            
        Raises:
            InvalidCredentialsError: If credentials are invalid
            AccountLockedError: If account is locked
            AccountInactiveError: If account is inactive
        """
        # Find user by username or email
        user = self.db.query(User).filter(
            or_(
                User.username == username_or_email,
                User.email == username_or_email
            )
        ).first()
        
        if not user:
            logger.warning(f"Login attempt with non-existent user: {username_or_email}")
            raise InvalidCredentialsError()
        
        # Check if account is active
        if not user.is_active:
            logger.warning(f"Login attempt with inactive account: {user.username}")
            raise AccountInactiveError()
        
        # Check if account is locked
        if user.is_locked:
            locked_until = user.locked_until.isoformat() if user.locked_until else None
            logger.warning(f"Login attempt with locked account: {user.username}")
            raise AccountLockedError(locked_until=locked_until)
        
        # Get current password
        current_password = self.db.query(UserPassword).filter(
            and_(
                UserPassword.user_id == user.id,
                UserPassword.is_current == True
            )
        ).first()
        
        if not current_password:
            logger.error(f"No current password found for user: {user.username}")
            raise InvalidCredentialsError()
        
        # Verify password
        if not verify_password(password, current_password.password_hash):
            # Increment login attempts
            user.login_attempts += 1
            
            # Lock account if too many failed attempts
            if user.login_attempts >= settings.MAX_LOGIN_ATTEMPTS:
                user.lock_account(
                    reason="Too many failed login attempts",
                    duration_hours=settings.LOCKOUT_DURATION_MINUTES / 60
                )
                logger.warning(f"Account locked due to too many failed attempts: {user.username}")
                self.db.commit()
                raise AccountLockedError()
            
            self.db.commit()
            logger.warning(f"Invalid password for user: {user.username}")
            raise InvalidCredentialsError()
        
        # Reset login attempts on successful authentication
        user.login_attempts = 0
        user.last_login = datetime.utcnow()
        user.last_activity = datetime.utcnow()
        
        self.db.commit()
        logger.info(f"User authenticated successfully: {user.username}")
        return user
    
    def login_user(
        self, 
        username_or_email: str, 
        password: str,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        device_info: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Login a user and create session tokens.
        
        Args:
            username_or_email: Username or email address
            password: Plain text password
            ip_address: Client IP address
            user_agent: Client user agent
            device_info: Additional device information
            
        Returns:
            Dictionary containing tokens and user information
        """
        try:
            # Authenticate user
            user = self.authenticate_user(username_or_email, password)
            
            # Create tokens
            access_token = create_access_token(data={"sub": str(user.id), "username": user.username})
            refresh_token = create_refresh_token(data={"sub": str(user.id), "username": user.username})
            
            # Create session record
            session = UserSession(
                user_id=user.id,
                session_token=generate_secure_token(),
                refresh_token=refresh_token,
                ip_address=ip_address,
                user_agent=user_agent,
                device_fingerprint=self._generate_device_fingerprint(user_agent, ip_address),
                expires_at=datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
            )
            
            self.db.add(session)
            
            # Log successful login
            login_log = UserLoginLog(
                user_id=user.id,
                username=user.username,
                ip_address=ip_address,
                user_agent=user_agent,
                success=True,
                device_info=device_info
            )
            
            self.db.add(login_log)
            self.db.commit()
            
            logger.info(f"User logged in successfully: {user.username}")
            
            return {
                "access_token": access_token,
                "refresh_token": refresh_token,
                "token_type": "bearer",
                "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
                "user": {
                    "id": str(user.id),
                    "username": user.username,
                    "email": user.email,
                    "full_name": user.full_name,
                    "is_active": user.is_active,
                    "is_superuser": user.is_superuser,
                    "department_id": str(user.department_id) if user.department_id else None,
                    "unit_id": str(user.unit_id) if user.unit_id else None,
                }
            }
        
        except Exception as e:
            # Log failed login attempt
            login_log = UserLoginLog(
                username=username_or_email,
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                failure_reason=str(e),
                device_info=device_info
            )
            
            self.db.add(login_log)
            self.db.commit()
            
            logger.error(f"Login failed for user: {username_or_email}, reason: {e}")
            raise
    
    def refresh_access_token(self, refresh_token: str) -> Dict[str, str]:
        """
        Refresh access token using refresh token.
        
        Args:
            refresh_token: Valid refresh token
            
        Returns:
            Dictionary containing new access token
            
        Raises:
            InvalidTokenError: If refresh token is invalid
            TokenExpiredError: If refresh token is expired
        """
        try:
            # Verify refresh token
            payload = verify_token(refresh_token, token_type="refresh")
            user_id = uuid.UUID(payload["sub"])
            
            # Check if session exists and is active
            session = self.db.query(UserSession).filter(
                and_(
                    UserSession.refresh_token == refresh_token,
                    UserSession.is_active == True,
                    UserSession.expires_at > datetime.utcnow()
                )
            ).first()
            
            if not session:
                logger.warning(f"Invalid or expired session for refresh token")
                raise InvalidTokenError("Invalid or expired session")
            
            # Get user
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user or not user.is_active:
                logger.warning(f"User not found or inactive for refresh token: {user_id}")
                raise InvalidTokenError("User not found or inactive")
            
            # Create new access token
            access_token = create_access_token(
                data={"sub": str(user.id), "username": user.username}
            )
            
            # Update user last activity
            user.last_activity = datetime.utcnow()
            self.db.commit()
            
            logger.info(f"Access token refreshed for user: {user.username}")
            
            return {
                "access_token": access_token,
                "token_type": "bearer",
                "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
            }
        
        except Exception as e:
            logger.error(f"Token refresh failed: {e}")
            raise
    
    def logout_user(self, refresh_token: str) -> bool:
        """
        Logout user by invalidating their session.
        
        Args:
            refresh_token: User's refresh token
            
        Returns:
            True if logout successful, False otherwise
        """
        try:
            # Find and deactivate session
            session = self.db.query(UserSession).filter(
                UserSession.refresh_token == refresh_token
            ).first()
            
            if session:
                session.is_active = False
                session.revoked_at = datetime.utcnow()
                self.db.commit()
                
                logger.info(f"User logged out successfully: {session.user_id}")
                return True
            
            return False
        
        except Exception as e:
            logger.error(f"Logout failed: {e}")
            return False
    
    def logout_all_sessions(self, user_id: uuid.UUID) -> int:
        """
        Logout user from all active sessions.
        
        Args:
            user_id: User ID
            
        Returns:
            Number of sessions logged out
        """
        try:
            # Deactivate all active sessions for the user
            sessions = self.db.query(UserSession).filter(
                and_(
                    UserSession.user_id == user_id,
                    UserSession.is_active == True
                )
            ).all()
            
            count = 0
            for session in sessions:
                session.is_active = False
                session.revoked_at = datetime.utcnow()
                count += 1
            
            self.db.commit()
            logger.info(f"Logged out {count} sessions for user: {user_id}")
            return count
        
        except Exception as e:
            logger.error(f"Logout all sessions failed: {e}")
            return 0
    
    def get_user_by_token(self, token: str) -> Optional[User]:
        """
        Get user by access token.
        
        Args:
            token: JWT access token
            
        Returns:
            User object if token is valid, None otherwise
        """
        try:
            payload = verify_token(token, token_type="access")
            user_id = uuid.UUID(payload["sub"])
            
            user = self.db.query(User).filter(
                and_(
                    User.id == user_id,
                    User.is_active == True
                )
            ).first()
            
            if user:
                # Update last activity
                user.last_activity = datetime.utcnow()
                self.db.commit()
            
            return user
        
        except Exception as e:
            logger.debug(f"Token validation failed: {e}")
            return None
    
    def change_password(
        self, 
        user_id: uuid.UUID, 
        current_password: str, 
        new_password: str
    ) -> bool:
        """
        Change user password.
        
        Args:
            user_id: User ID
            current_password: Current password
            new_password: New password
            
        Returns:
            True if password changed successfully
            
        Raises:
            RecordNotFoundError: If user not found
            InvalidCredentialsError: If current password is invalid
        """
        try:
            # Get user
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                raise RecordNotFoundError("User", str(user_id))
            
            # Get current password
            current_pwd = self.db.query(UserPassword).filter(
                and_(
                    UserPassword.user_id == user_id,
                    UserPassword.is_current == True
                )
            ).first()
            
            if not current_pwd:
                raise InvalidCredentialsError("No current password found")
            
            # Verify current password
            if not verify_password(current_password, current_pwd.password_hash):
                raise InvalidCredentialsError("Current password is incorrect")
            
            # Mark current password as not current
            current_pwd.is_current = False
            
            # Create new password record
            new_pwd = UserPassword(
                user_id=user_id,
                password_hash=hash_password(new_password),
                is_current=True
            )
            
            self.db.add(new_pwd)
            self.db.commit()
            
            logger.info(f"Password changed successfully for user: {user.username}")
            return True
        
        except Exception as e:
            logger.error(f"Password change failed for user {user_id}: {e}")
            self.db.rollback()
            raise
    
    def _generate_device_fingerprint(self, user_agent: Optional[str], ip_address: Optional[str]) -> Optional[str]:
        """
        Generate a device fingerprint for session tracking.
        
        Args:
            user_agent: Client user agent
            ip_address: Client IP address
            
        Returns:
            Device fingerprint string
        """
        if not user_agent and not ip_address:
            return None
        
        import hashlib
        fingerprint_data = f"{user_agent or ''}{ip_address or ''}"
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:32]