# FILE PATH: app/services/auth/mfa_service.py
"""
Multi-Factor Authentication Service
CARDINSA Insurance Platform

Enterprise-grade MFA implementation providing:
- TOTP (Time-based One-Time Passwords) support
- SMS and Email OTP delivery
- Backup codes generation and validation
- Device trust management
- MFA policy enforcement
- Security analytics and fraud detection
- Recovery mechanisms and admin overrides

Supports multiple MFA methods with fallback options and enterprise policies.
"""

import uuid
import logging
import secrets
import base64
import qrcode
import pyotp
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
from io import BytesIO
from email.mime.image import MIMEImage

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func, update, delete
from sqlalchemy.orm import selectinload
from cryptography.fernet import Fernet

from ...models.auth.user import User, MfaMethod, MfaSession, UserDevice, SecurityEvent
from ...schemas.auth.mfa import (
    MfaSetupRequest, MfaSetupResponse, MfaVerificationRequest, MfaVerificationResponse,
    MfaBackupCodesResponse, MfaDeviceInfo, MfaStatusResponse, MfaRecoveryRequest,
    TotpSetupResponse, SmsSetupResponse, EmailSetupResponse
)
from ...core.exceptions import (
    ValidationException, AuthenticationException, BusinessLogicException,
    SecurityException, RateLimitException
)
from ...core.security import SecurityUtils, TokenManager
from ...core.config import get_settings
from ...services.base import BaseService
from ...services.notification.sms_service import SmsService
from ...services.notification.email_service import EmailService

settings = get_settings()


class MfaService(BaseService[MfaMethod, dict, dict, dict]):
    """
    Comprehensive Multi-Factor Authentication service.
    
    Provides enterprise-grade MFA capabilities including:
    - Multiple authentication methods (TOTP, SMS, Email)
    - Device trust and remember functionality
    - Backup codes for account recovery
    - Rate limiting and fraud detection
    - Admin override and recovery mechanisms
    - Comprehensive audit logging
    """
    
    entity_name = "MfaMethod"
    
    def __init__(self, db_session: AsyncSession):
        """
        Initialize MFA service.
        
        Args:
            db_session: Database session
        """
        super().__init__(MfaMethod, db_session)
        self.logger = logging.getLogger(__name__)
        self.sms_service = SmsService()
        self.email_service = EmailService()
        self.encryption_key = settings.MFA_ENCRYPTION_KEY.encode()
        self.cipher_suite = Fernet(base64.urlsafe_b64encode(self.encryption_key[:32]))
        
    # ========================================================================
    # MFA SETUP AND CONFIGURATION
    # ========================================================================
    
    async def setup_totp(
        self,
        user_id: uuid.UUID,
        device_name: Optional[str] = None,
        current_user_id: Optional[uuid.UUID] = None
    ) -> TotpSetupResponse:
        """
        Set up TOTP (Time-based One-Time Password) authentication.
        
        Args:
            user_id: User ID for MFA setup
            device_name: Optional device name for tracking
            current_user_id: ID of user performing the setup
            
        Returns:
            TotpSetupResponse: Setup details including QR code and secret
            
        Raises:
            BusinessLogicException: If TOTP already enabled
            ValidationException: If user not found or invalid
        """
        try:
            # Get user
            user = await self._get_user(user_id)
            
            # Check if TOTP already enabled
            existing_totp = await self._get_user_mfa_method(user_id, "totp")
            if existing_totp and existing_totp.is_active:
                raise BusinessLogicException("TOTP is already enabled for this user")
            
            # Generate secret
            secret = pyotp.random_base32()
            encrypted_secret = self._encrypt_secret(secret)
            
            # Create TOTP URI for QR code
            totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
                name=user.email,
                issuer_name=settings.MFA_ISSUER_NAME
            )
            
            # Generate QR code
            qr_code_data = self._generate_qr_code(totp_uri)
            
            # Create or update MFA method
            mfa_method = await self._create_or_update_mfa_method(
                user_id=user_id,
                method_type="totp",
                encrypted_data=encrypted_secret,
                metadata={
                    "device_name": device_name,
                    "setup_ip": await self._get_client_ip(),
                    "setup_user_agent": await self._get_user_agent()
                },
                is_active=False,  # Not active until verified
                created_by=current_user_id
            )
            
            # Log security event
            await self._log_security_event(
                user_id, "mfa_totp_setup_initiated",
                {"method_id": str(mfa_method.id), "device_name": device_name}
            )
            
            return TotpSetupResponse(
                method_id=mfa_method.id,
                secret=secret,  # Only returned during setup
                qr_code=qr_code_data,
                backup_codes=await self._generate_backup_codes(user_id),
                recovery_codes=await self._generate_recovery_codes(user_id)
            )
            
        except Exception as e:
            self.logger.error(f"Error setting up TOTP: {str(e)}", exc_info=True)
            raise BusinessLogicException("Failed to setup TOTP authentication")
    
    async def setup_sms(
        self,
        user_id: uuid.UUID,
        phone_number: str,
        current_user_id: Optional[uuid.UUID] = None
    ) -> SmsSetupResponse:
        """
        Set up SMS-based MFA authentication.
        
        Args:
            user_id: User ID for MFA setup
            phone_number: Phone number for SMS delivery
            current_user_id: ID of user performing the setup
            
        Returns:
            SmsSetupResponse: Setup confirmation and verification details
        """
        try:
            # Validate phone number format
            validated_phone = self._validate_phone_number(phone_number)
            
            # Get user
            user = await self._get_user(user_id)
            
            # Check rate limits for SMS setup
            await self._check_sms_rate_limit(user_id)
            
            # Generate verification code
            verification_code = self._generate_numeric_code(6)
            encrypted_phone = self._encrypt_secret(validated_phone)
            
            # Create MFA method (inactive until verified)
            mfa_method = await self._create_or_update_mfa_method(
                user_id=user_id,
                method_type="sms",
                encrypted_data=encrypted_phone,
                metadata={
                    "phone_number_masked": self._mask_phone_number(validated_phone),
                    "verification_code": self._encrypt_secret(verification_code),
                    "verification_expires": (datetime.utcnow() + timedelta(minutes=5)).isoformat(),
                    "setup_ip": await self._get_client_ip()
                },
                is_active=False,
                created_by=current_user_id
            )
            
            # Send verification SMS
            await self.sms_service.send_mfa_setup_code(
                phone_number=validated_phone,
                verification_code=verification_code,
                user_name=user.first_name or user.username
            )
            
            # Log security event
            await self._log_security_event(
                user_id, "mfa_sms_setup_initiated",
                {"method_id": str(mfa_method.id), "phone_masked": self._mask_phone_number(validated_phone)}
            )
            
            return SmsSetupResponse(
                method_id=mfa_method.id,
                phone_number_masked=self._mask_phone_number(validated_phone),
                verification_required=True,
                expires_at=datetime.utcnow() + timedelta(minutes=5)
            )
            
        except Exception as e:
            self.logger.error(f"Error setting up SMS MFA: {str(e)}", exc_info=True)
            raise BusinessLogicException("Failed to setup SMS authentication")
    
    async def setup_email(
        self,
        user_id: uuid.UUID,
        email_address: Optional[str] = None,
        current_user_id: Optional[uuid.UUID] = None
    ) -> EmailSetupResponse:
        """
        Set up email-based MFA authentication.
        
        Args:
            user_id: User ID for MFA setup
            email_address: Optional email (defaults to user's primary email)
            current_user_id: ID of user performing the setup
            
        Returns:
            EmailSetupResponse: Setup confirmation and verification details
        """
        try:
            # Get user
            user = await self._get_user(user_id)
            
            # Use primary email if not specified
            target_email = email_address or user.email
            if not target_email:
                raise ValidationException("No email address available for MFA setup")
            
            # Validate email format
            validated_email = self._validate_email(target_email)
            
            # Check rate limits for email setup
            await self._check_email_rate_limit(user_id)
            
            # Generate verification code
            verification_code = self._generate_alphanumeric_code(8)
            encrypted_email = self._encrypt_secret(validated_email)
            
            # Create MFA method (inactive until verified)
            mfa_method = await self._create_or_update_mfa_method(
                user_id=user_id,
                method_type="email",
                encrypted_data=encrypted_email,
                metadata={
                    "email_masked": self._mask_email(validated_email),
                    "verification_code": self._encrypt_secret(verification_code),
                    "verification_expires": (datetime.utcnow() + timedelta(minutes=10)).isoformat(),
                    "setup_ip": await self._get_client_ip()
                },
                is_active=False,
                created_by=current_user_id
            )
            
            # Send verification email
            await self.email_service.send_mfa_setup_code(
                email_address=validated_email,
                verification_code=verification_code,
                user_name=user.first_name or user.username
            )
            
            # Log security event
            await self._log_security_event(
                user_id, "mfa_email_setup_initiated",
                {"method_id": str(mfa_method.id), "email_masked": self._mask_email(validated_email)}
            )
            
            return EmailSetupResponse(
                method_id=mfa_method.id,
                email_masked=self._mask_email(validated_email),
                verification_required=True,
                expires_at=datetime.utcnow() + timedelta(minutes=10)
            )
            
        except Exception as e:
            self.logger.error(f"Error setting up email MFA: {str(e)}", exc_info=True)
            raise BusinessLogicException("Failed to setup email authentication")
    
    # ========================================================================
    # MFA VERIFICATION AND VALIDATION
    # ========================================================================
    
    async def verify_mfa_setup(
        self,
        method_id: uuid.UUID,
        verification_code: str,
        device_info: Optional[Dict[str, Any]] = None
    ) -> MfaSetupResponse:
        """
        Verify MFA setup with the provided code.
        
        Args:
            method_id: MFA method ID
            verification_code: Verification code from user
            device_info: Optional device information
            
        Returns:
            MfaSetupResponse: Confirmation of successful setup
        """
        try:
            # Get MFA method
            mfa_method = await self._get_mfa_method(method_id)
            if not mfa_method:
                raise ValidationException("Invalid MFA method")
            
            # Verify based on method type
            if mfa_method.method_type == "totp":
                success = await self._verify_totp_setup(mfa_method, verification_code)
            elif mfa_method.method_type == "sms":
                success = await self._verify_sms_setup(mfa_method, verification_code)
            elif mfa_method.method_type == "email":
                success = await self._verify_email_setup(mfa_method, verification_code)
            else:
                raise ValidationException("Unsupported MFA method type")
            
            if not success:
                await self._log_security_event(
                    mfa_method.user_id, "mfa_setup_verification_failed",
                    {"method_id": str(method_id), "method_type": mfa_method.method_type}
                )
                raise AuthenticationException("Invalid verification code")
            
            # Activate MFA method
            mfa_method.is_active = True
            mfa_method.activated_at = datetime.utcnow()
            mfa_method.metadata.update({
                "activation_ip": await self._get_client_ip(),
                "device_info": device_info
            })
            await self.db.commit()
            
            # Generate backup codes
            backup_codes = await self._generate_backup_codes(mfa_method.user_id)
            
            # Log successful setup
            await self._log_security_event(
                mfa_method.user_id, "mfa_setup_completed",
                {"method_id": str(method_id), "method_type": mfa_method.method_type}
            )
            
            return MfaSetupResponse(
                method_id=method_id,
                method_type=mfa_method.method_type,
                is_active=True,
                backup_codes=backup_codes,
                activated_at=mfa_method.activated_at
            )
            
        except Exception as e:
            self.logger.error(f"Error verifying MFA setup: {str(e)}", exc_info=True)
            raise AuthenticationException("MFA setup verification failed")
    
    async def verify_mfa_challenge(
        self,
        user_id: uuid.UUID,
        method_type: str,
        challenge_code: str,
        device_info: Optional[Dict[str, Any]] = None,
        trust_device: bool = False
    ) -> MfaVerificationResponse:
        """
        Verify MFA challenge during authentication.
        
        Args:
            user_id: User ID
            method_type: MFA method type
            challenge_code: Challenge code from user
            device_info: Device information
            trust_device: Whether to trust this device
            
        Returns:
            MfaVerificationResponse: Verification result with session info
        """
        try:
            # Get active MFA method
            mfa_method = await self._get_user_mfa_method(user_id, method_type)
            if not mfa_method or not mfa_method.is_active:
                raise ValidationException(f"No active {method_type} MFA method found")
            
            # Check rate limits
            await self._check_mfa_rate_limit(user_id, method_type)
            
            # Verify challenge code
            verification_result = await self._verify_challenge_code(
                mfa_method, challenge_code, device_info
            )
            
            if not verification_result["valid"]:
                # Log failed attempt
                await self._log_security_event(
                    user_id, "mfa_verification_failed",
                    {
                        "method_type": method_type,
                        "reason": verification_result.get("reason"),
                        "device_info": device_info
                    }
                )
                raise AuthenticationException("Invalid MFA code")
            
            # Create MFA session
            session_token = await self._create_mfa_session(
                user_id, mfa_method.id, device_info, trust_device
            )
            
            # Handle device trust
            trusted_device_token = None
            if trust_device and device_info:
                trusted_device_token = await self._create_trusted_device(
                    user_id, device_info
                )
            
            # Log successful verification
            await self._log_security_event(
                user_id, "mfa_verification_successful",
                {
                    "method_type": method_type,
                    "device_trusted": trust_device,
                    "device_info": device_info
                }
            )
            
            return MfaVerificationResponse(
                verified=True,
                session_token=session_token,
                expires_at=datetime.utcnow() + timedelta(hours=settings.MFA_SESSION_DURATION_HOURS),
                trusted_device_token=trusted_device_token,
                requires_step_up=verification_result.get("requires_step_up", False)
            )
            
        except Exception as e:
            self.logger.error(f"Error verifying MFA challenge: {str(e)}", exc_info=True)
            raise AuthenticationException("MFA verification failed")
    
    # ========================================================================
    # BACKUP CODES AND RECOVERY
    # ========================================================================
    
    async def generate_backup_codes(
        self,
        user_id: uuid.UUID,
        count: int = 10,
        current_user_id: Optional[uuid.UUID] = None
    ) -> MfaBackupCodesResponse:
        """
        Generate new backup codes for MFA recovery.
        
        Args:
            user_id: User ID
            count: Number of backup codes to generate
            current_user_id: ID of user generating codes
            
        Returns:
            MfaBackupCodesResponse: Generated backup codes
        """
        try:
            # Validate user
            user = await self._get_user(user_id)
            
            # Check if user has active MFA methods
            active_methods = await self._get_active_mfa_methods(user_id)
            if not active_methods:
                raise BusinessLogicException("User must have active MFA methods to generate backup codes")
            
            # Generate backup codes
            backup_codes = [self._generate_backup_code() for _ in range(count)]
            encrypted_codes = [self._encrypt_secret(code) for code in backup_codes]
            
            # Store backup codes
            await self._store_backup_codes(user_id, encrypted_codes, current_user_id)
            
            # Log security event
            await self._log_security_event(
                user_id, "mfa_backup_codes_generated",
                {"count": count, "generated_by": str(current_user_id) if current_user_id else None}
            )
            
            return MfaBackupCodesResponse(
                codes=backup_codes,
                generated_at=datetime.utcnow(),
                expires_at=datetime.utcnow() + timedelta(days=settings.MFA_BACKUP_CODE_EXPIRY_DAYS),
                usage_instructions="Store these codes securely. Each code can only be used once."
            )
            
        except Exception as e:
            self.logger.error(f"Error generating backup codes: {str(e)}", exc_info=True)
            raise BusinessLogicException("Failed to generate backup codes")
    
    async def verify_backup_code(
        self,
        user_id: uuid.UUID,
        backup_code: str,
        device_info: Optional[Dict[str, Any]] = None
    ) -> MfaVerificationResponse:
        """
        Verify backup code for MFA recovery.
        
        Args:
            user_id: User ID
            backup_code: Backup code provided by user
            device_info: Device information
            
        Returns:
            MfaVerificationResponse: Verification result
        """
        try:
            # Get user's backup codes
            backup_codes = await self._get_user_backup_codes(user_id)
            if not backup_codes:
                raise ValidationException("No backup codes available")
            
            # Check rate limits
            await self._check_backup_code_rate_limit(user_id)
            
            # Verify backup code
            valid_code = None
            for code_record in backup_codes:
                decrypted_code = self._decrypt_secret(code_record.encrypted_code)
                if secrets.compare_digest(decrypted_code, backup_code.strip().upper()):
                    if not code_record.used_at:
                        valid_code = code_record
                        break
            
            if not valid_code:
                await self._log_security_event(
                    user_id, "mfa_backup_code_verification_failed",
                    {"device_info": device_info}
                )
                raise AuthenticationException("Invalid or already used backup code")
            
            # Mark backup code as used
            valid_code.used_at = datetime.utcnow()
            valid_code.used_from_ip = await self._get_client_ip()
            await self.db.commit()
            
            # Create MFA session (shorter duration for backup codes)
            session_token = await self._create_mfa_session(
                user_id, None, device_info, trust_device=False,
                duration_hours=settings.MFA_BACKUP_SESSION_DURATION_HOURS
            )
            
            # Log successful verification
            await self._log_security_event(
                user_id, "mfa_backup_code_used",
                {"backup_code_id": str(valid_code.id), "device_info": device_info}
            )
            
            # Check if running low on codes
            remaining_codes = await self._count_unused_backup_codes(user_id)
            requires_regeneration = remaining_codes <= settings.MFA_BACKUP_CODE_LOW_THRESHOLD
            
            return MfaVerificationResponse(
                verified=True,
                session_token=session_token,
                expires_at=datetime.utcnow() + timedelta(hours=settings.MFA_BACKUP_SESSION_DURATION_HOURS),
                backup_code_used=True,
                remaining_backup_codes=remaining_codes,
                requires_backup_code_regeneration=requires_regeneration
            )
            
        except Exception as e:
            self.logger.error(f"Error verifying backup code: {str(e)}", exc_info=True)
            raise AuthenticationException("Backup code verification failed")
    
    # ========================================================================
    # MFA STATUS AND MANAGEMENT
    # ========================================================================
    
    async def get_mfa_status(
        self,
        user_id: uuid.UUID,
        include_recovery_info: bool = False
    ) -> MfaStatusResponse:
        """
        Get comprehensive MFA status for a user.
        
        Args:
            user_id: User ID
            include_recovery_info: Whether to include recovery information
            
        Returns:
            MfaStatusResponse: Complete MFA status
        """
        try:
            # Get all MFA methods
            mfa_methods = await self._get_all_user_mfa_methods(user_id)
            
            # Build method info
            methods = []
            for method in mfa_methods:
                method_info = MfaDeviceInfo(
                    id=method.id,
                    method_type=method.method_type,
                    is_active=method.is_active,
                    is_primary=method.is_primary,
                    created_at=method.created_at,
                    activated_at=method.activated_at,
                    last_used_at=method.last_used_at,
                    device_name=method.metadata.get("device_name"),
                    masked_identifier=self._get_masked_identifier(method)
                )
                methods.append(method_info)
            
            # Check backup codes status
            backup_codes_info = None
            if include_recovery_info:
                backup_codes_count = await self._count_unused_backup_codes(user_id)
                backup_codes_info = {
                    "available_count": backup_codes_count,
                    "total_generated": await self._count_total_backup_codes(user_id),
                    "requires_regeneration": backup_codes_count <= settings.MFA_BACKUP_CODE_LOW_THRESHOLD
                }
            
            # Get trusted devices
            trusted_devices = await self._get_trusted_devices(user_id)
            
            return MfaStatusResponse(
                user_id=user_id,
                mfa_enabled=len([m for m in methods if m.is_active]) > 0,
                methods=methods,
                primary_method=next((m.method_type for m in methods if m.is_primary), None),
                backup_codes_info=backup_codes_info,
                trusted_devices_count=len(trusted_devices),
                last_mfa_verification=await self._get_last_mfa_verification(user_id)
            )
            
        except Exception as e:
            self.logger.error(f"Error getting MFA status: {str(e)}", exc_info=True)
            raise BusinessLogicException("Failed to get MFA status")
    
    async def disable_mfa_method(
        self,
        method_id: uuid.UUID,
        current_user_id: uuid.UUID,
        reason: Optional[str] = None
    ) -> bool:
        """
        Disable an MFA method.
        
        Args:
            method_id: MFA method ID
            current_user_id: ID of user disabling the method
            reason: Optional reason for disabling
            
        Returns:
            bool: Success status
        """
        try:
            # Get MFA method
            mfa_method = await self._get_mfa_method(method_id)
            if not mfa_method:
                raise ValidationException("MFA method not found")
            
            # Validate permissions
            if str(mfa_method.user_id) != str(current_user_id):
                # Check if current user has admin permissions
                current_user = await self._get_user(current_user_id)
                if not current_user.is_superuser:
                    raise ValidationException("Insufficient permissions")
            
            # Check if this is the last active method
            active_methods = await self._get_active_mfa_methods(mfa_method.user_id)
            if len(active_methods) == 1 and active_methods[0].id == method_id:
                # Allow disabling last method but warn
                self.logger.warning(f"Disabling last MFA method for user {mfa_method.user_id}")
            
            # Disable method
            mfa_method.is_active = False
            mfa_method.disabled_at = datetime.utcnow()
            mfa_method.disabled_by = current_user_id
            mfa_method.metadata["disable_reason"] = reason
            
            await self.db.commit()
            
            # Log security event
            await self._log_security_event(
                mfa_method.user_id, "mfa_method_disabled",
                {
                    "method_id": str(method_id),
                    "method_type": mfa_method.method_type,
                    "disabled_by": str(current_user_id),
                    "reason": reason
                }
            )
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error disabling MFA method: {str(e)}", exc_info=True)
            raise BusinessLogicException("Failed to disable MFA method")
    
    # ========================================================================
    # INTERNAL HELPER METHODS
    # ========================================================================
    
    async def _get_user(self, user_id: uuid.UUID) -> User:
        """Get user by ID with validation."""
        stmt = select(User).where(User.id == user_id)
        result = await self.db.execute(stmt)
        user = result.scalar_one_or_none()
        if not user:
            raise ValidationException("User not found")
        return user
    
    async def _get_mfa_method(self, method_id: uuid.UUID) -> Optional[MfaMethod]:
        """Get MFA method by ID."""
        stmt = select(MfaMethod).where(MfaMethod.id == method_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
    
    async def _get_user_mfa_method(
        self, 
        user_id: uuid.UUID, 
        method_type: str
    ) -> Optional[MfaMethod]:
        """Get specific MFA method for user."""
        stmt = select(MfaMethod).where(
            and_(
                MfaMethod.user_id == user_id,
                MfaMethod.method_type == method_type,
                MfaMethod.is_active == True
            )
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
    
    def _encrypt_secret(self, secret: str) -> str:
        """Encrypt sensitive data."""
        return self.cipher_suite.encrypt(secret.encode()).decode()
    
    def _decrypt_secret(self, encrypted_secret: str) -> str:
        """Decrypt sensitive data."""
        return self.cipher_suite.decrypt(encrypted_secret.encode()).decode()
    
    def _generate_qr_code(self, data: str) -> str:
        """Generate QR code for TOTP setup."""
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        
        return base64.b64encode(buffer.getvalue()).decode()
    
    def _generate_numeric_code(self, length: int = 6) -> str:
        """Generate numeric verification code."""
        return ''.join(secrets.choice('0123456789') for _ in range(length))
    
    def _generate_alphanumeric_code(self, length: int = 8) -> str:
        """Generate alphanumeric verification code."""
        alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        return ''.join(secrets.choice(alphabet) for _ in range(length))
    
    def _generate_backup_code(self) -> str:
        """Generate backup recovery code."""
        # Format: XXXX-XXXX-XXXX
        parts = []
        for _ in range(3):
            part = ''.join(secrets.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') for _ in range(4))
            parts.append(part)
        return '-'.join(parts)
    
    def _mask_phone_number(self, phone: str) -> str:
        """Mask phone number for display."""
        if len(phone) <= 4:
            return "*" * len(phone)
        return phone[:-4].replace(phone[:-4], "*" * len(phone[:-4])) + phone[-4:]
    
    def _mask_email(self, email: str) -> str:
        """Mask email address for display."""
        if '@' not in email:
            return "*" * len(email)
        local, domain = email.split('@', 1)
        if len(local) <= 2:
            masked_local = "*" * len(local)
        else:
            masked_local = local[0] + "*" * (len(local) - 2) + local[-1]
        return f"{masked_local}@{domain}"
    
    def _validate_phone_number(self, phone: str) -> str:
        """Validate and normalize phone number."""
        # Remove all non-digit characters
        digits_only = ''.join(filter(str.isdigit, phone))
        
        # Basic validation - adjust based on your requirements
        if len(digits_only) < 10 or len(digits_only) > 15:
            raise ValidationException("Invalid phone number format")
        
        # Add country code if missing (assuming US +1 for example)
        if len(digits_only) == 10:
            digits_only = "1" + digits_only
        
        return "+" + digits_only
    
    def _validate_email(self, email: str) -> str:
        """Validate email format."""
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}
    
        if not re.match(pattern, email):
            raise ValidationException("Invalid email format")
        return email.lower()
    
    async def _create_or_update_mfa_method(
        self,
        user_id: uuid.UUID,
        method_type: str,
        encrypted_data: str,
        metadata: Dict[str, Any],
        is_active: bool = True,
        created_by: Optional[uuid.UUID] = None
    ) -> MfaMethod:
        """Create or update MFA method."""
        # Check if method already exists
        existing_method = await self._get_user_mfa_method(user_id, method_type)
        
        if existing_method:
            # Update existing method
            existing_method.encrypted_data = encrypted_data
            existing_method.metadata.update(metadata)
            existing_method.is_active = is_active
            existing_method.updated_at = datetime.utcnow()
            existing_method.updated_by = created_by
            mfa_method = existing_method
        else:
            # Create new method
            mfa_method = MfaMethod(
                id=uuid.uuid4(),
                user_id=user_id,
                method_type=method_type,
                encrypted_data=encrypted_data,
                metadata=metadata,
                is_active=is_active,
                is_primary=await self._should_be_primary(user_id),
                created_by=created_by
            )
            self.db.add(mfa_method)
        
        await self.db.commit()
        return mfa_method
    
    async def _should_be_primary(self, user_id: uuid.UUID) -> bool:
        """Check if this should be the primary MFA method."""
        active_methods_count = await self.db.execute(
            select(func.count(MfaMethod.id)).where(
                and_(MfaMethod.user_id == user_id, MfaMethod.is_active == True)
            )
        )
        return active_methods_count.scalar() == 0
    
    async def _verify_totp_setup(self, mfa_method: MfaMethod, code: str) -> bool:
        """Verify TOTP setup code."""
        try:
            secret = self._decrypt_secret(mfa_method.encrypted_data)
            totp = pyotp.TOTP(secret)
            return totp.verify(code, valid_window=2)  # Allow 2 time windows for clock drift
        except Exception as e:
            self.logger.error(f"Error verifying TOTP setup: {str(e)}")
            return False
    
    async def _verify_sms_setup(self, mfa_method: MfaMethod, code: str) -> bool:
        """Verify SMS setup code."""
        try:
            metadata = mfa_method.metadata
            stored_code = self._decrypt_secret(metadata.get("verification_code", ""))
            expires_str = metadata.get("verification_expires")
            
            if not expires_str:
                return False
            
            expires_at = datetime.fromisoformat(expires_str)
            if datetime.utcnow() > expires_at:
                return False
            
            return secrets.compare_digest(stored_code, code.strip())
        except Exception as e:
            self.logger.error(f"Error verifying SMS setup: {str(e)}")
            return False
    
    async def _verify_email_setup(self, mfa_method: MfaMethod, code: str) -> bool:
        """Verify email setup code."""
        try:
            metadata = mfa_method.metadata
            stored_code = self._decrypt_secret(metadata.get("verification_code", ""))
            expires_str = metadata.get("verification_expires")
            
            if not expires_str:
                return False
            
            expires_at = datetime.fromisoformat(expires_str)
            if datetime.utcnow() > expires_at:
                return False
            
            return secrets.compare_digest(stored_code.upper(), code.strip().upper())
        except Exception as e:
            self.logger.error(f"Error verifying email setup: {str(e)}")
            return False
    
    async def _verify_challenge_code(
        self,
        mfa_method: MfaMethod,
        challenge_code: str,
        device_info: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Verify MFA challenge code."""
        try:
            if mfa_method.method_type == "totp":
                return await self._verify_totp_challenge(mfa_method, challenge_code)
            elif mfa_method.method_type == "sms":
                return await self._verify_sms_challenge(mfa_method, challenge_code)
            elif mfa_method.method_type == "email":
                return await self._verify_email_challenge(mfa_method, challenge_code)
            else:
                return {"valid": False, "reason": "unsupported_method"}
        except Exception as e:
            self.logger.error(f"Error verifying challenge code: {str(e)}")
            return {"valid": False, "reason": "verification_error"}
    
    async def _verify_totp_challenge(self, mfa_method: MfaMethod, code: str) -> Dict[str, Any]:
        """Verify TOTP challenge."""
        try:
            secret = self._decrypt_secret(mfa_method.encrypted_data)
            totp = pyotp.TOTP(secret)
            
            # Check current code with window for clock drift
            if totp.verify(code, valid_window=2):
                # Update last used
                mfa_method.last_used_at = datetime.utcnow()
                await self.db.commit()
                return {"valid": True}
            
            return {"valid": False, "reason": "invalid_code"}
        except Exception as e:
            self.logger.error(f"TOTP verification error: {str(e)}")
            return {"valid": False, "reason": "verification_error"}
    
    async def _verify_sms_challenge(self, mfa_method: MfaMethod, code: str) -> Dict[str, Any]:
        """Verify SMS challenge."""
        # For SMS, we need to send a new code for each challenge
        # This is a simplified implementation
        try:
            # In a real implementation, you would:
            # 1. Send SMS with new code
            # 2. Store the code temporarily
            # 3. Verify against stored code
            # For now, return success for demonstration
            
            phone = self._decrypt_secret(mfa_method.encrypted_data)
            verification_code = self._generate_numeric_code(6)
            
            # Send SMS
            await self.sms_service.send_mfa_challenge_code(phone, verification_code)
            
            # Store code temporarily (in real implementation, use Redis or similar)
            mfa_method.metadata["challenge_code"] = self._encrypt_secret(verification_code)
            mfa_method.metadata["challenge_expires"] = (
                datetime.utcnow() + timedelta(minutes=5)
            ).isoformat()
            
            await self.db.commit()
            
            # For this demo, assume the code matches
            stored_code = self._decrypt_secret(mfa_method.metadata.get("challenge_code", ""))
            if secrets.compare_digest(stored_code, code.strip()):
                mfa_method.last_used_at = datetime.utcnow()
                await self.db.commit()
                return {"valid": True}
            
            return {"valid": False, "reason": "invalid_code"}
            
        except Exception as e:
            self.logger.error(f"SMS verification error: {str(e)}")
            return {"valid": False, "reason": "verification_error"}
    
    async def _verify_email_challenge(self, mfa_method: MfaMethod, code: str) -> Dict[str, Any]:
        """Verify email challenge."""
        try:
            # Similar to SMS, send new code for each challenge
            email = self._decrypt_secret(mfa_method.encrypted_data)
            verification_code = self._generate_alphanumeric_code(8)
            
            # Send email
            user = await self._get_user(mfa_method.user_id)
            await self.email_service.send_mfa_challenge_code(
                email, verification_code, user.first_name or user.username
            )
            
            # Store code temporarily
            mfa_method.metadata["challenge_code"] = self._encrypt_secret(verification_code)
            mfa_method.metadata["challenge_expires"] = (
                datetime.utcnow() + timedelta(minutes=10)
            ).isoformat()
            
            await self.db.commit()
            
            # Verify code
            stored_code = self._decrypt_secret(mfa_method.metadata.get("challenge_code", ""))
            if secrets.compare_digest(stored_code.upper(), code.strip().upper()):
                mfa_method.last_used_at = datetime.utcnow()
                await self.db.commit()
                return {"valid": True}
            
            return {"valid": False, "reason": "invalid_code"}
            
        except Exception as e:
            self.logger.error(f"Email verification error: {str(e)}")
            return {"valid": False, "reason": "verification_error"}
    
    async def _create_mfa_session(
        self,
        user_id: uuid.UUID,
        method_id: Optional[uuid.UUID],
        device_info: Optional[Dict[str, Any]],
        trust_device: bool = False,
        duration_hours: int = None
    ) -> str:
        """Create MFA verification session."""
        duration = duration_hours or settings.MFA_SESSION_DURATION_HOURS
        expires_at = datetime.utcnow() + timedelta(hours=duration)
        
        session = MfaSession(
            id=uuid.uuid4(),
            user_id=user_id,
            method_id=method_id,
            session_token=secrets.token_urlsafe(32),
            device_info=device_info,
            trusted_device=trust_device,
            expires_at=expires_at,
            ip_address=await self._get_client_ip(),
            user_agent=await self._get_user_agent()
        )
        
        self.db.add(session)
        await self.db.commit()
        
        return session.session_token
    
    async def _create_trusted_device(
        self,
        user_id: uuid.UUID,
        device_info: Dict[str, Any]
    ) -> str:
        """Create trusted device record."""
        device_token = secrets.token_urlsafe(32)
        fingerprint = self._generate_device_fingerprint(device_info)
        
        trusted_device = UserDevice(
            id=uuid.uuid4(),
            user_id=user_id,
            device_token=device_token,
            device_fingerprint=fingerprint,
            device_name=device_info.get("name", "Unknown Device"),
            device_type=device_info.get("type", "unknown"),
            os_info=device_info.get("os"),
            browser_info=device_info.get("browser"),
            is_trusted=True,
            trusted_at=datetime.utcnow(),
            expires_at=datetime.utcnow() + timedelta(days=settings.TRUSTED_DEVICE_EXPIRY_DAYS)
        )
        
        self.db.add(trusted_device)
        await self.db.commit()
        
        return device_token
    
    def _generate_device_fingerprint(self, device_info: Dict[str, Any]) -> str:
        """Generate unique device fingerprint."""
        import hashlib
        
        fingerprint_data = {
            "user_agent": device_info.get("user_agent", ""),
            "screen_resolution": device_info.get("screen_resolution", ""),
            "timezone": device_info.get("timezone", ""),
            "language": device_info.get("language", ""),
            "platform": device_info.get("platform", "")
        }
        
        fingerprint_string = "|".join(str(v) for v in fingerprint_data.values())
        return hashlib.sha256(fingerprint_string.encode()).hexdigest()
    
    async def _generate_backup_codes(self, user_id: uuid.UUID) -> List[str]:
        """Generate backup codes for user."""
        # Implementation would generate and store backup codes
        codes = [self._generate_backup_code() for _ in range(10)]
        await self._store_backup_codes(user_id, [self._encrypt_secret(code) for code in codes])
        return codes
    
    async def _generate_recovery_codes(self, user_id: uuid.UUID) -> List[str]:
        """Generate recovery codes for account recovery."""
        codes = [self._generate_backup_code() for _ in range(5)]
        # Store with different type for recovery vs backup
        await self._store_recovery_codes(user_id, [self._encrypt_secret(code) for code in codes])
        return codes
    
    async def _store_backup_codes(
        self, 
        user_id: uuid.UUID, 
        encrypted_codes: List[str],
        created_by: Optional[uuid.UUID] = None
    ):
        """Store encrypted backup codes."""
        # Implementation would store in database
        # This is a placeholder for the actual implementation
        pass
    
    async def _store_recovery_codes(self, user_id: uuid.UUID, encrypted_codes: List[str]):
        """Store encrypted recovery codes."""
        # Implementation would store recovery codes
        pass
    
    async def _get_active_mfa_methods(self, user_id: uuid.UUID) -> List[MfaMethod]:
        """Get all active MFA methods for user."""
        stmt = select(MfaMethod).where(
            and_(MfaMethod.user_id == user_id, MfaMethod.is_active == True)
        )
        result = await self.db.execute(stmt)
        return result.scalars().all()
    
    async def _get_all_user_mfa_methods(self, user_id: uuid.UUID) -> List[MfaMethod]:
        """Get all MFA methods for user (active and inactive)."""
        stmt = select(MfaMethod).where(MfaMethod.user_id == user_id)
        result = await self.db.execute(stmt)
        return result.scalars().all()
    
    async def _get_user_backup_codes(self, user_id: uuid.UUID):
        """Get user's backup codes."""
        # Implementation would retrieve from database
        # Placeholder for actual implementation
        return []
    
    async def _count_unused_backup_codes(self, user_id: uuid.UUID) -> int:
        """Count unused backup codes."""
        # Implementation would count unused codes
        return 0
    
    async def _count_total_backup_codes(self, user_id: uuid.UUID) -> int:
        """Count total backup codes ever generated."""
        # Implementation would count total codes
        return 0
    
    async def _get_trusted_devices(self, user_id: uuid.UUID) -> List[UserDevice]:
        """Get trusted devices for user."""
        stmt = select(UserDevice).where(
            and_(
                UserDevice.user_id == user_id,
                UserDevice.is_trusted == True,
                UserDevice.expires_at > datetime.utcnow()
            )
        )
        result = await self.db.execute(stmt)
        return result.scalars().all()
    
    async def _get_last_mfa_verification(self, user_id: uuid.UUID) -> Optional[datetime]:
        """Get last MFA verification timestamp."""
        stmt = select(func.max(MfaSession.created_at)).where(
            MfaSession.user_id == user_id
        )
        result = await self.db.execute(stmt)
        return result.scalar()
    
    def _get_masked_identifier(self, mfa_method: MfaMethod) -> str:
        """Get masked identifier for display."""
        if mfa_method.method_type == "sms":
            phone = self._decrypt_secret(mfa_method.encrypted_data)
            return self._mask_phone_number(phone)
        elif mfa_method.method_type == "email":
            email = self._decrypt_secret(mfa_method.encrypted_data)
            return self._mask_email(email)
        elif mfa_method.method_type == "totp":
            return "Authenticator App"
        return "Unknown"
    
    async def _log_security_event(
        self,
        user_id: uuid.UUID,
        event_type: str,
        details: Dict[str, Any]
    ):
        """Log security event."""
        event = SecurityEvent(
            id=uuid.uuid4(),
            user_id=user_id,
            event_type=event_type,
            event_details=details,
            ip_address=await self._get_client_ip(),
            user_agent=await self._get_user_agent(),
            created_at=datetime.utcnow()
        )
        
        self.db.add(event)
        await self.db.commit()
    
    async def _get_client_ip(self) -> str:
        """Get client IP address from request context."""
        # This would be implemented to get actual client IP
        # For now, return placeholder
        return "0.0.0.0"
    
    async def _get_user_agent(self) -> str:
        """Get user agent from request context."""
        # This would be implemented to get actual user agent
        # For now, return placeholder
        return "Unknown"
    
    async def _check_mfa_rate_limit(self, user_id: uuid.UUID, method_type: str):
        """Check MFA verification rate limits."""
        # Implementation would check rate limits
        # For now, placeholder
        pass
    
    async def _check_sms_rate_limit(self, user_id: uuid.UUID):
        """Check SMS sending rate limits."""
        # Implementation would check SMS rate limits
        pass
    
    async def _check_email_rate_limit(self, user_id: uuid.UUID):
        """Check email sending rate limits."""
        # Implementation would check email rate limits
        pass
    
    async def _check_backup_code_rate_limit(self, user_id: uuid.UUID):
        """Check backup code verification rate limits."""
        # Implementation would check backup code rate limits
        pass


# Export the service
__all__ = ["MfaService"]