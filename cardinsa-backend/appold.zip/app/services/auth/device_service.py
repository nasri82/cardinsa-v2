"""
Device Service

Enterprise device fingerprinting and tracking for Cardinsa Insurance API.
Handles device identification, security monitoring, and trusted device management.
"""

from typing import Dict, List, Optional, Any, Tuple
from uuid import UUID, uuid4
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func
import hashlib
import json
from user_agents import parse as parse_user_agent

from app.core.exceptions import (
    DeviceException,
    SuspiciousDeviceException,
    DeviceNotFoundException,
    TooManyDevicesException
)
from app.models.auth.user import User, Device, DeviceFingerprint, Session as UserSession
from app.config.settings import get_settings

settings = get_settings()


class DeviceService:
    """Enterprise Device Management Service"""

    def __init__(self, db: Session):
        self.db = db
        
        # Device configuration
        self.max_devices_per_user = 20
        self.device_cleanup_days = 90  # Remove inactive devices after 90 days
        self.trusted_device_duration = timedelta(days=30)
        
        # Security thresholds
        self.suspicious_device_threshold = 5  # New devices in short period
        self.device_analysis_window_hours = 24

    async def get_or_create_device_fingerprint(
        self,
        user_id: UUID,
        ip_address: str,
        user_agent: str,
        device_info: Dict[str, Any],
        canvas_fingerprint: Optional[str] = None,
        webgl_fingerprint: Optional[str] = None,
        screen_resolution: Optional[str] = None,
        timezone: Optional[str] = None,
        language: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get existing device fingerprint or create new one
        
        Args:
            user_id: User's unique identifier
            ip_address: Client IP address
            user_agent: Client user agent string
            device_info: Parsed device information
            canvas_fingerprint: Canvas fingerprint (optional)
            webgl_fingerprint: WebGL fingerprint (optional)
            screen_resolution: Screen resolution (optional)
            timezone: Timezone (optional)
            language: Language preference (optional)
            
        Returns:
            Dict containing device fingerprint and metadata
            
        Raises:
            DeviceException: If fingerprinting fails
        """
        try:
            # Generate comprehensive fingerprint
            fingerprint_data = self._generate_fingerprint_data(
                ip_address, user_agent, device_info, canvas_fingerprint,
                webgl_fingerprint, screen_resolution, timezone, language
            )
            
            fingerprint_hash = self._calculate_fingerprint_hash(fingerprint_data)
            
            # Check if fingerprint exists
            existing_fingerprint = self.db.query(DeviceFingerprint).filter(
                DeviceFingerprint.fingerprint_hash == fingerprint_hash
            ).first()
            
            if existing_fingerprint:
                # Update last seen
                existing_fingerprint.last_seen_at = datetime.utcnow()
                existing_fingerprint.seen_count = (existing_fingerprint.seen_count or 0) + 1
                
                # Update IP if changed
                if existing_fingerprint.ip_address != ip_address:
                    existing_fingerprint.previous_ip_addresses = existing_fingerprint.previous_ip_addresses or []
                    if existing_fingerprint.ip_address not in existing_fingerprint.previous_ip_addresses:
                        existing_fingerprint.previous_ip_addresses.append(existing_fingerprint.ip_address)
                    existing_fingerprint.ip_address = ip_address
                
                self.db.commit()
                
                return {
                    "fingerprint": fingerprint_hash,
                    "is_new": False,
                    "device_id": existing_fingerprint.id,
                    "first_seen": existing_fingerprint.first_seen_at.isoformat(),
                    "last_seen": existing_fingerprint.last_seen_at.isoformat(),
                    "seen_count": existing_fingerprint.seen_count,
                    "risk_score": await self._calculate_device_risk_score(existing_fingerprint, user_id)
                }
            
            # Create new fingerprint
            new_fingerprint = DeviceFingerprint(
                id=uuid4(),
                fingerprint_hash=fingerprint_hash,
                fingerprint_data=fingerprint_data,
                ip_address=ip_address,
                user_agent=user_agent,
                device_info=device_info,
                first_seen_at=datetime.utcnow(),
                last_seen_at=datetime.utcnow(),
                seen_count=1,
                is_suspicious=await self._is_suspicious_device(user_id, fingerprint_data)
            )
            
            self.db.add(new_fingerprint)
            
            # Check device limits for user
            await self._check_device_limits(user_id)
            
            # Create device record for user
            device = await self._create_or_update_user_device(
                user_id, new_fingerprint.id, device_info
            )
            
            self.db.commit()
            
            risk_score = await self._calculate_device_risk_score(new_fingerprint, user_id)
            
            return {
                "fingerprint": fingerprint_hash,
                "is_new": True,
                "device_id": new_fingerprint.id,
                "user_device_id": device.id,
                "first_seen": new_fingerprint.first_seen_at.isoformat(),
                "last_seen": new_fingerprint.last_seen_at.isoformat(),
                "seen_count": 1,
                "risk_score": risk_score,
                "is_suspicious": new_fingerprint.is_suspicious
            }
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (TooManyDevicesException, SuspiciousDeviceException)):
                raise
            raise DeviceException(f"Failed to process device fingerprint: {str(e)}")

    async def trust_device(
        self,
        user_id: UUID,
        device_id: UUID,
        trust_duration: Optional[timedelta] = None
    ) -> Dict[str, Any]:
        """
        Mark a device as trusted for the user
        
        Args:
            user_id: User's unique identifier
            device_id: Device ID to trust
            trust_duration: How long to trust the device
            
        Returns:
            Dict with trust status
            
        Raises:
            DeviceNotFoundException: If device not found
        """
        try:
            device = self.db.query(Device).filter(
                and_(
                    Device.id == device_id,
                    Device.user_id == user_id
                )
            ).first()
            
            if not device:
                raise DeviceNotFoundException("Device not found")
            
            duration = trust_duration or self.trusted_device_duration
            
            device.is_trusted = True
            device.trusted_at = datetime.utcnow()
            device.trust_expires_at = datetime.utcnow() + duration
            
            self.db.commit()
            
            return {
                "trusted": True,
                "device_id": device_id,
                "trusted_until": device.trust_expires_at.isoformat(),
                "trust_duration_days": duration.days
            }
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, DeviceNotFoundException):
                raise
            raise DeviceException(f"Failed to trust device: {str(e)}")

    async def revoke_device_trust(
        self,
        user_id: UUID,
        device_id: UUID
    ) -> Dict[str, Any]:
        """
        Revoke trust for a device
        
        Args:
            user_id: User's unique identifier
            device_id: Device ID to untrust
            
        Returns:
            Dict with revocation status
        """
        try:
            device = self.db.query(Device).filter(
                and_(
                    Device.id == device_id,
                    Device.user_id == user_id
                )
            ).first()
            
            if not device:
                raise DeviceNotFoundException("Device not found")
            
            device.is_trusted = False
            device.trust_revoked_at = datetime.utcnow()
            device.trust_expires_at = None
            
            self.db.commit()
            
            return {
                "trust_revoked": True,
                "device_id": device_id,
                "revoked_at": device.trust_revoked_at.isoformat()
            }
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, DeviceNotFoundException):
                raise
            raise DeviceException(f"Failed to revoke device trust: {str(e)}")

    async def get_user_devices(
        self,
        user_id: UUID,
        include_inactive: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Get all devices for a user
        
        Args:
            user_id: User's unique identifier
            include_inactive: Whether to include inactive devices
            
        Returns:
            List of device information
        """
        try:
            query = self.db.query(Device).filter(Device.user_id == user_id)
            
            if not include_inactive:
                query = query.filter(Device.is_active == True)
            
            devices = query.order_by(desc(Device.last_used_at)).all()
            
            result = []
            for device in devices:
                # Get fingerprint details
                fingerprint = self.db.query(DeviceFingerprint).filter(
                    DeviceFingerprint.id == device.fingerprint_id
                ).first()
                
                device_info = {
                    "device_id": device.id,
                    "device_name": device.device_name,
                    "device_type": device.device_type,
                    "is_trusted": device.is_trusted,
                    "is_active": device.is_active,
                    "first_used_at": device.first_used_at.isoformat(),
                    "last_used_at": device.last_used_at.isoformat() if device.last_used_at else None,
                    "usage_count": device.usage_count or 0,
                    "current_location": device.current_location,
                    "is_current": device.last_used_at and device.last_used_at > datetime.utcnow() - timedelta(minutes=30)
                }
                
                # Trust information
                if device.is_trusted and device.trust_expires_at:
                    device_info["trust_expires_at"] = device.trust_expires_at.isoformat()
                    device_info["trust_expires_soon"] = device.trust_expires_at < datetime.utcnow() + timedelta(days=7)
                
                # Fingerprint information
                if fingerprint:
                    device_info["fingerprint"] = {
                        "fingerprint_hash": fingerprint.fingerprint_hash[:16] + "...",  # Truncated for security
                        "ip_address": fingerprint.ip_address,
                        "user_agent": fingerprint.user_agent,
                        "device_info": fingerprint.device_info,
                        "seen_count": fingerprint.seen_count,
                        "is_suspicious": fingerprint.is_suspicious,
                        "risk_score": await self._calculate_device_risk_score(fingerprint, user_id)
                    }
                
                result.append(device_info)
            
            return result
            
        except Exception as e:
            raise DeviceException(f"Failed to get user devices: {str(e)}")

    async def remove_device(
        self,
        user_id: UUID,
        device_id: UUID,
        force: bool = False
    ) -> Dict[str, Any]:
        """
        Remove/deactivate a device for a user
        
        Args:
            user_id: User's unique identifier
            device_id: Device ID to remove
            force: Whether to force removal even if it's the only device
            
        Returns:
            Dict with removal status
            
        Raises:
            DeviceNotFoundException: If device not found
            DeviceException: If cannot remove (e.g., last device)
        """
        try:
            device = self.db.query(Device).filter(
                and_(
                    Device.id == device_id,
                    Device.user_id == user_id
                )
            ).first()
            
            if not device:
                raise DeviceNotFoundException("Device not found")
            
            # Check if this is the only active device
            if not force:
                active_devices_count = self.db.query(Device).filter(
                    and_(
                        Device.user_id == user_id,
                        Device.is_active == True
                    )
                ).count()
                
                if active_devices_count <= 1:
                    raise DeviceException("Cannot remove the only active device. Use force=True to override.")
            
            # Deactivate device
            device.is_active = False
            device.removed_at = datetime.utcnow()
            device.is_trusted = False
            
            # Terminate any active sessions for this device
            self.db.query(UserSession).filter(
                and_(
                    UserSession.user_id == user_id,
                    UserSession.device_fingerprint == device.fingerprint.fingerprint_hash,
                    UserSession.is_active == True
                )
            ).update({
                "is_active": False,
                "terminated_at": datetime.utcnow(),
                "termination_reason": "device_removed"
            })
            
            self.db.commit()
            
            return {
                "removed": True,
                "device_id": device_id,
                "removed_at": device.removed_at.isoformat(),
                "sessions_terminated": True
            }
            
        except Exception as e:
            self.db.rollback()
            if isinstance(e, (DeviceNotFoundException, DeviceException)):
                raise
            raise DeviceException(f"Failed to remove device: {str(e)}")

    async def analyze_device_security(
        self,
        user_id: UUID,
        device_id: UUID
    ) -> Dict[str, Any]:
        """
        Perform comprehensive security analysis of a device
        
        Args:
            user_id: User's unique identifier
            device_id: Device ID to analyze
            
        Returns:
            Dict with security analysis results
        """
        try:
            device = self.db.query(Device).filter(
                and_(
                    Device.id == device_id,
                    Device.user_id == user_id
                )
            ).first()
            
            if not device:
                raise DeviceNotFoundException("Device not found")
            
            fingerprint = self.db.query(DeviceFingerprint).filter(
                DeviceFingerprint.id == device.fingerprint_id
            ).first()
            
            if not fingerprint:
                raise DeviceException("Device fingerprint not found")
            
            # Calculate comprehensive risk score
            risk_score = await self._calculate_comprehensive_risk_score(device, fingerprint, user_id)
            
            # Check for anomalies
            anomalies = await self._detect_device_anomalies(device, fingerprint, user_id)
            
            # Get usage patterns
            usage_patterns = await self._analyze_usage_patterns(device, user_id)
            
            # Security recommendations
            recommendations = await self._generate_security_recommendations(device, fingerprint, risk_score)
            
            return {
                "device_id": device_id,
                "overall_risk_score": risk_score,
                "risk_level": self._get_risk_level(risk_score),
                "anomalies": anomalies,
                "usage_patterns": usage_patterns,
                "security_recommendations": recommendations,
                "analysis_timestamp": datetime.utcnow().isoformat(),
                "device_health": {
                    "is_trusted": device.is_trusted,
                    "is_active": device.is_active,
                    "days_since_first_use": (datetime.utcnow() - device.first_used_at).days,
                    "usage_frequency": usage_patterns.get("frequency", "unknown")
                }
            }
            
        except Exception as e:
            if isinstance(e, (DeviceNotFoundException, DeviceException)):
                raise
            raise DeviceException(f"Failed to analyze device security: {str(e)}")

    async def cleanup_inactive_devices(self) -> Dict[str, int]:
        """
        Clean up inactive and old devices
        
        Returns:
            Dict with cleanup statistics
        """
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=self.device_cleanup_days)
            
            # Find inactive devices to remove
            inactive_devices = self.db.query(Device).filter(
                and_(
                    Device.is_active == False,
                    Device.removed_at < cutoff_date
                )
            ).all()
            
            # Find unused fingerprints
            unused_fingerprints = self.db.query(DeviceFingerprint).filter(
                and_(
                    DeviceFingerprint.last_seen_at < cutoff_date,
                    ~DeviceFingerprint.id.in_(
                        self.db.query(Device.fingerprint_id).filter(Device.is_active == True)
                    )
                )
            ).all()
            
            # Delete inactive devices
            devices_deleted = 0
            for device in inactive_devices:
                self.db.delete(device)
                devices_deleted += 1
            
            # Delete unused fingerprints
            fingerprints_deleted = 0
            for fingerprint in unused_fingerprints:
                self.db.delete(fingerprint)
                fingerprints_deleted += 1
            
            self.db.commit()
            
            return {
                "devices_deleted": devices_deleted,
                "fingerprints_deleted": fingerprints_deleted,
                "cleanup_date": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            self.db.rollback()
            raise DeviceException(f"Failed to cleanup devices: {str(e)}")

    # Private helper methods
    
    def _generate_fingerprint_data(
        self,
        ip_address: str,
        user_agent: str,
        device_info: Dict[str, Any],
        canvas_fingerprint: Optional[str] = None,
        webgl_fingerprint: Optional[str] = None,
        screen_resolution: Optional[str] = None,
        timezone: Optional[str] = None,
        language: Optional[str] = None
    ) -> Dict[str, Any]:
        """Generate comprehensive fingerprint data"""
        return {
            "user_agent": user_agent,
            "device_info": device_info,
            "canvas_fingerprint": canvas_fingerprint,
            "webgl_fingerprint": webgl_fingerprint,
            "screen_resolution": screen_resolution,
            "timezone": timezone,
            "language": language,
            "timestamp": datetime.utcnow().isoformat()
        }

    def _calculate_fingerprint_hash(self, fingerprint_data: Dict[str, Any]) -> str:
        """Calculate hash for fingerprint data"""
        # Create stable hash by sorting keys
        stable_data = json.dumps(fingerprint_data, sort_keys=True, default=str)
        return hashlib.sha256(stable_data.encode()).hexdigest()

    async def _is_suspicious_device(
        self,
        user_id: UUID,
        fingerprint_data: Dict[str, Any]
    ) -> bool:
        """Check if device appears suspicious"""
        try:
            # Check for recent device additions
            recent_time = datetime.utcnow() - timedelta(hours=self.device_analysis_window_hours)
            recent_devices = self.db.query(Device).filter(
                and_(
                    Device.user_id == user_id,
                    Device.first_used_at >= recent_time
                )
            ).count()
            
            if recent_devices >= self.suspicious_device_threshold:
                return True
            
            # Check for suspicious patterns in fingerprint
            device_info = fingerprint_data.get("device_info", {})
            
            # Bot detection
            if device_info.get("is_bot", False):
                return True
            
            # Unusual browser/OS combinations
            browser = device_info.get("browser", "").lower()
            os = device_info.get("os", "").lower()
            
            suspicious_combinations = [
                ("unknown", "unknown"),
                ("", ""),
            ]
            
            for sus_browser, sus_os in suspicious_combinations:
                if sus_browser in browser and sus_os in os:
                    return True
            
            return False
            
        except Exception:
            # If we can't determine, err on the side of caution
            return True

    async def _check_device_limits(self, user_id: UUID) -> None:
        """Check if user has exceeded device limits"""
        active_devices = self.db.query(Device).filter(
            and_(
                Device.user_id == user_id,
                Device.is_active == True
            )
        ).count()
        
        if active_devices >= self.max_devices_per_user:
            raise TooManyDevicesException(
                f"User has reached maximum number of devices ({self.max_devices_per_user})"
            )

    async def _create_or_update_user_device(
        self,
        user_id: UUID,
        fingerprint_id: UUID,
        device_info: Dict[str, Any]
    ) -> 'Device':
        """Create or update user device record"""
        # Check if device already exists for this user with this fingerprint
        existing_device = self.db.query(Device).filter(
            and_(
                Device.user_id == user_id,
                Device.fingerprint_id == fingerprint_id
            )
        ).first()
        
        if existing_device:
            # Update existing device
            existing_device.last_used_at = datetime.utcnow()
            existing_device.usage_count = (existing_device.usage_count or 0) + 1
            existing_device.is_active = True
            return existing_device
        
        # Create new device
        device_name = self._generate_device_name(device_info)
        
        device = Device(
            id=uuid4(),
            user_id=user_id,
            fingerprint_id=fingerprint_id,
            device_name=device_name,
            device_type=device_info.get("device_type", "unknown"),
            first_used_at=datetime.utcnow(),
            last_used_at=datetime.utcnow(),
            usage_count=1,
            is_active=True,
            is_trusted=False
        )
        
        self.db.add(device)
        return device

    def _generate_device_name(self, device_info: Dict[str, Any]) -> str:
        """Generate friendly device name"""
        browser = device_info.get("browser", "Unknown Browser")
        os = device_info.get("os", "Unknown OS")
        device_type = device_info.get("device_type", "device")
        
        if device_type == "mobile":
            return f"Mobile - {browser} on {os}"
        elif device_type == "tablet":
            return f"Tablet - {browser} on {os}"
        else:
            return f"Computer - {browser} on {os}"

    async def _calculate_device_risk_score(
        self,
        fingerprint: DeviceFingerprint,
        user_id: UUID
    ) -> float:
        """Calculate basic device risk score (0-1, higher is riskier)"""
        risk_score = 0.0
        
        # New device penalty
        device_age_hours = (datetime.utcnow() - fingerprint.first_seen_at).total_seconds() / 3600
        if device_age_hours < 24:
            risk_score += 0.3
        elif device_age_hours < 168:  # 1 week
            risk_score += 0.1
        
        # Suspicious device penalty
        if fingerprint.is_suspicious:
            risk_score += 0.4
        
        # Low usage penalty
        if fingerprint.seen_count < 5:
            risk_score += 0.2
        
        # Unknown device info penalty
        if fingerprint.device_info.get("browser") == "Unknown":
            risk_score += 0.1
        
        return min(1.0, risk_score)

    async def _calculate_comprehensive_risk_score(
        self,
        device: Device,
        fingerprint: DeviceFingerprint,
        user_id: UUID
    ) -> float:
        """Calculate comprehensive risk score with more factors"""
        base_score = await self._calculate_device_risk_score(fingerprint, user_id)
        
        # Trust factor
        if device.is_trusted:
            base_score *= 0.5
        
        # Usage pattern factor
        if device.usage_count > 50:
            base_score *= 0.8
        elif device.usage_count > 20:
            base_score *= 0.9
        
        # Time factor
        days_old = (datetime.utcnow() - device.first_used_at).days
        if days_old > 30:
            base_score *= 0.7
        elif days_old > 7:
            base_score *= 0.8
        
        return min(1.0, base_score)

    async def _detect_device_anomalies(
        self,
        device: Device,
        fingerprint: DeviceFingerprint,
        user_id: UUID
    ) -> List[Dict[str, Any]]:
        """Detect anomalies in device behavior"""
        anomalies = []
        
        # Rapid IP changes
        if len(fingerprint.previous_ip_addresses or []) > 5:
            anomalies.append({
                "type": "rapid_ip_changes",
                "severity": "medium",
                "description": "Device has changed IP addresses frequently",
                "count": len(fingerprint.previous_ip_addresses)
            })
        
        # Unusual usage gaps
        if device.last_used_at:
            days_since_use = (datetime.utcnow() - device.last_used_at).days
            if days_since_use > 30 and device.usage_count > 10:
                anomalies.append({
                    "type": "unusual_inactivity",
                    "severity": "low",
                    "description": "Long period of inactivity for frequently used device",
                    "days_inactive": days_since_use
                })
        
        # Suspicious browser/OS combination
        device_info = fingerprint.device_info
        if device_info.get("is_bot", False):
            anomalies.append({
                "type": "bot_detected",
                "severity": "high",
                "description": "Device appears to be a bot or automated system"
            })
        
        return anomalies

    async def _analyze_usage_patterns(
        self,
        device: Device,
        user_id: UUID
    ) -> Dict[str, Any]:
        """Analyze device usage patterns"""
        try:
            # Get session data for this device
            sessions = self.db.query(UserSession).filter(
                and_(
                    UserSession.user_id == user_id,
                    UserSession.device_fingerprint == device.fingerprint.fingerprint_hash
                )
            ).order_by(desc(UserSession.created_at)).limit(50).all()
            
            if not sessions:
                return {"frequency": "new", "pattern": "unknown"}
            
            # Calculate usage frequency
            first_session = sessions[-1].created_at
            days_active = (datetime.utcnow() - first_session).days or 1
            frequency = len(sessions) / days_active
            
            frequency_label = "daily" if frequency >= 1 else "weekly" if frequency >= 0.14 else "monthly" if frequency >= 0.03 else "rare"
            
            # Time pattern analysis
            session_hours = [s.created_at.hour for s in sessions[:20]]  # Last 20 sessions
            peak_hours = max(set(session_hours), key=session_hours.count) if session_hours else None
            
            return {
                "frequency": frequency_label,
                "frequency_score": frequency,
                "total_sessions": len(sessions),
                "days_active": days_active,
                "peak_hour": peak_hours,
                "pattern": "regular" if frequency >= 0.14 else "irregular"
            }
            
        except Exception:
            return {"frequency": "unknown", "pattern": "unknown"}

    async def _generate_security_recommendations(
        self,
        device: Device,
        fingerprint: DeviceFingerprint,
        risk_score: float
    ) -> List[Dict[str, str]]:
        """Generate security recommendations for device"""
        recommendations = []
        
        if risk_score > 0.7:
            recommendations.append({
                "priority": "high",
                "action": "Consider removing this device if you don't recognize it",
                "reason": "High risk score indicates potential security concern"
            })
        
        if not device.is_trusted:
            recommendations.append({
                "priority": "medium",
                "action": "Trust this device if you recognize it",
                "reason": "Trusting known devices improves security and user experience"
            })
        
        if fingerprint.seen_count < 5:
            recommendations.append({
                "priority": "low",
                "action": "Monitor this device's activity closely",
                "reason": "New device with limited usage history"
            })
        
        if len(fingerprint.previous_ip_addresses or []) > 3:
            recommendations.append({
                "priority": "medium",
                "action": "Verify this device's network connections",
                "reason": "Device has connected from multiple IP addresses"
            })
        
        return recommendations

    def _get_risk_level(self, risk_score: float) -> str:
        """Convert risk score to human-readable level"""
        if risk_score >= 0.8:
            return "very_high"
        elif risk_score >= 0.6:
            return "high"
        elif risk_score >= 0.4:
            return "medium"
        elif risk_score >= 0.2:
            return "low"
        else:
            return "very_low"