# Detect impossible travel
            travel_patterns = await self._detect_impossible_travel(start_time, user_id)
            detected_patterns.extend(travel_patterns)
            
            # Calculate overall threat level
            threat_level = self._calculate_threat_level(detected_patterns)
            
            return {
                "analysis_period": {
                    "start_time": start_time.isoformat(),
                    "end_time": datetime.utcnow().isoformat(),
                    "hours_analyzed": time_window_hours
                },
                "threat_level": threat_level,
                "patterns_detected": detected_patterns,
                "total_threats": len(detected_patterns),
                "high_severity_threats": len([p for p in detected_patterns if p.get("severity") == "high"]),
                "recommendations": self._generate_fraud_recommendations(detected_patterns)
            }
            
        except Exception as e:
            raise RiskException(f"Failed to detect fraud patterns: {str(e)}")

    async def create_risk_profile(self, user_id: UUID) -> Dict[str, Any]:
        """
        Create comprehensive risk profile for a user
        
        Args:
            user_id: User's unique identifier
            
        Returns:
            Dict containing user's risk profile
        """
        try:
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                raise RiskException("User not found")
            
            # Analyze historical behavior
            login_history = await self._analyze_login_history(user_id)
            device_patterns = await self._analyze_device_patterns(user_id)
            location_patterns = await self._analyze_location_patterns(user_id)
            temporal_patterns = await self._analyze_temporal_patterns(user_id)
            
            # Calculate baseline risk factors
            baseline_risk = await self._calculate_baseline_risk(user_id)
            
            # Generate risk score
            risk_score = self._calculate_user_risk_score(
                baseline_risk, login_history, device_patterns, location_patterns, temporal_patterns
            )
            
            return {
                "user_id": user_id,
                "risk_score": risk_score,
                "risk_level": self._score_to_risk_level(risk_score),
                "profile_created_at": datetime.utcnow().isoformat(),
                "behavioral_patterns": {
                    "login_frequency": login_history.get("frequency"),
                    "preferred_devices": device_patterns.get("device_types"),
                    "common_locations": location_patterns.get("frequent_locations"),
                    "active_hours": temporal_patterns.get("peak_hours")
                },
                "risk_factors": {
                    "account_age_days": (datetime.utcnow() - user.created_at).days,
                    "failed_login_rate": login_history.get("failure_rate", 0),
                    "device_diversity": device_patterns.get("unique_devices", 0),
                    "location_diversity": location_patterns.get("unique_locations", 0)
                },
                "recommendations": self._generate_user_recommendations(risk_score, baseline_risk)
            }
            
        except Exception as e:
            if isinstance(e, RiskException):
                raise
            raise RiskException(f"Failed to create risk profile: {str(e)}")

    async def monitor_real_time_threats(self) -> Dict[str, Any]:
        """
        Monitor for real-time security threats
        
        Returns:
            Dict containing current threat status
        """
        try:
            current_time = datetime.utcnow()
            
            # Active monitoring windows
            last_hour = current_time - timedelta(hours=1)
            last_5_minutes = current_time - timedelta(minutes=5)
            
            # Check for active threats
            active_threats = []
            
            # High-frequency failed logins
            failed_login_threats = await self._monitor_failed_login_spikes(last_hour)
            active_threats.extend(failed_login_threats)
            
            # Suspicious IP activity
            ip_threats = await self._monitor_suspicious_ip_activity(last_hour)
            active_threats.extend(ip_threats)
            
            # Account lockout patterns
            lockout_threats = await self._monitor_account_lockout_patterns(last_hour)
            active_threats.extend(lockout_threats)
            
            # Real-time bot detection
            bot_threats = await self._monitor_bot_activity(last_5_minutes)
            active_threats.extend(bot_threats)
            
            # Calculate current threat level
            current_threat_level = self._calculate_current_threat_level(active_threats)
            
            return {
                "monitoring_timestamp": current_time.isoformat(),
                "current_threat_level": current_threat_level,
                "active_threats": active_threats,
                "threat_count": len(active_threats),
                "critical_threats": len([t for t in active_threats if t.get("severity") == "critical"]),
                "system_status": "under_attack" if current_threat_level == "critical" else "normal",
                "last_updated": current_time.isoformat()
            }
            
        except Exception as e:
            raise RiskException(f"Failed to monitor real-time threats: {str(e)}")

    # Private helper methods for risk assessment
    
    async def _assess_failed_login_history(self, user_id: UUID, ip_address: str) -> List[RiskFactor]:
        """Assess risk based on failed login history"""
        risk_factors = []
        
        # Check recent failed logins for this user
        recent_time = datetime.utcnow() - timedelta(minutes=self.threat_params["failed_login_window_minutes"])
        
        failed_count = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.user_id == user_id,
                UserLoginLog.login_status == "failure",
                UserLoginLog.created_at >= recent_time
            )
        ).count()
        
        if failed_count >= self.threat_params["failed_login_threshold"]:
            risk_factors.append(RiskFactor(
                factor_type="excessive_failed_logins",
                risk_score=min(1.0, failed_count / 10.0),
                severity=RiskLevel.HIGH if failed_count > 10 else RiskLevel.MEDIUM,
                description=f"{failed_count} failed login attempts in {self.threat_params['failed_login_window_minutes']} minutes",
                evidence={"failed_count": failed_count, "window_minutes": self.threat_params["failed_login_window_minutes"]},
                confidence=0.9
            ))
        
        # Check failed logins from this IP
        ip_failed_count = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.ip_address == ip_address,
                UserLoginLog.login_status == "failure",
                UserLoginLog.created_at >= recent_time
            )
        ).count()
        
        if ip_failed_count >= self.threat_params["failed_login_threshold"]:
            risk_factors.append(RiskFactor(
                factor_type="ip_failed_logins",
                risk_score=min(1.0, ip_failed_count / 15.0),
                severity=RiskLevel.HIGH,
                description=f"IP {ip_address} has {ip_failed_count} failed login attempts",
                evidence={"ip_address": ip_address, "failed_count": ip_failed_count},
                confidence=0.8
            ))
        
        return risk_factors

    async def _assess_ip_reputation(self, ip_address: str) -> List[RiskFactor]:
        """Assess IP address reputation and characteristics"""
        risk_factors = []
        
        try:
            ip_obj = ipaddress.ip_address(ip_address)
            
            # Check if IP is in private ranges (shouldn't be for external logins)
            if ip_obj.is_private and not settings.ALLOW_PRIVATE_IPS:
                risk_factors.append(RiskFactor(
                    factor_type="private_ip_address",
                    risk_score=0.3,
                    severity=RiskLevel.LOW,
                    description="Login from private IP address",
                    evidence={"ip_address": ip_address, "is_private": True},
                    confidence=1.0
                ))
            
            # Check for loopback addresses
            if ip_obj.is_loopback:
                risk_factors.append(RiskFactor(
                    factor_type="loopback_ip_address",
                    risk_score=0.5,
                    severity=RiskLevel.MEDIUM,
                    description="Login from loopback address",
                    evidence={"ip_address": ip_address, "is_loopback": True},
                    confidence=1.0
                ))
            
            # Check against known malicious IP ranges (placeholder)
            # In production, this would check against threat intelligence feeds
            if self._is_known_malicious_ip(ip_address):
                risk_factors.append(RiskFactor(
                    factor_type="malicious_ip",
                    risk_score=0.9,
                    severity=RiskLevel.CRITICAL,
                    description="IP address is known to be malicious",
                    evidence={"ip_address": ip_address, "threat_intel": True},
                    confidence=0.95
                ))
            
        except ValueError:
            # Invalid IP address
            risk_factors.append(RiskFactor(
                factor_type="invalid_ip_address",
                risk_score=0.7,
                severity=RiskLevel.HIGH,
                description="Invalid IP address format",
                evidence={"ip_address": ip_address},
                confidence=1.0
            ))
        
        return risk_factors

    async def _assess_geolocation_risk(self, user_id: UUID, location_data: Optional[Dict[str, Any]]) -> List[RiskFactor]:
        """Assess geolocation-based risks"""
        risk_factors = []
        
        if not location_data:
            return risk_factors
        
        # Get user's recent locations
        recent_time = datetime.utcnow() - timedelta(days=30)
        recent_sessions = self.db.query(UserSession).filter(
            and_(
                UserSession.user_id == user_id,
                UserSession.created_at >= recent_time,
                UserSession.location_data.isnot(None)
            )
        ).all()
        
        if recent_sessions:
            # Check for impossible travel
            last_session = max(recent_sessions, key=lambda s: s.created_at)
            time_diff_hours = (datetime.utcnow() - last_session.created_at).total_seconds() / 3600
            
            if (last_session.location_data.get("latitude") and 
                last_session.location_data.get("longitude") and
                location_data.get("latitude") and 
                location_data.get("longitude")):
                
                distance_km = self._calculate_distance(
                    last_session.location_data["latitude"], last_session.location_data["longitude"],
                    location_data["latitude"], location_data["longitude"]
                )
                
                if time_diff_hours > 0:
                    speed_kmh = distance_km / time_diff_hours
                    
                    if speed_kmh > self.threat_params["impossible_travel_speed_kmh"]:
                        risk_factors.append(RiskFactor(
                            factor_type="impossible_travel",
                            risk_score=0.8,
                            severity=RiskLevel.HIGH,
                            description=f"Impossible travel: {distance_km:.0f}km in {time_diff_hours:.1f}h ({speed_kmh:.0f}km/h)",
                            evidence={
                                "distance_km": distance_km,
                                "time_hours": time_diff_hours,
                                "speed_kmh": speed_kmh,
                                "previous_location": last_session.location_data,
                                "current_location": location_data
                            },
                            confidence=0.9
                        ))
        
        # Check for high-risk countries
        country_code = location_data.get("country_code")
        if country_code in self.malicious_patterns["suspicious_countries"]:
            risk_factors.append(RiskFactor(
                factor_type="high_risk_country",
                risk_score=0.6,
                severity=RiskLevel.MEDIUM,
                description=f"Login from high-risk country: {country_code}",
                evidence={"country_code": country_code, "location": location_data},
                confidence=0.7
            ))
        
        return risk_factors

    async def _assess_device_risk(self, user_id: UUID, device_fingerprint: Optional[str], user_agent: str) -> List[RiskFactor]:
        """Assess device-related risks"""
        risk_factors = []
        
        if device_fingerprint:
            # Check if device is known to the user
            known_device = self.db.query(Device).filter(
                and_(
                    Device.user_id == user_id,
                    Device.fingerprint.has(fingerprint_hash=device_fingerprint),
                    Device.is_active == True
                )
            ).first()
            
            if not known_device:
                risk_factors.append(RiskFactor(
                    factor_type="unknown_device",
                    risk_score=0.4,
                    severity=RiskLevel.MEDIUM,
                    description="Login from unrecognized device",
                    evidence={"device_fingerprint": device_fingerprint[:16] + "..."},
                    confidence=0.8
                ))
            elif known_device.first_used_at > datetime.utcnow() - timedelta(days=self.threat_params["new_device_risk_days"]):
                risk_factors.append(RiskFactor(
                    factor_type="new_device",
                    risk_score=0.3,
                    severity=RiskLevel.LOW,
                    description="Login from recently added device",
                    evidence={"device_age_days": (datetime.utcnow() - known_device.first_used_at).days},
                    confidence=0.7
                ))
        
        return risk_factors

    async def _assess_behavioral_patterns(self, user_id: UUID, ip_address: str) -> List[RiskFactor]:
        """Assess behavioral pattern anomalies"""
        risk_factors = []
        
        # Check for rapid requests from same IP
        recent_time = datetime.utcnow() - timedelta(minutes=self.threat_params["rapid_requests_window_minutes"])
        
        request_count = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.ip_address == ip_address,
                UserLoginLog.created_at >= recent_time
            )
        ).count()
        
        if request_count >= self.threat_params["rapid_requests_threshold"]:
            risk_factors.append(RiskFactor(
                factor_type="rapid_requests",
                risk_score=0.7,
                severity=RiskLevel.HIGH,
                description=f"{request_count} requests in {self.threat_params['rapid_requests_window_minutes']} minutes",
                evidence={"request_count": request_count, "ip_address": ip_address},
                confidence=0.9
            ))
        
        return risk_factors

    async def _assess_temporal_patterns(self, user_id: UUID) -> List[RiskFactor]:
        """Assess temporal pattern risks"""
        risk_factors = []
        
        current_hour = datetime.utcnow().hour
        
        # Check for suspicious hours
        if (current_hour >= self.threat_params["suspicious_hours_start"] or 
            current_hour <= self.threat_params["suspicious_hours_end"]):
            
            # Get user's typical login hours
            typical_hours = await self._get_user_typical_hours(user_id)
            
            if typical_hours and current_hour not in typical_hours:
                risk_factors.append(RiskFactor(
                    factor_type="unusual_time",
                    risk_score=0.3,
                    severity=RiskLevel.LOW,
                    description=f"Login at unusual hour: {current_hour}:00",
                    evidence={"current_hour": current_hour, "typical_hours": typical_hours},
                    confidence=0.6
                ))
        
        return risk_factors

    async def _assess_user_agent_risk(self, user_agent: str) -> List[RiskFactor]:
        """Assess user agent for suspicious patterns"""
        risk_factors = []
        
        # Check against known bot patterns
        for pattern in self.malicious_patterns["user_agents"]:
            if re.match(pattern, user_agent, re.IGNORECASE):
                risk_factors.append(RiskFactor(
                    factor_type="bot_user_agent",
                    risk_score=0.8,
                    severity=RiskLevel.HIGH,
                    description="User agent matches known bot pattern",
                    evidence={"user_agent": user_agent, "pattern": pattern},
                    confidence=0.9
                ))
                break
        
        # Check for empty or very short user agents
        if not user_agent or len(user_agent) < 10:
            risk_factors.append(RiskFactor(
                factor_type="suspicious_user_agent",
                risk_score=0.5,
                severity=RiskLevel.MEDIUM,
                description="Suspicious or missing user agent",
                evidence={"user_agent": user_agent or "empty"},
                confidence=0.7
            ))
        
        return risk_factors

    async def _assess_rate_limiting_violations(self, ip_address: str) -> List[RiskFactor]:
        """Assess rate limiting violations"""
        risk_factors = []
        
        # This would integrate with your rate limiting system
        # For now, we'll simulate checking against recent activity
        
        recent_time = datetime.utcnow() - timedelta(minutes=1)
        recent_requests = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.ip_address == ip_address,
                UserLoginLog.created_at >= recent_time
            )
        ).count()
        
        if recent_requests > 10:  # More than 10 requests per minute
            risk_factors.append(RiskFactor(
                factor_type="rate_limit_violation",
                risk_score=0.6,
                severity=RiskLevel.MEDIUM,
                description=f"Rate limit exceeded: {recent_requests} requests per minute",
                evidence={"requests_per_minute": recent_requests, "ip_address": ip_address},
                confidence=0.8
            ))
        
        return risk_factors

    async def _assess_session_hijacking(self, session: UserSession, current_ip: str, current_user_agent: str) -> List[RiskFactor]:
        """Assess session hijacking indicators"""
        risk_factors = []
        
        # Check for IP address changes
        if session.ip_address != current_ip:
            risk_factors.append(RiskFactor(
                factor_type="session_ip_change",
                risk_score=0.5,
                severity=RiskLevel.MEDIUM,
                description="Session IP address changed",
                evidence={
                    "original_ip": session.ip_address,
                    "current_ip": current_ip,
                    "session_age_minutes": (datetime.utcnow() - session.created_at).total_seconds() / 60
                },
                confidence=0.7
            ))
        
        # Check for user agent changes
        if session.user_agent != current_user_agent:
            risk_factors.append(RiskFactor(
                factor_type="session_user_agent_change",
                risk_score=0.4,
                severity=RiskLevel.LOW,
                description="Session user agent changed",
                evidence={
                    "original_user_agent": session.user_agent,
                    "current_user_agent": current_user_agent
                },
                confidence=0.6
            ))
        
        return risk_factors

    async def _assess_session_activity_patterns(self, session: UserSession, activity_context: Optional[Dict[str, Any]]) -> List[RiskFactor]:
        """Assess session activity patterns"""
        risk_factors = []
        
        # Check session duration
        session_age_hours = (datetime.utcnow() - session.created_at).total_seconds() / 3600
        
        if session_age_hours > 24:  # Very long session
            risk_factors.append(RiskFactor(
                factor_type="long_session",
                risk_score=0.3,
                severity=RiskLevel.LOW,
                description=f"Session active for {session_age_hours:.1f} hours",
                evidence={"session_age_hours": session_age_hours},
                confidence=0.6
            ))
        
        return risk_factors

    async def _assess_session_age_risk(self, session: UserSession) -> List[RiskFactor]:
        """Assess risks related to session age"""
        risk_factors = []
        
        # Check if session is expired
        if session.expires_at < datetime.utcnow():
            risk_factors.append(RiskFactor(
                factor_type="expired_session",
                risk_score=1.0,
                severity=RiskLevel.CRITICAL,
                description="Session has expired",
                evidence={"expires_at": session.expires_at.isoformat()},
                confidence=1.0
            ))
        
        return risk_factors

    def _build_risk_assessment(self, risk_factors: List[RiskFactor]) -> RiskAssessment:
        """Build final risk assessment from individual factors"""
        if not risk_factors:
            return RiskAssessment(
                overall_risk_score=0.1,
                risk_level=RiskLevel.VERY_LOW,
                confidence_score=1.0,
                risk_factors=[],
                recommendations=["Continue monitoring"],
                timestamp=datetime.utcnow()
            )
        
        # Calculate weighted risk score
        total_weighted_score = sum(rf.risk_score * rf.confidence for rf in risk_factors)
        total_confidence = sum(rf.confidence for rf in risk_factors)
        
        overall_risk_score = min(1.0, total_weighted_score / len(risk_factors))
        confidence_score = total_confidence / len(risk_factors)
        
        # Determine risk level
        risk_level = self._score_to_risk_level(overall_risk_score)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(risk_factors, risk_level)
        
        return RiskAssessment(
            overall_risk_score=overall_risk_score,
            risk_level=risk_level,
            confidence_score=confidence_score,
            risk_factors=risk_factors,
            recommendations=recommendations,
            timestamp=datetime.utcnow()
        )

    def _score_to_risk_level(self, score: float) -> RiskLevel:
        """Convert numeric score to risk level"""
        if score >= 0.9:
            return RiskLevel.CRITICAL
        elif score >= 0.7:
            return RiskLevel.HIGH
        elif score >= 0.5:
            return RiskLevel.MEDIUM
        elif score >= 0.3:
            return RiskLevel.LOW
        else:
            return RiskLevel.VERY_LOW

    def _generate_recommendations(self, risk_factors: List[RiskFactor], risk_level: RiskLevel) -> List[str]:
        """Generate security recommendations based on risk assessment"""
        recommendations = []
        
        if risk_level == RiskLevel.CRITICAL:
            recommendations.append("Block login attempt immediately")
            recommendations.append("Alert security team")
            recommendations.append("Consider account lockout")
        
        elif risk_level == RiskLevel.HIGH:
            recommendations.append("Require additional authentication")
            recommendations.append("Monitor session closely")
            recommendations.append("Consider rate limiting")
        
        elif risk_level == RiskLevel.MEDIUM:
            recommendations.append("Request MFA verification")
            recommendations.append("Log detailed audit trail")
            recommendations.append("Monitor for suspicious activity")
        
        # Factor-specific recommendations
        factor_types = {rf.factor_type for rf in risk_factors}
        
        if "unknown_device" in factor_types:
            recommendations.append("Send device verification notification")
        
        if "impossible_travel" in factor_types:
            recommendations.append("Verify user location through alternative means")
        
        if "bot_user_agent" in factor_types:
            recommendations.append("Implement CAPTCHA challenge")
        
        if "failed_logins" in [rf.factor_type for rf in risk_factors]:
            recommendations.append("Consider temporary account lockout")
        
        return list(set(recommendations))  # Remove duplicates

    # Additional helper methods
    
    def _calculate_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate distance between two coordinates in kilometers"""
        from math import radians, cos, sin, asin, sqrt
        
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * asin(sqrt(a))
        r = 6371  # Radius of earth in kilometers
        return c * r

    def _is_known_malicious_ip(self, ip_address: str) -> bool:
        """Check if IP is in threat intelligence database"""
        # Placeholder - would integrate with threat intelligence feeds
        return False

    async def _get_user_typical_hours(self, user_id: UUID) -> List[int]:
        """Get user's typical login hours"""
        # Analyze historical login patterns
        login_logs = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.user_id == user_id,
                UserLoginLog.login_status == "success",
                UserLoginLog.created_at >= datetime.utcnow() - timedelta(days=30)
            )
        ).all()
        
        if not login_logs:
            return []
        
        # Count logins by hour
        hour_counts = {}
        for log in login_logs:
            hour = log.created_at.hour
            hour_counts[hour] = hour_counts.get(hour, 0) + 1
        
        # Return hours with significant activity (>10% of total logins)
        total_logins = len(login_logs)
        threshold = total_logins * 0.1
        
        return [hour for hour, count in hour_counts.items() if count >= threshold]

    # Fraud detection methods (simplified implementations)
    
    async def _detect_brute_force_attacks(self, start_time: datetime, ip_address: Optional[str] = None) -> List[Dict[str, Any]]:
        """Detect brute force attack patterns"""
        patterns = []
        
        query = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.created_at >= start_time,
                UserLoginLog.login_status == "failure"
            )
        )
        
        if ip_address:
            query = query.filter(UserLoginLog.ip_address == ip_address)
        
        # Group by IP address
        failed_by_ip = {}
        for log in query.all():
            ip = log.ip_address
            if ip not in failed_by_ip:
                failed_by_ip[ip] = []
            failed_by_ip[ip].append(log)
        
        # Detect IPs with excessive failures
        for ip, logs in failed_by_ip.items():
            if len(logs) >= 20:  # Threshold for brute force
                patterns.append({
                    "threat_type": ThreatType.BRUTE_FORCE.value,
                    "severity": "high",
                    "ip_address": ip,
                    "failed_attempts": len(logs),
                    "time_span_minutes": (max(log.created_at for log in logs) - min(log.created_at for log in logs)).total_seconds() / 60,
                    "targeted_users": len(set(log.user_id for log in logs if log.user_id))
                })
        
        return patterns

    async def _detect_credential_stuffing(self, start_time: datetime) -> List[Dict[str, Any]]:
        """Detect credential stuffing patterns"""
        patterns = []
        
        # Look for patterns where same IP tries many different usernames
        failed_logs = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.created_at >= start_time,
                UserLoginLog.login_status == "failure"
            )
        ).all()
        
        ip_user_attempts = {}
        for log in failed_logs:
            ip = log.ip_address
            if ip not in ip_user_attempts:
                ip_user_attempts[ip] = set()
            if log.user_id:
                ip_user_attempts[ip].add(log.user_id)
        
        # Detect IPs trying many different users
        for ip, user_ids in ip_user_attempts.items():
            if len(user_ids) >= 10:  # Threshold for credential stuffing
                patterns.append({
                    "threat_type": ThreatType.CREDENTIAL_STUFFING.value,
                    "severity": "high",
                    "ip_address": ip,
                    "unique_users_targeted": len(user_ids),
                    "description": f"IP {ip} attempted to access {len(user_ids)} different accounts"
                })
        
        return patterns

    async def _detect_account_takeover(self, user_id: UUID, start_time: datetime) -> List[Dict[str, Any]]:
        """Detect account takeover attempts"""
        patterns = []
        
        # Look for successful login followed by unusual activity
        user_sessions = self.db.query(UserSession).filter(
            and_(
                UserSession.user_id == user_id,
                UserSession.created_at >= start_time
            )
        ).all()
        
        for session in user_sessions:
            risk_indicators = 0
            
            # Check for IP changes
            if session.ip_address != session.user.last_login_ip:
                risk_indicators += 1
            
            # Check for location changes
            if session.location_data and hasattr(session.user, 'last_login_location'):
                # Implementation would check geographic distance
                risk_indicators += 1
            
            if risk_indicators >= 2:
                patterns.append({
                    "threat_type": ThreatType.ACCOUNT_TAKEOVER.value,
                    "severity": "high",
                    "user_id": str(user_id),
                    "session_id": str(session.id),
                    "risk_indicators": risk_indicators,
                    "description": "Potential account takeover detected"
                })
        
        return patterns

    async def _detect_bot_activity(self, start_time: datetime, ip_address: Optional[str] = None) -> List[Dict[str, Any]]:
        """Detect automated bot activity"""
        patterns = []
        
        query = self.db.query(UserLoginLog).filter(UserLoginLog.created_at >= start_time)
        if ip_address:
            query = query.filter(UserLoginLog.ip_address == ip_address)
        
        logs = query.all()
        
        # Group by IP and analyze patterns
        ip_patterns = {}
        for log in logs:
            ip = log.ip_address
            if ip not in ip_patterns:
                ip_patterns[ip] = []
            ip_patterns[ip].append(log)
        
        for ip, ip_logs in ip_patterns.items():
            if len(ip_logs) < 5:
                continue
            
            # Check for very regular timing patterns (bots often have consistent intervals)
            time_intervals = []
            sorted_logs = sorted(ip_logs, key=lambda x: x.created_at)
            
            for i in range(1, len(sorted_logs)):
                interval = (sorted_logs[i].created_at - sorted_logs[i-1].created_at).total_seconds()
                time_intervals.append(interval)
            
            if time_intervals:
                # Calculate variance in timing
                avg_interval = sum(time_intervals) / len(time_intervals)
                variance = sum((x - avg_interval) ** 2 for x in time_intervals) / len(time_intervals)
                
                # Low variance suggests automated behavior
                if variance < 10 and avg_interval < 60:  # Very consistent timing under 1 minute
                    patterns.append({
                        "threat_type": ThreatType.BOT_ACTIVITY.value,
                        "severity": "medium",
                        "ip_address": ip,
                        "request_count": len(ip_logs),
                        "avg_interval_seconds": avg_interval,
                        "timing_variance": variance,
                        "description": f"Highly regular request pattern detected from {ip}"
                    })
        
        return patterns

    async def _detect_impossible_travel(self, start_time: datetime, user_id: Optional[UUID] = None) -> List[Dict[str, Any]]:
        """Detect impossible travel patterns"""
        patterns = []
        
        query = self.db.query(UserSession).filter(
            and_(
                UserSession.created_at >= start_time,
                UserSession.location_data.isnot(None)
            )
        )
        
        if user_id:
            query = query.filter(UserSession.user_id == user_id)
        
        sessions = query.order_by(UserSession.created_at).all()
        
        # Group by user
        user_sessions = {}
        for session in sessions:
            uid = session.user_id
            if uid not in user_sessions:
                user_sessions[uid] = []
            user_sessions[uid].append(session)
        
        for uid, user_session_list in user_sessions.items():
            if len(user_session_list) < 2:
                continue
            
            for i in range(1, len(user_session_list)):
                current = user_session_list[i]
                previous = user_session_list[i-1]
                
                if (current.location_data.get("latitude") and current.location_data.get("longitude") and
                    previous.location_data.get("latitude") and previous.location_data.get("longitude")):
                    
                    distance_km = self._calculate_distance(
                        previous.location_data["latitude"], previous.location_data["longitude"],
                        current.location_data["latitude"], current.location_data["longitude"]
                    )
                    
                    time_diff_hours = (current.created_at - previous.created_at).total_seconds() / 3600
                    
                    if time_diff_hours > 0:
                        speed_kmh = distance_km / time_diff_hours
                        
                        if speed_kmh > self.threat_params["impossible_travel_speed_kmh"]:
                            patterns.append({
                                "threat_type": ThreatType.SUSPICIOUS_LOCATION.value,
                                "severity": "high",
                                "user_id": str(uid),
                                "distance_km": distance_km,
                                "time_hours": time_diff_hours,
                                "speed_kmh": speed_kmh,
                                "description": f"Impossible travel: {distance_km:.0f}km in {time_diff_hours:.1f}h"
                            })
        
        return patterns

    def _calculate_threat_level(self, patterns: List[Dict[str, Any]]) -> str:
        """Calculate overall threat level from detected patterns"""
        if not patterns:
            return "low"
        
        critical_count = sum(1 for p in patterns if p.get("severity") == "critical")
        high_count = sum(1 for p in patterns if p.get("severity") == "high")
        
        if critical_count > 0:
            return "critical"
        elif high_count >= 3:
            return "critical"
        elif high_count >= 1:
            return "high"
        elif len(patterns) >= 5:
            return "medium"
        else:
            return "low"

    def _generate_fraud_recommendations(self, patterns: List[Dict[str, Any]]) -> List[str]:
        """Generate recommendations based on detected fraud patterns"""
        recommendations = []
        
        threat_types = {p.get("threat_type") for p in patterns}
        
        if ThreatType.BRUTE_FORCE.value in threat_types:
            recommendations.extend([
                "Implement IP-based rate limiting",
                "Consider geographic blocking for suspicious regions",
                "Alert security team immediately"
            ])
        
        if ThreatType.CREDENTIAL_STUFFING.value in threat_types:
            recommendations.extend([
                "Force password resets for targeted accounts",
                "Implement CAPTCHA for suspicious IPs",
                "Review and strengthen password policies"
            ])
        
        if ThreatType.ACCOUNT_TAKEOVER.value in threat_types:
            recommendations.extend([
                "Lock affected accounts immediately",
                "Require MFA setup for all users",
                "Notify affected users via verified contact methods"
            ])
        
        if ThreatType.BOT_ACTIVITY.value in threat_types:
            recommendations.extend([
                "Implement advanced bot detection",
                "Add human verification challenges",
                "Review API access patterns"
            ])
        
        return list(set(recommendations))

    # Monitoring methods
    
    async def _monitor_failed_login_spikes(self, since: datetime) -> List[Dict[str, Any]]:
        """Monitor for spikes in failed logins"""
        threats = []
        
        failed_count = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.created_at >= since,
                UserLoginLog.login_status == "failure"
            )
        ).count()
        
        # Compare to historical average (simplified)
        if failed_count > 100:  # Threshold for spike
            threats.append({
                "threat_type": "failed_login_spike",
                "severity": "high" if failed_count > 500 else "medium",
                "failed_count": failed_count,
                "time_window": "1_hour",
                "description": f"Spike in failed logins: {failed_count} in last hour"
            })
        
        return threats

    async def _monitor_suspicious_ip_activity(self, since: datetime) -> List[Dict[str, Any]]:
        """Monitor for suspicious IP activity"""
        threats = []
        
        # Group login attempts by IP
        logs = self.db.query(UserLoginLog).filter(UserLoginLog.created_at >= since).all()
        
        ip_activity = {}
        for log in logs:
            ip = log.ip_address
            if ip not in ip_activity:
                ip_activity[ip] = {"total": 0, "failed": 0, "users": set()}
            
            ip_activity[ip]["total"] += 1
            if log.login_status == "failure":
                ip_activity[ip]["failed"] += 1
            if log.user_id:
                ip_activity[ip]["users"].add(log.user_id)
        
        for ip, activity in ip_activity.items():
            # High activity from single IP
            if activity["total"] > 50:
                threats.append({
                    "threat_type": "suspicious_ip_activity",
                    "severity": "medium",
                    "ip_address": ip,
                    "total_attempts": activity["total"],
                    "failed_attempts": activity["failed"],
                    "unique_users": len(activity["users"]),
                    "description": f"High activity from IP {ip}: {activity['total']} attempts"
                })
        
        return threats

    async def _monitor_account_lockout_patterns(self, since: datetime) -> List[Dict[str, Any]]:
        """Monitor for unusual account lockout patterns"""
        threats = []
        
        # Count locked accounts
        locked_count = self.db.query(User).filter(
            and_(
                User.locked_until.isnot(None),
                User.locked_until > datetime.utcnow()
            )
        ).count()
        
        if locked_count > 10:  # Threshold for concern
            threats.append({
                "threat_type": "mass_account_lockout",
                "severity": "high",
                "locked_accounts": locked_count,
                "description": f"Unusual number of locked accounts: {locked_count}"
            })
        
        return threats

    async def _monitor_bot_activity(self, since: datetime) -> List[Dict[str, Any]]:
        """Monitor for real-time bot activity"""
        threats = []
        
        # Look for bot-like user agents in recent activity
        logs = self.db.query(UserLoginLog).filter(UserLoginLog.created_at >= since).all()
        
        bot_requests = 0
        for log in logs:
            user_agent = log.user_agent or ""
            for pattern in self.malicious_patterns["user_agents"]:
                if re.match(pattern, user_agent, re.IGNORECASE):
                    bot_requests += 1
                    break
        
        if bot_requests > 5:  # Threshold for bot activity
            threats.append({
                "threat_type": ThreatType.BOT_ACTIVITY.value,
                "severity": "medium",
                "bot_requests": bot_requests,
                "time_window": "5_minutes",
                "description": f"Bot activity detected: {bot_requests} requests in 5 minutes"
            })
        
        return threats

    def _calculate_current_threat_level(self, threats: List[Dict[str, Any]]) -> str:
        """Calculate current system threat level"""
        if not threats:
            return "normal"
        
        critical_threats = [t for t in threats if t.get("severity") == "critical"]
        high_threats = [t for t in threats if t.get("severity") == "high"]
        
        if len(critical_threats) > 0:
            return "critical"
        elif len(high_threats) >= 2:
            return "high"
        elif len(high_threats) >= 1 or len(threats) >= 3:
            return "elevated"
        else:
            return "normal"

    # User profile analysis methods
    
    async def _analyze_login_history(self, user_id: UUID) -> Dict[str, Any]:
        """Analyze user's login history patterns"""
        logs = self.db.query(UserLoginLog).filter(
            UserLoginLog.user_id == user_id
        ).order_by(desc(UserLoginLog.created_at)).limit(100).all()
        
        if not logs:
            return {"frequency": "new_user", "failure_rate": 0}
        
        total_attempts = len(logs)
        failed_attempts = len([log for log in logs if log.login_status == "failure"])
        failure_rate = failed_attempts / total_attempts if total_attempts > 0 else 0
        
        # Calculate login frequency
        if total_attempts >= 2:
            time_span = (logs[0].created_at - logs[-1].created_at).days
            frequency = total_attempts / max(time_span, 1)
        else:
            frequency = 0
        
        return {
            "frequency": "daily" if frequency >= 1 else "weekly" if frequency >= 0.14 else "monthly",
            "failure_rate": failure_rate,
            "total_attempts": total_attempts,
            "avg_attempts_per_day": frequency
        }

    async def _analyze_device_patterns(self, user_id: UUID) -> Dict[str, Any]:
        """Analyze user's device usage patterns"""
        devices = self.db.query(Device).filter(Device.user_id == user_id).all()
        
        device_types = {}
        for device in devices:
            device_type = device.device_type or "unknown"
            device_types[device_type] = device_types.get(device_type, 0) + 1
        
        return {
            "unique_devices": len(devices),
            "device_types": device_types,
            "primary_device_type": max(device_types.items(), key=lambda x: x[1])[0] if device_types else "unknown"
        }

    async def _analyze_location_patterns(self, user_id: UUID) -> Dict[str, Any]:
        """Analyze user's location patterns"""
        sessions = self.db.query(UserSession).filter(
            and_(
                UserSession.user_id == user_id,
                UserSession.location_data.isnot(None)
            )
        ).all()
        
        if not sessions:
            return {"unique_locations": 0, "frequent_locations": []}
        
        # Simplified location analysis
        countries = {}
        for session in sessions:
            country = session.location_data.get("country_code")
            if country:
                countries[country] = countries.get(country, 0) + 1
        
        return {
            "unique_locations": len(countries),
            "frequent_locations": list(countries.keys()),
            "primary_country": max(countries.items(), key=lambda x: x[1])[0] if countries else None
        }

    async def _analyze_temporal_patterns(self, user_id: UUID) -> Dict[str, Any]:
        """Analyze user's temporal activity patterns"""
        logs = self.db.query(UserLoginLog).filter(
            and_(
                UserLoginLog.user_id == user_id,
                UserLoginLog.login_status == "success"
            )
        ).all()
        
        if not logs:
            return {"peak_hours": [], "active_days": []}
        
        # Analyze by hour
        hour_counts = {}
        day_counts = {}
        
        for log in logs:
            hour = log.created_at.hour
            day = log.created_at.weekday()
            
            hour_counts[hour] = hour_counts.get(hour, 0) + 1
            day_counts[day] = day_counts.get(day, 0) + 1
        
        # Find peak hours (top 25% of activity)
        sorted_hours = sorted(hour_counts.items(), key=lambda x: x[1], reverse=True)
        peak_hours = [hour for hour, count in sorted_hours[:6]]  # Top 6 hours
        
        return {
            "peak_hours": peak_hours,
            "active_days": list(day_counts.keys()),
            "most_active_hour": max(hour_counts.items(), key=lambda x: x[1])[0] if hour_counts else None
        }

    async def _calculate_baseline_risk(self, user_id: UUID) -> Dict[str, float]:
        """Calculate baseline risk factors for user"""
        user = self.db.query(User).filter(User.id == user_id).first()
        
        baseline_risk = {
            "account_age_risk": 0.0,
            "verification_risk": 0.0,
            "activity_risk": 0.0
        }
        
        if user:
            # Account age risk (newer accounts are riskier)
            account_age_days = (datetime.utcnow() - user.created_at).days
            if account_age_days < 7:
                baseline_risk["account_age_risk"] = 0.3
            elif account_age_days < 30:
                baseline_risk["account_age_risk"] = 0.1
            
            # Verification risk
            if not user.is_verified:
                baseline_risk["verification_risk"] = 0.2
            
            # Activity risk (no recent activity)
            if not user.last_login_at or (datetime.utcnow() - user.last_login_at).days > 90:
                baseline_risk["activity_risk"] = 0.1
        
        return baseline_risk

    def _calculate_user_risk_score(
        self,
        baseline_risk: Dict[str, float],
        login_history: Dict[str, Any],
        device_patterns: Dict[str, Any],
        location_patterns: Dict[str, Any],
        temporal_patterns: Dict[str, Any]
    ) -> float:
        """Calculate overall user risk score"""
        risk_score = 0.0
        
        # Baseline risks
        risk_score += sum(baseline_risk.values())
        
        # Login behavior risks
        failure_rate = login_history.get("failure_rate", 0)
        risk_score += failure_rate * 0.3
        
        # Device diversity risk
        device_count = device_patterns.get("unique_devices", 0)
        if device_count > 5:
            risk_score += 0.1  # Many devices can be risky
        
        # Location diversity risk
        location_count = location_patterns.get("unique_locations", 0)
        if location_count > 3:
            risk_score += 0.1  # Many locations can be risky
        
        return min(1.0, risk_score)

    def _generate_user_recommendations(self, risk_score: float, baseline_risk: Dict[str, float]) -> List[str]:
        """Generate recommendations for user based on risk profile"""
        recommendations = []
        
        if risk_score > 0.7:
            recommendations.append("Consider additional security measures for this user")
            recommendations.append("Monitor account activity closely")
        
        if baseline_risk.get("verification_risk", 0) > 0:
            recommendations.append("Complete account verification process")
        
        if baseline_risk.get("account_age_risk", 0) > 0:
            recommendations.append("New account - monitor for suspicious activity")
        
        if risk_score > 0.5:
            recommendations.append("Recommend enabling MFA")
            recommendations.append("Consider device registration requirements")
        
        return recommendations"""
Risk Service

Enterprise risk assessment and fraud detection for Cardinsa Insurance API.
Handles security risk scoring, behavioral analysis, and fraud prevention.
"""

from typing import Dict, List, Optional, Any, Tuple
from uuid import UUID, uuid4
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func, text
from enum import Enum
import json
import hashlib
from dataclasses import dataclass
import ipaddress
import re

from app.core.exceptions import RiskException, SecurityException
from app.models.auth.user import User, Session as UserSession, UserLoginLog, Device
from app.config.settings import get_settings
from app.services.auth.audit_service import AuditService

settings = get_settings()


class RiskLevel(str, Enum):
    """Risk assessment levels"""
    VERY_LOW = "very_low"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ThreatType(str, Enum):
    """Types of security threats"""
    BRUTE_FORCE = "brute_force"
    CREDENTIAL_STUFFING = "credential_stuffing"
    ACCOUNT_TAKEOVER = "account_takeover"
    SUSPICIOUS_LOCATION = "suspicious_location"
    DEVICE_ANOMALY = "device_anomaly"
    BEHAVIORAL_ANOMALY = "behavioral_anomaly"
    RATE_LIMITING = "rate_limiting"
    BOT_ACTIVITY = "bot_activity"


@dataclass
class RiskFactor:
    """Individual risk factor"""
    factor_type: str
    risk_score: float  # 0.0 to 1.0
    severity: RiskLevel
    description: str
    evidence: Dict[str, Any]
    confidence: float  # 0.0 to 1.0


@dataclass
class RiskAssessment:
    """Complete risk assessment result"""
    overall_risk_score: float
    risk_level: RiskLevel
    confidence_score: float
    risk_factors: List[RiskFactor]
    recommendations: List[str]
    timestamp: datetime


class RiskService:
    """Enterprise Risk Assessment and Fraud Detection Service"""

    def __init__(self, db: Session):
        self.db = db
        self.audit_service = AuditService(db)
        
        # Risk thresholds
        self.risk_thresholds = {
            RiskLevel.VERY_LOW: 0.1,
            RiskLevel.LOW: 0.3,
            RiskLevel.MEDIUM: 0.5,
            RiskLevel.HIGH: 0.7,
            RiskLevel.CRITICAL: 0.9
        }
        
        # Threat detection parameters
        self.threat_params = {
            "failed_login_threshold": 5,
            "failed_login_window_minutes": 15,
            "rapid_requests_threshold": 50,
            "rapid_requests_window_minutes": 5,
            "impossible_travel_speed_kmh": 1000,  # km/h
            "suspicious_hours_start": 23,  # 11 PM
            "suspicious_hours_end": 6,     # 6 AM
            "new_device_risk_days": 7,
            "location_change_risk_km": 500
        }
        
        # Known malicious patterns
        self.malicious_patterns = {
            "user_agents": [
                r".*bot.*", r".*crawler.*", r".*spider.*", r".*scraper.*",
                r".*automated.*", r".*script.*", r"^python.*", r"^curl.*"
            ],
            "suspicious_countries": ["CN", "RU", "KP", "IR"],  # Example high-risk countries
            "tor_exit_nodes": [],  # Would be populated from threat intelligence
            "known_vpn_ranges": []  # Would be populated from threat intelligence
        }

    async def assess_login_risk(
        self,
        user_id: UUID,
        ip_address: str,
        user_agent: str,
        location_data: Optional[Dict[str, Any]] = None,
        device_fingerprint: Optional[str] = None,
        additional_context: Optional[Dict[str, Any]] = None
    ) -> RiskAssessment:
        """
        Comprehensive risk assessment for login attempts
        
        Args:
            user_id: User attempting login
            ip_address: Source IP address
            user_agent: User agent string
            location_data: Geographic location data
            device_fingerprint: Device fingerprint
            additional_context: Additional context for assessment
            
        Returns:
            RiskAssessment object with detailed risk analysis
        """
        try:
            risk_factors = []
            
            # Get user information
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                risk_factors.append(RiskFactor(
                    factor_type="invalid_user",
                    risk_score=1.0,
                    severity=RiskLevel.CRITICAL,
                    description="User not found",
                    evidence={"user_id": str(user_id)},
                    confidence=1.0
                ))
                return self._build_risk_assessment(risk_factors)
            
            # Assess various risk factors
            risk_factors.extend(await self._assess_failed_login_history(user_id, ip_address))
            risk_factors.extend(await self._assess_ip_reputation(ip_address))
            risk_factors.extend(await self._assess_geolocation_risk(user_id, location_data))
            risk_factors.extend(await self._assess_device_risk(user_id, device_fingerprint, user_agent))
            risk_factors.extend(await self._assess_behavioral_patterns(user_id, ip_address))
            risk_factors.extend(await self._assess_temporal_patterns(user_id))
            risk_factors.extend(await self._assess_user_agent_risk(user_agent))
            risk_factors.extend(await self._assess_rate_limiting_violations(ip_address))
            
            # Build final assessment
            assessment = self._build_risk_assessment(risk_factors)
            
            # Log high-risk assessments
            if assessment.risk_level in [RiskLevel.HIGH, RiskLevel.CRITICAL]:
                await self.audit_service.log_event(
                    event_type="high_risk_login_attempt",
                    user_id=user_id,
                    ip_address=ip_address,
                    details={
                        "risk_score": assessment.overall_risk_score,
                        "risk_level": assessment.risk_level.value,
                        "risk_factors": [
                            {
                                "type": rf.factor_type,
                                "score": rf.risk_score,
                                "severity": rf.severity.value
                            }
                            for rf in assessment.risk_factors
                        ]
                    },
                    severity="high",
                    category="fraud_detection"
                )
            
            return assessment
            
        except Exception as e:
            raise RiskException(f"Failed to assess login risk: {str(e)}")

    async def assess_session_risk(
        self,
        session_id: UUID,
        current_ip: str,
        current_user_agent: str,
        activity_context: Optional[Dict[str, Any]] = None
    ) -> RiskAssessment:
        """
        Assess risk for an ongoing session
        
        Args:
            session_id: Active session ID
            current_ip: Current IP address
            current_user_agent: Current user agent
            activity_context: Context about current activity
            
        Returns:
            RiskAssessment for the session
        """
        try:
            # Get session information
            session = self.db.query(UserSession).filter(UserSession.id == session_id).first()
            if not session:
                return RiskAssessment(
                    overall_risk_score=1.0,
                    risk_level=RiskLevel.CRITICAL,
                    confidence_score=1.0,
                    risk_factors=[RiskFactor(
                        factor_type="invalid_session",
                        risk_score=1.0,
                        severity=RiskLevel.CRITICAL,
                        description="Session not found",
                        evidence={"session_id": str(session_id)},
                        confidence=1.0
                    )],
                    recommendations=["Terminate session immediately"],
                    timestamp=datetime.utcnow()
                )
            
            risk_factors = []
            
            # Check for session hijacking indicators
            risk_factors.extend(await self._assess_session_hijacking(session, current_ip, current_user_agent))
            
            # Check for unusual activity patterns
            risk_factors.extend(await self._assess_session_activity_patterns(session, activity_context))
            
            # Check session age and usage patterns
            risk_factors.extend(await self._assess_session_age_risk(session))
            
            return self._build_risk_assessment(risk_factors)
            
        except Exception as e:
            raise RiskException(f"Failed to assess session risk: {str(e)}")

    async def detect_fraud_patterns(
        self,
        user_id: Optional[UUID] = None,
        ip_address: Optional[str] = None,
        time_window_hours: int = 24
    ) -> Dict[str, Any]:
        """
        Detect fraud patterns across multiple dimensions
        
        Args:
            user_id: Specific user to analyze (optional)
            ip_address: Specific IP to analyze (optional)
            time_window_hours: Analysis time window
            
        Returns:
            Dict containing fraud detection results
        """
        try:
            start_time = datetime.utcnow() - timedelta(hours=time_window_hours)
            detected_patterns = []
            
            # Detect brute force attacks
            brute_force_patterns = await self._detect_brute_force_attacks(start_time, ip_address)
            detected_patterns.extend(brute_force_patterns)
            
            # Detect credential stuffing
            credential_stuffing_patterns = await self._detect_credential_stuffing(start_time)
            detected_patterns.extend(credential_stuffing_patterns)
            
            # Detect account takeover attempts
            if user_id:
                takeover_patterns = await self._detect_account_takeover(user_id, start_time)
                detected_patterns.extend(takeover_patterns)
            
            # Detect bot activity
            bot_patterns = await self._detect_bot_activity(start_time, ip_address)
            detected_patterns.extend(bot_patterns)
            
            # Detect impossible travel