# FILE PATH: app/services/auth/session_service.py
"""
Session Management Service
CARDINSA Insurance Platform

Enterprise-grade session management providing:
- Comprehensive session lifecycle management
- Multi-device session tracking
- Concurrent session limits
- Session security monitoring
- Device fingerprinting and validation
- Automatic session cleanup and rotation
- Geographic and behavioral anomaly detection
- Session analytics and reporting

Handles all aspects of user session security and management.
"""

import uuid
import logging
import secrets
import json
from typing import Dict, List, Optional, Tuple, Any, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func, update, delete, desc
from sqlalchemy.orm import selectinload
from redis.asyncio import Redis
import geoip2.database
import geoip2.errors
from user_agents import parse as parse_user_agent

from ...models.auth.user import User, Session, UserDevice, SecurityEvent, LoginAttempt
from ...schemas.auth.session import (
    SessionInfo, SessionCreate, SessionUpdate, DeviceInfo, LocationInfo,
    SessionListResponse, SessionSecurity, SessionAnalytics, SessionTerminateRequest
)
from ...core.exceptions import (
    SecurityException, ValidationException, BusinessLogicException,
    AuthenticationException, RateLimitException
)
from ...core.security import TokenManager, SecurityUtils
from ...core.config import get_settings
from ...services.base import BaseService
from ...services.notification.notification_service import NotificationService

settings = get_settings()


class SessionStatus(Enum):
    """Session status enumeration."""
    ACTIVE = "active"
    EXPIRED = "expired"
    TERMINATED = "terminated"
    SUSPICIOUS = "suspicious"
    LOCKED = "locked"


class SessionRisk(Enum):
    """Session risk levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class SessionSecurityContext:
    """Session security context information."""
    ip_address: str
    user_agent: str
    device_fingerprint: str
    location: Optional[Dict[str, Any]]
    risk_score: float
    anomaly_flags: List[str]
    trusted_device: bool


class SessionService(BaseService[Session, SessionCreate, SessionUpdate, SessionInfo]):
    """
    Comprehensive session management service.
    
    Provides enterprise-grade session capabilities including:
    - Session lifecycle management (create, validate, terminate)
    - Multi-device session tracking and limits
    - Security monitoring and anomaly detection
    - Geographic and behavioral analysis
    - Automatic cleanup and maintenance
    - Session analytics and reporting
    """
    
    entity_name = "Session"
    
    def __init__(self, db_session: AsyncSession, redis_client: Optional[Redis] = None):
        """
        Initialize session service.
        
        Args:
            db_session: Database session
            redis_client: Redis client for caching and real-time data
        """
        super().__init__(Session, db_session)
        self.logger = logging.getLogger(__name__)
        self.redis = redis_client
        self.token_manager = TokenManager()
        self.notification_service = NotificationService()
        
        # Initialize GeoIP database if available
        try:
            self.geoip_reader = geoip2.database.Reader(settings.GEOIP_DATABASE_PATH)
        except:
            self.geoip_reader = None
            self.logger.warning("GeoIP database not available - location detection disabled")
    
    # ========================================================================
    # SESSION LIFECYCLE MANAGEMENT
    # ========================================================================
    
    async def create_session(
        self,
        user_id: uuid.UUID,
        ip_address: str,
        user_agent: str,
        device_info: Optional[Dict[str, Any]] = None,
        remember_me: bool = False,
        trusted_device_token: Optional[str] = None
    ) -> SessionInfo:
        """
        Create a new user session with comprehensive security analysis.
        
        Args:
            user_id: User ID
            ip_address: Client IP address
            user_agent: Client user agent
            device_info: Optional device information
            remember_me: Whether to create long-lived session
            trusted_device_token: Token for trusted device validation
            
        Returns:
            SessionInfo: Created session information
            
        Raises:
            SecurityException: If session creation is blocked for security reasons
            BusinessLogicException: If concurrent session limit exceeded
        """
        try:
            # Get user and validate
            user = await self._get_user(user_id)
            
            # Check concurrent session limits
            await self._check_concurrent_session_limits(user_id)
            
            # Generate security context
            security_context = await self._analyze_session_security(
                user_id, ip_address, user_agent, device_info, trusted_device_token
            )
            
            # Check if session should be blocked
            if security_context.risk_score >= settings.SESSION_BLOCK_RISK_THRESHOLD:
                await self._log_security_event(
                    user_id, "session_blocked_high_risk",
                    {
                        "risk_score": security_context.risk_score,
                        "anomaly_flags": security_context.anomaly_flags,
                        "ip_address": ip_address
                    }
                )
                raise SecurityException("Session creation blocked due to security concerns")
            
            # Determine session duration
            if remember_me:
                expires_at = datetime.utcnow() + timedelta(days=settings.REMEMBER_ME_DURATION_DAYS)
            else:
                expires_at = datetime.utcnow() + timedelta(hours=settings.SESSION_DURATION_HOURS)
            
            # Generate session tokens
            access_token = await self.token_manager.create_access_token(user_id)
            refresh_token = await self.token_manager.create_refresh_token(user_id)
            session_id = str(uuid.uuid4())
            
            # Parse user agent for device info
            parsed_ua = parse_user_agent(user_agent)
            
            # Create session record
            session = Session(
                id=uuid.UUID(session_id),
                user_id=user_id,
                access_token_hash=self._hash_token(access_token),
                refresh_token_hash=self._hash_token(refresh_token),
                ip_address=ip_address,
                user_agent=user_agent,
                device_fingerprint=security_context.device_fingerprint,
                device_info={
                    "os": f"{parsed_ua.os.family} {parsed_ua.os.version_string}",
                    "browser": f"{parsed_ua.browser.family} {parsed_ua.browser.version_string}",
                    "device": parsed_ua.device.family,
                    "is_mobile": parsed_ua.is_mobile,
                    "is_tablet": parsed_ua.is_tablet,
                    "is_pc": parsed_ua.is_pc,
                    **device_info if device_info else {}
                },
                location_info=security_context.location,
                is_trusted_device=security_context.trusted_device,
                remember_me=remember_me,
                risk_score=security_context.risk_score,
                status=SessionStatus.ACTIVE.value,
                expires_at=expires_at,
                last_activity_at=datetime.utcnow()
            )
            
            self.db.add(session)
            await self.db.commit()
            
            # Cache session in Redis for fast lookups
            if self.redis:
                await self._cache_session(session, access_token, refresh_token)
            
            # Log session creation
            await self._log_security_event(
                user_id, "session_created",
                {
                    "session_id": session_id,
                    "ip_address": ip_address,
                    "risk_score": security_context.risk_score,
                    "trusted_device": security_context.trusted_device,
                    "location": security_context.location
                }
            )
            
            # Send security notification for high-risk sessions
            if security_context.risk_score >= settings.SESSION_NOTIFY_RISK_THRESHOLD:
                await self._send_security_notification(user, session, security_context)
            
            # Update user's last login
            user.last_login_at = datetime.utcnow()
            user.last_login_ip = ip_address
            await self.db.commit()
            
            return SessionInfo(
                session_id=session.id,
                user_id=user_id,
                access_token=access_token,
                refresh_token=refresh_token,
                expires_at=expires_at,
                device_info=session.device_info,
                location_info=session.location_info,
                is_trusted_device=session.is_trusted_device,
                risk_score=session.risk_score,
                created_at=session.created_at
            )
            
        except Exception as e:
            self.logger.error(f"Error creating session: {str(e)}", exc_info=True)
            if isinstance(e, (SecurityException, BusinessLogicException)):
                raise
            raise BusinessLogicException("Failed to create session")
    
    async def validate_session(
        self,
        access_token: str,
        update_activity: bool = True
    ) -> Optional[SessionInfo]:
        """
        Validate session and optionally update last activity.
        
        Args:
            access_token: Access token to validate
            update_activity: Whether to update last activity timestamp
            
        Returns:
            SessionInfo: Session information if valid, None if invalid
        """
        try:
            # Check Redis cache first
            if self.redis:
                cached_session = await self._get_cached_session(access_token)
                if cached_session:
                    if update_activity:
                        await self._update_session_activity(cached_session["session_id"])
                    return SessionInfo(**cached_session)
            
            # Fallback to database
            token_hash = self._hash_token(access_token)
            stmt = (
                select(Session)
                .where(
                    and_(
                        Session.access_token_hash == token_hash,
                        Session.status == SessionStatus.ACTIVE.value,
                        Session.expires_at > datetime.utcnow()
                    )
                )
                .options(selectinload(Session.user))
            )
            
            result = await self.db.execute(stmt)
            session = result.scalar_one_or_none()
            
            if not session:
                return None
            
            # Check if session should be marked as suspicious
            if await self._should_flag_session_suspicious(session):
                await self._mark_session_suspicious(session)
                return None
            
            # Update activity if requested
            if update_activity:
                await self._update_session_activity(session.id)
            
            # Re-cache in Redis
            if self.redis:
                await self._cache_session_info(session, access_token)
            
            return SessionInfo(
                session_id=session.id,
                user_id=session.user_id,
                access_token=access_token,
                expires_at=session.expires_at,
                device_info=session.device_info,
                location_info=session.location_info,
                is_trusted_device=session.is_trusted_device,
                risk_score=session.risk_score,
                last_activity_at=session.last_activity_at,
                created_at=session.created_at
            )
            
        except Exception as e:
            self.logger.error(f"Error validating session: {str(e)}", exc_info=True)
            return None
    
    async def refresh_session(
        self,
        refresh_token: str,
        ip_address: str,
        user_agent: str
    ) -> Optional[SessionInfo]:
        """
        Refresh session with new access token.
        
        Args:
            refresh_token: Refresh token
            ip_address: Current IP address
            user_agent: Current user agent
            
        Returns:
            SessionInfo: New session information with refreshed tokens
        """
        try:
            # Find session by refresh token
            token_hash = self._hash_token(refresh_token)
            stmt = (
                select(Session)
                .where(
                    and_(
                        Session.refresh_token_hash == token_hash,
                        Session.status == SessionStatus.ACTIVE.value,
                        Session.expires_at > datetime.utcnow()
                    )
                )
                .options(selectinload(Session.user))
            )
            
            result = await self.db.execute(stmt)
            session = result.scalar_one_or_none()
            
            if not session:
                return None
            
            # Security checks for refresh
            security_flags = await self._validate_refresh_security(
                session, ip_address, user_agent
            )
            
            if security_flags["block_refresh"]:
                await self._terminate_session(
                    session.id, "security_violation", 
                    {"flags": security_flags["reasons"]}
                )
                return None
            
            # Generate new tokens
            new_access_token = await self.token_manager.create_access_token(session.user_id)
            new_refresh_token = await self.token_manager.create_refresh_token(session.user_id)
            
            # Update session
            session.access_token_hash = self._hash_token(new_access_token)
            session.refresh_token_hash = self._hash_token(new_refresh_token)
            session.ip_address = ip_address
            session.user_agent = user_agent
            session.last_activity_at = datetime.utcnow()
            session.refresh_count = (session.refresh_count or 0) + 1
            
            # Update risk score if needed
            if security_flags["update_risk"]:
                session.risk_score = security_flags["new_risk_score"]
            
            await self.db.commit()
            
            # Update cache
            if self.redis:
                await self._cache_session(session, new_access_token, new_refresh_token)
            
            # Log refresh
            await self._log_security_event(
                session.user_id, "session_refreshed",
                {
                    "session_id": str(session.id),
                    "refresh_count": session.refresh_count,
                    "security_flags": security_flags["reasons"]
                }
            )
            
            return SessionInfo(
                session_id=session.id,
                user_id=session.user_id,
                access_token=new_access_token,
                refresh_token=new_refresh_token,
                expires_at=session.expires_at,
                device_info=session.device_info,
                location_info=session.location_info,
                is_trusted_device=session.is_trusted_device,
                risk_score=session.risk_score,
                last_activity_at=session.last_activity_at,
                created_at=session.created_at
            )
            
        except Exception as e:
            self.logger.error(f"Error refreshing session: {str(e)}", exc_info=True)
            return None
    
    async def terminate_session(
        self,
        session_id: uuid.UUID,
        termination_reason: str = "user_logout",
        terminated_by: Optional[uuid.UUID] = None
    ) -> bool:
        """
        Terminate a specific session.
        
        Args:
            session_id: Session ID to terminate
            termination_reason: Reason for termination
            terminated_by: User who terminated the session
            
        Returns:
            bool: Success status
        """
        try:
            return await self._terminate_session(session_id, termination_reason, {
                "terminated_by": str(terminated_by) if terminated_by else None
            })
        except Exception as e:
            self.logger.error(f"Error terminating session: {str(e)}", exc_info=True)
            return False
    
    async def terminate_all_user_sessions(
        self,
        user_id: uuid.UUID,
        except_session_id: Optional[uuid.UUID] = None,
        termination_reason: str = "admin_action"
    ) -> int:
        """
        Terminate all sessions for a user.
        
        Args:
            user_id: User ID
            except_session_id: Session to exclude from termination
            termination_reason: Reason for mass termination
            
        Returns:
            int: Number of sessions terminated
        """
        try:
            # Get all active sessions
            conditions = [
                Session.user_id == user_id,
                Session.status == SessionStatus.ACTIVE.value
            ]
            
            if except_session_id:
                conditions.append(Session.id != except_session_id)
            
            stmt = select(Session).where(and_(*conditions))
            result = await self.db.execute(stmt)
            sessions = result.scalars().all()
            
            terminated_count = 0
            for session in sessions:
                if await self._terminate_session(session.id, termination_reason):
                    terminated_count += 1
            
            # Log mass termination
            await self._log_security_event(
                user_id, "sessions_mass_terminated",
                {
                    "terminated_count": terminated_count,
                    "reason": termination_reason,
                    "excluded_session": str(except_session_id) if except_session_id else None
                }
            )
            
            return terminated_count
            
        except Exception as e:
            self.logger.error(f"Error terminating user sessions: {str(e)}", exc_info=True)
            return 0
    
    # ========================================================================
    # SESSION MONITORING AND ANALYTICS
    # ========================================================================
    
    async def get_user_sessions(
        self,
        user_id: uuid.UUID,
        include_terminated: bool = False,
        limit: int = 50
    ) -> SessionListResponse:
        """
        Get all sessions for a user.
        
        Args:
            user_id: User ID
            include_terminated: Whether to include terminated sessions
            limit: Maximum number of sessions to return
            
        Returns:
            SessionListResponse: List of user sessions
        """
        try:
            conditions = [Session.user_id == user_id]
            
            if not include_terminated:
                conditions.append(Session.status == SessionStatus.ACTIVE.value)
            
            stmt = (
                select(Session)
                .where(and_(*conditions))
                .order_by(desc(Session.last_activity_at))
                .limit(limit)
            )
            
            result = await self.db.execute(stmt)
            sessions = result.scalars().all()
            
            session_list = []
            for session in sessions:
                session_info = SessionInfo(
                    session_id=session.id,
                    user_id=session.user_id,
                    device_info=session.device_info,
                    location_info=session.location_info,
                    ip_address=session.ip_address,
                    is_trusted_device=session.is_trusted_device,
                    risk_score=session.risk_score,
                    status=session.status,
                    expires_at=session.expires_at,
                    last_activity_at=session.last_activity_at,
                    created_at=session.created_at
                )
                session_list.append(session_info)
            
            return SessionListResponse(
                sessions=session_list,
                total_count=len(session_list),
                active_count=len([s for s in session_list if s.status == SessionStatus.ACTIVE.value])
            )
            
        except Exception as e:
            self.logger.error(f"Error getting user sessions: {str(e)}", exc_info=True)
            return SessionListResponse(sessions=[], total_count=0, active_count=0)
    
    async def get_session_security_info(
        self,
        session_id: uuid.UUID
    ) -> Optional[SessionSecurity]:
        """
        Get detailed security information for a session.
        
        Args:
            session_id: Session ID
            
        Returns:
            SessionSecurity: Security information
        """
        try:
            stmt = (
                select(Session)
                .where(Session.id == session_id)
                .options(selectinload(Session.security_events))
            )
            
            result = await self.db.execute(stmt)
            session = result.scalar_one_or_none()
            
            if not session:
                return None
            
            # Get related security events
            security_events = await self._get_session_security_events(session_id)
            
            # Calculate session metrics
            metrics = await self._calculate_session_metrics(session)
            
            return SessionSecurity(
                session_id=session_id,
                risk_score=session.risk_score,
                trust_level=self._calculate_trust_level(session),
                anomaly_flags=self._extract_anomaly_flags(session),
                security_events=security_events,
                geographic_info=session.location_info,
                device_analysis=self._analyze_device_info(session.device_info),
                session_metrics=metrics
            )
            
        except Exception as e:
            self.logger.error(f"Error getting session security info: {str(e)}", exc_info=True)
            return None
    
    async def generate_session_analytics(
        self,
        user_id: Optional[uuid.UUID] = None,
        date_range_days: int = 30
    ) -> SessionAnalytics:
        """
        Generate comprehensive session analytics.
        
        Args:
            user_id: Optional user ID for user-specific analytics
            date_range_days: Date range for analysis
            
        Returns:
            SessionAnalytics: Analytics data
        """
        try:
            start_date = datetime.utcnow() - timedelta(days=date_range_days)
            
            # Base conditions
            conditions = [Session.created_at >= start_date]
            if user_id:
                conditions.append(Session.user_id == user_id)
            
            # Get session statistics
            stats_stmt = (
                select(
                    func.count(Session.id).label("total_sessions"),
                    func.count(Session.id).filter(
                        Session.status == SessionStatus.ACTIVE.value
                    ).label("active_sessions"),
                    func.avg(Session.risk_score).label("avg_risk_score"),
                    func.count(Session.id).filter(
                        Session.is_trusted_device == True
                    ).label("trusted_device_sessions")
                )
                .where(and_(*conditions))
            )
            
            stats_result = await self.db.execute(stats_stmt)
            stats = stats_result.fetchone()
            
            # Get geographic distribution
            geo_stmt = (
                select(
                    Session.location_info,
                    func.count(Session.id).label("session_count")
                )
                .where(and_(*conditions))
                .group_by(Session.location_info)
            )
            
            geo_result = await self.db.execute(geo_stmt)
            geographic_distribution = {}
            for row in geo_result:
                if row.location_info:
                    country = row.location_info.get("country", "Unknown")
                    geographic_distribution[country] = row.session_count
            
            # Get device statistics
            device_stmt = (
                select(
                    Session.device_info,
                    func.count(Session.id).label("session_count")
                )
                .where(and_(*conditions))
                .group_by(Session.device_info)
            )
            
            device_result = await self.db.execute(device_stmt)
            device_distribution = {"mobile": 0, "desktop": 0, "tablet": 0, "unknown": 0}
            
            for row in device_result:
                if row.device_info:
                    if row.device_info.get("is_mobile"):
                        device_distribution["mobile"] += row.session_count
                    elif row.device_info.get("is_tablet"):
                        device_distribution["tablet"] += row.session_count
                    elif row.device_info.get("is_pc"):
                        device_distribution["desktop"] += row.session_count
                    else:
                        device_distribution["unknown"] += row.session_count
            
            # Calculate security metrics
            security_metrics = await self._calculate_security_metrics(conditions)
            
            return SessionAnalytics(
                period_days=date_range_days,
                total_sessions=stats.total_sessions or 0,
                active_sessions=stats.active_sessions or 0,
                average_risk_score=float(stats.avg_risk_score or 0),
                trusted_device_sessions=stats.trusted_device_sessions or 0,
                geographic_distribution=geographic_distribution,
                device_distribution=device_distribution,
                security_metrics=security_metrics,
                generated_at=datetime.utcnow()
            )
            
        except Exception as e:
            self.logger.error(f"Error generating session analytics: {str(e)}", exc_info=True)
            return SessionAnalytics(
                period_days=date_range_days,
                total_sessions=0,
                active_sessions=0,
                average_risk_score=0.0,
                trusted_device_sessions=0,
                geographic_distribution={},
                device_distribution={},
                security_metrics={},
                generated_at=datetime.utcnow()
            )
    
    # ========================================================================
    # SESSION MAINTENANCE AND CLEANUP
    # ========================================================================
    
    async def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired and terminated sessions.
        
        Returns:
            int: Number of sessions cleaned up
        """
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=settings.SESSION_CLEANUP_DAYS)
            
            # Mark expired sessions as expired
            expired_update = (
                update(Session)
                .where(
                    and_(
                        Session.expires_at < datetime.utcnow(),
                        Session.status == SessionStatus.ACTIVE.value
                    )
                )
                .values(
                    status=SessionStatus.EXPIRED.value,
                    terminated_at=datetime.utcnow()
                )
            )
            
            expired_result = await self.db.execute(expired_update)
            expired_count = expired_result.rowcount
            
            # Delete old terminated sessions
            delete_stmt = delete(Session).where(
                and_(
                    Session.created_at < cutoff_date,
                    Session.status.in_([
                        SessionStatus.EXPIRED.value,
                        SessionStatus.TERMINATED.value
                    ])
                )
            )
            
            delete_result = await self.db.execute(delete_stmt)
            deleted_count = delete_result.rowcount
            
            await self.db.commit()
            
            # Clean Redis cache
            if self.redis:
                await self._cleanup_redis_sessions()
            
            total_cleaned = expired_count + deleted_count
            
            if total_cleaned > 0:
                self.logger.info(f"Cleaned up {total_cleaned} sessions ({expired_count} expired, {deleted_count} deleted)")
            
            return total_cleaned
            
        except Exception as e:
            self.logger.error(f"Error cleaning up sessions: {str(e)}", exc_info=True)
            return 0
    
    async def rotate_session_tokens(self, session_id: uuid.UUID) -> Optional[SessionInfo]:
        """
        Rotate tokens for a session (security measure).
        
        Args:
            session_id: Session ID to rotate tokens for
            
        Returns:
            SessionInfo: Updated session with new tokens
        """
        try:
            session = await self._get_session(session_id)
            if not session or session.status != SessionStatus.ACTIVE.value:
                return None
            
            # Generate new tokens
            new_access_token = await self.token_manager.create_access_token(session.user_id)
            new_refresh_token = await self.token_manager.create_refresh_token(session.user_id)
            
            # Update session
            session.access_token_hash = self._hash_token(new_access_token)
            session.refresh_token_hash = self._hash_token(new_refresh_token)
            session.token_rotated_at = datetime.utcnow()
            session.rotation_count = (session.rotation_count or 0) + 1
            
            await self.db.commit()
            
            # Update cache
            if self.redis:
                await self._cache_session(session, new_access_token, new_refresh_token)
            
            # Log rotation
            await self._log_security_event(
                session.user_id, "session_tokens_rotated",
                {"session_id": str(session_id), "rotation_count": session.rotation_count}
            )
            
            return SessionInfo(
                session_id=session.id,
                user_id=session.user_id,
                access_token=new_access_token,
                refresh_token=new_refresh_token,
                expires_at=session.expires_at,
                device_info=session.device_info,
                location_info=session.location_info,
                is_trusted_device=session.is_trusted_device,
                risk_score=session.risk_score,
                last_activity_at=session.last_activity_at,
                created_at=session.created_at
            )
            
        except Exception as e:
            self.logger.error(f"Error rotating session tokens: {str(e)}", exc_info=True)
            return None
    
    # ========================================================================
    # INTERNAL HELPER METHODS
    # ========================================================================
    
    async def _get_user(self, user_id: uuid.UUID) -> User:
        """Get user by ID."""
        stmt = select(User).where(User.id == user_id)
        result = await self.db.execute(stmt)
        user = result.scalar_one_or_none()
        if not user:
            raise ValidationException("User not found")
        return user
    
    async def _get_session(self, session_id: uuid.UUID) -> Optional[Session]:
        """Get session by ID."""
        stmt = select(Session).where(Session.id == session_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
    
    def _hash_token(self, token: str) -> str:
        """Hash token for storage."""
        import hashlib
        return hashlib.sha256(token.encode()).hexdigest()
    
    async def _analyze_session_security(
        self,
        user_id: uuid.UUID,
        ip_address: str,
        user_agent: str,
        device_info: Optional[Dict[str, Any]],
        trusted_device_token: Optional[str]
    ) -> SessionSecurityContext:
        """Analyze session security context."""
        risk_score = 0.0
        anomaly_flags = []
        trusted_device = False
        
        # Check trusted device
        if trusted_device_token:
            trusted_device = await self._validate_trusted_device(user_id, trusted_device_token)
            if trusted_device:
                risk_score -= 0.3  # Lower risk for trusted devices
        
        # Geographic analysis
        location = await self._analyze_location(ip_address)
        if location:
            # Check if location is unusual for this user
            if await self._is_unusual_location(user_id, location):
                risk_score += 0.4
                anomaly_flags.append("unusual_location")
        
        # Time-based analysis
        if await self._is_unusual_time(user_id):
            risk_score += 0.2
            anomaly_flags.append("unusual_time")
        
        # Device fingerprinting
        device_fingerprint = await self._generate_device_fingerprint(user_agent, device_info)
        if await self._is_new_device(user_id, device_fingerprint):
            risk_score += 0.3
            anomaly_flags.append("new_device")
        
        # User agent analysis
        if await self._is_suspicious_user_agent(user_agent):
            risk_score += 0.5
            anomaly_flags.append("suspicious_user_agent")
        
        # Check for rapid session creation
        if await self._has_rapid_session_creation(user_id, ip_address):
            risk_score += 0.6
            anomaly_flags.append("rapid_session_creation")
        
        # Normalize risk score
        risk_score = max(0.0, min(1.0, risk_score))
        
        return SessionSecurityContext(
            ip_address=ip_address,
            user_agent=user_agent,
            device_fingerprint=device_fingerprint,
            location=location,
            risk_score=risk_score,
            anomaly_flags=anomaly_flags,
            trusted_device=trusted_device
        )
    
    async def _analyze_location(self, ip_address: str) -> Optional[Dict[str, Any]]:
        """Analyze geographic location from IP address."""
        if not self.geoip_reader:
            return None
        
        try:
            response = self.geoip_reader.city(ip_address)
            return {
                "country": response.country.name,
                "country_code": response.country.iso_code,
                "city": response.city.name,
                "region": response.subdivisions.most_specific.name,
                "latitude": float(response.location.latitude) if response.location.latitude else None,
                "longitude": float(response.location.longitude) if response.location.longitude else None,
                "timezone": response.location.time_zone
            }
        except geoip2.errors.AddressNotFoundError:
            return None
        except Exception as e:
            self.logger.warning(f"GeoIP lookup failed for {ip_address}: {str(e)}")
            return None
    
    async def _check_concurrent_session_limits(self, user_id: uuid.UUID):
        """Check if user has exceeded concurrent session limits."""
        active_count = await self.db.execute(
            select(func.count(Session.id)).where(
                and_(
                    Session.user_id == user_id,
                    Session.status == SessionStatus.ACTIVE.value,
                    Session.expires_at > datetime.utcnow()
                )
            )
        )
        
        if active_count.scalar() >= settings.MAX_CONCURRENT_SESSIONS:
            raise BusinessLogicException("Maximum concurrent sessions exceeded")
    
    async def _terminate_session(
        self,
        session_id: uuid.UUID,
        reason: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Internal method to terminate a session."""
        try:
            session = await self._get_session(session_id)
            if not session:
                return False
            
            # Update session status
            session.status = SessionStatus.TERMINATED.value
            session.terminated_at = datetime.utcnow()
            session.termination_reason = reason
            if metadata:
                session.termination_metadata = metadata
            
            await self.db.commit()
            
            # Remove from Redis cache
            if self.redis:
                await self._remove_cached_session(session_id)
            
            # Log termination
            await self._log_security_event(
                session.user_id, "session_terminated",
                {
                    "session_id": str(session_id),
                    "reason": reason,
                    "metadata": metadata
                }
            )
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error terminating session {session_id}: {str(e)}")
            return False
    
    async def _update_session_activity(self, session_id: uuid.UUID):
        """Update session last activity timestamp."""
        try:
            update_stmt = (
                update(Session)
                .where(Session.id == session_id)
                .values(last_activity_at=datetime.utcnow())
            )
            await self.db.execute(update_stmt)
            await self.db.commit()
        except Exception as e:
            self.logger.error(f"Error updating session activity: {str(e)}")
    
    async def _cache_session(
        self,
        session: Session,
        access_token: str,
        refresh_token: str
    ):
        """Cache session information in Redis."""
        if not self.redis:
            return
        
        session_data = {
            "session_id": str(session.id),
            "user_id": str(session.user_id),
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_at": session.expires_at.isoformat(),
            "device_info": session.device_info,
            "location_info": session.location_info,
            "is_trusted_device": session.is_trusted_device,
            "risk_score": session.risk_score,
            "last_activity_at": session.last_activity_at.isoformat(),
            "created_at": session.created_at.isoformat()
        }
        
        # Cache with expiration
        await self.redis.setex(
            f"session:{self._hash_token(access_token)}",
            settings.SESSION_CACHE_TTL,
            json.dumps(session_data, default=str)
        )
    
    async def _get_cached_session(self, access_token: str) -> Optional[Dict[str, Any]]:
        """Get session from Redis cache."""
        if not self.redis:
            return None
        
        try:
            cached = await self.redis.get(f"session:{self._hash_token(access_token)}")
            if cached:
                return json.loads(cached)
        except Exception as e:
            self.logger.warning(f"Redis cache error: {str(e)}")
        
        return None
    
    async def _log_security_event(
        self,
        user_id: uuid.UUID,
        event_type: str,
        details: Dict[str, Any]
    ):
        """Log security event."""
        event = SecurityEvent(
            id=uuid.uuid4(),
            user_id=user_id,
            event_type=event_type,
            event_details=details,
            created_at=datetime.utcnow()
        )
        
        self.db.add(event)
        await self.db.commit()
    
    # Additional placeholder methods for completeness
    async def _validate_trusted_device(self, user_id: uuid.UUID, token: str) -> bool:
        """Validate trusted device token."""
        # Implementation would check trusted device records
        return False
    
    async def _is_unusual_location(self, user_id: uuid.UUID, location: Dict[str, Any]) -> bool:
        """Check if location is unusual for user."""
        # Implementation would analyze user's location history
        return False
    
    async def _is_unusual_time(self, user_id: uuid.UUID) -> bool:
        """Check if login time is unusual."""
        # Implementation would analyze user's login patterns
        return False
    
    async def _generate_device_fingerprint(
        self, 
        user_agent: str, 
        device_info: Optional[Dict[str, Any]]
    ) -> str:
        """Generate device fingerprint."""
        import hashlib
        fingerprint_data = user_agent
        if device_info:
            fingerprint_data += str(sorted(device_info.items()))
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()
    
    async def _is_new_device(self, user_id: uuid.UUID, fingerprint: str) -> bool:
        """Check if device is new for user."""
        # Implementation would check device history
        return True
    
    async def _is_suspicious_user_agent(self, user_agent: str) -> bool:
        """Check if user agent is suspicious."""
        # Implementation would check against suspicious patterns
        return False
    
    async def _has_rapid_session_creation(self, user_id: uuid.UUID, ip_address: str) -> bool:
        """Check for rapid session creation patterns."""
        # Implementation would check recent session creation rate
        return False


# Export the service
__all__ = ["SessionService", "SessionStatus", "SessionRisk"]