# app/services/auth/permission_service.py
class PermissionService:
    async def check_permission(self, user: User, resource: str, action: str) -> bool
    async def get_user_permissions(self, user_id: UUID) -> List[Permission]
    async def check_department_isolation(self, user: User, resource: str) -> bool
    async def get_accessible_records(self, user: User, resource: str) -> Query