"""
User Service for CARDINSA Insurance Platform

This service provides business logic for user management including:
- User CRUD operations (inherits from BaseService)
- Authentication and password management
- User profile management
- Multi-tenancy and company associations
- Permission and role management
- Security features (account locking, MFA, etc.)
"""

import uuid
import logging
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func, update
from sqlalchemy.orm import selectinload

from ...models.auth.user import User
from ...schemas.auth.user import (
    UserCreate,
    UserUpdate, 
    UserResponse,
    UserPreferences,
    UserPasswordChange
)
from ...schemas.auth.auth import LoginRequest
from ...services.base import BaseService
from ...core.exceptions import (
    ValidationException,
    AuthenticationException,
    BusinessLogicException,
    ResourceNotFoundException
)
from ...core.security import (
    PasswordSecurity,
    PermissionManager,
    hash_password,
    verify_password
)
from ...schemas.base import FilterParams, PaginationParams, PaginatedResponse


class UserService(BaseService[User, UserCreate, UserUpdate, UserResponse]):
    """
    User service providing business logic for user management.
    
    Inherits from BaseService to get:
    - Complete CRUD operations (create, get, list, update, delete, restore)
    - Transaction management
    - Validation hooks
    - Audit logging
    - Error handling
    - Pagination and filtering
    """
    
    entity_name = "User"
    
    def __init__(self, db_session: AsyncSession):
        """
        Initialize user service.
        
        Args:
            db_session: Database session
        """
        super().__init__(User, db_session)
        self.logger = logging.getLogger(__name__)
    
    # Override validation hooks from BaseService
    async def _validate_create(
        self,
        create_data: Dict[str, Any],
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Validate user creation data.
        
        Args:
            create_data: User creation data
            current_user_id: ID of user performing the creation
            
        Raises:
            ValidationException: If validation fails
            BusinessLogicException: If business rules are violated
        """
        email = create_data.get("email")
        
        if not email:
            raise ValidationException("Email is required")
        
        # Check if email already exists
        existing_user = await self.get_by_email(email)
        if existing_user:
            if existing_user.is_archived:
                raise BusinessLogicException(
                    f"A user with email '{email}' exists but is archived. "
                    "Please restore the user or contact an administrator."
                )
            else:
                raise ValidationException(f"User with email '{email}' already exists")
        
        # Validate password if provided
        password = create_data.get("password")
        if password:
            validation_result = PasswordSecurity.validate_password_strength(password)
            if not validation_result["valid"]:
                raise ValidationException(
                    f"Password validation failed: {', '.join(validation_result['errors'])}"
                )
        
        # Validate superuser creation (only superusers can create other superusers)
        if create_data.get("is_superuser") and current_user_id:
            current_user = await self.get(current_user_id)
            if not current_user or not current_user.is_superuser:
                raise ValidationException("Only superusers can create other superusers")
    
    async def _validate_update(
        self,
        db_obj: User,
        update_data: Dict[str, Any],
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Validate user update data.
        
        Args:
            db_obj: Existing user object
            update_data: Update data
            current_user_id: ID of user performing the update
        """
        # Check email uniqueness if email is being changed
        new_email = update_data.get("email")
        if new_email and new_email != db_obj.email:
            existing_user = await self.get_by_email(new_email)
            if existing_user and existing_user.id != db_obj.id:
                raise ValidationException(f"User with email '{new_email}' already exists")
        
        # Validate superuser changes (only superusers can modify superuser status)
        if "is_superuser" in update_data and current_user_id:
            current_user = await self.get(current_user_id)
            if not current_user or not current_user.is_superuser:
                raise ValidationException("Only superusers can modify superuser status")
        
        # Prevent users from deactivating themselves
        if "is_active" in update_data and not update_data["is_active"]:
            if current_user_id and str(current_user_id) == str(db_obj.id):
                raise BusinessLogicException("Users cannot deactivate their own account")
    
    async def _validate_delete(
        self,
        db_obj: User,
        current_user_id: Optional[uuid.UUID]
    ) -> None:
        """
        Validate user deletion.
        
        Args:
            db_obj: User to be deleted
            current_user_id: ID of user performing the deletion
        """
        # Prevent users from deleting themselves
        if current_user_id and str(current_user_id) == str(db_obj.id):
            raise BusinessLogicException("Users cannot delete their own account")
        
        # Prevent deletion of superusers by non-superusers
        if db_obj.is_superuser and current_user_id:
            current_user = await self.get(current_user_id)
            if not current_user or not current_user.is_superuser:
                raise ValidationException("Only superusers can delete other superusers")
    
    async def create(
        self,
        obj_in: UserCreate,
        current_user_id: Optional[uuid.UUID] = None,
        company_id: Optional[uuid.UUID] = None,
        **kwargs
    ) -> User:
        """
        Create a new user with password hashing and additional setup.
        
        Args:
            obj_in: User creation data
            current_user_id: ID of user creating the user
            company_id: Company ID for association
            **kwargs: Additional creation parameters
            
        Returns:
            User: Created user
        """
        # Hash the password before creation
        create_data = obj_in.dict(exclude={"password", "company_ids", "role_names"})
        
        if obj_in.password:
            create_data["password_hash"] = hash_password(obj_in.password)
            create_data["password_changed_at"] = datetime.utcnow()
        
        # Generate full_name if not provided
        if not create_data.get("full_name"):
            create_data["full_name"] = f"{create_data.get('first_name', '')} {create_data.get('last_name', '')}".strip()
        
        # Create the user using the base service
        user = await super().create(create_data, current_user_id, company_id, **kwargs)
        
        # Handle company associations if provided
        if obj_in.company_ids:
            await self._associate_with_companies(user, obj_in.company_ids)
        
        # Handle role assignments if provided  
        if obj_in.role_names:
            await self._assign_roles(user, obj_in.role_names)
        
        self.logger.info(
            f"User created successfully",
            extra={
                "user_id": str(user.id),
                "email": user.email,
                "created_by": str(current_user_id) if current_user_id else None
            }
        )
        
        return user
    
    async def get_by_email(
        self,
        email: str,
        include_archived: bool = False
    ) -> Optional[User]:
        """
        Get user by email address.
        
        Args:
            email: User's email address
            include_archived: Include archived users
            
        Returns:
            Optional[User]: User if found, None otherwise
        """
        try:
            query = select(User).where(User.email == email.lower())
            
            if not include_archived:
                query = query.where(User.archived_at.is_(None))
            
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
            
        except Exception as e:
            self.logger.error(f"Error getting user by email: {str(e)}")
            raise
    
    async def authenticate_user(
        self,
        email: str,
        password: str,
        ip_address: Optional[str] = None
    ) -> Tuple[Optional[User], str]:
        """
        Authenticate a user with email and password.
        
        Args:
            email: User's email
            password: User's password
            ip_address: Client IP address
            
        Returns:
            Tuple[Optional[User], str]: User object and status message
            
        Raises:
            AuthenticationException: If authentication fails
        """
        try:
            # Get user by email
            user = await self.get_by_email(email)
            
            if not user:
                # Don't reveal whether email exists
                self.logger.warning(
                    f"Authentication attempt with non-existent email: {email}",
                    extra={"email": email, "ip_address": ip_address}
                )
                return None, "Invalid email or password"
            
            # Check if user is active and not archived
            if not user.is_active or user.is_archived:
                self.logger.warning(
                    f"Authentication attempt with inactive user: {email}",
                    extra={"user_id": str(user.id), "ip_address": ip_address}
                )
                return None, "Account is inactive"
            
            # Check if account is locked
            if user.is_locked:
                self.logger.warning(
                    f"Authentication attempt with locked account: {email}",
                    extra={"user_id": str(user.id), "ip_address": ip_address}
                )
                return None, f"Account is locked until {user.locked_until}"
            
            # Verify password
            if not verify_password(password, user.password_hash):
                # Increment failed login attempts
                user.increment_failed_login()
                await self.db.commit()
                
                self.logger.warning(
                    f"Failed authentication attempt for user: {email}",
                    extra={
                        "user_id": str(user.id),
                        "ip_address": ip_address,
                        "failed_attempts": user.failed_login_attempts
                    }
                )
                
                if user.is_locked:
                    return None, f"Account has been locked due to too many failed attempts"
                
                return None, "Invalid email or password"
            
            # Successful authentication
            user.record_successful_login(ip_address)
            await self.db.commit()
            
            self.logger.info(
                f"Successful authentication for user: {email}",
                extra={
                    "user_id": str(user.id),
                    "ip_address": ip_address
                }
            )
            
            return user, "Authentication successful"
            
        except Exception as e:
            self.logger.error(f"Error during authentication: {str(e)}")
            raise AuthenticationException("Authentication failed")
    
    async def change_password(
        self,
        user_id: uuid.UUID,
        password_change: UserPasswordChange,
        current_user_id: Optional[uuid.UUID] = None
    ) -> bool:
        """
        Change user's password.
        
        Args:
            user_id: ID of user whose password to change
            password_change: Password change request
            current_user_id: ID of user making the change
            
        Returns:
            bool: True if password changed successfully
            
        Raises:
            AuthenticationException: If current password is incorrect
            ValidationException: If new password is invalid
        """
        try:
            # Get the user
            user = await self.get_or_404(user_id)
            
            # Verify current password
            if not verify_password(password_change.current_password, user.password_hash):
                self.logger.warning(
                    f"Failed password change attempt - incorrect current password",
                    extra={
                        "user_id": str(user_id),
                        "changed_by": str(current_user_id) if current_user_id else None
                    }
                )
                raise AuthenticationException("Current password is incorrect")
            
            # Hash new password
            new_password_hash = hash_password(password_change.new_password)
            
            # Update password
            user.password_hash = new_password_hash
            user.password_changed_at = datetime.utcnow()
            
            if current_user_id:
                user.updated_by = current_user_id
            
            await self.db.commit()
            
            self.logger.info(
                f"Password changed successfully",
                extra={
                    "user_id": str(user_id),
                    "changed_by": str(current_user_id) if current_user_id else None
                }
            )
            
            return True
            
        except (AuthenticationException, ValidationException):
            raise
        except Exception as e:
            self.logger.error(f"Error changing password: {str(e)}")
            raise BusinessLogicException("Failed to change password")
    
    async def reset_password(
        self,
        user_id: uuid.UUID,
        new_password: str,
        reset_by: Optional[uuid.UUID] = None
    ) -> bool:
        """
        Reset user's password (admin function).
        
        Args:
            user_id: ID of user whose password to reset
            new_password: New password
            reset_by: ID of user performing the reset
            
        Returns:
            bool: True if password reset successfully
        """
        try:
            # Validate password strength
            validation_result = PasswordSecurity.validate_password_strength(new_password)
            if not validation_result["valid"]:
                raise ValidationException(
                    f"Password validation failed: {', '.join(validation_result['errors'])}"
                )
            
            # Get the user
            user = await self.get_or_404(user_id)
            
            # Hash new password
            new_password_hash = hash_password(new_password)
            
            # Update password and reset security fields
            user.password_hash = new_password_hash
            user.password_changed_at = datetime.utcnow()
            user.reset_failed_login()  # Clear any lockout
            
            if reset_by:
                user.updated_by = reset_by
            
            await self.db.commit()
            
            self.logger.info(
                f"Password reset successfully",
                extra={
                    "user_id": str(user_id),
                    "reset_by": str(reset_by) if reset_by else None
                }
            )
            
            return True
            
        except (ValidationException,):
            raise
        except Exception as e:
            self.logger.error(f"Error resetting password: {str(e)}")
            raise BusinessLogicException("Failed to reset password")
    
    async def update_preferences(
        self,
        user_id: uuid.UUID,
        preferences: UserPreferences,
        current_user_id: Optional[uuid.UUID] = None
    ) -> User:
        """
        Update user preferences.
        
        Args:
            user_id: ID of user to update
            preferences: New preferences
            current_user_id: ID of user making the update
            
        Returns:
            User: Updated user
        """
        try:
            user = await self.get_or_404(user_id)
            
            # Convert preferences to dict and update
            preferences_dict = preferences.dict(exclude_unset=True)
            user.update_preferences(preferences_dict)
            
            if current_user_id:
                user.updated_by = current_user_id
            
            await self.db.commit()
            await self.db.refresh(user)
            
            return user
            
        except Exception as e:
            self.logger.error(f"Error updating user preferences: {str(e)}")
            raise BusinessLogicException("Failed to update user preferences")
    
    async def search_users(
        self,
        search_term: str,
        pagination: Optional[PaginationParams] = None,
        company_id: Optional[uuid.UUID] = None,
        include_archived: bool = False
    ) -> PaginatedResponse:
        """
        Search users by name or email.
        
        Args:
            search_term: Search term
            pagination: Pagination parameters
            company_id: Filter by company
            include_archived: Include archived users
            
        Returns:
            PaginatedResponse: Paginated search results
        """
        try:
            # Build search query
            search_filter = or_(
                User.email.ilike(f"%{search_term}%"),
                User.first_name.ilike(f"%{search_term}%"),
                User.last_name.ilike(f"%{search_term}%"),
                User.full_name.ilike(f"%{search_term}%")
            )
            
            query = select(User).where(search_filter)
            
            # Apply company filter if provided
            if company_id:
                # This would require proper company relationship setup
                pass
            
            # Apply archived filter
            if not include_archived:
                query = query.where(User.archived_at.is_(None))
            
            # Get total count
            count_query = select(func.count()).select_from(query.subquery())
            total_result = await self.db.execute(count_query)
            total = total_result.scalar()
            
            # Apply pagination
            if pagination:
                query = query.offset(pagination.offset).limit(pagination.size)
            else:
                pagination = PaginationParams(page=1, size=20)
            
            # Execute search
            result = await self.db.execute(query)
            users = result.scalars().all()
            
            # Calculate pagination info
            from ...schemas.base import PaginationInfo
            pages = (total + pagination.size - 1) // pagination.size
            pagination_info = PaginationInfo(
                page=pagination.page,
                size=pagination.size,
                total=total,
                pages=pages,
                has_next=pagination.page < pages,
                has_prev=pagination.page > 1
            )
            
            return PaginatedResponse(
                items=users,
                pagination=pagination_info
            )
            
        except Exception as e:
            self.logger.error(f"Error searching users: {str(e)}")
            raise BusinessLogicException("Failed to search users")
    
    async def get_user_permissions(
        self,
        user_id: uuid.UUID,
        company_id: Optional[uuid.UUID] = None
    ) -> List[str]:
        """
        Get effective permissions for a user.
        
        Args:
            user_id: User ID
            company_id: Company context
            
        Returns:
            List[str]: List of permission names
        """
        try:
            user = await self.get_or_404(user_id)
            return user.get_permissions(company_id)
            
        except Exception as e:
            self.logger.error(f"Error getting user permissions: {str(e)}")
            return []
    
    async def unlock_user(
        self,
        user_id: uuid.UUID,
        unlocked_by: Optional[uuid.UUID] = None
    ) -> User:
        """
        Unlock a locked user account.
        
        Args:
            user_id: User ID to unlock
            unlocked_by: ID of user performing the unlock
            
        Returns:
            User: Unlocked user
        """
        try:
            user = await self.get_or_404(user_id)
            
            user.reset_failed_login()
            
            if unlocked_by:
                user.updated_by = unlocked_by
            
            await self.db.commit()
            await self.db.refresh(user)
            
            self.logger.info(
                f"User account unlocked",
                extra={
                    "user_id": str(user_id),
                    "unlocked_by": str(unlocked_by) if unlocked_by else None
                }
            )
            
            return user
            
        except Exception as e:
            self.logger.error(f"Error unlocking user: {str(e)}")
            raise BusinessLogicException("Failed to unlock user account")
    
    async def verify_email(
        self,
        user_id: uuid.UUID,
        verified_by: Optional[uuid.UUID] = None
    ) -> User:
        """
        Mark user's email as verified.
        
        Args:
            user_id: User ID to verify
            verified_by: ID of user performing the verification
            
        Returns:
            User: Verified user
        """
        try:
            user = await self.get_or_404(user_id)
            
            user.is_verified = True
            
            if verified_by:
                user.updated_by = verified_by
            
            await self.db.commit()
            await self.db.refresh(user)
            
            self.logger.info(
                f"User email verified",
                extra={
                    "user_id": str(user_id),
                    "email": user.email,
                    "verified_by": str(verified_by) if verified_by else None
                }
            )
            
            return user
            
        except Exception as e:
            self.logger.error(f"Error verifying user email: {str(e)}")
            raise BusinessLogicException("Failed to verify user email")
    
    # Private helper methods
    async def _associate_with_companies(
        self,
        user: User,
        company_ids: List[uuid.UUID]
    ) -> None:
        """
        Associate user with companies.
        
        Args:
            user: User to associate
            company_ids: List of company IDs
            
        Note: This will be implemented when Company model is created
        """
        # TODO: Implement when Company model is available
        pass
    
    async def _assign_roles(
        self,
        user: User,
        role_names: List[str]
    ) -> None:
        """
        Assign roles to user.
        
        Args:
            user: User to assign roles to
            role_names: List of role names
            
        Note: This will be implemented when Role model is created
        """
        # TODO: Implement when Role model is available
        pass


# Export the UserService
__all__ = ["UserService"]