"""
Role-Based Access Control (RBAC) service with department/unit logic.
"""

import uuid
import logging
from typing import List, Optional, Dict, Any, Set
from datetime import datetime

from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_

from app.core.exceptions import (
    InsufficientPermissionsError,
    ResourceAccessDeniedError,
    DepartmentAccessDeniedError,
    RecordNotFoundError
)
from app.models.auth.user import (
    User, Role, Permission, Department, Unit,
    user_roles, role_permissions
)

logger = logging.getLogger(__name__)


class RBACService:
    """Role-Based Access Control service for managing permissions and access."""
    
    def __init__(self, db: Session):
        self.db = db
    
    # User Role Management
    
    def assign_role_to_user(
        self, 
        user_id: uuid.UUID, 
        role_id: uuid.UUID,
        assigned_by: uuid.UUID,
        expires_at: Optional[datetime] = None
    ) -> bool:
        """
        Assign a role to a user.
        
        Args:
            user_id: User ID
            role_id: Role ID to assign
            assigned_by: ID of user assigning the role
            expires_at: Optional expiration date for the role assignment
            
        Returns:
            True if role assigned successfully
            
        Raises:
            RecordNotFoundError: If user or role not found
        """
        try:
            # Verify user and role exist
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                raise RecordNotFoundError("User", str(user_id))
            
            role = self.db.query(Role).filter(Role.id == role_id).first()
            if not role:
                raise RecordNotFoundError("Role", str(role_id))
            
            # Check if role is already assigned
            existing_assignment = self.db.execute(
                user_roles.select().where(
                    and_(
                        user_roles.c.user_id == user_id,
                        user_roles.c.role_id == role_id,
                        user_roles.c.is_active == True
                    )
                )
            ).first()
            
            if existing_assignment:
                logger.info(f"Role {role.code} already assigned to user {user.username}")
                return True
            
            # Insert new role assignment
            self.db.execute(
                user_roles.insert().values(
                    user_id=user_id,
                    role_id=role_id,
                    assigned_by=assigned_by,
                    assigned_at=datetime.utcnow(),
                    expires_at=expires_at,
                    is_active=True
                )
            )
            
            self.db.commit()
            logger.info(f"Role {role.code} assigned to user {user.username}")
            return True
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to assign role {role_id} to user {user_id}: {e}")
            raise
    
    def remove_role_from_user(
        self, 
        user_id: uuid.UUID, 
        role_id: uuid.UUID
    ) -> bool:
        """
        Remove a role from a user.
        
        Args:
            user_id: User ID
            role_id: Role ID to remove
            
        Returns:
            True if role removed successfully
        """
        try:
            # Update role assignment to inactive
            result = self.db.execute(
                user_roles.update().where(
                    and_(
                        user_roles.c.user_id == user_id,
                        user_roles.c.role_id == role_id
                    )
                ).values(is_active=False)
            )
            
            self.db.commit()
            
            if result.rowcount > 0:
                logger.info(f"Role {role_id} removed from user {user_id}")
                return True
            
            return False
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to remove role {role_id} from user {user_id}: {e}")
            raise
    
    def get_user_roles(self, user_id: uuid.UUID) -> List[Role]:
        """
        Get all active roles for a user.
        
        Args:
            user_id: User ID
            
        Returns:
            List of user's active roles
        """
        try:
            roles = self.db.query(Role).join(user_roles).filter(
                and_(
                    user_roles.c.user_id == user_id,
                    user_roles.c.is_active == True,
                    or_(
                        user_roles.c.expires_at.is_(None),
                        user_roles.c.expires_at > datetime.utcnow()
                    ),
                    Role.is_active == True
                )
            ).all()
            
            return roles
            
        except Exception as e:
            logger.error(f"Failed to get roles for user {user_id}: {e}")
            return []
    
    # Permission Management
    
    def get_user_permissions(self, user_id: uuid.UUID) -> Set[str]:
        """
        Get all permissions for a user (through their roles).
        
        Args:
            user_id: User ID
            
        Returns:
            Set of permission codes
        """
        try:
            # Get user's active roles
            user_roles_query = self.db.query(user_roles.c.role_id).filter(
                and_(
                    user_roles.c.user_id == user_id,
                    user_roles.c.is_active == True,
                    or_(
                        user_roles.c.expires_at.is_(None),
                        user_roles.c.expires_at > datetime.utcnow()
                    )
                )
            ).subquery()
            
            # Get permissions through roles
            permissions = self.db.query(Permission.code).join(role_permissions).join(
                user_roles_query, role_permissions.c.role_id == user_roles_query.c.role_id
            ).filter(
                Role.is_active == True
            ).distinct().all()
            
            return {perm.code for perm in permissions}
            
        except Exception as e:
            logger.error(f"Failed to get permissions for user {user_id}: {e}")
            return set()
    
    def user_has_permission(self, user_id: uuid.UUID, permission_code: str) -> bool:
        """
        Check if a user has a specific permission.
        
        Args:
            user_id: User ID
            permission_code: Permission code to check
            
        Returns:
            True if user has the permission
        """
        user_permissions = self.get_user_permissions(user_id)
        return permission_code in user_permissions
    
    def user_has_any_permission(self, user_id: uuid.UUID, permission_codes: List[str]) -> bool:
        """
        Check if a user has any of the specified permissions.
        
        Args:
            user_id: User ID
            permission_codes: List of permission codes to check
            
        Returns:
            True if user has any of the permissions
        """
        user_permissions = self.get_user_permissions(user_id)
        return any(perm in user_permissions for perm in permission_codes)
    
    def user_has_all_permissions(self, user_id: uuid.UUID, permission_codes: List[str]) -> bool:
        """
        Check if a user has all of the specified permissions.
        
        Args:
            user_id: User ID
            permission_codes: List of permission codes to check
            
        Returns:
            True if user has all permissions
        """
        user_permissions = self.get_user_permissions(user_id)
        return all(perm in user_permissions for perm in permission_codes)
    
    def require_permission(self, user_id: uuid.UUID, permission_code: str) -> None:
        """
        Require a user to have a specific permission.
        
        Args:
            user_id: User ID
            permission_code: Required permission code
            
        Raises:
            InsufficientPermissionsError: If user lacks the permission
        """
        if not self.user_has_permission(user_id, permission_code):
            logger.warning(f"User {user_id} lacks required permission: {permission_code}")
            raise InsufficientPermissionsError(permission_code)
    
    # Role Management
    
    def user_has_role(self, user_id: uuid.UUID, role_code: str) -> bool:
        """
        Check if a user has a specific role.
        
        Args:
            user_id: User ID
            role_code: Role code to check
            
        Returns:
            True if user has the role
        """
        try:
            role_exists = self.db.query(Role).join(user_roles).filter(
                and_(
                    user_roles.c.user_id == user_id,
                    user_roles.c.is_active == True,
                    or_(
                        user_roles.c.expires_at.is_(None),
                        user_roles.c.expires_at > datetime.utcnow()
                    ),
                    Role.code == role_code,
                    Role.is_active == True
                )
            ).first()
            
            return role_exists is not None
            
        except Exception as e:
            logger.error(f"Failed to check role {role_code} for user {user_id}: {e}")
            return False
    
    def user_has_any_role(self, user_id: uuid.UUID, role_codes: List[str]) -> bool:
        """
        Check if a user has any of the specified roles.
        
        Args:
            user_id: User ID
            role_codes: List of role codes to check
            
        Returns:
            True if user has any of the roles
        """
        return any(self.user_has_role(user_id, role_code) for role_code in role_codes)
    
    def require_role(self, user_id: uuid.UUID, role_code: str) -> None:
        """
        Require a user to have a specific role.
        
        Args:
            user_id: User ID
            role_code: Required role code
            
        Raises:
            InsufficientPermissionsError: If user lacks the role
        """
        if not self.user_has_role(user_id, role_code):
            logger.warning(f"User {user_id} lacks required role: {role_code}")
            raise InsufficientPermissionsError(f"Role '{role_code}' required")
    
    # Organizational Access Control
    
    def user_can_access_department(
        self, 
        user_id: uuid.UUID, 
        target_department_id: uuid.UUID,
        permission_code: Optional[str] = None
    ) -> bool:
        """
        Check if a user can access a specific department's resources.
        
        Args:
            user_id: User ID
            target_department_id: Department ID to access
            permission_code: Optional specific permission to check
            
        Returns:
            True if user can access the department
        """
        try:
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                return False
            
            # Superusers can access all departments
            if user.is_superuser:
                return True
            
            # Check if user has a global permission that allows cross-department access
            if permission_code:
                global_permission = f"{permission_code}.all_departments"
                if self.user_has_permission(user_id, global_permission):
                    return True
            
            # Users can access their own department
            if user.department_id == target_department_id:
                return True
            
            # Check for specific department access permissions
            dept_permission = f"department.access.{target_department_id}"
            if self.user_has_permission(user_id, dept_permission):
                return True
            
            # Check if user has manager role for the target department
            target_dept = self.db.query(Department).filter(
                Department.id == target_department_id
            ).first()
            
            if target_dept and target_dept.manager_id == user_id:
                return True
            
            # Check if user's department is parent of target department
            if target_dept and target_dept.parent_department_id == user.department_id:
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to check department access for user {user_id}: {e}")
            return False
    
    def user_can_access_unit(
        self, 
        user_id: uuid.UUID, 
        target_unit_id: uuid.UUID,
        permission_code: Optional[str] = None
    ) -> bool:
        """
        Check if a user can access a specific unit's resources.
        
        Args:
            user_id: User ID
            target_unit_id: Unit ID to access
            permission_code: Optional specific permission to check
            
        Returns:
            True if user can access the unit
        """
        try:
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                return False
            
            # Superusers can access all units
            if user.is_superuser:
                return True
            
            # Check if user has a global permission that allows cross-unit access
            if permission_code:
                global_permission = f"{permission_code}.all_units"
                if self.user_has_permission(user_id, global_permission):
                    return True
            
            # Users can access their own unit
            if user.unit_id == target_unit_id:
                return True
            
            # Get target unit and check department access
            target_unit = self.db.query(Unit).filter(
                Unit.id == target_unit_id
            ).first()
            
            if not target_unit:
                return False
            
            # Check if user can access the unit's department
            if self.user_can_access_department(user_id, target_unit.department_id, permission_code):
                return True
            
            # Check if user is the unit manager
            if target_unit.manager_id == user_id:
                return True
            
            # Check for specific unit access permissions
            unit_permission = f"unit.access.{target_unit_id}"
            if self.user_has_permission(user_id, unit_permission):
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to check unit access for user {user_id}: {e}")
            return False
    
    def require_department_access(
        self, 
        user_id: uuid.UUID, 
        department_id: uuid.UUID,
        permission_code: Optional[str] = None
    ) -> None:
        """
        Require a user to have access to a specific department.
        
        Args:
            user_id: User ID
            department_id: Required department ID
            permission_code: Optional specific permission to check
            
        Raises:
            DepartmentAccessDeniedError: If user cannot access the department
        """
        if not self.user_can_access_department(user_id, department_id, permission_code):
            logger.warning(f"User {user_id} denied access to department {department_id}")
            raise DepartmentAccessDeniedError(str(department_id))
    
    def require_unit_access(
        self, 
        user_id: uuid.UUID, 
        unit_id: uuid.UUID,
        permission_code: Optional[str] = None
    ) -> None:
        """
        Require a user to have access to a specific unit.
        
        Args:
            user_id: User ID
            unit_id: Required unit ID
            permission_code: Optional specific permission to check
            
        Raises:
            ResourceAccessDeniedError: If user cannot access the unit
        """
        if not self.user_can_access_unit(user_id, unit_id, permission_code):
            logger.warning(f"User {user_id} denied access to unit {unit_id}")
            raise ResourceAccessDeniedError("unit", str(unit_id))
    
    # Resource Access Control
    
    def can_access_resource(
        self, 
        user_id: uuid.UUID, 
        resource_type: str,
        resource_id: Optional[str] = None,
        action: str = "read",
        owner_id: Optional[uuid.UUID] = None,
        department_id: Optional[uuid.UUID] = None,
        unit_id: Optional[uuid.UUID] = None
    ) -> bool:
        """
        Check if a user can access a specific resource.
        
        Args:
            user_id: User ID
            resource_type: Type of resource (e.g., 'policy', 'claim')
            resource_id: Optional specific resource ID
            action: Action to perform ('read', 'write', 'delete')
            owner_id: Optional resource owner ID
            department_id: Optional resource department ID
            unit_id: Optional resource unit ID
            
        Returns:
            True if user can access the resource
        """
        try:
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                return False
            
            # Superusers can access everything
            if user.is_superuser:
                return True
            
            # Check for global permission
            global_permission = f"{resource_type}.{action}.all"
            if self.user_has_permission(user_id, global_permission):
                return True
            
            # Check for own resource access
            if owner_id and owner_id == user_id:
                own_permission = f"{resource_type}.{action}.own"
                if self.user_has_permission(user_id, own_permission):
                    return True
            
            # Check for department-level access
            if department_id:
                if self.user_can_access_department(user_id, department_id):
                    dept_permission = f"{resource_type}.{action}.department"
                    if self.user_has_permission(user_id, dept_permission):
                        return True
            
            # Check for unit-level access
            if unit_id:
                if self.user_can_access_unit(user_id, unit_id):
                    unit_permission = f"{resource_type}.{action}.unit"
                    if self.user_has_permission(user_id, unit_permission):
                        return True
            
            # Check for basic resource permission
            basic_permission = f"{resource_type}.{action}"
            if self.user_has_permission(user_id, basic_permission):
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to check resource access for user {user_id}: {e}")
            return False
    
    def require_resource_access(
        self, 
        user_id: uuid.UUID, 
        resource_type: str,
        action: str = "read",
        resource_id: Optional[str] = None,
        owner_id: Optional[uuid.UUID] = None,
        department_id: Optional[uuid.UUID] = None,
        unit_id: Optional[uuid.UUID] = None
    ) -> None:
        """
        Require a user to have access to a specific resource.
        
        Args:
            user_id: User ID
            resource_type: Type of resource
            action: Action to perform
            resource_id: Optional specific resource ID
            owner_id: Optional resource owner ID
            department_id: Optional resource department ID
            unit_id: Optional resource unit ID
            
        Raises:
            ResourceAccessDeniedError: If user cannot access the resource
        """
        if not self.can_access_resource(
            user_id, resource_type, resource_id, action, owner_id, department_id, unit_id
        ):
            logger.warning(f"User {user_id} denied {action} access to {resource_type}")
            raise ResourceAccessDeniedError(resource_type, resource_id)
    
    # Utility Methods
    
    def get_user_organizational_context(self, user_id: uuid.UUID) -> Dict[str, Any]:
        """
        Get user's organizational context (department, unit, roles, permissions).
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary containing organizational context
        """
        try:
            user = self.db.query(User).options(
                joinedload(User.department),
                joinedload(User.unit),
                joinedload(User.roles)
            ).filter(User.id == user_id).first()
            
            if not user:
                return {}
            
            roles = self.get_user_roles(user_id)
            permissions = self.get_user_permissions(user_id)
            
            context = {
                "user_id": str(user.id),
                "username": user.username,
                "is_superuser": user.is_superuser,
                "is_staff": user.is_staff,
                "department": {
                    "id": str(user.department.id) if user.department else None,
                    "name": user.department.name if user.department else None,
                    "code": user.department.code if user.department else None,
                } if user.department else None,
                "unit": {
                    "id": str(user.unit.id) if user.unit else None,
                    "name": user.unit.name if user.unit else None,
                    "code": user.unit.code if user.unit else None,
                } if user.unit else None,
                "roles": [
                    {
                        "id": str(role.id),
                        "name": role.name,
                        "code": role.code,
                        "level": role.level
                    } for role in roles
                ],
                "permissions": list(permissions),
                "accessible_departments": self._get_accessible_departments(user_id),
                "accessible_units": self._get_accessible_units(user_id),
            }
            
            return context
            
        except Exception as e:
            logger.error(f"Failed to get organizational context for user {user_id}: {e}")
            return {}
    
    def _get_accessible_departments(self, user_id: uuid.UUID) -> List[Dict[str, str]]:
        """Get list of departments accessible by the user."""
        try:
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                return []
            
            # Superusers can access all departments
            if user.is_superuser:
                departments = self.db.query(Department).filter(
                    Department.is_active == True
                ).all()
                return [
                    {"id": str(dept.id), "name": dept.name, "code": dept.code}
                    for dept in departments
                ]
            
            accessible_departments = []
            
            # User's own department
            if user.department:
                accessible_departments.append({
                    "id": str(user.department.id),
                    "name": user.department.name,
                    "code": user.department.code
                })
            
            # Departments where user is manager
            managed_departments = self.db.query(Department).filter(
                and_(
                    Department.manager_id == user_id,
                    Department.is_active == True
                )
            ).all()
            
            for dept in managed_departments:
                if not any(d["id"] == str(dept.id) for d in accessible_departments):
                    accessible_departments.append({
                        "id": str(dept.id),
                        "name": dept.name,
                        "code": dept.code
                    })
            
            return accessible_departments
            
        except Exception as e:
            logger.error(f"Failed to get accessible departments for user {user_id}: {e}")
            return []
    
    def _get_accessible_units(self, user_id: uuid.UUID) -> List[Dict[str, str]]:
        """Get list of units accessible by the user."""
        try:
            user = self.db.query(User).filter(User.id == user_id).first()
            if not user:
                return []
            
            # Superusers can access all units
            if user.is_superuser:
                units = self.db.query(Unit).filter(Unit.is_active == True).all()
                return [
                    {"id": str(unit.id), "name": unit.name, "code": unit.code}
                    for unit in units
                ]
            
            accessible_units = []
            
            # User's own unit
            if user.unit:
                accessible_units.append({
                    "id": str(user.unit.id),
                    "name": user.unit.name,
                    "code": user.unit.code
                })
            
            # Units in user's department
            if user.department_id:
                dept_units = self.db.query(Unit).filter(
                    and_(
                        Unit.department_id == user.department_id,
                        Unit.is_active == True
                    )
                ).all()
                
                for unit in dept_units:
                    if not any(u["id"] == str(unit.id) for u in accessible_units):
                        accessible_units.append({
                            "id": str(unit.id),
                            "name": unit.name,
                            "code": unit.code
                        })
            
            # Units where user is manager
            managed_units = self.db.query(Unit).filter(
                and_(
                    Unit.manager_id == user_id,
                    Unit.is_active == True
                )
            ).all()
            
            for unit in managed_units:
                if not any(u["id"] == str(unit.id) for u in accessible_units):
                    accessible_units.append({
                        "id": str(unit.id),
                        "name": unit.name,
                        "code": unit.code
                    })
            
            return accessible_units
            
        except Exception as e:
            logger.error(f"Failed to get accessible units for user {user_id}: {e}")
            return []
    
    # Permission and Role Creation/Management
    
    def create_permission(
        self, 
        code: str, 
        name: str, 
        resource: str, 
        action: str,
        scope: Optional[str] = None,
        description: Optional[str] = None,
        conditions: Optional[Dict] = None
    ) -> Permission:
        """
        Create a new permission.
        
        Args:
            code: Unique permission code
            name: Permission name
            resource: Resource type
            action: Action type
            scope: Optional scope (own, department, all)
            description: Optional description
            conditions: Optional additional conditions
            
        Returns:
            Created permission object
        """
        try:
            permission = Permission(
                code=code,
                name=name,
                resource=resource,
                action=action,
                scope=scope,
                description=description,
                conditions=conditions
            )
            
            self.db.add(permission)
            self.db.commit()
            
            logger.info(f"Permission created: {code}")
            return permission
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to create permission {code}: {e}")
            raise
    
    def create_role(
        self, 
        code: str, 
        name: str,
        description: Optional[str] = None,
        level: int = 0,
        permission_codes: Optional[List[str]] = None
    ) -> Role:
        """
        Create a new role with optional permissions.
        
        Args:
            code: Unique role code
            name: Role name
            description: Optional description
            level: Role level (for hierarchy)
            permission_codes: Optional list of permission codes to assign
            
        Returns:
            Created role object
        """
        try:
            role = Role(
                code=code,
                name=name,
                description=description,
                level=level
            )
            
            self.db.add(role)
            self.db.flush()  # Get the role ID
            
            # Assign permissions if provided
            if permission_codes:
                permissions = self.db.query(Permission).filter(
                    Permission.code.in_(permission_codes)
                ).all()
                
                for permission in permissions:
                    self.db.execute(
                        role_permissions.insert().values(
                            role_id=role.id,
                            permission_id=permission.id,
                            granted_at=datetime.utcnow()
                        )
                    )
            
            self.db.commit()
            
            logger.info(f"Role created: {code} with {len(permission_codes or [])} permissions")
            return role
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to create role {code}: {e}")
            raise
    
    def assign_permission_to_role(
        self, 
        role_id: uuid.UUID, 
        permission_id: uuid.UUID,
        granted_by: uuid.UUID
    ) -> bool:
        """
        Assign a permission to a role.
        
        Args:
            role_id: Role ID
            permission_id: Permission ID
            granted_by: ID of user granting the permission
            
        Returns:
            True if permission assigned successfully
        """
        try:
            # Check if permission is already assigned
            existing = self.db.execute(
                role_permissions.select().where(
                    and_(
                        role_permissions.c.role_id == role_id,
                        role_permissions.c.permission_id == permission_id
                    )
                )
            ).first()
            
            if existing:
                return True
            
            # Insert new permission assignment
            self.db.execute(
                role_permissions.insert().values(
                    role_id=role_id,
                    permission_id=permission_id,
                    granted_by=granted_by,
                    granted_at=datetime.utcnow()
                )
            )
            
            self.db.commit()
            logger.info(f"Permission {permission_id} assigned to role {role_id}")
            return True
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to assign permission {permission_id} to role {role_id}: {e}")
            raise