# app/services/auth/role_service.py
from typing import Dict, List, Optional, Any
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from sqlalchemy.orm import selectinload

from ...models.auth.role import Role, Permission, RolePermission
from ...models.auth.user import User, UserRole
from ...models.company.department import Department, Unit
from ...schemas.auth.role import RoleCreate, RoleUpdate
from ...core.exceptions import ValidationException, ResourceNotFoundException
from ..base import BaseService


class RoleService(BaseService):
    """Enhanced Role Service with Department/Unit Support"""
    
    async def create_department_role(self, role_data: RoleCreate, db: AsyncSession) -> Role:
        """Create a role with department/unit scope"""
        
        # Validate department exists
        if role_data.department:
            dept_exists = await self._validate_department_exists(role_data.department, db)
            if not dept_exists:
                raise ValidationException(f"Department '{role_data.department}' not found")
        
        # Validate unit exists within department
        if role_data.unit:
            if not role_data.department:
                raise ValidationException("Unit specified without department")
            
            unit_exists = await self._validate_unit_exists(
                role_data.department, role_data.unit, db
            )
            if not unit_exists:
                raise ValidationException(
                    f"Unit '{role_data.unit}' not found in department '{role_data.department}'"
                )
        
        # Create role
        role = Role(
            name=role_data.name,
            description=role_data.description,
            user_type=role_data.user_type,
            department=role_data.department,
            unit=role_data.unit,
            access_level=role_data.access_level,
            is_manager=role_data.is_manager
        )
        
        db.add(role)
        await db.commit()
        await db.refresh(role)
        
        return role
    
    async def assign_user_to_role(self, user_id: UUID, role_id: UUID, db: AsyncSession) -> None:
        """Assign user to role with organizational validation"""
        
        # Check if role exists
        role = await self.get_role_by_id(role_id, db)
        if not role:
            raise ResourceNotFoundException("Role not found", resource_type="Role")
        
        # Check if user exists
        user = await self._get_user_by_id(user_id, db)
        if not user:
            raise ResourceNotFoundException("User not found", resource_type="User")
        
        # Validate organizational consistency
        await self._validate_user_role_assignment(user, role, db)
        
        # Create user-role assignment
        user_role = UserRole(user_id=user_id, role_id=role_id)
        db.add(user_role)
        await db.commit()
    
    async def get_department_roles(self, department: str, db: AsyncSession) -> List[Role]:
        """Get all roles for a specific department"""
        
        query = select(Role).where(
            and_(
                Role.department == department,
                Role.archived_at.is_(None)
            )
        ).options(selectinload(Role.permissions))
        
        result = await db.execute(query)
        return result.scalars().all()
    
    async def get_user_department_access(self, user_id: UUID, db: AsyncSession) -> Dict[str, Any]:
        """Get user's department and unit access levels"""
        
        # Get user's roles with department/unit info
        query = select(User).where(User.id == user_id).options(
            selectinload(User.roles).selectinload(Role.permissions)
        )
        
        result = await db.execute(query)
        user = result.scalar_one_or_none()
        
        if not user:
            raise ResourceNotFoundException("User not found", resource_type="User")
        
        # Build access map
        access_map = {
            "departments": {},
            "units": {},
            "is_global_manager": False,
            "company_wide_access": []
        }
        
        for role in user.roles:
            # Company-wide roles (no department specified)
            if not role.department:
                access_map["company_wide_access"].extend([p.name for p in role.permissions])
                if role.is_manager:
                    access_map["is_global_manager"] = True
            
            # Department-specific roles
            elif role.department:
                dept_key = role.department
                if dept_key not in access_map["departments"]:
                    access_map["departments"][dept_key] = {
                        "permissions": [],
                        "is_manager": False,
                        "access_level": "standard",
                        "units": {}
                    }
                
                dept_access = access_map["departments"][dept_key]
                dept_access["permissions"].extend([p.name for p in role.permissions])
                
                if role.is_manager:
                    dept_access["is_manager"] = True
                
                if role.access_level:
                    dept_access["access_level"] = role.access_level
                
                # Unit-specific access
                if role.unit:
                    unit_key = role.unit
                    if unit_key not in dept_access["units"]:
                        dept_access["units"][unit_key] = {
                            "permissions": [],
                            "is_manager": False,
                            "access_level": "standard"
                        }
                    
                    unit_access = dept_access["units"][unit_key]
                    unit_access["permissions"].extend([p.name for p in role.permissions])
                    
                    if role.is_manager:
                        unit_access["is_manager"] = True
                    
                    if role.access_level:
                        unit_access["access_level"] = role.access_level
        
        return access_map
    
    async def check_department_permission(
        self,
        user_id: UUID,
        target_department: str,
        action: str,
        target_unit: Optional[str] = None,
        db: AsyncSession = None
    ) -> bool:
        """Check if user can perform action in specific department/unit"""
        
        access_map = await self.get_user_department_access(user_id, db)
        
        # Global managers have access to everything
        if access_map["is_global_manager"]:
            return True
        
        # Check company-wide permissions
        if action in access_map["company_wide_access"]:
            return True
        
        # Check department-specific access
        if target_department in access_map["departments"]:
            dept_access = access_map["departments"][target_department]
            
            # Department manager has full access to department
            if dept_access["is_manager"]:
                return True
            
            # Check specific unit access if requested
            if target_unit:
                if target_unit in dept_access["units"]:
                    unit_access = dept_access["units"][target_unit]
                    
                    # Unit manager or has specific permission
                    return (
                        unit_access["is_manager"] or 
                        action in unit_access["permissions"]
                    )
                
                # No specific unit access, check if department permission allows
                return action in dept_access["permissions"]
            
            # Department-level permission check
            return action in dept_access["permissions"]
        
        return False
    
    async def get_hierarchical_permissions(self, user_id: UUID, db: AsyncSession) -> Dict[str, List[str]]:
        """Get permissions with department/unit hierarchy"""
        
        access_map = await self.get_user_department_access(user_id, db)
        
        hierarchical_perms = {
            "global": access_map["company_wide_access"],
            "departments": {}
        }
        
        for dept, dept_data in access_map["departments"].items():
            hierarchical_perms["departments"][dept] = {
                "permissions": dept_data["permissions"],
                "is_manager": dept_data["is_manager"],
                "units": {}
            }
            
            for unit, unit_data in dept_data["units"].items():
                hierarchical_perms["departments"][dept]["units"][unit] = {
                    "permissions": unit_data["permissions"],
                    "is_manager": unit_data["is_manager"]
                }
        
        return hierarchical_perms
    
    async def validate_role_permissions(self, role: Role, db: AsyncSession) -> bool:
        """Validate that role permissions are appropriate for its scope"""
        
        # Load role permissions
        await db.refresh(role, ['permissions'])
        
        permission_names = [p.name for p in role.permissions]
        
        # Check each permission has appropriate scope
        for perm_name in permission_names:
            permission = await self._get_permission_by_name(perm_name, db)
            if not permission:
                continue
            
            # Validate scope alignment
            if not self._validate_permission_scope(role, permission):
                return False
        
        return True
    
    # Helper methods
    async def _validate_department_exists(self, department_code: str, db: AsyncSession) -> bool:
        """Check if department exists"""
        query = select(Department).where(
            and_(
                Department.code == department_code,
                Department.is_active == True
            )
        )
        result = await db.execute(query)
        return result.scalar_one_or_none() is not None
    
    async def _validate_unit_exists(self, department_code: str, unit_code: str, db: AsyncSession) -> bool:
        """Check if unit exists within department"""
        query = select(Unit).join(Department).where(
            and_(
                Department.code == department_code,
                Unit.code == unit_code,
                Unit.is_active == True,
                Department.is_active == True
            )
        )
        result = await db.execute(query)
        return result.scalar_one_or_none() is not None
    
    async def _get_user_by_id(self, user_id: UUID, db: AsyncSession) -> Optional[User]:
        """Get user by ID"""
        query = select(User).where(User.id == user_id)
        result = await db.execute(query)
        return result.scalar_one_or_none()
    
    async def _get_permission_by_name(self, permission_name: str, db: AsyncSession) -> Optional[Permission]:
        """Get permission by name"""
        query = select(Permission).where(Permission.name == permission_name)
        result = await db.execute(query)
        return result.scalar_one_or_none()
    
    async def _validate_user_role_assignment(self, user: User, role: Role, db: AsyncSession) -> None:
        """Validate that user can be assigned to this role"""
        
        # If role has department/unit scope, validate user's organizational context
        if role.department:
            # Check if user belongs to the same company (if company context exists)
            # Additional validation logic can be added here
            pass
    
    async def _validate_permission_scope(self, role: Role, permission: Permission) -> bool:
        """Validate that permission scope matches role scope"""
        
        # If role is department-scoped, permission should allow department scope
        if role.department and permission.scope_department:
            return permission.scope_department == role.department or permission.scope_department == "*"
        
        # If role is unit-scoped, permission should allow unit scope
        if role.unit and permission.scope_unit:
            return (
                permission.scope_unit == role.unit or 
                permission.scope_unit == "*"
            ) and (
                permission.scope_department == role.department or 
                permission.scope_department == "*"
            )
        
        return True
    
    async def get_role_by_id(self, role_id: UUID, db: AsyncSession) -> Optional[Role]:
        """Get role by ID with permissions"""
        query = select(Role).where(Role.id == role_id).options(
            selectinload(Role.permissions)
        )
        result = await db.execute(query)
        return result.scalar_one_or_none()