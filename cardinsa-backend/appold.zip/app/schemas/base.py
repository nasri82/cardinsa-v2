"""
Base schemas with common fields and configurations.
"""

from datetime import datetime
from typing import Optional, Any, Dict, Union
from uuid import UUID
from enum import Enum

from pydantic import BaseModel, Field, ConfigDict


class SortOrderEnum(str, Enum):
    """Sort order enumeration."""
    ASC = "asc"
    DESC = "desc"


class BaseSchema(BaseModel):
    """Base schema with common configuration for all schemas."""
    model_config = ConfigDict(
        from_attributes=True,
        validate_assignment=True,
        arbitrary_types_allowed=True,
        str_strip_whitespace=True,
        use_enum_values=True
    )


class BaseCreateSchema(BaseSchema):
    """Base schema for create operations."""
    pass


class BaseUpdateSchema(BaseSchema):
    """Base schema for update operations."""
    pass


class BaseResponseSchema(BaseSchema):
    """Base response schema."""
    id: UUID = Field(..., description="Record ID")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Update timestamp")


class TimestampSchema(BaseSchema):
    """Schema with timestamp fields."""
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Update timestamp")


class AuditSchema(TimestampSchema):
    """Schema with audit fields."""
    created_by: Optional[UUID] = Field(None, description="Creator user ID")
    updated_by: Optional[UUID] = Field(None, description="Last updater user ID")
    archived_at: Optional[datetime] = Field(None, description="Soft delete timestamp")


class SuccessResponseSchema(BaseSchema):
    """Success response schema."""
    success: bool = Field(default=True, description="Response success status")
    message: str = Field(..., description="Response message")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Response timestamp")


class ErrorResponseSchema(BaseSchema):
    """Error response schema."""
    success: bool = Field(default=False, description="Response success status")
    error: bool = Field(default=True, description="Error flag")
    message: str = Field(..., description="Error message")
    code: Optional[str] = Field(None, description="Error code")
    details: Optional[Any] = Field(None, description="Error details")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Error timestamp")


class PaginationParams(BaseSchema):
    """Pagination parameters for requests."""
    page: int = Field(default=1, ge=1, description="Page number")
    per_page: int = Field(default=20, ge=1, le=100, description="Items per page")
    search: Optional[str] = Field(None, description="Search query")
    sort_by: Optional[str] = Field(None, description="Sort field")
    sort_order: SortOrderEnum = Field(default=SortOrderEnum.ASC, description="Sort order")


class QueryParams(BaseSchema):
    """Query parameters for requests."""
    search: Optional[str] = Field(None, description="Search query")
    limit: Optional[int] = Field(None, ge=1, le=1000, description="Result limit")
    offset: Optional[int] = Field(None, ge=0, description="Result offset")
    fields: Optional[list] = Field(None, description="Fields to include")


class SortParams(BaseSchema):
    """Sort parameters for requests."""
    sort_by: Optional[str] = Field(None, description="Sort field")
    sort_order: SortOrderEnum = Field(default=SortOrderEnum.ASC, description="Sort order")


class FilterParams(BaseSchema):
    """Filter parameters for requests."""
    search: Optional[str] = Field(None, description="Search query")
    status: Optional[str] = Field(None, description="Status filter")
    is_active: Optional[bool] = Field(None, description="Active status filter")
    created_after: Optional[datetime] = Field(None, description="Created after date")
    created_before: Optional[datetime] = Field(None, description="Created before date")
    tags: Optional[list] = Field(None, description="Tags filter")


class SearchParams(BaseSchema):
    """Search parameters for requests."""
    query: Optional[str] = Field(None, description="Search query")
    fields: Optional[list] = Field(None, description="Fields to search in")
    exact_match: bool = Field(default=False, description="Exact match flag")
    case_sensitive: bool = Field(default=False, description="Case sensitive search")


class PaginationInfo(BaseSchema):
    """Pagination information for responses."""
    page: int = Field(..., ge=1, description="Current page number")
    per_page: int = Field(..., ge=1, le=100, description="Items per page")
    total: int = Field(..., ge=0, description="Total items count")
    pages: int = Field(..., ge=0, description="Total pages count")
    has_next: bool = Field(..., description="Has next page")
    has_prev: bool = Field(..., description="Has previous page")


class PaginationSchema(BaseSchema):
    """Pagination information schema (legacy)."""
    page: int = Field(default=1, ge=1, description="Current page number")
    per_page: int = Field(default=20, ge=1, le=100, description="Items per page")
    total: int = Field(..., ge=0, description="Total items count")
    pages: int = Field(..., ge=0, description="Total pages count")
    has_next: bool = Field(..., description="Has next page")
    has_prev: bool = Field(..., description="Has previous page")


class MetadataSchema(BaseSchema):
    """Metadata schema for responses."""
    total_count: int = Field(..., description="Total count")
    filtered_count: int = Field(..., description="Filtered count")
    page_count: int = Field(..., description="Page count")
    current_page: int = Field(..., description="Current page")
    has_more: bool = Field(..., description="Has more pages")


class PaginatedResponse(BaseSchema):
    """Generic paginated response schema."""
    items: list = Field(..., description="Response items")
    pagination: PaginationInfo = Field(..., description="Pagination information")
    metadata: Optional[MetadataSchema] = Field(None, description="Additional metadata")


class PaginatedResponseSchema(BaseSchema):
    """Paginated response schema (legacy)."""
    items: list = Field(..., description="Response items")
    pagination: PaginationSchema = Field(..., description="Pagination info")


class BulkOperationRequest(BaseSchema):
    """Bulk operation request schema."""
    ids: list[UUID] = Field(..., description="List of record IDs")
    action: str = Field(..., description="Action to perform")
    parameters: Optional[Dict[str, Any]] = Field(None, description="Action parameters")


class BulkOperationResponse(BaseSchema):
    """Bulk operation response schema."""
    success_count: int = Field(..., description="Number of successful operations")
    error_count: int = Field(..., description="Number of failed operations")
    total_count: int = Field(..., description="Total number of operations")
    errors: Optional[list] = Field(None, description="List of errors")
    success: bool = Field(..., description="Overall operation success")


class StatusResponse(BaseSchema):
    """Status response schema."""
    status: str = Field(..., description="Operation status")
    message: Optional[str] = Field(None, description="Status message")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Status timestamp")


class ValidationErrorSchema(BaseSchema):
    """Validation error schema."""
    field: str = Field(..., description="Field name")
    message: str = Field(..., description="Error message")
    value: Optional[Any] = Field(None, description="Invalid value")


class DetailedErrorResponse(BaseSchema):
    """Detailed error response schema."""
    success: bool = Field(default=False, description="Response success status")
    error: bool = Field(default=True, description="Error flag")
    message: str = Field(..., description="Error message")
    code: Optional[str] = Field(None, description="Error code")
    details: Optional[Any] = Field(None, description="Error details")
    validation_errors: Optional[list[ValidationErrorSchema]] = Field(None, description="Validation errors")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Error timestamp")


class HealthCheckResponse(BaseSchema):
    """Health check response schema."""
    status: str = Field(..., description="Health status")
    version: str = Field(..., description="Application version")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Check timestamp")
    services: Optional[Dict[str, str]] = Field(None, description="Service statuses")


class ConfigurationSchema(BaseSchema):
    """Configuration schema."""
    key: str = Field(..., description="Configuration key")
    value: Union[str, int, float, bool, dict, list] = Field(..., description="Configuration value")
    description: Optional[str] = Field(None, description="Configuration description")
    is_sensitive: bool = Field(default=False, description="Sensitive configuration flag")


class FileUploadResponse(BaseSchema):
    """File upload response schema."""
    filename: str = Field(..., description="Uploaded filename")
    file_size: int = Field(..., description="File size in bytes")
    file_path: str = Field(..., description="File storage path")
    upload_timestamp: datetime = Field(default_factory=datetime.utcnow, description="Upload timestamp")
    file_id: Optional[UUID] = Field(None, description="File ID")


class ExportRequest(BaseSchema):
    """Export request schema."""
    format: str = Field(..., description="Export format (csv, xlsx, json, pdf)")
    filters: Optional[Dict[str, Any]] = Field(None, description="Export filters")
    columns: Optional[list] = Field(None, description="Columns to export")
    include_headers: bool = Field(default=True, description="Include headers flag")


class ImportRequest(BaseSchema):
    """Import request schema."""
    file_path: str = Field(..., description="File path to import")
    format: str = Field(..., description="Import format")
    mapping: Optional[Dict[str, str]] = Field(None, description="Column mapping")
    validate_only: bool = Field(default=False, description="Validation only flag")
    skip_duplicates: bool = Field(default=True, description="Skip duplicates flag")


class ImportResponse(BaseSchema):
    """Import response schema."""
    total_records: int = Field(..., description="Total records processed")
    successful_imports: int = Field(..., description="Successful imports")
    failed_imports: int = Field(..., description="Failed imports")
    errors: Optional[list] = Field(None, description="Import errors")
    warnings: Optional[list] = Field(None, description="Import warnings")
    import_id: UUID = Field(..., description="Import operation ID")


class AuditLogSchema(BaseSchema):
    """Audit log schema."""
    action: str = Field(..., description="Action performed")
    resource_type: str = Field(..., description="Resource type")
    resource_id: Optional[UUID] = Field(None, description="Resource ID")
    user_id: Optional[UUID] = Field(None, description="User ID")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Action timestamp")
    details: Optional[Dict[str, Any]] = Field(None, description="Action details")
    ip_address: Optional[str] = Field(None, description="IP address")
    user_agent: Optional[str] = Field(None, description="User agent")


class NotificationSchema(BaseSchema):
    """Notification schema."""
    title: str = Field(..., description="Notification title")
    message: str = Field(..., description="Notification message")
    type: str = Field(..., description="Notification type")
    recipient_id: UUID = Field(..., description="Recipient user ID")
    is_read: bool = Field(default=False, description="Read status")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation timestamp")
    expires_at: Optional[datetime] = Field(None, description="Expiration timestamp")


class PermissionSchema(BaseSchema):
    """Permission schema."""
    resource: str = Field(..., description="Resource name")
    action: str = Field(..., description="Action name")
    granted: bool = Field(..., description="Permission granted flag")
    conditions: Optional[Dict[str, Any]] = Field(None, description="Permission conditions")


class CacheSchema(BaseSchema):
    """Cache schema."""
    key: str = Field(..., description="Cache key")
    value: Any = Field(..., description="Cache value")
    ttl: Optional[int] = Field(None, description="Time to live in seconds")
    tags: Optional[list] = Field(None, description="Cache tags")


class RateLimitSchema(BaseSchema):
    """Rate limit schema."""
    limit: int = Field(..., description="Rate limit")
    remaining: int = Field(..., description="Remaining requests")
    reset_time: datetime = Field(..., description="Reset timestamp")
    window: str = Field(..., description="Time window")