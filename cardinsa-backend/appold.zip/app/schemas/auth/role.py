# FILE PATH: app/schemas/auth/role.py

"""
Enhanced Role Management Schemas
CARDINSA Insurance Platform

World-class Pydantic schemas for Role-Based Access Control (RBAC).
Comprehensive validation, analytics, and enterprise features while maintaining backward compatibility.
"""

from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from uuid import UUID
import re

from pydantic import BaseModel, Field, validator
from app.schemas.base import BaseSchema, TimestampSchema, AuditSchema, PaginatedResponseSchema


# ===== PERMISSION SCHEMAS =====

class PermissionBase(BaseSchema):
    """Enhanced base permission schema with comprehensive validation."""
    name: str = Field(
        ..., 
        min_length=3, 
        max_length=100,
        description="Permission name (format: resource:action)"
    )
    resource: str = Field(
        ..., 
        min_length=2, 
        max_length=50,
        description="Resource type (e.g., user, policy, claim)"
    )
    action: str = Field(
        ..., 
        min_length=2, 
        max_length=50,
        description="Action type (e.g., read, write, admin)"
    )
    description: Optional[str] = Field(
        None, 
        max_length=500,
        description="Human-readable permission description"
    )
    scope: Optional[str] = Field(
        "global", 
        description="Permission scope (global, department, unit, self)"
    )
    conditions: Optional[Dict[str, Any]] = Field(
        None,
        description="Additional conditions for permission validation"
    )
    
    @validator('name')
    def validate_permission_name(cls, v):
        """Validate permission name format."""
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]*:[a-zA-Z][a-zA-Z0-9_]*$', v):
            raise ValueError('Permission name must follow format: resource:action')
        return v.lower()
    
    @validator('scope')
    def validate_scope(cls, v):
        """Validate permission scope."""
        valid_scopes = ['global', 'department', 'unit', 'self', 'custom']
        if v and v not in valid_scopes:
            raise ValueError(f'Scope must be one of: {", ".join(valid_scopes)}')
        return v


class PermissionCreate(PermissionBase):
    """Permission creation schema with enhanced validation."""
    is_system_permission: bool = Field(
        False, 
        description="System permission flag (cannot be deleted)"
    )
    risk_level: str = Field(
        "low", 
        description="Security risk level: low, medium, high, critical"
    )
    
    @validator('risk_level')
    def validate_risk_level(cls, v):
        """Validate risk level."""
        valid_levels = ['low', 'medium', 'high', 'critical']
        if v not in valid_levels:
            raise ValueError(f'Risk level must be one of: {", ".join(valid_levels)}')
        return v


class PermissionUpdate(BaseSchema):
    """Permission update schema for partial updates."""
    description: Optional[str] = Field(None, max_length=500)
    scope: Optional[str] = Field(None)
    conditions: Optional[Dict[str, Any]] = Field(None)
    is_active: Optional[bool] = Field(None, description="Active status")


class PermissionInfo(PermissionBase, AuditSchema):
    """Comprehensive permission information schema."""
    id: UUID = Field(..., description="Permission unique identifier")
    is_system_permission: bool = Field(False, description="System permission flag")
    is_active: bool = Field(True, description="Permission active status")
    risk_level: str = Field("low", description="Security risk level")
    usage_count: int = Field(0, description="Number of roles using this permission")
    last_used: Optional[datetime] = Field(None, description="Last usage timestamp")


class PermissionAnalytics(BaseSchema):
    """Permission usage analytics schema."""
    permission_id: UUID = Field(..., description="Permission identifier")
    permission_name: str = Field(..., description="Permission name")
    total_roles: int = Field(..., description="Total roles with this permission")
    total_users: int = Field(..., description="Total users with this permission")
    usage_frequency: int = Field(..., description="Usage frequency score")
    risk_assessment: str = Field(..., description="Security risk assessment")
    recommendations: List[str] = Field(default_factory=list, description="Optimization recommendations")


# ===== ROLE SCHEMAS =====

class RoleBase(BaseSchema):
    """Enhanced base role schema with comprehensive validation."""
    name: str = Field(
        ..., 
        min_length=2, 
        max_length=100,
        description="Role display name"
    )
    description: Optional[str] = Field(
        None, 
        max_length=500,
        description="Role description and purpose"
    )
    role_type: str = Field(
        "business", 
        description="Role type: system, business, operational, support, custom"
    )
    level: int = Field(
        5, 
        ge=0, 
        le=10,
        description="Role hierarchy level (0-10, higher = more privileges)"
    )
    is_active: bool = Field(True, description="Role active status")
    
    @validator('name')
    def validate_role_name(cls, v):
        """Validate role name format."""
        # Remove extra whitespace and validate
        cleaned_name = re.sub(r'\s+', ' ', v.strip())
        if not re.match(r'^[a-zA-Z0-9\s\-_\.]+$', cleaned_name):
            raise ValueError('Role name can only contain letters, numbers, spaces, hyphens, underscores, and dots')
        return cleaned_name
    
    @validator('role_type')
    def validate_role_type(cls, v):
        """Validate role type."""
        valid_types = ['system', 'business', 'operational', 'support', 'custom']
        if v not in valid_types:
            raise ValueError(f'Role type must be one of: {", ".join(valid_types)}')
        return v


class RoleCreate(RoleBase):
    """Enhanced role creation schema with comprehensive options."""
    permission_ids: List[UUID] = Field(
        default_factory=list, 
        description="Permission IDs to assign to this role"
    )
    permission_names: List[str] = Field(
        default_factory=list,
        description="Permission names to assign (alternative to IDs)"
    )
    parent_role_id: Optional[UUID] = Field(
        None, 
        description="Parent role ID for hierarchy"
    )
    settings: Optional[Dict[str, Any]] = Field(
        None, 
        description="Role-specific settings and configurations"
    )
    auto_assign_conditions: Optional[Dict[str, Any]] = Field(
        None,
        description="Conditions for automatic role assignment"
    )
    expiry_policy: Optional[Dict[str, Any]] = Field(
        None,
        description="Role expiry and renewal policies"
    )
    
    @validator('permission_names', each_item=True)
    def validate_permission_names(cls, v):
        """Validate permission name format."""
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]*:[a-zA-Z][a-zA-Z0-9_]*$', v):
            raise ValueError('Permission name must follow format: resource:action')
        return v.lower()


class RoleUpdate(BaseSchema):
    """Enhanced role update schema for partial updates."""
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    level: Optional[int] = Field(None, ge=0, le=10)
    is_active: Optional[bool] = Field(None)
    parent_role_id: Optional[UUID] = Field(None)
    settings: Optional[Dict[str, Any]] = Field(None)
    
    @validator('name')
    def validate_name_update(cls, v):
        """Validate name update."""
        if v is not None:
            cleaned_name = re.sub(r'\s+', ' ', v.strip())
            if not re.match(r'^[a-zA-Z0-9\s\-_\.]+$', cleaned_name):
                raise ValueError('Role name can only contain letters, numbers, spaces, hyphens, underscores, and dots')
            return cleaned_name
        return v


class RoleInfo(RoleBase, AuditSchema):
    """Comprehensive role information schema."""
    id: UUID = Field(..., description="Role unique identifier")
    code: str = Field(..., description="System-generated role code")
    is_system_role: bool = Field(False, description="System role flag (protected)")
    parent_role_id: Optional[UUID] = Field(None, description="Parent role ID")
    settings: Optional[Dict[str, Any]] = Field(None, description="Role settings")
    users_count: int = Field(0, description="Number of users with this role")
    active_users_count: int = Field(0, description="Number of active users")
    child_roles_count: int = Field(0, description="Number of child roles")


class RoleDetailedInfo(RoleInfo):
    """Detailed role information with relationships and analytics."""
    permissions: List[PermissionInfo] = Field(
        default_factory=list, 
        description="Role permissions"
    )
    parent_role: Optional[Dict[str, Any]] = Field(
        None, 
        description="Parent role information"
    )
    child_roles: List[Dict[str, Any]] = Field(
        default_factory=list, 
        description="Child roles information"
    )
    users: Optional[List[Dict[str, Any]]] = Field(
        None, 
        description="Users with this role (if requested)"
    )
    analytics: Optional[Dict[str, Any]] = Field(
        None, 
        description="Usage analytics and insights"
    )
    audit_log: Optional[List[Dict[str, Any]]] = Field(
        None, 
        description="Recent audit log entries"
    )


class RoleHierarchy(BaseSchema):
    """Role hierarchy tree schema."""
    current_role: Dict[str, Any] = Field(..., description="Current role information")
    ancestors: List[Dict[str, Any]] = Field(
        default_factory=list, 
        description="Parent roles up the hierarchy"
    )
    descendants: List[Dict[str, Any]] = Field(
        default_factory=list, 
        description="Child roles down the hierarchy"
    )
    hierarchy_stats: Dict[str, Any] = Field(
        ..., 
        description="Hierarchy statistics and metrics"
    )


# ===== ROLE OPERATION SCHEMAS =====

class RolePermissionAssignment(BaseSchema):
    """Role-permission assignment schema."""
    role_id: UUID = Field(..., description="Role identifier")
    permissions: List[str] = Field(
        ..., 
        min_items=1, 
        description="Permission names to assign"
    )
    mode: str = Field(
        "add", 
        description="Operation mode: add, remove, replace"
    )
    
    @validator('mode')
    def validate_mode(cls, v):
        """Validate operation mode."""
        valid_modes = ['add', 'remove', 'replace']
        if v not in valid_modes:
            raise ValueError(f'Mode must be one of: {", ".join(valid_modes)}')
        return v
    
    @validator('permissions', each_item=True)
    def validate_permissions(cls, v):
        """Validate permission format."""
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]*:[a-zA-Z][a-zA-Z0-9_]*$', v):
            raise ValueError('Permission must follow format: resource:action')
        return v.lower()


class UserRoleAssignment(BaseSchema):
    """User-role assignment schema."""
    user_id: UUID = Field(..., description="User identifier")
    role_id: UUID = Field(..., description="Role identifier")
    expires_at: Optional[datetime] = Field(
        None, 
        description="Assignment expiration date"
    )
    assigned_by_reason: Optional[str] = Field(
        None, 
        max_length=200,
        description="Reason for assignment"
    )


class BulkUserRoleAssignment(BaseSchema):
    """Bulk user-role assignment schema."""
    assignments: List[UserRoleAssignment] = Field(
        ..., 
        min_items=1, 
        max_items=100,
        description="List of user-role assignments"
    )
    operation: str = Field(
        "assign", 
        description="Operation type: assign, unassign"
    )
    batch_reason: Optional[str] = Field(
        None, 
        max_length=200,
        description="Reason for bulk operation"
    )
    
    @validator('operation')
    def validate_operation(cls, v):
        """Validate operation type."""
        if v not in ['assign', 'unassign']:
            raise ValueError('Operation must be either "assign" or "unassign"')
        return v


class RoleCloneRequest(BaseSchema):
    """Role cloning request schema."""
    name: str = Field(
        ..., 
        min_length=2, 
        max_length=100,
        description="New role name"
    )
    modifications: Optional[Dict[str, Any]] = Field(
        None,
        description="Modifications to apply to cloned role"
    )
    include_users: bool = Field(
        False, 
        description="Whether to copy user assignments"
    )
    clone_permissions: bool = Field(
        True, 
        description="Whether to copy permissions"
    )
    clone_hierarchy: bool = Field(
        False, 
        description="Whether to maintain parent-child relationships"
    )


# ===== RESPONSE SCHEMAS =====

class RoleResponse(BaseSchema):
    """Single role response schema."""
    message: str = Field(..., description="Operation result message")
    role: RoleDetailedInfo = Field(..., description="Role information")
    meta: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")


class RoleListResponse(PaginatedResponseSchema):
    """Paginated role list response with enhanced metadata."""
    items: List[RoleInfo] = Field(..., description="List of roles")
    meta: Dict[str, Any] = Field(..., description="List metadata and statistics")
    features: Dict[str, bool] = Field(..., description="Feature flags for response")


class BulkOperationResponse(BaseSchema):
    """Bulk operation response schema."""
    message: str = Field(..., description="Operation summary message")
    total_processed: int = Field(..., description="Total items processed")
    successful_count: int = Field(..., description="Successful operations")
    failed_count: int = Field(..., description="Failed operations")
    skipped_count: int = Field(0, description="Skipped operations")
    results: Dict[str, List[Dict[str, Any]]] = Field(
        ..., 
        description="Detailed results by category"
    )
    validation_only: bool = Field(False, description="Whether this was validation only")
    audit: Dict[str, Any] = Field(..., description="Audit information")


class PermissionConflictInfo(BaseSchema):
    """Permission conflict information schema."""
    conflict_type: str = Field(..., description="Type of conflict detected")
    conflicting_permissions: List[str] = Field(..., description="Conflicting permission names")
    severity: str = Field(..., description="Conflict severity: low, medium, high")
    recommendation: str = Field(..., description="Recommended resolution")
    auto_resolvable: bool = Field(..., description="Whether conflict can be auto-resolved")


class RoleValidationResponse(BaseSchema):
    """Role validation response schema."""
    valid: bool = Field(..., description="Overall validation result")
    message: str = Field(..., description="Validation summary message")
    validation_errors: List[str] = Field(
        default_factory=list, 
        description="List of validation errors"
    )
    warnings: List[str] = Field(
        default_factory=list, 
        description="List of validation warnings"
    )
    conflicts: List[PermissionConflictInfo] = Field(
        default_factory=list, 
        description="Permission conflicts detected"
    )
    impact_analysis: Dict[str, Any] = Field(
        ..., 
        description="Impact analysis of proposed changes"
    )
    recommendations: List[str] = Field(
        default_factory=list, 
        description="Optimization recommendations"
    )


# ===== ANALYTICS SCHEMAS =====

class RoleUsageAnalytics(BaseSchema):
    """Role usage analytics schema."""
    assignment_stats: Dict[str, Any] = Field(..., description="Assignment statistics")
    permission_usage: Dict[str, Any] = Field(..., description="Permission usage patterns")
    activity_trends: Dict[str, Any] = Field(..., description="Activity trends over time")
    user_distribution: Dict[str, Any] = Field(..., description="User distribution analysis")


class RoleAnalyticsSummary(BaseSchema):
    """Comprehensive role analytics summary."""
    period: str = Field(..., description="Analytics period")
    generated_at: datetime = Field(..., description="Report generation timestamp")
    overview: Dict[str, Any] = Field(..., description="High-level overview statistics")
    user_distribution: Dict[str, Any] = Field(..., description="User role distribution")
    permission_analysis: Dict[str, Any] = Field(..., description="Permission usage analysis")
    activity_trends: Optional[Dict[str, Any]] = Field(None, description="Activity trends")
    recommendations: List[str] = Field(..., description="System recommendations")


class RoleImpactAnalysis(BaseSchema):
    """Role change impact analysis schema."""
    users_affected: int = Field(..., description="Number of users affected")
    child_roles_affected: int = Field(0, description="Number of child roles affected")
    permission_changes: List[str] = Field(
        default_factory=list, 
        description="List of permission changes"
    )
    security_impact: str = Field(..., description="Security impact level")
    estimated_downtime: Optional[str] = Field(None, description="Estimated system impact")
    requires_notification: bool = Field(..., description="Whether users need notification")
    rollback_plan: Optional[Dict[str, Any]] = Field(None, description="Rollback strategy")


class RoleComparisonResult(BaseSchema):
    """Role comparison result schema."""
    role_a: Dict[str, Any] = Field(..., description="First role information")
    role_b: Dict[str, Any] = Field(..., description="Second role information")
    differences: Dict[str, Any] = Field(..., description="Detailed differences")
    similarities: Dict[str, Any] = Field(..., description="Common elements")
    comparison_score: float = Field(..., description="Similarity score (0-1)")
    merge_recommendations: List[str] = Field(
        default_factory=list,
        description="Recommendations for role consolidation"
    )


# ===== SEARCH AND FILTER SCHEMAS =====

class RoleSearchRequest(BaseSchema):
    """Advanced role search request schema."""
    query: Optional[str] = Field(None, description="Search query")
    filters: Optional[Dict[str, Any]] = Field(None, description="Search filters")
    sort_options: Optional[Dict[str, str]] = Field(None, description="Sorting options")
    include_inactive: bool = Field(False, description="Include inactive roles")
    permission_filter: Optional[List[str]] = Field(None, description="Filter by permissions")
    user_count_range: Optional[Dict[str, int]] = Field(None, description="User count range")
    
    @validator('permission_filter', each_item=True)
    def validate_permission_filter(cls, v):
        """Validate permission filter format."""
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]*:[a-zA-Z][a-zA-Z0-9_*]*$', v):
            raise ValueError('Permission filter must follow format: resource:action (wildcards allowed)')
        return v.lower()


class PermissionSearchRequest(BaseSchema):
    """Permission search request schema."""
    query: Optional[str] = Field(None, description="Search query")
    resource_filter: Optional[str] = Field(None, description="Filter by resource type")
    action_filter: Optional[str] = Field(None, description="Filter by action type")
    scope_filter: Optional[str] = Field(None, description="Filter by scope")
    risk_level_filter: Optional[str] = Field(None, description="Filter by risk level")
    unused_only: bool = Field(False, description="Show only unused permissions")


# ===== AUDIT AND COMPLIANCE SCHEMAS =====

class RoleAuditEntry(TimestampSchema):
    """Role audit log entry schema."""
    audit_id: str = Field(..., description="Unique audit identifier")
    role_id: UUID = Field(..., description="Role identifier")
    role_name: str = Field(..., description="Role name at time of action")
    action: str = Field(..., description="Action performed")
    user_id: UUID = Field(..., description="User who performed action")
    username: str = Field(..., description="Username who performed action")
    changes: Optional[List[str]] = Field(None, description="List of changes made")
    before_state: Optional[Dict[str, Any]] = Field(None, description="State before change")
    after_state: Optional[Dict[str, Any]] = Field(None, description="State after change")
    ip_address: str = Field(..., description="IP address of user")
    user_agent: Optional[str] = Field(None, description="User agent string")


class RoleComplianceReport(BaseSchema):
    """Role compliance reporting schema."""
    report_id: str = Field(..., description="Report identifier")
    generated_at: datetime = Field(..., description="Report generation time")
    period: str = Field(..., description="Reporting period")
    role_statistics: Dict[str, Any] = Field(..., description="Role usage statistics")
    permission_analysis: Dict[str, Any] = Field(..., description="Permission analysis")
    compliance_issues: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="Identified compliance issues"
    )
    recommendations: List[str] = Field(
        default_factory=list,
        description="Compliance recommendations"
    )
    risk_assessment: Dict[str, Any] = Field(..., description="Overall risk assessment")


# ===== EXPORT AND IMPORT SCHEMAS =====

class RoleExportRequest(BaseSchema):
    """Role export request schema."""
    role_ids: Optional[List[UUID]] = Field(None, description="Specific roles to export")
    include_permissions: bool = Field(True, description="Include permission details")
    include_users: bool = Field(False, description="Include user assignments")
    include_hierarchy: bool = Field(True, description="Include hierarchy relationships")
    format: str = Field("json", description="Export format: json, csv, xlsx")
    
    @validator('format')
    def validate_format(cls, v):
        """Validate export format."""
        valid_formats = ['json', 'csv', 'xlsx']
        if v not in valid_formats:
            raise ValueError(f'Format must be one of: {", ".join(valid_formats)}')
        return v


class RoleImportRequest(BaseSchema):
    """Role import request schema."""
    data: Union[List[Dict[str, Any]], str] = Field(..., description="Import data")
    format: str = Field("json", description="Data format")
    validation_mode: str = Field("strict", description="Validation mode: strict, lenient")
    conflict_resolution: str = Field("skip", description="Conflict resolution: skip, update, merge")
    dry_run: bool = Field(False, description="Perform validation only")


# Export all schemas
__all__ = [
    # Permission schemas
    "PermissionBase", "PermissionCreate", "PermissionUpdate", "PermissionInfo", 
    "PermissionAnalytics",
    
    # Role schemas
    "RoleBase", "RoleCreate", "RoleUpdate", "RoleInfo", "RoleDetailedInfo", 
    "RoleHierarchy",
    
    # Operation schemas
    "RolePermissionAssignment", "UserRoleAssignment", "BulkUserRoleAssignment", 
    "RoleCloneRequest",
    
    # Response schemas
    "RoleResponse", "RoleListResponse", "BulkOperationResponse", 
    "PermissionConflictInfo", "RoleValidationResponse",
    
    # Analytics schemas
    "RoleUsageAnalytics", "RoleAnalyticsSummary", "RoleImpactAnalysis", 
    "RoleComparisonResult",
    
    # Search schemas
    "RoleSearchRequest", "PermissionSearchRequest",
    
    # Audit schemas
    "RoleAuditEntry", "RoleComplianceReport",
    
    # Import/Export schemas
    "RoleExportRequest", "RoleImportRequest"
]