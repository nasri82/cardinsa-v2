"""
Authentication schemas package.
"""

from .auth import (
    LoginRequest, LoginResponse, RefreshTokenRequest, RefreshTokenResponse,
    LogoutRequest, LogoutResponse, TokenValidationRequest, TokenValidationResponse,
    SecurityEventRequest, AccountSecurityInfo, TokenData, SessionInfo,
    LoginAttemptInfo
)

from .user import (
    UserCreate, UserUpdate, UserPasswordChange, UserInfo, UserDetailedInfo,
    UserListResponse, UserResponse, UserRoleAssignment, UserBulkAction,
    UserSearchRequest, UsernameAvailabilityRequest, EmailAvailabilityRequest,
    AvailabilityResponse, DepartmentInfo, UnitInfo
)

from .role import (
    PermissionCreate, PermissionUpdate, PermissionInfo, PermissionListResponse,
    RoleCreate, RoleUpdate, RoleInfo, RoleDetailedInfo, RoleListResponse,
    RoleResponse, RolePermissionAssignment, RolePermissionBulkAssignment,
    UserRoleAssignment, UserRoleBulkAssignment, RoleSearchRequest,
    PermissionSearchRequest, UserPermissionSummary, RoleAnalytics,
    PermissionAnalytics, RBACOverview
)

__all__ = [
    # Auth schemas
    "LoginRequest", "LoginResponse", "RefreshTokenRequest", "RefreshTokenResponse",
    "LogoutRequest", "LogoutResponse", "TokenValidationRequest", "TokenValidationResponse",
    "SecurityEventRequest", "AccountSecurityInfo", "TokenData", "SessionInfo",
    "LoginAttemptInfo",
    
    # User schemas
    "UserCreate", "UserUpdate", "UserPasswordChange", "UserInfo", "UserDetailedInfo",
    "UserListResponse", "UserResponse", "UserRoleAssignment", "UserBulkAction",
    "UserSearchRequest", "UsernameAvailabilityRequest", "EmailAvailabilityRequest",
    "AvailabilityResponse", "DepartmentInfo", "UnitInfo",
    
    # Role schemas
    "PermissionCreate", "PermissionUpdate", "PermissionInfo", "PermissionListResponse",
    "RoleCreate", "RoleUpdate", "RoleInfo", "RoleDetailedInfo", "RoleListResponse",
    "RoleResponse", "RolePermissionAssignment", "RolePermissionBulkAssignment",
    "UserRoleAssignment", "UserRoleBulkAssignment", "RoleSearchRequest",
    "PermissionSearchRequest", "UserPermissionSummary", "RoleAnalytics",
    "PermissionAnalytics", "RBACOverview"
]