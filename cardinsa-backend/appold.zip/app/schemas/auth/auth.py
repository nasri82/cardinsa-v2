# FILE PATH: app/schemas/auth/auth.py

"""
Enhanced Authentication Schemas
CARDINSA Insurance Platform

World-class Pydantic schemas for authentication with comprehensive validation.
Supports all enhanced features while maintaining backward compatibility.
"""

from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from uuid import UUID
import re

from pydantic import BaseModel, Field, validator, EmailStr
from app.schemas.base import BaseSchema, TimestampSchema, AuditSchema


# ===== CORE AUTHENTICATION SCHEMAS =====

class LoginRequest(BaseSchema):
    """Enhanced login request with MFA and device support."""
    username: str = Field(
        ..., 
        min_length=3, 
        max_length=100,
        description="Username or email address"
    )
    password: str = Field(
        ..., 
        min_length=8, 
        max_length=128,
        description="User password"
    )
    mfa_code: Optional[str] = Field(
        None, 
        min_length=4, 
        max_length=8,
        description="Multi-factor authentication code"
    )
    device_name: Optional[str] = Field(
        "Web Browser", 
        max_length=100,
        description="Device name for session tracking"
    )
    remember_me: bool = Field(
        False, 
        description="Extend session duration"
    )
    
    @validator('username')
    def validate_username(cls, v):
        """Validate username format."""
        if '@' in v:  # Email format
            if not re.match(r'^[^@]+@[^@]+\.[^@]+$', v):
                raise ValueError('Invalid email format')
        else:  # Username format
            if not re.match(r'^[a-zA-Z0-9_.-]+$', v):
                raise ValueError('Username can only contain letters, numbers, dots, hyphens, and underscores')
        return v.lower().strip()
    
    @validator('mfa_code')
    def validate_mfa_code(cls, v):
        """Validate MFA code format."""
        if v and not re.match(r'^\d{4,8}$', v):
            raise ValueError('MFA code must be 4-8 digits')
        return v


class UserInfo(BaseSchema):
    """Enhanced user information schema."""
    id: str = Field(..., description="User unique identifier")
    username: str = Field(..., description="Username")
    email: EmailStr = Field(..., description="Email address")
    full_name: Optional[str] = Field(None, description="Full display name")
    is_active: bool = Field(..., description="Account active status")
    is_verified: bool = Field(..., description="Email verification status")
    is_staff: bool = Field(False, description="Staff access flag")
    is_superuser: bool = Field(False, description="Superuser access flag")
    created_at: datetime = Field(..., description="Account creation date")
    last_login: Optional[datetime] = Field(None, description="Last login timestamp")
    timezone: str = Field("UTC", description="User timezone")
    locale: str = Field("en-US", description="User locale preference")


class TokenInfo(BaseSchema):
    """Token information schema."""
    type: str = Field(..., description="Token type")
    expires_at: datetime = Field(..., description="Token expiration time")
    issued_at: datetime = Field(..., description="Token issue time")
    scope: str = Field("full_access", description="Token scope")
    refresh_count: Optional[int] = Field(0, description="Refresh count for tracking")


class SecurityInfo(BaseSchema):
    """Security context information."""
    ip_address: str = Field(..., description="Client IP address")
    device_trusted: bool = Field(False, description="Device trust status")
    location_verified: bool = Field(False, description="Location verification status")
    risk_score: str = Field("unknown", description="Security risk assessment")
    mfa_verified: bool = Field(False, description="MFA verification status")
    last_activity: datetime = Field(..., description="Last activity timestamp")
    login_count: Optional[int] = Field(0, description="Total login count")
    last_login_ip: Optional[str] = Field(None, description="Previous login IP")
    password_expires_at: Optional[datetime] = Field(None, description="Password expiration")
    must_change_password: bool = Field(False, description="Password change required flag")


class SessionInfo(BaseSchema):
    """Session information schema."""
    session_id: str = Field(..., description="Session identifier")
    device_name: str = Field(..., description="Device name")
    ip_address: str = Field(..., description="Session IP address")
    created_at: datetime = Field(..., description="Session creation time")
    last_activity: Optional[datetime] = Field(None, description="Last activity time")
    expires_at: datetime = Field(..., description="Session expiration time")
    is_current: bool = Field(False, description="Current session flag")
    is_active: bool = Field(True, description="Session active status")


class LoginResponse(BaseSchema):
    """Enhanced login response with comprehensive information."""
    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field("bearer", description="Token type")
    expires_in: int = Field(..., description="Token expiration in seconds")
    refresh_token: Optional[str] = Field(None, description="Refresh token")
    mfa_required: bool = Field(False, description="MFA requirement flag")
    
    user: UserInfo = Field(..., description="User information")
    session: SessionInfo = Field(..., description="Session information")
    security: SecurityInfo = Field(..., description="Security context")


class MFARequiredResponse(BaseSchema):
    """MFA requirement response."""
    mfa_required: bool = Field(True, description="MFA required flag")
    message: str = Field(..., description="MFA requirement message")
    available_methods: List[str] = Field(..., description="Available MFA methods")
    temp_token: str = Field(..., description="Temporary token for MFA verification")


# ===== TOKEN MANAGEMENT SCHEMAS =====

class TokenData(BaseSchema):
    """Token data schema for JWT payload information."""
    user_id: str = Field(..., description="User ID from token")
    username: Optional[str] = Field(None, description="Username from token")
    email: Optional[str] = Field(None, description="Email from token")
    scopes: List[str] = Field(default_factory=list, description="Token scopes/permissions")
    exp: Optional[int] = Field(None, description="Token expiration timestamp")
    iat: Optional[int] = Field(None, description="Token issued at timestamp")
    sub: Optional[str] = Field(None, description="Token subject")
    iss: Optional[str] = Field(None, description="Token issuer")
    aud: Optional[str] = Field(None, description="Token audience")
    session_id: Optional[str] = Field(None, description="Associated session ID")
    device_id: Optional[str] = Field(None, description="Associated device ID")
    token_type: str = Field("access", description="Type of token")
    company_id: Optional[str] = Field(None, description="Company ID from token")
    roles: List[str] = Field(default_factory=list, description="User roles")
    permissions: List[str] = Field(default_factory=list, description="User permissions")
    
    class Config:
        schema_extra = {
            "example": {
                "user_id": "user_123456789",
                "username": "john.doe",
                "email": "john.doe@company.com",
                "scopes": ["read", "write", "admin"],
                "exp": 1640995200,
                "iat": 1640991600,
                "sub": "user_123456789",
                "iss": "cardinsa-api",
                "aud": "cardinsa-app",
                "session_id": "sess_987654321",
                "device_id": "dev_456789123",
                "token_type": "access",
                "company_id": "comp_123456",
                "roles": ["admin", "user"],
                "permissions": ["users.read", "users.write", "companies.read"]
            }
        }


class RefreshTokenRequest(BaseSchema):
    """Token refresh request."""
    refresh_token: str = Field(..., description="Valid refresh token")


class RefreshTokenResponse(BaseSchema):
    """Enhanced token refresh response."""
    access_token: str = Field(..., description="New access token")
    token_type: str = Field("bearer", description="Token type")
    expires_in: int = Field(..., description="Token expiration in seconds")
    refresh_token: str = Field(..., description="New refresh token (rotated)")
    
    user: Dict[str, Any] = Field(..., description="User information")
    token_info: TokenInfo = Field(..., description="Token metadata")


class TokenValidationRequest(BaseSchema):
    """Token validation request."""
    token: str = Field(..., description="Token to validate")
    token_type: str = Field("access", description="Token type")


class TokenValidationResponse(BaseSchema):
    """Enhanced token validation response."""
    valid: bool = Field(..., description="Token validity status")
    user: Optional[UserInfo] = Field(None, description="User information if valid")
    token: Optional[TokenInfo] = Field(None, description="Token information")
    security: SecurityInfo = Field(..., description="Security context")
    session: Optional[SessionInfo] = Field(None, description="Session information")
    error: Optional[Dict[str, Any]] = Field(None, description="Error details if invalid")
    action_required: Optional[str] = Field(None, description="Required action")


# ===== LOGOUT SCHEMAS =====

class LogoutRequest(BaseSchema):
    """Enhanced logout request."""
    logout_all: bool = Field(False, description="Logout from all devices")
    reason: Optional[str] = Field(None, description="Logout reason")


class LogoutResponse(BaseSchema):
    """Enhanced logout response."""
    message: str = Field(..., description="Logout confirmation message")
    user: Optional[Dict[str, str]] = Field(None, description="User information")
    session: Dict[str, Any] = Field(..., description="Session termination details")
    security: Optional[Dict[str, Any]] = Field(None, description="Security summary")


# ===== USER PROFILE SCHEMAS =====

class UserPreferences(BaseSchema):
    """User preferences schema."""
    theme: str = Field("light", description="UI theme preference")
    language: str = Field("en", description="Language preference")
    notifications_enabled: bool = Field(True, description="Notifications enabled")
    email_notifications: bool = Field(True, description="Email notifications enabled")
    timezone: str = Field("UTC", description="Timezone preference")


class UserRole(BaseSchema):
    """User role information."""
    id: str = Field(..., description="Role identifier")
    name: str = Field(..., description="Role name")
    description: str = Field(..., description="Role description")


class UserSecurityProfile(BaseSchema):
    """User security profile information."""
    mfa_enabled: bool = Field(False, description="MFA enabled status")
    mfa_methods: List[str] = Field(default_factory=list, description="Configured MFA methods")
    password_expires_at: Optional[datetime] = Field(None, description="Password expiration")
    must_change_password: bool = Field(False, description="Password change required")
    account_locked: bool = Field(False, description="Account lock status")
    login_attempts: int = Field(0, description="Failed login attempts")
    last_password_change: Optional[datetime] = Field(None, description="Last password change")


class CurrentUserResponse(BaseSchema):
    """Enhanced current user response."""
    user: UserInfo = Field(..., description="User information")
    permissions: List[str] = Field(..., description="User permissions")
    roles: List[UserRole] = Field(..., description="User roles")
    security: UserSecurityProfile = Field(..., description="Security profile")
    session: SessionInfo = Field(..., description="Current session")
    preferences: UserPreferences = Field(..., description="User preferences")


# ===== PASSWORD MANAGEMENT SCHEMAS =====

class PasswordChangeRequest(BaseSchema):
    """Password change request."""
    current_password: str = Field(..., description="Current password")
    new_password: str = Field(..., min_length=8, description="New password")
    confirm_password: str = Field(..., description="Password confirmation")
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        """Validate password confirmation."""
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match')
        return v
    
    @validator('new_password')
    def validate_password_strength(cls, v):
        """Validate password strength."""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one digit')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain at least one special character')
        return v


class PasswordResetRequest(BaseSchema):
    """Password reset request."""
    email: EmailStr = Field(..., description="Email address for reset")


class PasswordResetConfirmRequest(BaseSchema):
    """Password reset confirmation."""
    reset_token: str = Field(..., description="Password reset token")
    new_password: str = Field(..., min_length=8, description="New password")
    confirm_password: str = Field(..., description="Password confirmation")
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        """Validate password confirmation."""
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match')
        return v


# ===== MFA SCHEMAS =====

class MFASetupRequest(BaseSchema):
    """MFA setup request."""
    method: str = Field(..., description="MFA method (totp, sms, email)")
    phone_number: Optional[str] = Field(None, description="Phone number for SMS")
    
    @validator('method')
    def validate_method(cls, v):
        """Validate MFA method."""
        allowed_methods = ['totp', 'sms', 'email']
        if v not in allowed_methods:
            raise ValueError(f'Method must be one of: {", ".join(allowed_methods)}')
        return v


class MFAVerificationRequest(BaseSchema):
    """MFA verification request."""
    temp_token: str = Field(..., description="Temporary MFA token")
    mfa_code: str = Field(..., min_length=4, max_length=8, description="MFA verification code")
    method: str = Field(..., description="MFA method used")


class MFASetupResponse(BaseSchema):
    """MFA setup response."""
    method: str = Field(..., description="MFA method")
    setup_complete: bool = Field(..., description="Setup completion status")
    backup_codes: Optional[List[str]] = Field(None, description="Backup codes")
    qr_code: Optional[str] = Field(None, description="QR code for TOTP setup")


# ===== SECURITY EVENT SCHEMAS =====

class SecurityEventRequest(BaseSchema):
    """Security event logging request."""
    event_type: str = Field(..., description="Security event type")
    description: str = Field(..., description="Event description")
    severity: str = Field("info", description="Event severity level")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional event data")
    
    @validator('severity')
    def validate_severity(cls, v):
        """Validate severity level."""
        allowed_levels = ['low', 'info', 'warning', 'high', 'critical']
        if v not in allowed_levels:
            raise ValueError(f'Severity must be one of: {", ".join(allowed_levels)}')
        return v


class LoginAttemptInfo(BaseSchema):
    """Login attempt information."""
    username: str = Field(..., description="Attempted username")
    ip_address: str = Field(..., description="Attempt IP address")
    user_agent: str = Field(..., description="User agent string")
    success: bool = Field(..., description="Attempt success status")
    failure_reason: Optional[str] = Field(None, description="Failure reason")
    timestamp: datetime = Field(..., description="Attempt timestamp")
    device_info: Optional[Dict[str, str]] = Field(None, description="Device information")


# ===== ERROR RESPONSE SCHEMAS =====

class AuthErrorResponse(BaseSchema):
    """Authentication error response."""
    error: str = Field(..., description="Error code")
    message: str = Field(..., description="Error message")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Error timestamp")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")


class ValidationErrorResponse(BaseSchema):
    """Validation error response."""
    error: str = Field("VALIDATION_ERROR", description="Error code")
    message: str = Field(..., description="Validation error message")
    fields: Dict[str, str] = Field(..., description="Field-specific errors")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Error timestamp")


# ===== BATCH OPERATION SCHEMAS =====

class BatchLoginRequest(BaseSchema):
    """Batch login request for testing/admin purposes."""
    credentials: List[LoginRequest] = Field(..., description="List of login credentials")
    max_concurrent: int = Field(5, ge=1, le=10, description="Maximum concurrent logins")


class BatchLoginResponse(BaseSchema):
    """Batch login response."""
    successful: List[LoginResponse] = Field(..., description="Successful logins")
    failed: List[Dict[str, Any]] = Field(..., description="Failed login attempts")
    summary: Dict[str, int] = Field(..., description="Operation summary")


# ===== AUDIT AND COMPLIANCE SCHEMAS =====

class AuditLogEntry(TimestampSchema):
    """Audit log entry schema."""
    event_id: str = Field(..., description="Unique event identifier")
    event_type: str = Field(..., description="Event type")
    user_id: Optional[str] = Field(None, description="Associated user ID")
    ip_address: str = Field(..., description="Source IP address")
    user_agent: Optional[str] = Field(None, description="User agent")
    resource: Optional[str] = Field(None, description="Accessed resource")
    action: str = Field(..., description="Performed action")
    result: str = Field(..., description="Action result")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional details")


class ComplianceReport(BaseSchema):
    """Compliance reporting schema."""
    report_id: str = Field(..., description="Report identifier")
    period: str = Field(..., description="Reporting period")
    user_activity: Dict[str, Any] = Field(..., description="User activity summary")
    security_events: Dict[str, Any] = Field(..., description="Security events summary")
    access_patterns: Dict[str, Any] = Field(..., description="Access patterns analysis")
    generated_at: datetime = Field(default_factory=datetime.utcnow, description="Report generation time")


# ===== ACCOUNT SECURITY SCHEMAS =====

class AccountSecurityInfo(BaseSchema):
    """Comprehensive account security information schema."""
    
    # Basic Account Status
    account_status: str = Field(..., description="Current account status")
    is_active: bool = Field(True, description="Account is active")
    is_locked: bool = Field(False, description="Account is locked")
    locked_until: Optional[datetime] = Field(None, description="Account locked until")
    lock_reason: Optional[str] = Field(None, description="Reason for account lock")
    
    # Authentication Security
    failed_login_attempts: int = Field(0, ge=0, description="Failed login attempts")
    max_login_attempts: int = Field(5, ge=1, description="Maximum allowed login attempts")
    last_successful_login: Optional[datetime] = Field(None, description="Last successful login")
    last_failed_login: Optional[datetime] = Field(None, description="Last failed login attempt")
    last_login_ip: Optional[str] = Field(None, description="Last login IP address")
    
    # Password Security
    password_last_changed: Optional[datetime] = Field(None, description="Password last changed")
    password_expires_at: Optional[datetime] = Field(None, description="Password expiration")
    must_change_password: bool = Field(False, description="Must change password")
    password_strength_score: float = Field(0.0, ge=0.0, le=1.0, description="Password strength score")
    password_age_days: Optional[int] = Field(None, ge=0, description="Password age in days")
    
    # Multi-Factor Authentication
    mfa_enabled: bool = Field(False, description="MFA is enabled")
    mfa_required: bool = Field(False, description="MFA is required for this account")
    mfa_methods: List[str] = Field(default_factory=list, description="Available MFA methods")
    backup_codes_remaining: int = Field(0, ge=0, description="Backup codes remaining")
    mfa_last_used: Optional[datetime] = Field(None, description="MFA last used timestamp")
    
    # Session and Device Security
    active_sessions_count: int = Field(0, ge=0, description="Number of active sessions")
    trusted_devices_count: int = Field(0, ge=0, description="Number of trusted devices")
    max_concurrent_sessions: int = Field(3, ge=1, description="Maximum concurrent sessions allowed")
    session_timeout_minutes: int = Field(30, ge=1, description="Session timeout in minutes")
    
    # Risk Assessment
    risk_score: float = Field(0.0, ge=0.0, le=1.0, description="Overall account risk score")
    risk_level: str = Field("low", description="Risk level assessment")
    risk_factors: List[str] = Field(default_factory=list, description="Identified risk factors")
    last_risk_assessment: Optional[datetime] = Field(None, description="Last risk assessment")
    
    # Security Events and Monitoring
    recent_security_events_count: int = Field(0, ge=0, description="Recent security events count")
    suspicious_activity_detected: bool = Field(False, description="Suspicious activity detected")
    last_security_event: Optional[datetime] = Field(None, description="Last security event")
    security_alerts_count: int = Field(0, ge=0, description="Active security alerts")
    
    # Protection and Compliance
    protection_level: str = Field("standard", description="Account protection level")
    security_score: float = Field(0.0, ge=0.0, le=1.0, description="Overall security score")
    compliance_status: str = Field("compliant", description="Compliance status")
    
    # Recommendations
    security_recommendations: List[str] = Field(default_factory=list, description="Security recommendations")
    critical_actions_required: int = Field(0, ge=0, description="Critical actions requiring attention")
    
    # Insurance-Specific Fields
    regulatory_compliance_level: str = Field("standard", description="Insurance regulatory compliance level")
    data_classification: str = Field("confidential", description="Data classification level")
    encryption_level: str = Field("AES-256", description="Encryption standard used")
    
    # Audit and Review Information
    last_security_review: Optional[datetime] = Field(None, description="Last security review date")
    next_security_review: Optional[datetime] = Field(None, description="Next scheduled security review")
    monitoring_enabled: bool = Field(True, description="Security monitoring enabled")
    
    # Metadata
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Security profile creation")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Last security profile update")
    
    @validator('risk_level')
    def validate_risk_level(cls, v):
        """Validate risk level values."""
        allowed_levels = ['low', 'medium', 'high', 'critical']
        if v not in allowed_levels:
            raise ValueError(f'Risk level must be one of: {", ".join(allowed_levels)}')
        return v
    
    @validator('protection_level')
    def validate_protection_level(cls, v):
        """Validate protection level values."""
        allowed_levels = ['basic', 'standard', 'enhanced', 'maximum']
        if v not in allowed_levels:
            raise ValueError(f'Protection level must be one of: {", ".join(allowed_levels)}')
        return v
    
    @validator('account_status')
    def validate_account_status(cls, v):
        """Validate account status values."""
        allowed_statuses = ['active', 'inactive', 'suspended', 'locked', 'pending', 'disabled']
        if v not in allowed_statuses:
            raise ValueError(f'Account status must be one of: {", ".join(allowed_statuses)}')
        return v
    
    @validator('compliance_status')
    def validate_compliance_status(cls, v):
        """Validate compliance status values."""
        allowed_statuses = ['compliant', 'non_compliant', 'pending_review', 'requires_action']
        if v not in allowed_statuses:
            raise ValueError(f'Compliance status must be one of: {", ".join(allowed_statuses)}')
        return v


class DeviceSecurityInfo(BaseSchema):
    """Device security information."""
    device_id: str = Field(..., description="Device identifier")
    device_name: Optional[str] = Field(None, description="Device name")
    device_type: str = Field("unknown", description="Device type")
    is_trusted: bool = Field(False, description="Device is trusted")
    last_used: Optional[datetime] = Field(None, description="Last used timestamp")
    risk_score: float = Field(0.0, ge=0.0, le=1.0, description="Device risk score")


class SecurityEventInfo(BaseSchema):
    """Security event information."""
    event_id: str = Field(..., description="Event identifier")
    event_type: str = Field(..., description="Event type")
    severity: str = Field("info", description="Event severity")
    description: str = Field(..., description="Event description")
    timestamp: datetime = Field(..., description="Event timestamp")
    resolved: bool = Field(False, description="Event resolved")


class SecurityRecommendationInfo(BaseSchema):
    """Security recommendation information."""
    id: str = Field(..., description="Recommendation ID")
    title: str = Field(..., description="Recommendation title")
    description: str = Field(..., description="Recommendation description")
    priority: str = Field("medium", description="Priority level")
    category: str = Field("general", description="Security category")
    action_required: bool = Field(False, description="Immediate action required")


# Export all schemas
__all__ = [
    # Core authentication
    "LoginRequest", "LoginResponse", "MFARequiredResponse", "UserInfo", "TokenInfo",
    "SecurityInfo", "SessionInfo", "CurrentUserResponse",
    
    # Token management
    "RefreshTokenRequest", "RefreshTokenResponse", "TokenValidationRequest", 
    "TokenValidationResponse", "TokenData",
    
    # Logout
    "LogoutRequest", "LogoutResponse",
    
    # User management
    "UserPreferences", "UserRole", "UserSecurityProfile",
    
    # Password management
    "PasswordChangeRequest", "PasswordResetRequest", "PasswordResetConfirmRequest",
    
    # MFA
    "MFASetupRequest", "MFAVerificationRequest", "MFASetupResponse",
    
    # Security and audit
    "SecurityEventRequest", "LoginAttemptInfo", "AuditLogEntry", "ComplianceReport",
    
    # Error handling
    "AuthErrorResponse", "ValidationErrorResponse",
    
    # Batch operations
    "BatchLoginRequest", "BatchLoginResponse",
    
    # Account Security - NEW ADDITIONS
    "AccountSecurityInfo", "DeviceSecurityInfo", "SecurityEventInfo", "SecurityRecommendationInfo"
]