"""
User management schemas for user CRUD operations.
"""

from datetime import datetime
from typing import Optional, List
from uuid import UUID

from pydantic import Field, EmailStr, validator

from app.schemas.base import BaseSchema, AuditSchema, PaginatedResponseSchema
from app.schemas.auth.role import RoleInfo


# Base User Schemas
class UserBase(BaseSchema):
    """Base user schema with common fields."""
    username: str = Field(..., min_length=3, max_length=100, description="Username")
    email: EmailStr = Field(..., description="Email address")
    first_name: Optional[str] = Field(None, max_length=100, description="First name")
    last_name: Optional[str] = Field(None, max_length=100, description="Last name")
    phone: Optional[str] = Field(None, max_length=20, description="Phone number")
    is_active: bool = Field(default=True, description="Account active status")


class UserCreate(UserBase):
    """User creation schema."""
    password: str = Field(..., min_length=8, description="User password")
    confirm_password: str = Field(..., description="Confirm password")
    department_id: Optional[UUID] = Field(None, description="Department ID")
    unit_id: Optional[UUID] = Field(None, description="Unit ID")
    role_ids: Optional[List[UUID]] = Field(default_factory=list, description="Role IDs to assign")
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        """Validate that password and confirm_password match."""
        if 'password' in values and v != values['password']:
            raise ValueError('Passwords do not match')
        return v


class UserUpdate(BaseSchema):
    """User update schema."""
    username: Optional[str] = Field(None, min_length=3, max_length=100, description="Username")
    email: Optional[EmailStr] = Field(None, description="Email address")
    first_name: Optional[str] = Field(None, max_length=100, description="First name")
    last_name: Optional[str] = Field(None, max_length=100, description="Last name")
    phone: Optional[str] = Field(None, max_length=20, description="Phone number")
    is_active: Optional[bool] = Field(None, description="Account active status")
    department_id: Optional[UUID] = Field(None, description="Department ID")
    unit_id: Optional[UUID] = Field(None, description="Unit ID")
    timezone: Optional[str] = Field(None, max_length=50, description="User timezone")
    language: Optional[str] = Field(None, max_length=10, description="User language")
    avatar_url: Optional[str] = Field(None, description="Avatar URL")


class UserPasswordChange(BaseSchema):
    """User password change schema."""
    current_password: str = Field(..., description="Current password")
    new_password: str = Field(..., min_length=8, description="New password")
    confirm_password: str = Field(..., description="Confirm new password")
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        """Validate that new_password and confirm_password match."""
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match')
        return v


# User Preferences Schema
class UserPreferences(BaseSchema):
    """User preferences and settings schema."""
    theme: str = Field("light", description="UI theme preference (light, dark, auto)")
    language: str = Field("en", description="Primary language preference")
    locale: str = Field("en-US", description="Locale preference for formatting")
    timezone: str = Field("UTC", description="User timezone preference")
    date_format: str = Field("YYYY-MM-DD", description="Preferred date format")
    time_format: str = Field("24h", description="Preferred time format (12h, 24h)")
    currency: str = Field("USD", description="Preferred currency")
    
    # Notification Preferences
    email_notifications: bool = Field(True, description="Enable email notifications")
    push_notifications: bool = Field(True, description="Enable push notifications")
    sms_notifications: bool = Field(False, description="Enable SMS notifications")
    notification_frequency: str = Field("immediate", description="Notification frequency")
    
    # UI/UX Preferences
    sidebar_collapsed: bool = Field(False, description="Sidebar collapsed by default")
    page_size: int = Field(20, ge=10, le=100, description="Default page size for lists")
    table_density: str = Field("standard", description="Table row density (compact, standard, comfortable)")
    show_tooltips: bool = Field(True, description="Show help tooltips")
    
    # Privacy and Security
    profile_visibility: str = Field("internal", description="Profile visibility (public, internal, private)")
    share_activity: bool = Field(True, description="Share activity with team")
    two_factor_required: bool = Field(False, description="Require 2FA for sensitive operations")
    
    # Communication Preferences
    preferred_contact_method: str = Field("email", description="Preferred contact method")
    working_hours_start: str = Field("09:00", description="Working hours start time")
    working_hours_end: str = Field("17:00", description="Working hours end time")
    working_days: List[str] = Field(
        default_factory=lambda: ["monday", "tuesday", "wednesday", "thursday", "friday"],
        description="Working days"
    )
    
    @validator('theme')
    def validate_theme(cls, v):
        """Validate theme preference."""
        valid_themes = ['light', 'dark', 'auto']
        if v not in valid_themes:
            raise ValueError(f'Theme must be one of: {", ".join(valid_themes)}')
        return v
    
    @validator('time_format')
    def validate_time_format(cls, v):
        """Validate time format preference."""
        valid_formats = ['12h', '24h']
        if v not in valid_formats:
            raise ValueError(f'Time format must be one of: {", ".join(valid_formats)}')
        return v
    
    @validator('notification_frequency')
    def validate_notification_frequency(cls, v):
        """Validate notification frequency."""
        valid_frequencies = ['immediate', 'hourly', 'daily', 'weekly', 'never']
        if v not in valid_frequencies:
            raise ValueError(f'Notification frequency must be one of: {", ".join(valid_frequencies)}')
        return v
    
    @validator('profile_visibility')
    def validate_profile_visibility(cls, v):
        """Validate profile visibility."""
        valid_visibility = ['public', 'internal', 'private']
        if v not in valid_visibility:
            raise ValueError(f'Profile visibility must be one of: {", ".join(valid_visibility)}')
        return v
    
    @validator('preferred_contact_method')
    def validate_contact_method(cls, v):
        """Validate preferred contact method."""
        valid_methods = ['email', 'phone', 'sms', 'slack', 'teams']
        if v not in valid_methods:
            raise ValueError(f'Contact method must be one of: {", ".join(valid_methods)}')
        return v


class UserPreferencesUpdate(BaseSchema):
    """User preferences update schema for partial updates."""
    theme: Optional[str] = Field(None, description="UI theme preference")
    language: Optional[str] = Field(None, description="Primary language preference")
    locale: Optional[str] = Field(None, description="Locale preference")
    timezone: Optional[str] = Field(None, description="User timezone preference")
    date_format: Optional[str] = Field(None, description="Preferred date format")
    time_format: Optional[str] = Field(None, description="Preferred time format")
    currency: Optional[str] = Field(None, description="Preferred currency")
    
    # Notification Preferences
    email_notifications: Optional[bool] = Field(None, description="Enable email notifications")
    push_notifications: Optional[bool] = Field(None, description="Enable push notifications")
    sms_notifications: Optional[bool] = Field(None, description="Enable SMS notifications")
    notification_frequency: Optional[str] = Field(None, description="Notification frequency")
    
    # UI/UX Preferences
    sidebar_collapsed: Optional[bool] = Field(None, description="Sidebar collapsed by default")
    page_size: Optional[int] = Field(None, ge=10, le=100, description="Default page size for lists")
    table_density: Optional[str] = Field(None, description="Table row density")
    show_tooltips: Optional[bool] = Field(None, description="Show help tooltips")
    
    # Privacy and Security
    profile_visibility: Optional[str] = Field(None, description="Profile visibility")
    share_activity: Optional[bool] = Field(None, description="Share activity with team")
    two_factor_required: Optional[bool] = Field(None, description="Require 2FA for sensitive operations")
    
    # Communication Preferences
    preferred_contact_method: Optional[str] = Field(None, description="Preferred contact method")
    working_hours_start: Optional[str] = Field(None, description="Working hours start time")
    working_hours_end: Optional[str] = Field(None, description="Working hours end time")
    working_days: Optional[List[str]] = Field(None, description="Working days")


# Response Schemas
class DepartmentInfo(BaseSchema):
    """Department information schema."""
    id: UUID = Field(..., description="Department ID")
    name: str = Field(..., description="Department name")
    code: str = Field(..., description="Department code")
    description: Optional[str] = Field(None, description="Department description")


class UnitInfo(BaseSchema):
    """Unit information schema."""
    id: UUID = Field(..., description="Unit ID")
    name: str = Field(..., description="Unit name")
    code: str = Field(..., description="Unit code")
    description: Optional[str] = Field(None, description="Unit description")
    department_id: UUID = Field(..., description="Department ID")


class UserInfo(UserBase, AuditSchema):
    """User information response schema."""
    id: UUID = Field(..., description="User ID")
    is_staff: bool = Field(default=False, description="Staff user status")
    is_superuser: bool = Field(default=False, description="Superuser status")
    email_verified: bool = Field(default=False, description="Email verification status")
    phone_verified: bool = Field(default=False, description="Phone verification status")
    two_factor_enabled: bool = Field(default=False, description="2FA enabled status")
    account_locked: bool = Field(default=False, description="Account locked status")
    last_login: Optional[datetime] = Field(None, description="Last login timestamp")
    last_activity: Optional[datetime] = Field(None, description="Last activity timestamp")
    login_attempts: int = Field(default=0, description="Failed login attempts count")
    
    # Organizational info
    department_id: Optional[UUID] = Field(None, description="Department ID")
    unit_id: Optional[UUID] = Field(None, description="Unit ID")
    department: Optional[DepartmentInfo] = Field(None, description="Department information")
    unit: Optional[UnitInfo] = Field(None, description="Unit information")
    
    # Profile info
    timezone: str = Field(default="UTC", description="User timezone")
    language: str = Field(default="en", description="User language")
    avatar_url: Optional[str] = Field(None, description="Avatar URL")
    bio: Optional[str] = Field(None, description="User bio")
    
    @property
    def full_name(self) -> str:
        """Get user's full name."""
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        elif self.first_name:
            return self.first_name
        elif self.last_name:
            return self.last_name
        return self.username


class UserDetailedInfo(UserInfo):
    """Detailed user information with roles and permissions."""
    roles: List[RoleInfo] = Field(default_factory=list, description="User roles")
    permissions: List[str] = Field(default_factory=list, description="User permissions")
    accessible_departments: List[DepartmentInfo] = Field(default_factory=list, description="Accessible departments")
    accessible_units: List[UnitInfo] = Field(default_factory=list, description="Accessible units")
    preferences: Optional[UserPreferences] = Field(None, description="User preferences")


class UserListResponse(PaginatedResponseSchema):
    """Paginated user list response."""
    items: List[UserInfo] = Field(..., description="List of users")


class UserResponse(BaseSchema):
    """Single user response."""
    user: UserDetailedInfo = Field(..., description="User information")


# User Management Schemas
class UserRoleAssignment(BaseSchema):
    """User role assignment schema."""
    user_id: UUID = Field(..., description="User ID")
    role_id: UUID = Field(..., description="Role ID")
    expires_at: Optional[datetime] = Field(None, description="Assignment expiration")


class UserBulkAction(BaseSchema):
    """User bulk action schema."""
    user_ids: List[UUID] = Field(..., min_items=1, description="List of user IDs")
    action: str = Field(..., description="Action to perform")
    parameters: Optional[dict] = Field(None, description="Action parameters")


class UserSearchRequest(BaseSchema):
    """User search request schema."""
    query: Optional[str] = Field(None, description="Search query")
    department_id: Optional[UUID] = Field(None, description="Filter by department")
    unit_id: Optional[UUID] = Field(None, description="Filter by unit")
    role_id: Optional[UUID] = Field(None, description="Filter by role")
    is_active: Optional[bool] = Field(None, description="Filter by active status")
    is_staff: Optional[bool] = Field(None, description="Filter by staff status")
    created_after: Optional[datetime] = Field(None, description="Filter by creation date")
    created_before: Optional[datetime] = Field(None, description="Filter by creation date")


# Validation Schemas
class UsernameAvailabilityRequest(BaseSchema):
    """Username availability check request."""
    username: str = Field(..., min_length=3, max_length=100, description="Username to check")


class EmailAvailabilityRequest(BaseSchema):
    """Email availability check request."""
    email: EmailStr = Field(..., description="Email to check")


class AvailabilityResponse(BaseSchema):
    """Availability check response."""
    available: bool = Field(..., description="Availability status")
    message: str = Field(..., description="Availability message")
    suggestions: List[str] = Field(default_factory=list, description="Alternative suggestions")


# Export all schemas
__all__ = [
    # Base schemas
    "UserBase", "UserCreate", "UserUpdate", "UserPasswordChange",
    
    # Preferences
    "UserPreferences", "UserPreferencesUpdate",
    
    # Response schemas
    "DepartmentInfo", "UnitInfo", "UserInfo", "UserDetailedInfo",
    "UserListResponse", "UserResponse",
    
    # Management schemas
    "UserRoleAssignment", "UserBulkAction", "UserSearchRequest",
    
    # Validation schemas
    "UsernameAvailabilityRequest", "EmailAvailabilityRequest", "AvailabilityResponse"
]