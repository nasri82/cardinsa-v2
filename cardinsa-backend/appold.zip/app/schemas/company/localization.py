"""
Localization Schemas

Pydantic schemas for multi-language support, translations, locales,
and language preferences.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, List, Dict, Any
from uuid import UUID

from pydantic import BaseModel, Field, validator
from app.schemas.base import BaseResponse, PaginatedResponse


# Language Schemas

class LanguageBase(BaseModel):
    """Base language schema with common fields"""
    
    language_code: str = Field(..., min_length=2, max_length=10, description="Language code")
    language_name: str = Field(..., min_length=1, max_length=100, description="Language name")
    native_name: str = Field(..., min_length=1, max_length=100, description="Native language name")
    english_name: str = Field(..., min_length=1, max_length=100, description="English language name")
    
    # Language Properties
    text_direction: str = Field("ltr", description="Text direction (ltr/rtl)")
    script: Optional[str] = Field(None, max_length=50, description="Writing script")
    
    # Classification
    language_family: Optional[str] = Field(None, max_length=100, description="Language family")
    language_branch: Optional[str] = Field(None, max_length=100, description="Language branch")
    
    # Usage Information
    primary_countries: Optional[List[str]] = Field(None, description="Primary countries using this language")
    speaker_count: Optional[int] = Field(None, ge=0, description="Total speakers")
    native_speakers: Optional[int] = Field(None, ge=0, description="Native speakers")
    
    @validator('text_direction')
    def validate_text_direction(cls, v):
        if v not in ['ltr', 'rtl']:
            raise ValueError('Text direction must be ltr or rtl')
        return v
    
    @validator('language_code')
    def validate_language_code(cls, v):
        if not v.isalpha():
            raise ValueError('Language code must contain only letters')
        return v.lower()


class LanguageCreate(LanguageBase):
    """Schema for creating a new language"""
    
    # ISO Codes
    iso_639_1: Optional[str] = Field(None, min_length=2, max_length=2, description="ISO 639-1 code")
    iso_639_2: Optional[str] = Field(None, min_length=3, max_length=3, description="ISO 639-2 code")
    iso_639_3: Optional[str] = Field(None, min_length=3, max_length=3, description="ISO 639-3 code")
    
    # Status
    is_active: bool = Field(True, description="Is language active")
    is_supported: bool = Field(False, description="Is language supported")
    
    # Formatting
    date_format: str = Field("MM/dd/yyyy", max_length=50, description="Default date format")
    time_format: str = Field("HH:mm", max_length=20, description="Default time format")
    number_format: Optional[Dict[str, Any]] = Field(None, description="Number formatting rules")
    
    # Typography
    recommended_fonts: Optional[List[str]] = Field(None, description="Recommended fonts")
    line_height_adjustments: Optional[Decimal] = Field(1.0, ge=0.5, le=3.0, description="Line height adjustment")
    
    # Priority
    display_priority: int = Field(999, ge=1, le=9999, description="Display priority")
    sort_order: int = Field(999, ge=1, le=9999, description="Sort order")


class LanguageUpdate(BaseModel):
    """Schema for updating language information"""
    
    language_name: Optional[str] = Field(None, min_length=1, max_length=100)
    native_name: Optional[str] = Field(None, min_length=1, max_length=100)
    english_name: Optional[str] = Field(None, min_length=1, max_length=100)
    
    text_direction: Optional[str] = Field(None, description="Text direction")
    script: Optional[str] = Field(None, max_length=50)
    
    language_family: Optional[str] = Field(None, max_length=100)
    language_branch: Optional[str] = Field(None, max_length=100)
    
    primary_countries: Optional[List[str]] = Field(None)
    speaker_count: Optional[int] = Field(None, ge=0)
    native_speakers: Optional[int] = Field(None, ge=0)
    
    is_active: Optional[bool] = Field(None)
    is_supported: Optional[bool] = Field(None)
    
    date_format: Optional[str] = Field(None, max_length=50)
    time_format: Optional[str] = Field(None, max_length=20)
    number_format: Optional[Dict[str, Any]] = Field(None)
    
    recommended_fonts: Optional[List[str]] = Field(None)
    line_height_adjustments: Optional[Decimal] = Field(None, ge=0.5, le=3.0)
    
    display_priority: Optional[int] = Field(None, ge=1, le=9999)
    sort_order: Optional[int] = Field(None, ge=1, le=9999)
    
    @validator('text_direction')
    def validate_text_direction(cls, v):
        if v and v not in ['ltr', 'rtl']:
            raise ValueError('Text direction must be ltr or rtl')
        return v


class LanguageResponse(BaseResponse):
    """Schema for language response data"""
    
    language_code: str
    iso_639_1: Optional[str]
    iso_639_2: Optional[str]
    iso_639_3: Optional[str]
    
    language_name: str
    native_name: str
    english_name: str
    
    text_direction: str
    script: Optional[str]
    
    language_family: Optional[str]
    language_branch: Optional[str]
    language_group: Optional[str]
    
    primary_countries: Optional[List[str]]
    speaker_count: Optional[int]
    native_speakers: Optional[int]
    
    is_active: bool
    is_supported: bool
    completion_percentage: Decimal
    
    translation_quality: str
    last_translation_update: Optional[datetime]
    
    date_format: str
    time_format: str
    number_format: Optional[Dict[str, Any]]
    currency_format: Optional[Dict[str, Any]]
    
    plural_rules: Optional[Dict[str, Any]]
    plural_forms_count: int
    
    recommended_fonts: Optional[List[str]]
    line_height_adjustments: Optional[Decimal]
    
    display_priority: int
    sort_order: int


class LanguageListResponse(BaseModel):
    """Schema for language list response"""
    
    languages: List[LanguageResponse] = Field(..., description="List of languages")
    total_count: int = Field(..., description="Total number of languages")
    active_count: int = Field(..., description="Number of active languages")
    supported_count: int = Field(..., description="Number of supported languages")


# Translation Schemas

class TranslationBase(BaseModel):
    """Base translation schema"""
    
    translation_key: str = Field(..., min_length=1, max_length=255, description="Translation key")
    translation_value: str = Field(..., min_length=1, description="Translation value")
    
    # Context
    context: Optional[str] = Field(None, max_length=200, description="Translation context")
    module: Optional[str] = Field(None, max_length=100, description="Module or feature")
    screen: Optional[str] = Field(None, max_length=100, description="Screen or page")
    
    @validator('translation_key')
    def validate_translation_key(cls, v):
        # Allow letters, numbers, dots, hyphens, and underscores
        import re
        if not re.match(r'^[a-zA-Z0-9._-]+$', v):
            raise ValueError('Translation key can only contain letters, numbers, dots, hyphens, and underscores')
        return v


class TranslationCreate(TranslationBase):
    """Schema for creating a translation"""
    
    language_code: str = Field(..., min_length=2, max_length=10, description="Language code")
    
    # Metadata
    is_plural: bool = Field(False, description="Is plural translation")
    plural_forms: Optional[Dict[str, str]] = Field(None, description="Plural forms")
    
    # Validation
    max_length: Optional[int] = Field(None, ge=1, description="Maximum length constraint")
    min_length: Optional[int] = Field(None, ge=0, description="Minimum length constraint")
    
    # Status
    translation_status: str = Field("draft", description="Translation status")
    
    # Comments
    translator_notes: Optional[str] = Field(None, description="Translator notes")
    
    @validator('translation_status')
    def validate_translation_status(cls, v):
        if v not in ['draft', 'review', 'approved', 'published']:
            raise ValueError('Invalid translation status')
        return v
    
    @validator('min_length', 'max_length')
    def validate_length_constraints(cls, v, values):
        if v is not None and 'translation_value' in values:
            translation_value = values['translation_value']
            if 'min_length' in values and values['min_length'] and len(translation_value) < values['min_length']:
                raise ValueError('Translation value is shorter than minimum length')
            if 'max_length' in values and values['max_length'] and len(translation_value) > values['max_length']:
                raise ValueError('Translation value exceeds maximum length')
        return v


class TranslationUpdate(BaseModel):
    """Schema for updating a translation"""
    
    translation_value: Optional[str] = Field(None, min_length=1)
    context: Optional[str] = Field(None, max_length=200)
    module: Optional[str] = Field(None, max_length=100)
    screen: Optional[str] = Field(None, max_length=100)
    
    is_plural: Optional[bool] = Field(None)
    plural_forms: Optional[Dict[str, str]] = Field(None)
    
    translation_status: Optional[str] = Field(None)
    
    translator_notes: Optional[str] = Field(None)
    reviewer_comments: Optional[str] = Field(None)
    
    @validator('translation_status')
    def validate_translation_status(cls, v):
        if v and v not in ['draft', 'review', 'approved', 'published']:
            raise ValueError('Invalid translation status')
        return v


class TranslationResponse(BaseResponse):
    """Schema for translation response data"""
    
    translation_key: str
    language_id: UUID
    
    translation_value: str
    original_value: Optional[str]
    
    context: Optional[str]
    module: Optional[str]
    screen: Optional[str]
    
    character_count: Optional[int]
    word_count: Optional[int]
    is_plural: bool
    plural_forms: Optional[Dict[str, str]]
    
    translation_status: str
    quality_score: Optional[Decimal]
    
    translator_id: Optional[UUID]
    reviewer_id: Optional[UUID]
    approved_by: Optional[UUID]
    
    translated_at: Optional[datetime]
    reviewed_at: Optional[datetime]
    approved_at: Optional[datetime]
    
    version: int
    previous_version_id: Optional[UUID]
    
    usage_count: int
    last_used: Optional[datetime]
    
    max_length: Optional[int]
    min_length: Optional[int]
    
    translator_notes: Optional[str]
    reviewer_comments: Optional[str]
    
    tags: Optional[List[str]]


class TranslationBulkImport(BaseModel):
    """Schema for bulk translation import"""
    
    language_code: str = Field(..., min_length=2, max_length=10, description="Target language code")
    translations: Dict[str, str] = Field(..., min_items=1, description="Translation key-value pairs")
    module: Optional[str] = Field(None, max_length=100, description="Module for all translations")
    translation_status: str = Field("draft", description="Status for all translations")
    overwrite_existing: bool = Field(False, description="Overwrite existing translations")
    
    @validator('translation_status')
    def validate_translation_status(cls, v):
        if v not in ['draft', 'review', 'approved']:
            raise ValueError('Invalid translation status for bulk import')
        return v
    
    @validator('translations')
    def validate_translations(cls, v):
        if len(v) > 1000:
            raise ValueError('Cannot import more than 1000 translations at once')
        return v


class TranslationBulkImportResponse(BaseModel):
    """Schema for bulk import response"""
    
    imported: int = Field(..., description="Number of translations imported")
    updated: int = Field(..., description="Number of translations updated")
    errors: int = Field(..., description="Number of errors")
    details: List[str] = Field(default_factory=list, description="Error details")
    
    class Config:
        schema_extra = {
            "example": {
                "imported": 85,
                "updated": 12,
                "errors": 3,
                "details": [
                    "Error importing 'invalid.key': Invalid key format",
                    "Error importing 'long.value': Value exceeds maximum length",
                    "Error importing 'empty.value': Value cannot be empty"
                ]
            }
        }


class TranslationSearchParams(BaseModel):
    """Schema for translation search parameters"""
    
    language_code: Optional[str] = Field(None, description="Filter by language code")
    module: Optional[str] = Field(None, description="Filter by module")
    context: Optional[str] = Field(None, description="Filter by context")
    status: Optional[str] = Field(None, description="Filter by translation status")
    search_key: Optional[str] = Field(None, description="Search in translation keys")
    search_value: Optional[str] = Field(None, description="Search in translation values")
    
    # Sorting
    sort_by: str = Field("translation_key", description="Sort field")
    sort_order: str = Field("asc", description="Sort order")
    
    # Pagination
    page: int = Field(1, ge=1, description="Page number")
    page_size: int = Field(50, ge=1, le=200, description="Page size")
    
    @validator('sort_order')
    def validate_sort_order(cls, v):
        if v not in ['asc', 'desc']:
            raise ValueError('Sort order must be asc or desc')
        return v


# Locale Schemas

class LocaleResponse(BaseResponse):
    """Schema for locale response data"""
    
    locale_code: str = Field(..., description="Locale code")
    language_id: UUID = Field(..., description="Language ID")
    country_code: str = Field(..., description="Country code")
    
    locale_name: str = Field(..., description="Locale name")
    native_name: str = Field(..., description="Native locale name")
    
    # Currency Settings
    currency_code: str = Field(..., description="Currency code")
    currency_symbol: str = Field(..., description="Currency symbol")
    currency_position: str = Field(..., description="Currency position")
    
    # Number Formatting
    decimal_separator: str = Field(..., description="Decimal separator")
    thousands_separator: str = Field(..., description="Thousands separator")
    number_grouping: List[int] = Field(..., description="Number grouping")
    
    # Date and Time Formatting
    date_format: str = Field(..., description="Date format")
    time_format: str = Field(..., description="Time format")
    datetime_format: str = Field(..., description="DateTime format")
    
    # Calendar Settings
    first_day_of_week: int = Field(..., description="First day of week")
    weekend_days: List[int] = Field(..., description="Weekend days")
    
    # Regional Preferences
    address_format: Optional[str] = Field(None, description="Address format")
    phone_format: Optional[str] = Field(None, description="Phone format")
    
    # Units
    measurement_system: str = Field(..., description="Measurement system")
    temperature_unit: str = Field(..., description="Temperature unit")
    
    # Status
    is_active: bool = Field(..., description="Is locale active")
    is_default: bool = Field(..., description="Is default locale")
    usage_priority: int = Field(..., description="Usage priority")


# Language Settings Schemas

class LanguageSettingBase(BaseModel):
    """Base language setting schema"""
    
    preferred_language_id: UUID = Field(..., description="Preferred language ID")
    fallback_language_id: Optional[UUID] = Field(None, description="Fallback language ID")
    
    # Locale Preferences
    preferred_locale: Optional[str] = Field(None, max_length=10, description="Preferred locale")
    timezone: Optional[str] = Field(None, max_length=100, description="Timezone")
    
    # Content Preferences
    auto_translate: bool = Field(True, description="Enable auto-translation")
    show_original_text: bool = Field(False, description="Show original text")
    translation_quality_threshold: Decimal = Field(0.8, ge=0.0, le=1.0, description="Quality threshold")


class LanguageSettingCreate(LanguageSettingBase):
    """Schema for creating language settings"""
    
    # Entity Association (either user or company)
    user_id: Optional[UUID] = Field(None, description="User ID")
    company_id: Optional[UUID] = Field(None, description="Company ID")
    
    # UI Preferences
    ui_language_override: Optional[UUID] = Field(None, description="UI language override")
    date_format_override: Optional[str] = Field(None, max_length=50, description="Date format override")
    time_format_override: Optional[str] = Field(None, max_length=20, description="Time format override")
    
    # Communication Preferences
    email_language_id: Optional[UUID] = Field(None, description="Email language")
    sms_language_id: Optional[UUID] = Field(None, description="SMS language")
    document_language_id: Optional[UUID] = Field(None, description="Document language")
    
    # Advanced Settings
    content_regions: Optional[List[str]] = Field(None, description="Preferred content regions")
    cultural_preferences: Optional[Dict[str, Any]] = Field(None, description="Cultural preferences")
    accessibility_settings: Optional[Dict[str, Any]] = Field(None, description="Accessibility settings")
    
    @validator('user_id', 'company_id')
    def validate_entity_association(cls, v, values):
        user_id = values.get('user_id')
        company_id = values.get('company_id')
        
        if not user_id and not company_id:
            raise ValueError('Either user_id or company_id must be provided')
        if user_id and company_id:
            raise ValueError('Cannot specify both user_id and company_id')
        return v


class LanguageSettingUpdate(BaseModel):
    """Schema for updating language settings"""
    
    preferred_language_id: Optional[UUID] = Field(None, description="Preferred language ID")
    fallback_language_id: Optional[UUID] = Field(None, description="Fallback language ID")
    
    preferred_locale: Optional[str] = Field(None, max_length=10)
    timezone: Optional[str] = Field(None, max_length=100)
    
    auto_translate: Optional[bool] = Field(None)
    show_original_text: Optional[bool] = Field(None)
    translation_quality_threshold: Optional[Decimal] = Field(None, ge=0.0, le=1.0)
    
    ui_language_override: Optional[UUID] = Field(None)
    date_format_override: Optional[str] = Field(None, max_length=50)
    time_format_override: Optional[str] = Field(None, max_length=20)
    
    email_language_id: Optional[UUID] = Field(None)
    sms_language_id: Optional[UUID] = Field(None)
    document_language_id: Optional[UUID] = Field(None)
    
    content_regions: Optional[List[str]] = Field(None)
    cultural_preferences: Optional[Dict[str, Any]] = Field(None)
    accessibility_settings: Optional[Dict[str, Any]] = Field(None)


class LanguageSettingResponse(BaseResponse):
    """Schema for language setting response"""
    
    # Entity Association
    user_id: Optional[UUID]
    company_id: Optional[UUID]
    
    # Language Preferences
    preferred_language_id: UUID
    fallback_language_id: Optional[UUID]
    
    # Locale Preferences
    preferred_locale: Optional[str]
    timezone: Optional[str]
    
    # Content Preferences
    auto_translate: bool
    show_original_text: bool
    translation_quality_threshold: Decimal
    
    # UI Preferences
    ui_language_override: Optional[UUID]
    date_format_override: Optional[str]
    time_format_override: Optional[str]
    number_format_override: Optional[Dict[str, Any]]
    
    # Communication Preferences
    email_language_id: Optional[UUID]
    sms_language_id: Optional[UUID]
    document_language_id: Optional[UUID]
    
    # Advanced Settings
    content_regions: Optional[List[str]]
    cultural_preferences: Optional[Dict[str, Any]]
    accessibility_settings: Optional[Dict[str, Any]]
    
    # Usage Statistics
    language_usage_stats: Optional[Dict[str, Any]]
    last_language_change: Optional[datetime]
    
    # Status
    is_active: bool


# Translation Statistics Schemas

class TranslationStatistics(BaseModel):
    """Schema for translation statistics"""
    
    language: Optional[str] = Field(None, description="Language code (if filtered)")
    total_keys: int = Field(..., description="Total translation keys")
    translated: int = Field(..., description="Number of translated keys")
    approved: int = Field(..., description="Number of approved translations")
    draft: int = Field(..., description="Number of draft translations")
    review: int = Field(..., description="Number of translations in review")
    completion_percentage: float = Field(..., description="Completion percentage")
    
    # Language-specific statistics (when not filtered by language)
    languages: Optional[List[Dict[str, Any]]] = Field(None, description="Per-language statistics")
    
    class Config:
        schema_extra = {
            "example": {
                "language": "en",
                "total_keys": 1500,
                "translated": 1450,
                "approved": 1400,
                "draft": 30,
                "review": 20,
                "completion_percentage": 93.33
            }
        }


class MissingTranslationsResponse(BaseModel):
    """Schema for missing translations response"""
    
    language_code: str = Field(..., description="Language code")
    total_missing: int = Field(..., description="Total missing translations")
    missing_keys: List[Dict[str, Any]] = Field(..., description="Missing translation keys with metadata")
    
    class Config:
        schema_extra = {
            "example": {
                "language_code": "fr",
                "total_missing": 45,
                "missing_keys": [
                    {
                        "key_name": "auth.login.button",
                        "context": "button",
                        "module": "auth",
                        "translation_priority": "high",
                        "usage_count": 1500,
                        "description": "Login button text"
                    },
                    {
                        "key_name": "claims.submit.title",
                        "context": "title",
                        "module": "claims",
                        "translation_priority": "normal",
                        "usage_count": 800,
                        "description": "Claims submission page title"
                    }
                ]
            }
        }


# Translation Management Schemas

class TranslationApprovalRequest(BaseModel):
    """Schema for translation approval request"""
    
    translation_id: UUID = Field(..., description="Translation ID to approve")
    comments: Optional[str] = Field(None, description="Approval comments")
    quality_score: Optional[Decimal] = Field(None, ge=0.0, le=1.0, description="Quality score")


class TranslationApprovalResponse(BaseModel):
    """Schema for translation approval response"""
    
    translation_id: UUID = Field(..., description="Approved translation ID")
    previous_status: str = Field(..., description="Previous status")
    new_status: str = Field(..., description="New status")
    approved_by: UUID = Field(..., description="Approver user ID")
    approved_at: datetime = Field(..., description="Approval timestamp")
    comments: Optional[str] = Field(None, description="Approval comments")


class TranslationExportRequest(BaseModel):
    """Schema for translation export request"""
    
    language_codes: List[str] = Field(..., min_items=1, description="Languages to export")
    format: str = Field("json", description="Export format")
    modules: Optional[List[str]] = Field(None, description="Filter by modules")
    status: Optional[str] = Field("approved", description="Filter by status")
    include_metadata: bool = Field(False, description="Include translation metadata")
    
    @validator('format')
    def validate_format(cls, v):
        if v not in ['json', 'csv', 'xlsx', 'po', 'xliff']:
            raise ValueError('Format must be one of: json, csv, xlsx, po, xliff')
        return v
    
    @validator('language_codes')
    def validate_language_codes(cls, v):
        if len(v) > 50:
            raise ValueError('Cannot export more than 50 languages at once')
        return v


class TranslationExportResponse(BaseModel):
    """Schema for translation export response"""
    
    export_id: UUID = Field(..., description="Export job ID")
    language_codes: List[str] = Field(..., description="Exported languages")
    format: str = Field(..., description="Export format")
    status: str = Field(..., description="Export status")
    download_url: Optional[str] = Field(None, description="Download URL when ready")
    expires_at: Optional[datetime] = Field(None, description="Download expiration")
    created_at: datetime = Field(..., description="Export creation time")
    
    # Statistics
    total_translations: int = Field(..., description="Total translations exported")
    file_size_bytes: Optional[int] = Field(None, description="File size in bytes")


# Language Key Management Schemas

class LanguageKeyCreate(BaseModel):
    """Schema for creating language keys"""
    
    key_name: str = Field(..., min_length=1, max_length=255, description="Translation key name")
    key_category: Optional[str] = Field(None, max_length=100, description="Key category")
    context: Optional[str] = Field(None, max_length=200, description="Usage context")
    module: Optional[str] = Field(None, max_length=100, description="Module or feature")
    component: Optional[str] = Field(None, max_length=100, description="Component")
    
    # Content Type
    data_type: str = Field("string", description="Data type")
    is_html: bool = Field(False, description="Contains HTML")
    is_plural: bool = Field(False, description="Is plural form")
    has_variables: bool = Field(False, description="Contains variables")
    
    # Variables
    variables: Optional[List[str]] = Field(None, description="Variable names")
    variable_types: Optional[Dict[str, str]] = Field(None, description="Variable types")
    
    # Constraints
    max_length: Optional[int] = Field(None, ge=1, description="Maximum length")
    min_length: Optional[int] = Field(None, ge=0, description="Minimum length")
    validation_pattern: Optional[str] = Field(None, max_length=500, description="Validation regex")
    
    # Priority
    translation_priority: str = Field("normal", description="Translation priority")
    business_impact: str = Field("medium", description="Business impact")
    
    # Default Content
    default_value: Optional[str] = Field(None, description="Default value")
    fallback_value: Optional[str] = Field(None, description="Fallback value")
    
    # Documentation
    description: Optional[str] = Field(None, description="Key description")
    usage_examples: Optional[List[str]] = Field(None, description="Usage examples")
    context_help: Optional[str] = Field(None, description="Context help")
    
    @validator('data_type')
    def validate_data_type(cls, v):
        if v not in ['string', 'html', 'markdown', 'json', 'array']:
            raise ValueError('Invalid data type')
        return v
    
    @validator('translation_priority')
    def validate_translation_priority(cls, v):
        if v not in ['critical', 'high', 'normal', 'low']:
            raise ValueError('Invalid translation priority')
        return v
    
    @validator('business_impact')
    def validate_business_impact(cls, v):
        if v not in ['high', 'medium', 'low']:
            raise ValueError('Invalid business impact')
        return v


class LanguageKeyResponse(BaseResponse):
    """Schema for language key response"""
    
    key_name: str
    key_category: Optional[str]
    context: Optional[str]
    module: Optional[str]
    component: Optional[str]
    feature: Optional[str]
    
    # Content Type
    data_type: str
    is_html: bool
    is_plural: bool
    has_variables: bool
    
    # Variables
    variables: Optional[List[str]]
    variable_types: Optional[Dict[str, str]]
    
    # Constraints
    max_length: Optional[int]
    min_length: Optional[int]
    validation_pattern: Optional[str]
    validation_rules: Optional[Dict[str, Any]]
    
    # Usage Statistics
    usage_count: int
    last_used: Optional[datetime]
    first_used: Optional[datetime]
    
    # Lifecycle
    is_deprecated: bool
    deprecation_date: Optional[datetime]
    replacement_key: Optional[str]
    removal_date: Optional[datetime]
    
    # Priority
    translation_priority: str
    business_impact: str
    
    # Default Content
    default_value: Optional[str]
    fallback_value: Optional[str]
    
    # Quality
    translation_completeness: Decimal
    quality_score: Optional[Decimal]
    
    # Documentation
    description: Optional[str]
    usage_examples: Optional[List[str]]
    context_help: Optional[str]
    
    # Metadata
    tags: Optional[List[str]]


# Effective Language Resolution Schema

class EffectiveLanguageRequest(BaseModel):
    """Schema for effective language resolution request"""
    
    user_id: Optional[UUID] = Field(None, description="User ID")
    company_id: Optional[UUID] = Field(None, description="Company ID")
    fallback_language: str = Field("en", description="Fallback language code")


class EffectiveLanguageResponse(BaseModel):
    """Schema for effective language response"""
    
    effective_language_code: str = Field(..., description="Effective language code")
    source: str = Field(..., description="Source of language preference")
    language_info: LanguageResponse = Field(..., description="Language details")
    locale_info: Optional[LocaleResponse] = Field(None, description="Locale details")
    
    class Config:
        schema_extra = {
            "example": {
                "effective_language_code": "en",
                "source": "user_preference",
                "language_info": {
                    "language_code": "en",
                    "language_name": "English",
                    "native_name": "English",
                    "text_direction": "ltr"
                },
                "locale_info": {
                    "locale_code": "en_US",
                    "currency_code": "USD",
                    "date_format": "MM/dd/yyyy"
                }
            }
        }