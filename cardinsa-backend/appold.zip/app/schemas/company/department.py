"""
Department and Organizational Structure Schemas

Pydantic schemas for department management, organizational hierarchy,
units, and user assignments.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, List, Dict, Any
from uuid import UUID

from pydantic import BaseModel, Field, validator
from app.schemas.base import BaseResponse, PaginatedResponse


# Department Schemas

class DepartmentBase(BaseModel):
    """Base department schema with common fields"""
    
    department_name: str = Field(..., min_length=1, max_length=100, description="Department name")
    description: Optional[str] = Field(None, description="Department description")
    
    # Type and Classification
    department_type: str = Field("operational", description="Department type")
    business_function: Optional[str] = Field(None, max_length=100, description="Business function")
    
    # Contact Information
    primary_email: Optional[str] = Field(None, max_length=255, description="Primary email")
    primary_phone: Optional[str] = Field(None, max_length=50, description="Primary phone")
    extension: Optional[str] = Field(None, max_length=20, description="Phone extension")
    
    # Location
    office_location: Optional[str] = Field(None, max_length=200, description="Office location")
    floor: Optional[str] = Field(None, max_length=20, description="Floor")
    building: Optional[str] = Field(None, max_length=100, description="Building")
    
    # Financial
    cost_center: Optional[str] = Field(None, max_length=50, description="Cost center")
    budget_code: Optional[str] = Field(None, max_length=50, description="Budget code")
    annual_budget: Optional[Decimal] = Field(None, ge=0, description="Annual budget")
    currency: Optional[str] = Field(None, max_length=3, description="Budget currency")
    
    # Operational
    working_hours: Optional[Dict[str, Any]] = Field(None, description="Working hours schedule")
    timezone: Optional[str] = Field(None, max_length=100, description="Department timezone")
    
    @validator('department_type')
    def validate_department_type(cls, v):
        valid_types = ['operational', 'support', 'executive', 'administrative', 'technical']
        if v not in valid_types:
            raise ValueError(f'Department type must be one of: {", ".join(valid_types)}')
        return v
    
    @validator('business_function')
    def validate_business_function(cls, v):
        if v:
            valid_functions = [
                'underwriting', 'claims', 'sales', 'customer_service', 
                'finance', 'hr', 'it', 'legal', 'compliance', 'marketing'
            ]
            if v not in valid_functions:
                raise ValueError(f'Business function must be one of: {", ".join(valid_functions)}')
        return v


class DepartmentCreate(DepartmentBase):
    """Schema for creating a new department"""
    
    company_id: UUID = Field(..., description="Company ID")
    parent_department_id: Optional[UUID] = Field(None, description="Parent department ID")
    department_code: Optional[str] = Field(None, max_length=20, description="Department code")
    
    # Management
    head_of_department_id: Optional[UUID] = Field(None, description="Head of department user ID")
    deputy_head_id: Optional[UUID] = Field(None, description="Deputy head user ID")
    
    # Geographic
    city_id: Optional[UUID] = Field(None, description="City ID")
    region_id: Optional[UUID] = Field(None, description="Region ID")
    country_id: Optional[UUID] = Field(None, description="Country ID")
    
    # Capacity
    max_capacity: Optional[int] = Field(None, ge=1, description="Maximum capacity")
    target_headcount: Optional[int] = Field(None, ge=1, description="Target headcount")
    
    # Configuration
    security_level: str = Field("standard", description="Security level")
    business_priority: str = Field("normal", description="Business priority")
    strategic_importance: str = Field("medium", description="Strategic importance")
    
    # Additional Data
    product_lines: Optional[List[str]] = Field(None, description="Product lines handled")
    regulatory_scope: Optional[List[str]] = Field(None, description="Regulatory areas")
    license_requirements: Optional[List[str]] = Field(None, description="License requirements")
    
    @validator('security_level')
    def validate_security_level(cls, v):
        valid_levels = ['public', 'internal', 'confidential', 'restricted', 'top_secret']
        if v not in valid_levels:
            raise ValueError(f'Security level must be one of: {", ".join(valid_levels)}')
        return v
    
    @validator('business_priority')
    def validate_business_priority(cls, v):
        if v not in ['critical', 'high', 'normal', 'low']:
            raise ValueError('Business priority must be critical, high, normal, or low')
        return v
    
    @validator('strategic_importance')
    def validate_strategic_importance(cls, v):
        if v not in ['high', 'medium', 'low']:
            raise ValueError('Strategic importance must be high, medium, or low')
        return v


class DepartmentUpdate(BaseModel):
    """Schema for updating department information"""
    
    department_name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = Field(None)
    
    department_type: Optional[str] = Field(None)
    business_function: Optional[str] = Field(None, max_length=100)
    
    primary_email: Optional[str] = Field(None, max_length=255)
    primary_phone: Optional[str] = Field(None, max_length=50)
    extension: Optional[str] = Field(None, max_length=20)
    
    office_location: Optional[str] = Field(None, max_length=200)
    floor: Optional[str] = Field(None, max_length=20)
    building: Optional[str] = Field(None, max_length=100)
    
    cost_center: Optional[str] = Field(None, max_length=50)
    budget_code: Optional[str] = Field(None, max_length=50)
    annual_budget: Optional[Decimal] = Field(None, ge=0)
    currency: Optional[str] = Field(None, max_length=3)
    
    working_hours: Optional[Dict[str, Any]] = Field(None)
    timezone: Optional[str] = Field(None, max_length=100)
    
    head_of_department_id: Optional[UUID] = Field(None)
    deputy_head_id: Optional[UUID] = Field(None)
    
    max_capacity: Optional[int] = Field(None, ge=1)
    target_headcount: Optional[int] = Field(None, ge=1)
    
    security_level: Optional[str] = Field(None)
    business_priority: Optional[str] = Field(None)
    strategic_importance: Optional[str] = Field(None)
    
    product_lines: Optional[List[str]] = Field(None)
    regulatory_scope: Optional[List[str]] = Field(None)
    license_requirements: Optional[List[str]] = Field(None)
    
    custom_fields: Optional[Dict[str, Any]] = Field(None)
    notes: Optional[str] = Field(None)


class DepartmentResponse(BaseResponse):
    """Schema for department response data"""
    
    # Basic Information
    department_name: str
    department_code: str
    description: Optional[str]
    
    # Company and Hierarchy
    company_id: UUID
    parent_department_id: Optional[UUID]
    department_level: int
    department_path: Optional[str]
    
    # Type and Classification
    department_type: str
    business_function: Optional[str]
    
    # Management
    head_of_department_id: Optional[UUID]
    deputy_head_id: Optional[UUID]
    
    # Contact Information
    primary_email: Optional[str]
    primary_phone: Optional[str]
    extension: Optional[str]
    
    # Location
    office_location: Optional[str]
    floor: Optional[str]
    building: Optional[str]
    room_numbers: Optional[List[str]]
    
    # Geographic
    city_id: Optional[UUID]
    region_id: Optional[UUID]
    country_id: Optional[UUID]
    
    # Operational
    working_hours: Optional[Dict[str, Any]]
    timezone: Optional[str]
    holiday_calendar: Optional[str]
    
    # Financial
    cost_center: Optional[str]
    budget_code: Optional[str]
    annual_budget: Optional[Decimal]
    currency: Optional[str]
    
    # Staffing
    max_capacity: Optional[int]
    current_headcount: int
    target_headcount: Optional[int]
    
    # Configuration
    security_level: str
    business_priority: str
    strategic_importance: str
    
    # Status
    department_status: str
    effective_date: Optional[datetime]
    dissolution_date: Optional[datetime]
    
    # Insurance-Specific
    product_lines: Optional[List[str]]
    regulatory_scope: Optional[List[str]]
    license_requirements: Optional[List[str]]
    
    # Performance
    performance_metrics: Optional[Dict[str, Any]]
    kpi_targets: Optional[Dict[str, Any]]
    
    # Additional Data
    custom_fields: Optional[Dict[str, Any]]
    notes: Optional[str]


class DepartmentHierarchyNode(BaseModel):
    """Schema for a node in department hierarchy tree"""
    
    id: UUID = Field(..., description="Department ID")
    name: str = Field(..., description="Department name")
    code: str = Field(..., description="Department code")
    level: int = Field(..., description="Hierarchy level")
    status: str = Field(..., description="Department status")
    headcount: int = Field(..., description="Current headcount")
    children: List['DepartmentHierarchyNode'] = Field(default_factory=list, description="Child departments")


class DepartmentHierarchyResponse(BaseModel):
    """Schema for department hierarchy response"""
    
    departments: List[DepartmentHierarchyNode] = Field(..., description="Department hierarchy tree")
    total_departments: int = Field(..., description="Total departments in hierarchy")
    max_depth: int = Field(..., description="Maximum hierarchy depth")


class DepartmentMember(BaseModel):
    """Schema for department member information"""
    
    id: UUID = Field(..., description="User ID")
    name: str = Field(..., description="Full name")
    email: str = Field(..., description="Email address")
    unit_id: Optional[UUID] = Field(None, description="Unit ID")
    is_head: bool = Field(False, description="Is head of department")
    is_deputy: bool = Field(False, description="Is deputy head")


class DepartmentMembersResponse(BaseModel):
    """Schema for department members response"""
    
    department: Dict[str, Any] = Field(..., description="Department information")
    total_members: int = Field(..., description="Total number of members")
    members: List[DepartmentMember] = Field(..., description="Department members")
    units: Optional[List[Dict[str, Any]]] = Field(None, description="Units with members")


# Unit Schemas

class UnitBase(BaseModel):
    """Base unit schema with common fields"""
    
    unit_name: str = Field(..., min_length=1, max_length=100, description="Unit name")
    description: Optional[str] = Field(None, description="Unit description")
    
    # Type and Specialization
    unit_type: str = Field("team", description="Unit type")
    specialization: Optional[str] = Field(None, max_length=100, description="Unit specialization")
    
    # Contact Information
    unit_email: Optional[str] = Field(None, max_length=255, description="Unit email")
    unit_phone: Optional[str] = Field(None, max_length=50, description="Unit phone")
    extension: Optional[str] = Field(None, max_length=20, description="Phone extension")
    
    # Location
    location: Optional[str] = Field(None, max_length=200, description="Unit location")
    floor: Optional[str] = Field(None, max_length=20, description="Floor")
    room_number: Optional[str] = Field(None, max_length=20, description="Room number")
    
    @validator('unit_type')
    def validate_unit_type(cls, v):
        valid_types = ['team', 'squad', 'group', 'section', 'division', 'bureau']
        if v not in valid_types:
            raise ValueError(f'Unit type must be one of: {", ".join(valid_types)}')
        return v


class UnitCreate(UnitBase):
    """Schema for creating a new unit"""
    
    department_id: UUID = Field(..., description="Department ID")
    unit_code: Optional[str] = Field(None, max_length=20, description="Unit code")
    
    # Management
    unit_manager_id: Optional[UUID] = Field(None, description="Unit manager user ID")
    assistant_manager_id: Optional[UUID] = Field(None, description="Assistant manager user ID")
    
    # Capacity
    max_members: Optional[int] = Field(None, ge=1, description="Maximum members")
    optimal_size: Optional[int] = Field(None, ge=1, description="Optimal size")
    
    # Operational
    working_schedule: Optional[Dict[str, Any]] = Field(None, description="Working schedule")
    shift_pattern: Optional[str] = Field(None, max_length=50, description="Shift pattern")
    
    # Skills and Requirements
    required_skills: Optional[List[str]] = Field(None, description="Required skills")
    skill_levels: Optional[Dict[str, str]] = Field(None, description="Skill level requirements")
    certifications_required: Optional[List[str]] = Field(None, description="Required certifications")
    
    # Financial
    cost_center: Optional[str] = Field(None, max_length=50, description="Cost center")
    budget_allocation: Optional[Decimal] = Field(None, ge=0, description="Budget allocation")
    
    # Configuration
    business_criticality: str = Field("normal", description="Business criticality")
    security_clearance: Optional[str] = Field(None, max_length=50, description="Security clearance")
    
    # Insurance-Specific
    product_specialization: Optional[List[str]] = Field(None, description="Product specialization")
    customer_segments: Optional[List[str]] = Field(None, description="Customer segments served")
    regulatory_functions: Optional[List[str]] = Field(None, description="Regulatory functions")
    
    # Performance and Analytics
    performance_targets: Optional[Dict[str, Any]] = Field(None, description="Performance targets")
    custom_fields: Optional[Dict[str, Any]] = Field(None, description="Custom fields")
    notes: Optional[str] = Field(None, description="Additional notes")
    
    @validator('business_criticality')
    def validate_business_criticality(cls, v):
        if v not in ['critical', 'high', 'normal', 'low']:
            raise ValueError('Business criticality must be critical, high, normal, or low')
        return v


class UnitUpdate(BaseModel):
    """Schema for updating unit information"""
    
    unit_name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = Field(None)
    
    unit_type: Optional[str] = Field(None)
    specialization: Optional[str] = Field(None, max_length=100)
    
    unit_email: Optional[str] = Field(None, max_length=255)
    unit_phone: Optional[str] = Field(None, max_length=50)
    extension: Optional[str] = Field(None, max_length=20)
    
    location: Optional[str] = Field(None, max_length=200)
    floor: Optional[str] = Field(None, max_length=20)
    room_number: Optional[str] = Field(None, max_length=20)
    
    unit_manager_id: Optional[UUID] = Field(None)
    assistant_manager_id: Optional[UUID] = Field(None)
    
    max_members: Optional[int] = Field(None, ge=1)
    optimal_size: Optional[int] = Field(None, ge=1)
    
    working_schedule: Optional[Dict[str, Any]] = Field(None)
    shift_pattern: Optional[str] = Field(None, max_length=50)
    
    required_skills: Optional[List[str]] = Field(None)
    skill_levels: Optional[Dict[str, str]] = Field(None)
    certifications_required: Optional[List[str]] = Field(None)
    
    cost_center: Optional[str] = Field(None, max_length=50)
    budget_allocation: Optional[Decimal] = Field(None, ge=0)
    
    business_criticality: Optional[str] = Field(None)
    security_clearance: Optional[str] = Field(None, max_length=50)
    
    product_specialization: Optional[List[str]] = Field(None)
    customer_segments: Optional[List[str]] = Field(None)
    regulatory_functions: Optional[List[str]] = Field(None)
    
    performance_targets: Optional[Dict[str, Any]] = Field(None)
    custom_fields: Optional[Dict[str, Any]] = Field(None)
    notes: Optional[str] = Field(None)


class UnitResponse(BaseResponse):
    """Schema for unit response data"""
    
    # Basic Information
    unit_name: str
    unit_code: str
    description: Optional[str]
    
    # Department Association
    department_id: UUID
    
    # Type and Specialization
    unit_type: str
    specialization: Optional[str]
    
    # Management
    unit_manager_id: Optional[UUID]
    assistant_manager_id: Optional[UUID]
    
    # Contact Information
    unit_email: Optional[str]
    unit_phone: Optional[str]
    extension: Optional[str]
    
    # Location
    location: Optional[str]
    floor: Optional[str]
    room_number: Optional[str]
    seating_arrangement: Optional[str]
    
    # Operational
    working_schedule: Optional[Dict[str, Any]]
    shift_pattern: Optional[str]
    break_schedule: Optional[Dict[str, Any]]
    
    # Staffing
    max_members: Optional[int]
    current_members: int
    optimal_size: Optional[int]
    
    # Skills and Requirements
    required_skills: Optional[List[str]]
    skill_levels: Optional[Dict[str, str]]
    certifications_required: Optional[List[str]]
    
    # Performance
    performance_targets: Optional[Dict[str, Any]]
    productivity_metrics: Optional[Dict[str, Any]]
    quality_standards: Optional[Dict[str, Any]]
    
    # Financial
    cost_center: Optional[str]
    budget_allocation: Optional[Decimal]
    overhead_percentage: Optional[Decimal]
    
    # Processes and Tools
    primary_processes: Optional[List[str]]
    secondary_processes: Optional[List[str]]
    software_tools: Optional[List[str]]
    
    # Insurance-Specific
    product_specialization: Optional[List[str]]
    customer_segments: Optional[List[str]]
    regulatory_functions: Optional[List[str]]
    
    # Configuration
    business_criticality: str
    security_clearance: Optional[str]
    
    # Status
    unit_status: str
    formation_date: Optional[datetime]
    dissolution_date: Optional[datetime]
    
    # Additional Data
    custom_fields: Optional[Dict[str, Any]]
    notes: Optional[str]


class UnitMember(BaseModel):
    """Schema for unit member information"""
    
    id: UUID = Field(..., description="User ID")
    name: str = Field(..., description="Full name")
    email: str = Field(..., description="Email address")
    is_manager: bool = Field(False, description="Is unit manager")
    is_assistant_manager: bool = Field(False, description="Is assistant manager")


class UnitMembersResponse(BaseModel):
    """Schema for unit members response"""
    
    unit: Dict[str, Any] = Field(..., description="Unit information")
    total_members: int = Field(..., description="Total number of members")
    members: List[UnitMember] = Field(..., description="Unit members")
    capacity_info: Dict[str, Any] = Field(..., description="Capacity information")


# User Assignment Schemas

class UserAssignmentRequest(BaseModel):
    """Schema for user assignment requests"""
    
    user_id: UUID = Field(..., description="User ID to assign")
    department_id: Optional[UUID] = Field(None, description="Department ID")
    unit_id: Optional[UUID] = Field(None, description="Unit ID")
    
    @validator('department_id', 'unit_id')
    def validate_assignment_target(cls, v, values):
        department_id = values.get('department_id')
        unit_id = values.get('unit_id')
        
        if not department_id and not unit_id:
            raise ValueError('Either department_id or unit_id must be provided')
        return v


class UserAssignmentResponse(BaseModel):
    """Schema for user assignment response"""
    
    user_id: UUID = Field(..., description="Assigned user ID")
    previous_assignment: Optional[Dict[str, Any]] = Field(None, description="Previous assignment")
    new_assignment: Dict[str, Any] = Field(..., description="New assignment")
    assignment_date: datetime = Field(..., description="Assignment timestamp")
    assigned_by: UUID = Field(..., description="User who made the assignment")


class BulkUserAssignmentRequest(BaseModel):
    """Schema for bulk user assignment"""
    
    assignments: List[UserAssignmentRequest] = Field(..., min_items=1, max_items=100, description="User assignments")
    
    @validator('assignments')
    def validate_assignments(cls, v):
        if len(v) > 100:
            raise ValueError('Cannot assign more than 100 users at once')
        return v


class BulkUserAssignmentResponse(BaseModel):
    """Schema for bulk assignment response"""
    
    successful_assignments: int = Field(..., description="Number of successful assignments")
    failed_assignments: int = Field(..., description="Number of failed assignments")
    assignment_details: List[Dict[str, Any]] = Field(..., description="Assignment details")
    errors: List[str] = Field(default_factory=list, description="Assignment errors")


# Statistics and Analytics Schemas

class DepartmentStatistics(BaseModel):
    """Schema for department statistics"""
    
    department_id: UUID = Field(..., description="Department ID")
    department_name: str = Field(..., description="Department name")
    
    # Basic Stats
    total_members: int = Field(..., description="Total members")
    total_units: int = Field(..., description="Total units")
    active_units: int = Field(..., description="Active units")
    
    # Capacity
    max_capacity: Optional[int] = Field(None, description="Maximum capacity")
    utilization_rate: Optional[float] = Field(None, description="Capacity utilization rate")
    
    # Financial
    total_budget: Optional[Decimal] = Field(None, description="Total budget")
    budget_utilization: Optional[float] = Field(None, description="Budget utilization percentage")
    
    # Performance
    performance_score: Optional[float] = Field(None, description="Performance score")
    kpi_achievement: Optional[Dict[str, float]] = Field(None, description="KPI achievement rates")


class OrganizationalStatistics(BaseModel):
    """Schema for organizational statistics"""
    
    # Department Statistics
    departments: Dict[str, int] = Field(..., description="Department statistics")
    
    # Unit Statistics
    units: Dict[str, int] = Field(..., description="Unit statistics")
    
    # User Assignment Statistics
    users: Dict[str, int] = Field(..., description="User assignment statistics")
    
    # Hierarchy Information
    hierarchy: Dict[str, int] = Field(..., description="Hierarchy statistics")
    
    class Config:
        schema_extra = {
            "example": {
                "departments": {
                    "total": 12,
                    "active": 11,
                    "average_headcount": 15.5
                },
                "units": {
                    "total": 45,
                    "active": 42,
                    "average_members": 6.8
                },
                "users": {
                    "total": 186,
                    "assigned_to_department": 180,
                    "assigned_to_unit": 165,
                    "unassigned": 6
                },
                "hierarchy": {
                    "max_depth": 4,
                    "total_levels": 4
                }
            }
        }


class DepartmentPerformanceMetrics(BaseModel):
    """Schema for department performance metrics"""
    
    department_info: Dict[str, Any] = Field(..., description="Department information")
    
    # Staffing Metrics
    staffing: Dict[str, Any] = Field(..., description="Staffing metrics")
    
    # Unit Metrics
    units: Dict[str, int] = Field(..., description="Unit metrics")
    
    # Performance Targets
    performance_targets: Optional[Dict[str, Any]] = Field(None, description="Performance targets")
    
    # Efficiency Metrics
    efficiency_metrics: Optional[Dict[str, float]] = Field(None, description="Efficiency metrics")
    
    # Quality Metrics
    quality_metrics: Optional[Dict[str, float]] = Field(None, description="Quality metrics")
    
    class Config:
        schema_extra = {
            "example": {
                "department_info": {
                    "id": "123e4567-e89b-12d3-a456-426614174000",
                    "name": "Claims Processing",
                    "status": "active"
                },
                "staffing": {
                    "current_headcount": 25,
                    "target_headcount": 28,
                    "max_capacity": 35,
                    "utilization_rate": 71.4
                },
                "units": {
                    "total_units": 4,
                    "active_units": 4,
                    "units_at_capacity": 1
                },
                "performance_targets": {
                    "claims_processed_per_day": 150,
                    "average_processing_time_hours": 24,
                    "customer_satisfaction_score": 4.5
                }
            }
        }


# Search and Filter Schemas

class DepartmentSearchParams(BaseModel):
    """Schema for department search parameters"""
    
    company_id: UUID = Field(..., description="Company ID")
    search_term: Optional[str] = Field(None, description="Search in department name")
    department_type: Optional[str] = Field(None, description="Filter by department type")
    business_function: Optional[str] = Field(None, description="Filter by business function")
    status: Optional[str] = Field(None, description="Filter by department status")
    parent_department_id: Optional[UUID] = Field(None, description="Filter by parent department")
    
    # Capacity filters
    min_headcount: Optional[int] = Field(None, ge=0, description="Minimum headcount")
    max_headcount: Optional[int] = Field(None, ge=0, description="Maximum headcount")
    
    # Geographic filters
    city_id: Optional[UUID] = Field(None, description="Filter by city")
    region_id: Optional[UUID] = Field(None, description="Filter by region")
    country_id: Optional[UUID] = Field(None, description="Filter by country")
    
    # Sorting
    sort_by: str = Field("department_name", description="Sort field")
    sort_order: str = Field("asc", description="Sort order")
    
    # Pagination
    page: int = Field(1, ge=1, description="Page number")
    page_size: int = Field(50, ge=1, le=200, description="Page size")


class UnitSearchParams(BaseModel):
    """Schema for unit search parameters"""
    
    department_id: UUID = Field(..., description="Department ID")
    search_term: Optional[str] = Field(None, description="Search in unit name")
    unit_type: Optional[str] = Field(None, description="Filter by unit type")
    specialization: Optional[str] = Field(None, description="Filter by specialization")
    status: Optional[str] = Field(None, description="Filter by unit status")
    business_criticality: Optional[str] = Field(None, description="Filter by business criticality")
    
    # Capacity filters
    min_members: Optional[int] = Field(None, ge=0, description="Minimum members")
    max_members: Optional[int] = Field(None, ge=0, description="Maximum members")
    at_capacity: Optional[bool] = Field(None, description="Filter units at capacity")
    
    # Sorting
    sort_by: str = Field("unit_name", description="Sort field")
    sort_order: str = Field("asc", description="Sort order")
    
    # Pagination
    page: int = Field(1, ge=1, description="Page number")
    page_size: int = Field(50, ge=1, le=200, description="Page size")


# Management Action Schemas

class HeadAssignmentRequest(BaseModel):
    """Schema for head of department assignment"""
    
    department_id: UUID = Field(..., description="Department ID")
    user_id: UUID = Field(..., description="User ID to assign as head")
    effective_date: Optional[datetime] = Field(None, description="Effective date")
    comments: Optional[str] = Field(None, description="Assignment comments")


class ManagerAssignmentRequest(BaseModel):
    """Schema for unit manager assignment"""
    
    unit_id: UUID = Field(..., description="Unit ID")
    user_id: UUID = Field(..., description="User ID to assign as manager")
    role: str = Field("manager", description="Manager role")
    effective_date: Optional[datetime] = Field(None, description="Effective date")
    comments: Optional[str] = Field(None, description="Assignment comments")
    
    @validator('role')
    def validate_role(cls, v):
        if v not in ['manager', 'assistant_manager']:
            raise ValueError('Role must be manager or assistant_manager')
        return v


class ManagementAssignmentResponse(BaseModel):
    """Schema for management assignment response"""
    
    assignment_id: UUID = Field(..., description="Assignment ID")
    entity_type: str = Field(..., description="Entity type (department/unit)")
    entity_id: UUID = Field(..., description="Entity ID")
    user_id: UUID = Field(..., description="Assigned user ID")
    role: str = Field(..., description="Assigned role")
    effective_date: datetime = Field(..., description="Effective date")
    assigned_by: UUID = Field(..., description="User who made the assignment")
    status: str = Field(..., description="Assignment status")


# Capacity Management Schemas

class CapacityAnalysis(BaseModel):
    """Schema for capacity analysis"""
    
    entity_type: str = Field(..., description="Entity type (department/unit)")
    entity_id: UUID = Field(..., description="Entity ID")
    entity_name: str = Field(..., description="Entity name")
    
    # Current State
    current_capacity: int = Field(..., description="Current member count")
    max_capacity: Optional[int] = Field(None, description="Maximum capacity")
    target_capacity: Optional[int] = Field(None, description="Target capacity")
    
    # Utilization
    utilization_rate: Optional[float] = Field(None, description="Utilization percentage")
    capacity_status: str = Field(..., description="Capacity status")
    
    # Recommendations
    recommended_actions: List[str] = Field(default_factory=list, description="Capacity recommendations")
    
    @validator('capacity_status')
    def validate_capacity_status(cls, v):
        valid_statuses = ['under_capacity', 'optimal', 'at_capacity', 'over_capacity']
        if v not in valid_statuses:
            raise ValueError(f'Capacity status must be one of: {", ".join(valid_statuses)}')
        return v


class CapacityPlanningRequest(BaseModel):
    """Schema for capacity planning request"""
    
    entity_type: str = Field(..., description="Entity type (department/unit)")
    entity_ids: List[UUID] = Field(..., min_items=1, description="Entity IDs to analyze")
    planning_horizon_months: int = Field(12, ge=1, le=60, description="Planning horizon in months")
    include_growth_projections: bool = Field(True, description="Include growth projections")
    
    @validator('entity_type')
    def validate_entity_type(cls, v):
        if v not in ['department', 'unit']:
            raise ValueError('Entity type must be department or unit')
        return v


class CapacityPlanningResponse(BaseModel):
    """Schema for capacity planning response"""
    
    analysis_id: UUID = Field(..., description="Analysis ID")
    entity_type: str = Field(..., description="Entity type")
    planning_horizon_months: int = Field(..., description="Planning horizon")
    generated_at: datetime = Field(..., description="Analysis generation time")
    
    # Analysis Results
    capacity_analyses: List[CapacityAnalysis] = Field(..., description="Individual capacity analyses")
    
    # Summary
    total_entities: int = Field(..., description="Total entities analyzed")
    entities_over_capacity: int = Field(..., description="Entities over capacity")
    entities_under_capacity: int = Field(..., description="Entities under capacity")
    
    # Recommendations
    strategic_recommendations: List[str] = Field(default_factory=list, description="Strategic recommendations")
    resource_requirements: Dict[str, Any] = Field(default_factory=dict, description="Resource requirements")


# Organizational Reporting Schemas

class OrganizationalChart(BaseModel):
    """Schema for organizational chart data"""
    
    chart_id: UUID = Field(..., description="Chart ID")
    company_id: UUID = Field(..., description="Company ID")
    chart_type: str = Field(..., description="Chart type")
    
    # Chart Data
    departments: List[DepartmentHierarchyNode] = Field(..., description="Department nodes")
    connections: List[Dict[str, Any]] = Field(..., description="Organizational connections")
    
    # Metadata
    total_positions: int = Field(..., description="Total positions")
    filled_positions: int = Field(..., description="Filled positions")
    vacant_positions: int = Field(..., description="Vacant positions")
    
    # Generation Info
    generated_at: datetime = Field(..., description="Chart generation time")
    generated_by: UUID = Field(..., description="User who generated chart")
    
    @validator('chart_type')
    def validate_chart_type(cls, v):
        valid_types = ['functional', 'hierarchical', 'matrix', 'flat']
        if v not in valid_types:
            raise ValueError(f'Chart type must be one of: {", ".join(valid_types)}')
        return v


class DepartmentComparisonRequest(BaseModel):
    """Schema for department comparison request"""
    
    department_ids: List[UUID] = Field(..., min_items=2, max_items=10, description="Departments to compare")
    comparison_metrics: List[str] = Field(..., description="Metrics to compare")
    time_period: Optional[Dict[str, Any]] = Field(None, description="Time period for comparison")
    
    @validator('comparison_metrics')
    def validate_comparison_metrics(cls, v):
        valid_metrics = [
            'headcount', 'budget', 'performance', 'efficiency',
            'utilization', 'turnover', 'satisfaction', 'productivity'
        ]
        for metric in v:
            if metric not in valid_metrics:
                raise ValueError(f'Invalid metric: {metric}. Must be one of: {", ".join(valid_metrics)}')
        return v


class DepartmentComparisonResponse(BaseModel):
    """Schema for department comparison response"""
    
    comparison_id: UUID = Field(..., description="Comparison ID")
    departments: List[Dict[str, Any]] = Field(..., description="Department data")
    metrics: Dict[str, Any] = Field(..., description="Comparison metrics")
    insights: List[str] = Field(default_factory=list, description="Key insights")
    recommendations: List[str] = Field(default_factory=list, description="Recommendations")
    generated_at: datetime = Field(..., description="Comparison generation time")


# Workflow and Process Schemas

class DepartmentWorkflowRequest(BaseModel):
    """Schema for department workflow creation"""
    
    department_id: UUID = Field(..., description="Department ID")
    workflow_name: str = Field(..., min_length=1, max_length=100, description="Workflow name")
    workflow_type: str = Field(..., description="Workflow type")
    description: Optional[str] = Field(None, description="Workflow description")
    
    # Workflow Steps
    steps: List[Dict[str, Any]] = Field(..., min_items=1, description="Workflow steps")
    
    # Configuration
    auto_execute: bool = Field(False, description="Auto-execute workflow")
    requires_approval: bool = Field(True, description="Requires approval")
    approval_roles: Optional[List[str]] = Field(None, description="Roles that can approve")
    
    @validator('workflow_type')
    def validate_workflow_type(cls, v):
        valid_types = ['onboarding', 'offboarding', 'transfer', 'promotion', 'restructuring']
        if v not in valid_types:
            raise ValueError(f'Workflow type must be one of: {", ".join(valid_types)}')
        return v


class DepartmentWorkflowResponse(BaseModel):
    """Schema for department workflow response"""
    
    workflow_id: UUID = Field(..., description="Workflow ID")
    department_id: UUID = Field(..., description="Department ID")
    workflow_name: str = Field(..., description="Workflow name")
    workflow_type: str = Field(..., description="Workflow type")
    status: str = Field(..., description="Workflow status")
    
    # Execution Data
    steps: List[Dict[str, Any]] = Field(..., description="Workflow steps")
    current_step: Optional[int] = Field(None, description="Current step index")
    completion_percentage: float = Field(..., description="Completion percentage")
    
    # Metadata
    created_at: datetime = Field(..., description="Creation timestamp")
    started_at: Optional[datetime] = Field(None, description="Start timestamp")
    completed_at: Optional[datetime] = Field(None, description="Completion timestamp")
    created_by: UUID = Field(..., description="Creator user ID")


# Advanced Analytics Schemas

class DepartmentTrendAnalysis(BaseModel):
    """Schema for department trend analysis"""
    
    department_id: UUID = Field(..., description="Department ID")
    analysis_period: Dict[str, Any] = Field(..., description="Analysis period")
    
    # Trend Data
    headcount_trends: Dict[str, Any] = Field(..., description="Headcount trends")
    budget_trends: Dict[str, Any] = Field(..., description="Budget trends")
    performance_trends: Dict[str, Any] = Field(..., description="Performance trends")
    efficiency_trends: Dict[str, Any] = Field(..., description="Efficiency trends")
    
    # Predictions
    future_projections: Dict[str, Any] = Field(..., description="Future projections")
    risk_factors: List[str] = Field(default_factory=list, description="Identified risk factors")
    opportunities: List[str] = Field(default_factory=list, description="Identified opportunities")
    
    # Recommendations
    strategic_recommendations: List[str] = Field(default_factory=list, description="Strategic recommendations")
    tactical_recommendations: List[str] = Field(default_factory=list, description="Tactical recommendations")


class DepartmentBenchmarkingRequest(BaseModel):
    """Schema for department benchmarking request"""
    
    department_id: UUID = Field(..., description="Department ID to benchmark")
    benchmark_type: str = Field(..., description="Benchmarking type")
    comparison_groups: List[str] = Field(..., description="Comparison groups")
    metrics: List[str] = Field(..., description="Metrics to benchmark")
    
    @validator('benchmark_type')
    def validate_benchmark_type(cls, v):
        valid_types = ['internal', 'industry', 'best_practice', 'competitive']
        if v not in valid_types:
            raise ValueError(f'Benchmark type must be one of: {", ".join(valid_types)}')
        return v


class DepartmentBenchmarkingResponse(BaseModel):
    """Schema for department benchmarking response"""
    
    benchmark_id: UUID = Field(..., description="Benchmark ID")
    department_info: Dict[str, Any] = Field(..., description="Department information")
    benchmark_results: Dict[str, Any] = Field(..., description="Benchmarking results")
    
    # Performance Comparison
    performance_gaps: List[Dict[str, Any]] = Field(..., description="Performance gaps")
    strengths: List[str] = Field(default_factory=list, description="Department strengths")
    improvement_areas: List[str] = Field(default_factory=list, description="Areas for improvement")
    
    # Action Plan
    recommended_actions: List[Dict[str, Any]] = Field(..., description="Recommended actions")
    implementation_timeline: Dict[str, Any] = Field(..., description="Implementation timeline")
    expected_outcomes: Dict[str, Any] = Field(..., description="Expected outcomes")


# Export and Import Schemas

class DepartmentExportRequest(BaseModel):
    """Schema for department data export"""
    
    department_ids: Optional[List[UUID]] = Field(None, description="Specific departments to export")
    include_units: bool = Field(True, description="Include unit data")
    include_members: bool = Field(True, description="Include member data")
    include_hierarchy: bool = Field(True, description="Include hierarchy data")
    include_metrics: bool = Field(False, description="Include performance metrics")
    
    # Export Format
    export_format: str = Field("json", description="Export format")
    compression: bool = Field(True, description="Compress export file")
    
    @validator('export_format')
    def validate_export_format(cls, v):
        valid_formats = ['json', 'csv', 'xlsx', 'xml']
        if v not in valid_formats:
            raise ValueError(f'Export format must be one of: {", ".join(valid_formats)}')
        return v


class DepartmentExportResponse(BaseModel):
    """Schema for department export response"""
    
    export_id: UUID = Field(..., description="Export ID")
    file_url: str = Field(..., description="Download URL")
    file_size: int = Field(..., description="File size in bytes")
    record_count: int = Field(..., description="Number of records exported")
    export_format: str = Field(..., description="Export format")
    
    # Metadata
    generated_at: datetime = Field(..., description="Export generation time")
    expires_at: datetime = Field(..., description="Download link expiration")
    generated_by: UUID = Field(..., description="User who generated export")


class DepartmentImportRequest(BaseModel):
    """Schema for department data import"""
    
    file_url: str = Field(..., description="Import file URL")
    import_mode: str = Field("create_only", description="Import mode")
    validate_only: bool = Field(False, description="Validation only mode")
    
    # Import Options
    skip_duplicates: bool = Field(True, description="Skip duplicate records")
    update_existing: bool = Field(False, description="Update existing records")
    create_hierarchy: bool = Field(True, description="Create hierarchy relationships")
    
    @validator('import_mode')
    def validate_import_mode(cls, v):
        valid_modes = ['create_only', 'update_only', 'create_and_update', 'replace']
        if v not in valid_modes:
            raise ValueError(f'Import mode must be one of: {", ".join(valid_modes)}')
        return v


class DepartmentImportResponse(BaseModel):
    """Schema for department import response"""
    
    import_id: UUID = Field(..., description="Import ID")
    status: str = Field(..., description="Import status")
    
    # Import Results
    total_records: int = Field(..., description="Total records processed")
    successful_imports: int = Field(..., description="Successful imports")
    failed_imports: int = Field(..., description="Failed imports")
    skipped_records: int = Field(..., description="Skipped records")
    
    # Details
    validation_errors: List[Dict[str, Any]] = Field(default_factory=list, description="Validation errors")
    import_errors: List[Dict[str, Any]] = Field(default_factory=list, description="Import errors")
    warnings: List[str] = Field(default_factory=list, description="Import warnings")
    
    # Metadata
    started_at: datetime = Field(..., description="Import start time")
    completed_at: Optional[datetime] = Field(None, description="Import completion time")
    imported_by: UUID = Field(..., description="User who initiated import")


# Fix the forward reference for DepartmentHierarchyNode
DepartmentHierarchyNode.model_rebuild()