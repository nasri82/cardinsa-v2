"""
Company Management Schemas

Pydantic schemas for company management, system configuration,
and company-related operations.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, List, Dict, Any
from uuid import UUID

from pydantic import BaseModel, Field, validator, EmailStr
from app.schemas.base import BaseResponse, PaginatedResponse


class CompanyBase(BaseModel):
    """Base company schema with common fields"""
    company_name: str = Field(..., min_length=1, max_length=255, description="Company name")
    legal_name: str = Field(..., min_length=1, max_length=255, description="Legal company name")
    company_code: Optional[str] = Field(None, max_length=50, description="Unique company code")
    registration_number: Optional[str] = Field(None, max_length=100, description="Company registration number")
    tax_id: Optional[str] = Field(None, max_length=100, description="Tax identification number")
    
    # Industry and Business
    industry_type: str = Field("insurance", max_length=100, description="Industry type")
    business_type: str = Field("insurance_company", max_length=50, description="Business type")
    company_size: Optional[str] = Field(None, max_length=50, description="Company size classification")
    
    # Contact Information
    primary_email: Optional[EmailStr] = Field(None, description="Primary company email")
    primary_phone: Optional[str] = Field(None, max_length=50, description="Primary phone number")
    website_url: Optional[str] = Field(None, max_length=500, description="Company website URL")
    
    # Address Information
    address_line1: Optional[str] = Field(None, max_length=255, description="Address line 1")
    address_line2: Optional[str] = Field(None, max_length=255, description="Address line 2")
    city: Optional[str] = Field(None, max_length=100, description="City")
    state_province: Optional[str] = Field(None, max_length=100, description="State or province")
    postal_code: Optional[str] = Field(None, max_length=20, description="Postal code")
    country_code: Optional[str] = Field(None, max_length=3, description="Country code")
    
    # Geographic and Operational
    primary_country_id: Optional[UUID] = Field(None, description="Primary country ID")
    headquarters_timezone: str = Field("UTC", max_length=100, description="Headquarters timezone")
    regulatory_region: Optional[str] = Field(None, max_length=100, description="Regulatory region")
    
    # Financial
    base_currency: str = Field("USD", max_length=3, description="Base currency code")
    supported_currencies: Optional[List[str]] = Field(None, description="Supported currencies")
    fiscal_year_start: Optional[int] = Field(1, ge=1, le=12, description="Fiscal year start month")
    
    # Branding
    logo_url: Optional[str] = Field(None, max_length=500, description="Company logo URL")
    favicon_url: Optional[str] = Field(None, max_length=500, description="Company favicon URL")
    brand_colors: Optional[Dict[str, Any]] = Field(None, description="Brand color scheme")
    
    @validator('company_size')
    def validate_company_size(cls, v):
        if v and v not in ['small', 'medium', 'large', 'enterprise']:
            raise ValueError('Invalid company size')
        return v
    
    @validator('base_currency')
    def validate_currency(cls, v):
        valid_currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF', 'CNY']
        if v not in valid_currencies:
            raise ValueError(f'Currency must be one of: {", ".join(valid_currencies)}')
        return v


class CompanyCreate(CompanyBase):
    """Schema for creating a new company"""
    
    # Additional fields for creation
    subscription_tier: str = Field("basic", description="Subscription tier")
    enabled_features: Optional[List[str]] = Field(None, description="Enabled features")
    compliance_requirements: Optional[List[str]] = Field(None, description="Compliance requirements")
    data_residency: Optional[str] = Field(None, max_length=100, description="Data residency requirement")
    
    # Admin user data (optional)
    admin_user: Optional[Dict[str, Any]] = Field(None, description="Admin user information")
    
    @validator('subscription_tier')
    def validate_subscription_tier(cls, v):
        if v not in ['basic', 'professional', 'enterprise', 'custom']:
            raise ValueError('Invalid subscription tier')
        return v


class CompanyUpdate(BaseModel):
    """Schema for updating company information"""
    
    # Optional fields for updates
    company_name: Optional[str] = Field(None, min_length=1, max_length=255)
    legal_name: Optional[str] = Field(None, min_length=1, max_length=255)
    primary_email: Optional[EmailStr] = Field(None)
    primary_phone: Optional[str] = Field(None, max_length=50)
    website_url: Optional[str] = Field(None, max_length=500)
    
    # Address updates
    address_line1: Optional[str] = Field(None, max_length=255)
    address_line2: Optional[str] = Field(None, max_length=255)
    city: Optional[str] = Field(None, max_length=100)
    state_province: Optional[str] = Field(None, max_length=100)
    postal_code: Optional[str] = Field(None, max_length=20)
    country_code: Optional[str] = Field(None, max_length=3)
    
    # Operational updates
    headquarters_timezone: Optional[str] = Field(None, max_length=100)
    regulatory_region: Optional[str] = Field(None, max_length=100)
    base_currency: Optional[str] = Field(None, max_length=3)
    supported_currencies: Optional[List[str]] = Field(None)
    
    # Branding updates
    logo_url: Optional[str] = Field(None, max_length=500)
    favicon_url: Optional[str] = Field(None, max_length=500)
    brand_colors: Optional[Dict[str, Any]] = Field(None)
    custom_themes: Optional[Dict[str, Any]] = Field(None)
    
    # Status and features
    enabled_features: Optional[List[str]] = Field(None)
    feature_limits: Optional[Dict[str, Any]] = Field(None)
    compliance_requirements: Optional[List[str]] = Field(None)
    
    # Notes and metadata
    notes: Optional[str] = Field(None, description="Company notes")
    custom_fields: Optional[Dict[str, Any]] = Field(None)
    tags: Optional[List[str]] = Field(None)


class CompanyResponse(BaseResponse):
    """Schema for company response data"""
    
    # Basic Information
    company_name: str
    legal_name: str
    company_code: str
    registration_number: Optional[str]
    tax_id: Optional[str]
    
    # Classification
    industry_type: str
    business_type: str
    company_size: Optional[str]
    
    # Contact Information
    primary_email: Optional[str]
    primary_phone: Optional[str]
    website_url: Optional[str]
    
    # Address
    address_line1: Optional[str]
    address_line2: Optional[str]
    city: Optional[str]
    state_province: Optional[str]
    postal_code: Optional[str]
    country_code: Optional[str]
    
    # Geographic and Regulatory
    primary_country_id: Optional[UUID]
    headquarters_timezone: str
    regulatory_region: Optional[str]
    
    # Financial
    base_currency: str
    supported_currencies: Optional[List[str]]
    fiscal_year_start: Optional[int]
    
    # Branding
    logo_url: Optional[str]
    favicon_url: Optional[str]
    brand_colors: Optional[Dict[str, Any]]
    custom_themes: Optional[Dict[str, Any]]
    
    # Status and Lifecycle
    company_status: str
    subscription_tier: str
    onboarding_status: str
    
    # Features and Configuration
    enabled_features: Optional[List[str]]
    feature_limits: Optional[Dict[str, Any]]
    license_info: Optional[Dict[str, Any]]
    
    # Compliance
    compliance_requirements: Optional[List[str]]
    data_residency: Optional[str]
    security_level: str
    
    # Operational Dates
    setup_date: Optional[datetime]
    go_live_date: Optional[datetime]
    contract_start_date: Optional[datetime]
    contract_end_date: Optional[datetime]
    last_activity_date: Optional[datetime]
    
    # Billing
    billing_contact_email: Optional[str]
    payment_terms: Optional[int]
    billing_frequency: str
    
    # Metadata
    notes: Optional[str]
    custom_fields: Optional[Dict[str, Any]]
    tags: Optional[List[str]]


class CompanySearchParams(BaseModel):
    """Schema for company search parameters"""
    
    # Search fields
    name: Optional[str] = Field(None, description="Search by company name")
    code: Optional[str] = Field(None, description="Search by company code")
    email: Optional[str] = Field(None, description="Search by email")
    
    # Filter fields
    status: Optional[str] = Field(None, description="Filter by company status")
    subscription_tier: Optional[str] = Field(None, description="Filter by subscription tier")
    country_id: Optional[UUID] = Field(None, description="Filter by country")
    industry_type: Optional[str] = Field(None, description="Filter by industry")
    company_size: Optional[str] = Field(None, description="Filter by company size")
    
    # Date filters
    created_after: Optional[datetime] = Field(None, description="Filter by creation date (after)")
    created_before: Optional[datetime] = Field(None, description="Filter by creation date (before)")
    
    # Sorting
    sort_by: str = Field("company_name", description="Sort field")
    sort_order: str = Field("asc", description="Sort order (asc/desc)")
    
    @validator('sort_order')
    def validate_sort_order(cls, v):
        if v not in ['asc', 'desc']:
            raise ValueError('Sort order must be asc or desc')
        return v


class CompanyListResponse(PaginatedResponse):
    """Schema for paginated company list response"""
    
    companies: List[CompanyResponse] = Field(..., description="List of companies")


class CompanyStatistics(BaseModel):
    """Schema for company statistics"""
    
    company_info: Dict[str, Any] = Field(..., description="Basic company information")
    user_statistics: Dict[str, int] = Field(..., description="User-related statistics")
    organizational_statistics: Dict[str, int] = Field(..., description="Organizational statistics")
    features: Dict[str, Any] = Field(..., description="Feature and limit information")
    
    class Config:
        schema_extra = {
            "example": {
                "company_info": {
                    "id": "123e4567-e89b-12d3-a456-426614174000",
                    "name": "ACME Insurance",
                    "code": "ACME01",
                    "status": "active",
                    "subscription_tier": "enterprise",
                    "setup_date": "2024-01-15T00:00:00Z",
                    "company_age_days": 45
                },
                "user_statistics": {
                    "total_users": 150,
                    "active_users": 145,
                    "users_with_logins": 130
                },
                "organizational_statistics": {
                    "total_departments": 8,
                    "active_departments": 8
                },
                "features": {
                    "enabled_features": ["claims", "policies", "analytics"],
                    "feature_limits": {"max_users": 200, "max_policies": 10000}
                }
            }
        }


# System Configuration Schemas

class SystemConfigurationUpdate(BaseModel):
    """Schema for updating system configuration"""
    
    # Authentication & Security
    password_policy: Optional[Dict[str, Any]] = Field(None, description="Password policy settings")
    session_settings: Optional[Dict[str, Any]] = Field(None, description="Session configuration")
    mfa_requirements: Optional[Dict[str, Any]] = Field(None, description="MFA requirements")
    security_settings: Optional[Dict[str, Any]] = Field(None, description="Security settings")
    
    # Localization
    default_language: Optional[str] = Field(None, max_length=10, description="Default language")
    supported_languages: Optional[List[str]] = Field(None, description="Supported languages")
    default_locale: Optional[str] = Field(None, max_length=10, description="Default locale")
    timezone_settings: Optional[Dict[str, Any]] = Field(None, description="Timezone settings")
    
    # Business Rules
    business_rules: Optional[Dict[str, Any]] = Field(None, description="Business rules configuration")
    workflow_settings: Optional[Dict[str, Any]] = Field(None, description="Workflow settings")
    approval_workflows: Optional[Dict[str, Any]] = Field(None, description="Approval workflows")
    
    # Insurance-Specific
    policy_settings: Optional[Dict[str, Any]] = Field(None, description="Policy settings")
    claim_settings: Optional[Dict[str, Any]] = Field(None, description="Claim settings")
    underwriting_settings: Optional[Dict[str, Any]] = Field(None, description="Underwriting settings")
    pricing_settings: Optional[Dict[str, Any]] = Field(None, description="Pricing settings")
    
    # Financial
    currency_settings: Optional[Dict[str, Any]] = Field(None, description="Currency settings")
    tax_settings: Optional[Dict[str, Any]] = Field(None, description="Tax settings")
    billing_settings: Optional[Dict[str, Any]] = Field(None, description="Billing settings")
    
    # Communication
    email_settings: Optional[Dict[str, Any]] = Field(None, description="Email settings")
    sms_settings: Optional[Dict[str, Any]] = Field(None, description="SMS settings")
    notification_settings: Optional[Dict[str, Any]] = Field(None, description="Notification settings")
    
    # Integration
    api_configuration: Optional[Dict[str, Any]] = Field(None, description="API configuration")
    third_party_integrations: Optional[Dict[str, Any]] = Field(None, description="Third-party integrations")
    webhook_configuration: Optional[Dict[str, Any]] = Field(None, description="Webhook configuration")
    
    # UI/UX
    ui_customization: Optional[Dict[str, Any]] = Field(None, description="UI customization")
    branding_settings: Optional[Dict[str, Any]] = Field(None, description="Branding settings")
    
    # Performance and Features
    performance_settings: Optional[Dict[str, Any]] = Field(None, description="Performance settings")
    feature_flags: Optional[Dict[str, Any]] = Field(None, description="Feature flags")
    experimental_features: Optional[Dict[str, Any]] = Field(None, description="Experimental features")


class SystemConfigurationResponse(BaseResponse):
    """Schema for system configuration response"""
    
    company_id: UUID = Field(..., description="Company ID")
    
    # Configuration categories
    password_policy: Optional[Dict[str, Any]]
    session_settings: Optional[Dict[str, Any]]
    mfa_requirements: Optional[Dict[str, Any]]
    security_settings: Optional[Dict[str, Any]]
    
    default_language: str
    supported_languages: Optional[List[str]]
    default_locale: str
    timezone_settings: Optional[Dict[str, Any]]
    
    business_rules: Optional[Dict[str, Any]]
    workflow_settings: Optional[Dict[str, Any]]
    approval_workflows: Optional[Dict[str, Any]]
    
    policy_settings: Optional[Dict[str, Any]]
    claim_settings: Optional[Dict[str, Any]]
    underwriting_settings: Optional[Dict[str, Any]]
    pricing_settings: Optional[Dict[str, Any]]
    
    currency_settings: Optional[Dict[str, Any]]
    tax_settings: Optional[Dict[str, Any]]
    billing_settings: Optional[Dict[str, Any]]
    
    email_settings: Optional[Dict[str, Any]]
    sms_settings: Optional[Dict[str, Any]]
    notification_settings: Optional[Dict[str, Any]]
    
    api_configuration: Optional[Dict[str, Any]]
    third_party_integrations: Optional[Dict[str, Any]]
    webhook_configuration: Optional[Dict[str, Any]]
    
    ui_customization: Optional[Dict[str, Any]]
    branding_settings: Optional[Dict[str, Any]]
    
    performance_settings: Optional[Dict[str, Any]]
    feature_flags: Optional[Dict[str, Any]]
    experimental_features: Optional[Dict[str, Any]]
    
    # Metadata
    environment_type: str
    configuration_version: str
    last_configuration_update: Optional[datetime]