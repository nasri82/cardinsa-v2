"""
Geographic Data Schemas

Pydantic schemas for geographic data including countries, regions,
cities, states, address validation, and location services.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, List, Dict, Any, Tuple
from uuid import UUID

from pydantic import BaseModel, Field, validator
from app.schemas.base import BaseResponse, PaginatedResponse


# Country Schemas

class CountryResponse(BaseResponse):
    """Schema for country response data"""
    
    # Basic Information
    country_name: str = Field(..., description="Country name")
    country_name_local: Optional[str] = Field(None, description="Local country name")
    
    # ISO Codes
    iso_alpha_2: str = Field(..., description="ISO 2-letter country code")
    iso_alpha_3: str = Field(..., description="ISO 3-letter country code")
    iso_numeric: Optional[str] = Field(None, description="ISO numeric country code")
    
    # Regional Information
    continent: Optional[str] = Field(None, description="Continent")
    region: Optional[str] = Field(None, description="Geographic region")
    sub_region: Optional[str] = Field(None, description="Sub-region")
    
    # Currency
    currency_code: Optional[str] = Field(None, description="Currency code")
    currency_name: Optional[str] = Field(None, description="Currency name")
    currency_symbol: Optional[str] = Field(None, description="Currency symbol")
    
    # Geographic Data
    capital_city: Optional[str] = Field(None, description="Capital city")
    latitude: Optional[Decimal] = Field(None, description="Latitude coordinate")
    longitude: Optional[Decimal] = Field(None, description="Longitude coordinate")
    area_km2: Optional[Decimal] = Field(None, description="Area in square kilometers")
    population: Optional[int] = Field(None, description="Population")
    
    # Language and Communication
    official_languages: Optional[List[str]] = Field(None, description="Official languages")
    primary_language: Optional[str] = Field(None, description="Primary language")
    phone_code: Optional[str] = Field(None, description="International phone code")
    
    # Insurance and Regulatory
    insurance_regulatory_body: Optional[str] = Field(None, description="Insurance regulatory authority")
    solvency_framework: Optional[str] = Field(None, description="Solvency framework")
    
    # Market Information
    gdp_per_capita: Optional[Decimal] = Field(None, description="GDP per capita")
    market_maturity: Optional[str] = Field(None, description="Market maturity level")
    insurance_penetration: Optional[Decimal] = Field(None, description="Insurance penetration percentage")
    
    # Risk Ratings
    political_risk_rating: Optional[str] = Field(None, description="Political risk rating")
    economic_risk_rating: Optional[str] = Field(None, description="Economic risk rating")
    
    # Status
    is_active: bool = Field(..., description="Is country active")
    is_supported: bool = Field(..., description="Is country supported for operations")
    operations_status: str = Field(..., description="Operations status")
    
    # Compliance
    sanctioned: bool = Field(..., description="Is country sanctioned")
    high_risk_jurisdiction: bool = Field(..., description="Is high-risk jurisdiction")


class CountrySearchParams(BaseModel):
    """Schema for country search parameters"""
    
    search_term: Optional[str] = Field(None, description="Search term for country name")
    region: Optional[str] = Field(None, description="Filter by region")
    continent: Optional[str] = Field(None, description="Filter by continent")
    active_only: bool = Field(True, description="Return only active countries")
    supported_only: bool = Field(False, description="Return only supported countries")
    limit: int = Field(50, ge=1, le=200, description="Maximum results")


# Region Schemas

class RegionResponse(BaseResponse):
    """Schema for region response data"""
    
    # Basic Information
    region_name: str = Field(..., description="Region name")
    region_name_local: Optional[str] = Field(None, description="Local region name")
    region_code: Optional[str] = Field(None, description="Region code")
    
    # Associations
    country_id: UUID = Field(..., description="Country ID")
    
    # Administrative Information
    region_type: str = Field(..., description="Type of region")
    administrative_level: int = Field(..., description="Administrative level")
    capital_city: Optional[str] = Field(None, description="Capital city")
    
    # Geographic Data
    latitude: Optional[Decimal] = Field(None, description="Latitude coordinate")
    longitude: Optional[Decimal] = Field(None, description="Longitude coordinate")
    area_km2: Optional[Decimal] = Field(None, description="Area in square kilometers")
    population: Optional[int] = Field(None, description="Population")
    population_density: Optional[Decimal] = Field(None, description="Population density")
    
    # Economic Data
    gdp: Optional[Decimal] = Field(None, description="GDP")
    gdp_per_capita: Optional[Decimal] = Field(None, description="GDP per capita")
    unemployment_rate: Optional[Decimal] = Field(None, description="Unemployment rate")
    
    # Insurance Data
    regulatory_authority: Optional[str] = Field(None, description="Regional regulatory authority")
    
    # Risk Factors
    natural_disaster_risk: Optional[Dict[str, Any]] = Field(None, description="Natural disaster risk data")
    crime_rate: Optional[Decimal] = Field(None, description="Crime rate")
    
    # Pricing Factors
    cost_of_living_index: Optional[Decimal] = Field(None, description="Cost of living index")
    medical_cost_multiplier: Optional[Decimal] = Field(None, description="Medical cost multiplier")
    regional_risk_factor: Optional[Decimal] = Field(None, description="Regional risk factor")
    
    # Status
    is_active: bool = Field(..., description="Is region active")
    is_supported: bool = Field(..., description="Is region supported")


class RegionSearchParams(BaseModel):
    """Schema for region search parameters"""
    
    country_id: UUID = Field(..., description="Country ID to search within")
    search_term: Optional[str] = Field(None, description="Search term for region name")
    region_type: Optional[str] = Field(None, description="Filter by region type")
    active_only: bool = Field(True, description="Return only active regions")
    limit: int = Field(50, ge=1, le=200, description="Maximum results")


# City Schemas

class CityResponse(BaseResponse):
    """Schema for city response data"""
    
    # Basic Information
    city_name: str = Field(..., description="City name")
    city_name_local: Optional[str] = Field(None, description="Local city name")
    city_code: Optional[str] = Field(None, description="City code")
    
    # Geographic Associations
    country_id: UUID = Field(..., description="Country ID")
    region_id: Optional[UUID] = Field(None, description="Region ID")
    
    # Administrative Data
    city_type: str = Field(..., description="Type of city")
    administrative_status: Optional[str] = Field(None, description="Administrative status")
    
    # Geographic Coordinates
    latitude: Optional[Decimal] = Field(None, description="Latitude coordinate")
    longitude: Optional[Decimal] = Field(None, description="Longitude coordinate")
    elevation: Optional[int] = Field(None, description="Elevation in meters")
    area_km2: Optional[Decimal] = Field(None, description="Area in square kilometers")
    
    # Demographics
    population: Optional[int] = Field(None, description="Population")
    population_density: Optional[Decimal] = Field(None, description="Population density")
    urban_rural_classification: Optional[str] = Field(None, description="Urban/rural classification")
    
    # Economic Indicators
    median_income: Optional[Decimal] = Field(None, description="Median income")
    cost_of_living_index: Optional[Decimal] = Field(None, description="Cost of living index")
    unemployment_rate: Optional[Decimal] = Field(None, description="Unemployment rate")
    
    # Healthcare Infrastructure
    hospitals_count: Optional[int] = Field(None, description="Number of hospitals")
    doctors_per_capita: Optional[Decimal] = Field(None, description="Doctors per capita")
    healthcare_quality_rating: Optional[Decimal] = Field(None, description="Healthcare quality rating")
    
    # Risk Factors
    crime_rate: Optional[Decimal] = Field(None, description="Crime rate")
    traffic_accident_rate: Optional[Decimal] = Field(None, description="Traffic accident rate")
    
    # Insurance Pricing Factors
    base_risk_multiplier: Optional[Decimal] = Field(None, description="Base risk multiplier")
    medical_cost_factor: Optional[Decimal] = Field(None, description="Medical cost factor")
    property_cost_factor: Optional[Decimal] = Field(None, description="Property cost factor")
    auto_insurance_factor: Optional[Decimal] = Field(None, description="Auto insurance factor")
    
    # Infrastructure
    postal_codes: Optional[List[str]] = Field(None, description="Postal codes for the city")
    timezone: Optional[str] = Field(None, description="Timezone")
    public_transport_quality: Optional[str] = Field(None, description="Public transport quality")
    
    # Climate
    climate_zone: Optional[str] = Field(None, description="Climate zone")
    average_temperature: Optional[Decimal] = Field(None, description="Average temperature")
    
    # Business Environment
    business_district: bool = Field(False, description="Is business district")
    industrial_zone: bool = Field(False, description="Is industrial zone")
    
    # Status
    is_active: bool = Field(..., description="Is city active")
    is_major_city: bool = Field(..., description="Is major city")
    service_coverage: str = Field(..., description="Service coverage level")


class CitySearchParams(BaseModel):
    """Schema for city search parameters"""
    
    search_term: str = Field(..., min_length=1, description="Search term for city name")
    country_id: Optional[UUID] = Field(None, description="Filter by country")
    region_id: Optional[UUID] = Field(None, description="Filter by region")
    major_cities_only: bool = Field(False, description="Return only major cities")
    active_only: bool = Field(True, description="Return only active cities")
    limit: int = Field(20, ge=1, le=100, description="Maximum results")


# State Schemas

class StateResponse(BaseResponse):
    """Schema for state response data"""
    
    # Basic Information
    state_name: str = Field(..., description="State name")
    state_name_local: Optional[str] = Field(None, description="Local state name")
    state_code: str = Field(..., description="State code")
    iso_code: Optional[str] = Field(None, description="ISO state code")
    
    # Country Association
    country_id: UUID = Field(..., description="Country ID")
    
    # Administrative Data
    state_type: str = Field(..., description="Type of state")
    capital_city: Optional[str] = Field(None, description="Capital city")
    largest_city: Optional[str] = Field(None, description="Largest city")
    
    # Geographic Information
    latitude: Optional[Decimal] = Field(None, description="Latitude coordinate")
    longitude: Optional[Decimal] = Field(None, description="Longitude coordinate")
    area_km2: Optional[Decimal] = Field(None, description="Area in square kilometers")
    population: Optional[int] = Field(None, description="Population")
    
    # Insurance Regulatory Framework
    insurance_commissioner: Optional[str] = Field(None, description="Insurance commissioner")
    regulatory_department: Optional[str] = Field(None, description="Regulatory department")
    licensing_authority: Optional[str] = Field(None, description="Licensing authority")
    
    # Tax Information
    premium_tax_rate: Optional[Decimal] = Field(None, description="Premium tax rate")
    surplus_lines_tax: Optional[Decimal] = Field(None, description="Surplus lines tax")
    
    # Risk Information
    seismic_risk_zone: Optional[str] = Field(None, description="Seismic risk zone")
    
    # Status
    is_active: bool = Field(..., description="Is state active")
    licensing_status: str = Field(..., description="Licensing status")
    compliance_status: str = Field(..., description="Compliance status")


class StateSearchParams(BaseModel):
    """Schema for state search parameters"""
    
    country_id: UUID = Field(..., description="Country ID to search within")
    search_term: Optional[str] = Field(None, description="Search term for state name")
    licensing_status: Optional[str] = Field(None, description="Filter by licensing status")
    active_only: bool = Field(True, description="Return only active states")
    limit: int = Field(50, ge=1, le=200, description="Maximum results")


# Address Validation Schemas

class AddressValidationRequest(BaseModel):
    """Schema for address validation request"""
    
    address_line1: str = Field(..., min_length=1, max_length=255, description="Address line 1")
    address_line2: Optional[str] = Field(None, max_length=255, description="Address line 2")
    city: Optional[str] = Field(None, max_length=100, description="City")
    state_province: Optional[str] = Field(None, max_length=100, description="State or province")
    postal_code: Optional[str] = Field(None, max_length=20, description="Postal code")
    country_code: str = Field(..., min_length=2, max_length=3, description="Country code")
    
    @validator('country_code')
    def validate_country_code(cls, v):
        return v.upper()


class AddressValidationResponse(BaseModel):
    """Schema for address validation response"""
    
    is_valid: bool = Field(..., description="Is address valid")
    confidence_score: float = Field(..., ge=0.0, le=1.0, description="Confidence score")
    standardized_address: Dict[str, Any] = Field(..., description="Standardized address")
    suggestions: List[Dict[str, Any]] = Field(default_factory=list, description="Address suggestions")
    validation_errors: List[str] = Field(default_factory=list, description="Validation errors")
    
    class Config:
        schema_extra = {
            "example": {
                "is_valid": True,
                "confidence_score": 0.95,
                "standardized_address": {
                    "address_line1": "123 Main Street",
                    "address_line2": "Suite 100",
                    "city": "New York",
                    "state_province": "New York",
                    "postal_code": "10001",
                    "country": "United States",
                    "country_code": "US"
                },
                "suggestions": [],
                "validation_errors": []
            }
        }


# Geocoding Schemas

class GeocodingResponse(BaseModel):
    """Schema for geocoding response"""
    
    latitude: float = Field(..., description="Latitude coordinate")
    longitude: float = Field(..., description="Longitude coordinate")
    accuracy: str = Field(..., description="Accuracy level")
    source: str = Field(..., description="Data source")
    
    class Config:
        schema_extra = {
            "example": {
                "latitude": 40.7589,
                "longitude": -73.9851,
                "accuracy": "city_level",
                "source": "database"
            }
        }


# Location Risk Assessment Schemas

class LocationRiskAssessment(BaseModel):
    """Schema for location risk assessment"""
    
    overall_risk_score: float = Field(..., ge=0.0, le=1.0, description="Overall risk score")
    risk_factors: Dict[str, float] = Field(..., description="Individual risk factors")
    location_info: Dict[str, Any] = Field(..., description="Location information")
    recommendations: List[str] = Field(default_factory=list, description="Risk recommendations")
    
    class Config:
        schema_extra = {
            "example": {
                "overall_risk_score": 0.35,
                "risk_factors": {
                    "crime": 0.4,
                    "natural_disasters": 0.2,
                    "traffic": 0.5,
                    "healthcare": 0.3
                },
                "location_info": {
                    "nearest_city": "Miami",
                    "distance_km": 5.2,
                    "population": 463347,
                    "is_major_city": True
                },
                "recommendations": [
                    "Consider additional security measures due to moderate crime rate",
                    "Evaluate hurricane coverage for natural disaster protection"
                ]
            }
        }


# Geographic Statistics Schemas

class GeographicStatistics(BaseModel):
    """Schema for geographic statistics"""
    
    countries: Dict[str, int] = Field(..., description="Country statistics")
    regions: Dict[str, int] = Field(..., description="Region statistics")
    cities: Dict[str, int] = Field(..., description="City statistics")
    states: Optional[Dict[str, int]] = Field(None, description="State statistics")
    
    class Config:
        schema_extra = {
            "example": {
                "countries": {
                    "total": 195,
                    "supported": 25
                },
                "regions": {
                    "total": 1247,
                    "supported": 156
                },
                "cities": {
                    "total": 15420,
                    "major": 987,
                    "with_coverage": 234
                },
                "states": {
                    "total": 50,
                    "licensed": 48
                }
            }
        }


# Service Coverage Schemas

class ServiceCoverageResponse(BaseModel):
    """Schema for service coverage areas"""
    
    countries: List[Dict[str, Any]] = Field(..., description="Countries with service coverage")
    
    class Config:
        schema_extra = {
            "example": {
                "countries": [
                    {
                        "id": "123e4567-e89b-12d3-a456-426614174000",
                        "name": "United States",
                        "iso_code": "US",
                        "operations_status": "active",
                        "supported_regions": [
                            {
                                "id": "234e5678-e89b-12d3-a456-426614174001",
                                "name": "California",
                                "code": "CA"
                            }
                        ],
                        "supported_cities": [
                            {
                                "id": "345e6789-e89b-12d3-a456-426614174002",
                                "name": "Los Angeles",
                                "coverage_level": "full"
                            }
                        ]
                    }
                ]
            }
        }


# Coordinate-based Schemas

class CoordinateSearch(BaseModel):
    """Schema for coordinate-based searches"""
    
    latitude: Decimal = Field(..., ge=-90, le=90, description="Latitude coordinate")
    longitude: Decimal = Field(..., ge=-180, le=180, description="Longitude coordinate")
    radius_km: int = Field(50, ge=1, le=1000, description="Search radius in kilometers")
    limit: int = Field(10, ge=1, le=50, description="Maximum results")


class NearbyCity(BaseModel):
    """Schema for nearby city result"""
    
    city: CityResponse = Field(..., description="City information")
    distance_km: Decimal = Field(..., description="Distance in kilometers")


class NearbySearchResponse(BaseModel):
    """Schema for nearby search response"""
    
    search_coordinates: Dict[str, Decimal] = Field(..., description="Search coordinates")
    radius_km: int = Field(..., description="Search radius")
    results: List[NearbyCity] = Field(..., description="Nearby cities")
    total_found: int = Field(..., description="Total cities found")


# Distance Calculation Schemas

class DistanceCalculationRequest(BaseModel):
    """Schema for distance calculation request"""
    
    origin_latitude: Decimal = Field(..., ge=-90, le=90, description="Origin latitude")
    origin_longitude: Decimal = Field(..., ge=-180, le=180, description="Origin longitude")
    destination_latitude: Decimal = Field(..., ge=-90, le=90, description="Destination latitude")
    destination_longitude: Decimal = Field(..., ge=-180, le=180, description="Destination longitude")


class DistanceCalculationResponse(BaseModel):
    """Schema for distance calculation response"""
    
    distance_km: Decimal = Field(..., description="Distance in kilometers")
    distance_miles: Decimal = Field(..., description="Distance in miles")
    
    class Config:
        schema_extra = {
            "example": {
                "distance_km": 1234.56,
                "distance_miles": 767.12
            }
        }