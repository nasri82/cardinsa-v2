"""
Company & Multi-Tenancy Schemas Package

This package contains all Pydantic schemas for request/response models
related to company management, multi-tenancy, geographic data,
localization, and organizational structure.

Phase 1.2: Company & Multi-Tenancy Schemas
- Company management schemas
- Geographic data schemas
- Localization and translation schemas
- Department and organizational schemas
"""

# Company Management Schemas
from .company import (
    CompanyCreate,
    CompanyUpdate,
    CompanyResponse,
    CompanySearchParams,
    CompanyStatistics,
    SystemConfigurationUpdate,
    SystemConfigurationResponse,
    CompanyListResponse
)

# Geographic Data Schemas
from .geography import (
    CountryResponse,
    CountrySearchParams,
    RegionResponse,
    RegionSearchParams,
    CityResponse,
    CitySearchParams,
    StateResponse,
    StateSearchParams,
    AddressValidationRequest,
    AddressValidationResponse,
    GeocodingResponse,
    LocationRiskAssessment,
    GeographicStatistics,
    ServiceCoverageResponse
)

# Localization Schemas
from .localization import (
    LanguageCreate,
    LanguageUpdate,
    LanguageResponse,
    LanguageListResponse,
    TranslationCreate,
    TranslationUpdate,
    TranslationResponse,
    TranslationBulkImport,
    TranslationSearchParams,
    LocaleResponse,
    LanguageSettingCreate,
    LanguageSettingUpdate,
    LanguageSettingResponse,
    TranslationStatistics,
    MissingTranslationsResponse
)

# Department and Organizational Schemas
from .department import (
    DepartmentCreate,
    DepartmentUpdate,
    DepartmentResponse,
    DepartmentHierarchyResponse,
    DepartmentMembersResponse,
    DepartmentStatistics,
    UnitCreate,
    UnitUpdate,
    UnitResponse,
    UnitMembersResponse,
    UserAssignmentRequest,
    OrganizationalStatistics,
    DepartmentPerformanceMetrics
)

__all__ = [
    # Company Management
    "CompanyCreate",
    "CompanyUpdate", 
    "CompanyResponse",
    "CompanySearchParams",
    "CompanyStatistics",
    "SystemConfigurationUpdate",
    "SystemConfigurationResponse",
    "CompanyListResponse",
    
    # Geographic Data
    "CountryResponse",
    "CountrySearchParams",
    "RegionResponse",
    "RegionSearchParams", 
    "CityResponse",
    "CitySearchParams",
    "StateResponse",
    "StateSearchParams",
    "AddressValidationRequest",
    "AddressValidationResponse",
    "GeocodingResponse",
    "LocationRiskAssessment",
    "GeographicStatistics",
    "ServiceCoverageResponse",
    
    # Localization
    "LanguageCreate",
    "LanguageUpdate",
    "LanguageResponse",
    "LanguageListResponse",
    "TranslationCreate",
    "TranslationUpdate", 
    "TranslationResponse",
    "TranslationBulkImport",
    "TranslationSearchParams",
    "LocaleResponse",
    "LanguageSettingCreate",
    "LanguageSettingUpdate",
    "LanguageSettingResponse",
    "TranslationStatistics",
    "MissingTranslationsResponse",
    
    # Department and Organization
    "DepartmentCreate",
    "DepartmentUpdate",
    "DepartmentResponse",
    "DepartmentHierarchyResponse",
    "DepartmentMembersResponse",
    "DepartmentStatistics",
    "UnitCreate",
    "UnitUpdate",
    "UnitResponse", 
    "UnitMembersResponse",
    "UserAssignmentRequest",
    "OrganizationalStatistics",
    "DepartmentPerformanceMetrics"
]