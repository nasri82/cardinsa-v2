"""
Base model class with common fields for all database models.
"""

import uuid
from datetime import datetime
from typing import Optional

try:
    from sqlalchemy import Column, DateTime, String, Text, Boolean, ForeignKey
    from sqlalchemy.dialects.postgresql import UUID
    from sqlalchemy.ext.declarative import declarative_base, declared_attr
    from sqlalchemy.orm import Mapped, mapped_column, relationship
    
    # Create the declarative base
    Base = declarative_base()
    SQLALCHEMY_AVAILABLE = True
    
except ImportError:
    # Fallback if SQLAlchemy is not available
    print("Warning: SQLAlchemy not available, creating mock Base")
    
    class MockBase:
        """Mock base class when SQLAlchemy is not available."""
        pass
    
    Base = MockBase
    SQLALCHEMY_AVAILABLE = False


if SQLALCHEMY_AVAILABLE:
    class BaseModel(Base):
        """
        Base model class with common fields for all models.
        Provides audit trail and soft delete functionality.
        """
        __abstract__ = True

        # Primary key
        id: Mapped[uuid.UUID] = mapped_column(
            UUID(as_uuid=True), 
            primary_key=True, 
            default=uuid.uuid4,
            nullable=False
        )
        
        # Audit fields
        created_by: Mapped[Optional[uuid.UUID]] = mapped_column(
            UUID(as_uuid=True), 
            nullable=True
        )
        
        updated_by: Mapped[Optional[uuid.UUID]] = mapped_column(
            UUID(as_uuid=True), 
            nullable=True
        )
        
        # Timestamp fields
        created_at: Mapped[datetime] = mapped_column(
            DateTime(timezone=False), 
            default=datetime.utcnow,
            nullable=False
        )
        
        updated_at: Mapped[Optional[datetime]] = mapped_column(
            DateTime(timezone=False), 
            onupdate=datetime.utcnow,
            nullable=True
        )
        
        # Soft delete
        archived_at: Mapped[Optional[datetime]] = mapped_column(
            DateTime(timezone=False), 
            nullable=True
        )

        @declared_attr
        def __tablename__(cls):
            """
            Generate table name from class name.
            Convert CamelCase to snake_case.
            """
            import re
            name = re.sub('([a-z0-9])([A-Z])', r'\1_\2', cls.__name__)
            return name.lower()

        def soft_delete(self):
            """Mark the record as deleted by setting archived_at."""
            self.archived_at = datetime.utcnow()

        def restore(self):
            """Restore a soft-deleted record."""
            self.archived_at = None

        @property
        def is_deleted(self) -> bool:
            """Check if the record is soft-deleted."""
            return self.archived_at is not None

        def __repr__(self):
            return f"<{self.__class__.__name__}(id={self.id})>"


    class CompanyIsolatedModel(BaseModel):
        """
        Base model for multi-tenant models that are isolated by company.
        Automatically includes company_id for data isolation.
        """
        __abstract__ = True

        # Company isolation field
        company_id: Mapped[uuid.UUID] = mapped_column(
            UUID(as_uuid=True),
            ForeignKey("companies.id", ondelete="CASCADE"),
            nullable=False,
            index=True
        )

        def __repr__(self):
            return f"<{self.__class__.__name__}(id={self.id}, company_id={self.company_id})>"


    class TimestampMixin:
        """Mixin for models that only need timestamp fields."""
        
        created_at: Mapped[datetime] = mapped_column(
            DateTime(timezone=False), 
            default=datetime.utcnow,
            nullable=False
        )
        
        updated_at: Mapped[Optional[datetime]] = mapped_column(
            DateTime(timezone=False), 
            onupdate=datetime.utcnow,
            nullable=True
        )


    class AuditMixin:
        """Mixin for models that need audit trail fields."""
        
        created_by: Mapped[Optional[uuid.UUID]] = mapped_column(
            UUID(as_uuid=True), 
            nullable=True
        )
        
        updated_by: Mapped[Optional[uuid.UUID]] = mapped_column(
            UUID(as_uuid=True), 
            nullable=True
        )


    class SoftDeleteMixin:
        """Mixin for models that need soft delete functionality."""
        
        archived_at: Mapped[Optional[datetime]] = mapped_column(
            DateTime(timezone=False), 
            nullable=True
        )

        def soft_delete(self):
            """Mark the record as deleted by setting archived_at."""
            self.archived_at = datetime.utcnow()

        def restore(self):
            """Restore a soft-deleted record."""
            self.archived_at = None

        @property
        def is_deleted(self) -> bool:
            """Check if the record is soft-deleted."""
            return self.archived_at is not None


    class CompanyMixin:
        """Mixin for company isolation."""
        
        company_id: Mapped[uuid.UUID] = mapped_column(
            UUID(as_uuid=True),
            ForeignKey("companies.id", ondelete="CASCADE"),
            nullable=False,
            index=True
        )


    # Additional base models for specific use cases

    class UserScopedModel(BaseModel):
        """
        Base model for models that are scoped to a specific user.
        """
        __abstract__ = True

        user_id: Mapped[uuid.UUID] = mapped_column(
            UUID(as_uuid=True),
            ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
            index=True
        )


    class DepartmentScopedModel(CompanyIsolatedModel):
        """
        Base model for models that are scoped to a department within a company.
        """
        __abstract__ = True

        department_id: Mapped[Optional[uuid.UUID]] = mapped_column(
            UUID(as_uuid=True),
            ForeignKey("departments.id", ondelete="SET NULL"),
            nullable=True,
            index=True
        )


    class AuditLogModel(BaseModel):
        """
        Base model for audit log entries.
        Includes additional fields for tracking changes.
        """
        __abstract__ = True

        # Entity being audited
        entity_type: Mapped[str] = mapped_column(String(100), nullable=False)
        entity_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
        
        # Action details
        action: Mapped[str] = mapped_column(String(50), nullable=False)
        old_values: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
        new_values: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
        
        # Context
        ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
        user_agent: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


    class ConfigurationModel(CompanyIsolatedModel):
        """
        Base model for configuration settings.
        """
        __abstract__ = True

        # Configuration key-value
        config_key: Mapped[str] = mapped_column(String(100), nullable=False)
        config_value: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
        config_type: Mapped[str] = mapped_column(String(50), default="string", nullable=False)
        
        # Metadata
        description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
        is_system_config: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
        is_encrypted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

else:
    # Mock classes when SQLAlchemy is not available
    class BaseModel:
        pass
    
    class CompanyIsolatedModel:
        pass
    
    class TimestampMixin:
        pass
    
    class AuditMixin:
        pass
    
    class SoftDeleteMixin:
        pass
    
    class CompanyMixin:
        pass
    
    class UserScopedModel:
        pass
    
    class DepartmentScopedModel:
        pass
    
    class AuditLogModel:
        pass
    
    class ConfigurationModel:
        pass


# Export all base models and mixins - ENSURE Base is first and available
__all__ = [
    "Base",                    # CRITICAL: SQLAlchemy declarative base
    "BaseModel", 
    "CompanyIsolatedModel",
    "UserScopedModel",
    "DepartmentScopedModel",
    "AuditLogModel",
    "ConfigurationModel",
    "TimestampMixin",
    "AuditMixin", 
    "SoftDeleteMixin",
    "CompanyMixin"
]