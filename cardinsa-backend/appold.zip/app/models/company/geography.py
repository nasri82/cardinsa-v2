"""
Geographic Data Models

Models for managing geographic information including countries, regions,
cities, and states. These models support location-based services,
regulatory compliance, and geographic pricing factors.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, List
from sqlalchemy import (
    Column, String, Text, Boolean, DateTime, Integer, 
    Numeric, JSON, ForeignKey, UniqueConstraint, Index
)
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID, JSONB

from app.models.base import BaseModel, TimestampMixin, AuditMixin


class Country(BaseModel, TimestampMixin, AuditMixin):
    """
    Country Model
    
    Master data for countries with ISO codes, regulatory information,
    and insurance-specific data.
    """
    __tablename__ = "countries"
    
    # Basic Country Information
    country_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    country_name_local: Mapped[Optional[str]] = mapped_column(String(100))
    
    # ISO Codes and Standards
    iso_alpha_2: Mapped[str] = mapped_column(String(2), unique=True, nullable=False, index=True)
    iso_alpha_3: Mapped[str] = mapped_column(String(3), unique=True, nullable=False, index=True)
    iso_numeric: Mapped[Optional[str]] = mapped_column(String(3), unique=True)
    
    # Regional and Continental Information
    continent: Mapped[Optional[str]] = mapped_column(String(50))
    region: Mapped[Optional[str]] = mapped_column(String(100))
    sub_region: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Currency and Financial
    currency_code: Mapped[Optional[str]] = mapped_column(String(3))
    currency_name: Mapped[Optional[str]] = mapped_column(String(100))
    currency_symbol: Mapped[Optional[str]] = mapped_column(String(10))
    
    # Geographic Data
    capital_city: Mapped[Optional[str]] = mapped_column(String(100))
    latitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    longitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    area_km2: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    population: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Language and Localization
    official_languages: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    primary_language: Mapped[Optional[str]] = mapped_column(String(10))
    
    # Timezone Information
    timezones: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    utc_offset: Mapped[Optional[str]] = mapped_column(String(10))
    
    # Communication Standards
    phone_code: Mapped[Optional[str]] = mapped_column(String(10))
    postal_code_format: Mapped[Optional[str]] = mapped_column(String(100))
    postal_code_regex: Mapped[Optional[str]] = mapped_column(String(200))
    
    # Insurance and Regulatory
    insurance_regulatory_body: Mapped[Optional[str]] = mapped_column(String(200))
    insurance_laws: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    regulatory_requirements: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    solvency_framework: Mapped[Optional[str]] = mapped_column(String(100))
    # e.g., "Solvency II", "RBC", "C-ROSS", "SST"
    
    # Market Information
    gdp_per_capita: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    market_maturity: Mapped[Optional[str]] = mapped_column(String(50))
    # emerging, developing, developed
    insurance_penetration: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))  # Percentage
    
    # Risk Factors
    political_risk_rating: Mapped[Optional[str]] = mapped_column(String(10))
    # AAA, AA, A, BBB, BB, B, CCC, CC, C, D
    economic_risk_rating: Mapped[Optional[str]] = mapped_column(String(10))
    natural_disaster_risk: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Business Environment
    business_environment_rank: Mapped[Optional[int]] = mapped_column(Integer)
    corruption_perception_index: Mapped[Optional[int]] = mapped_column(Integer)
    legal_system_quality: Mapped[Optional[str]] = mapped_column(String(50))
    
    # Status and Operational
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_supported: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # Whether we provide insurance services in this country
    operations_status: Mapped[str] = mapped_column(String(50), default="not_supported", nullable=False)
    # not_supported, planned, pilot, active, suspended
    
    # Compliance and Legal
    sanctioned: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    high_risk_jurisdiction: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    fatca_compliant: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Additional Data
    notes: Mapped[Optional[str]] = mapped_column(Text)
    external_references: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    regions = relationship("Region", back_populates="country", cascade="all, delete-orphan")
    states = relationship("State", back_populates="country", cascade="all, delete-orphan")
    companies = relationship("Company", foreign_keys="Company.primary_country_id", back_populates="primary_country")
    
    # Indexes
    __table_args__ = (
        Index("idx_countries_iso2", "iso_alpha_2"),
        Index("idx_countries_iso3", "iso_alpha_3"),
        Index("idx_countries_active", "is_active"),
        Index("idx_countries_supported", "is_supported"),
        Index("idx_countries_region", "region"),
        UniqueConstraint("iso_alpha_2", name="uq_countries_iso2"),
        UniqueConstraint("iso_alpha_3", name="uq_countries_iso3"),
    )
    
    def __repr__(self) -> str:
        return f"<Country(id={self.id}, name={self.country_name}, iso={self.iso_alpha_2})>"


class Region(BaseModel, TimestampMixin, AuditMixin):
    """
    Region Model
    
    Administrative regions within countries (provinces, states, etc.)
    Used for regulatory compliance and geographic pricing.
    """
    __tablename__ = "regions"
    
    # Basic Information
    region_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    region_name_local: Mapped[Optional[str]] = mapped_column(String(100))
    region_code: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    
    # Country Association
    country_id: Mapped[UUID] = mapped_column(
        ForeignKey("countries.id", ondelete="CASCADE"), 
        nullable=False, 
        index=True
    )
    
    # Administrative Information
    region_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # state, province, territory, district, canton, etc.
    administrative_level: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    capital_city: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Geographic Data
    latitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    longitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    area_km2: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    population: Mapped[Optional[int]] = mapped_column(Integer)
    population_density: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2))
    
    # Economic Data
    gdp: Mapped[Optional[Decimal]] = mapped_column(Numeric(20, 2))
    gdp_per_capita: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    unemployment_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    
    # Insurance-Specific Data
    insurance_regulations: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    regulatory_authority: Mapped[Optional[str]] = mapped_column(String(200))
    license_requirements: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Risk Assessment
    natural_disaster_risk: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    crime_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(8, 2))
    healthcare_quality_index: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    
    # Pricing Factors
    cost_of_living_index: Mapped[Optional[Decimal]] = mapped_column(Numeric(8, 2))
    medical_cost_multiplier: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2), default=1.0)
    regional_risk_factor: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2), default=1.0)
    
    # Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_supported: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Additional Information
    timezone: Mapped[Optional[str]] = mapped_column(String(100))
    postal_code_prefix: Mapped[Optional[str]] = mapped_column(String(10))
    notes: Mapped[Optional[str]] = mapped_column(Text)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    country = relationship("Country", back_populates="regions")
    cities = relationship("City", back_populates="region", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index("idx_regions_country", "country_id"),
        Index("idx_regions_active", "is_active"),
        Index("idx_regions_type", "region_type"),
        UniqueConstraint("country_id", "region_code", name="uq_regions_country_code"),
    )
    
    def __repr__(self) -> str:
        return f"<Region(id={self.id}, name={self.region_name}, country={self.country_id})>"


class City(BaseModel, TimestampMixin, AuditMixin):
    """
    City Model
    
    City-level geographic data for precise location services,
    demographics, and local pricing factors.
    """
    __tablename__ = "cities"
    
    # Basic Information
    city_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    city_name_local: Mapped[Optional[str]] = mapped_column(String(100))
    city_code: Mapped[Optional[str]] = mapped_column(String(20))
    
    # Geographic Associations
    country_id: Mapped[UUID] = mapped_column(
        ForeignKey("countries.id", ondelete="CASCADE"), 
        nullable=False, 
        index=True
    )
    region_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("regions.id", ondelete="SET NULL"),
        index=True
    )
    
    # Administrative Data
    city_type: Mapped[str] = mapped_column(String(50), default="city", nullable=False)
    # city, town, village, municipality, metropolis
    administrative_status: Mapped[Optional[str]] = mapped_column(String(50))
    # capital, major, minor, rural
    
    # Geographic Coordinates
    latitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    longitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    elevation: Mapped[Optional[int]] = mapped_column(Integer)  # meters above sea level
    area_km2: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2))
    
    # Population and Demographics
    population: Mapped[Optional[int]] = mapped_column(Integer)
    population_density: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2))
    urban_rural_classification: Mapped[Optional[str]] = mapped_column(String(20))
    # urban, suburban, rural
    age_distribution: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Economic Indicators
    median_income: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    poverty_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    unemployment_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    cost_of_living_index: Mapped[Optional[Decimal]] = mapped_column(Numeric(8, 2))
    
    # Healthcare Infrastructure
    hospitals_count: Mapped[Optional[int]] = mapped_column(Integer)
    doctors_per_capita: Mapped[Optional[Decimal]] = mapped_column(Numeric(8, 4))
    healthcare_quality_rating: Mapped[Optional[Decimal]] = mapped_column(Numeric(3, 1))
    medical_facilities: Mapped[Optional[List[Dict[str, Any]]]] = mapped_column(JSONB)
    
    # Risk Factors
    crime_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(8, 2))
    natural_disaster_history: Mapped[Optional[List[Dict[str, Any]]]] = mapped_column(JSONB)
    environmental_risks: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    traffic_accident_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(8, 2))
    
    # Insurance Pricing Factors
    base_risk_multiplier: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 3), default=1.0)
    medical_cost_factor: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 3), default=1.0)
    property_cost_factor: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 3), default=1.0)
    auto_insurance_factor: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 3), default=1.0)
    
    # Infrastructure and Services
    postal_codes: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    timezone: Mapped[Optional[str]] = mapped_column(String(100))
    area_codes: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    public_transport_quality: Mapped[Optional[str]] = mapped_column(String(20))
    # excellent, good, fair, poor
    
    # Climate Data
    climate_zone: Mapped[Optional[str]] = mapped_column(String(50))
    average_temperature: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    annual_rainfall: Mapped[Optional[Decimal]] = mapped_column(Numeric(8, 2))
    weather_patterns: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Business Environment
    business_district: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    industrial_zone: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    major_employers: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    economic_sectors: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Status and Operations
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_major_city: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    service_coverage: Mapped[str] = mapped_column(String(20), default="none", nullable=False)
    # none, limited, partial, full
    
    # Additional Data
    points_of_interest: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    landmarks: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Data Sources and Quality
    data_source: Mapped[Optional[str]] = mapped_column(String(100))
    data_quality_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(3, 2))
    last_updated: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Relationships
    country = relationship("Country")
    region = relationship("Region", back_populates="cities")
    
    # Indexes
    __table_args__ = (
        Index("idx_cities_country", "country_id"),
        Index("idx_cities_region", "region_id"),
        Index("idx_cities_coordinates", "latitude", "longitude"),
        Index("idx_cities_active", "is_active"),
        Index("idx_cities_major", "is_major_city"),
        Index("idx_cities_coverage", "service_coverage"),
        UniqueConstraint("country_id", "region_id", "city_name", name="uq_cities_location_name"),
    )
    
    def __repr__(self) -> str:
        return f"<City(id={self.id}, name={self.city_name}, country={self.country_id})>"
    
    @property
    def full_location(self) -> str:
        """Get full location string"""
        parts = [self.city_name]
        if self.region:
            parts.append(self.region.region_name)
        if self.country:
            parts.append(self.country.country_name)
        return ", ".join(parts)


class State(BaseModel, TimestampMixin, AuditMixin):
    """
    State Model
    
    State/Province-level administrative divisions with specific focus
    on insurance regulations and compliance requirements.
    """
    __tablename__ = "states"
    
    # Basic Information
    state_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    state_name_local: Mapped[Optional[str]] = mapped_column(String(100))
    state_code: Mapped[str] = mapped_column(String(10), nullable=False, index=True)
    iso_code: Mapped[Optional[str]] = mapped_column(String(10))
    
    # Country Association
    country_id: Mapped[UUID] = mapped_column(
        ForeignKey("countries.id", ondelete="CASCADE"), 
        nullable=False, 
        index=True
    )
    
    # Administrative Data
    state_type: Mapped[str] = mapped_column(String(50), default="state", nullable=False)
    # state, province, territory, federal_district, autonomous_region
    capital_city: Mapped[Optional[str]] = mapped_column(String(100))
    largest_city: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Geographic Information
    latitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    longitude: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 7))
    area_km2: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    population: Mapped[Optional[int]] = mapped_column(Integer)
    population_density: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2))
    
    # Insurance Regulatory Framework
    insurance_commissioner: Mapped[Optional[str]] = mapped_column(String(200))
    regulatory_department: Mapped[Optional[str]] = mapped_column(String(200))
    insurance_code: Mapped[Optional[str]] = mapped_column(String(100))
    licensing_authority: Mapped[Optional[str]] = mapped_column(String(200))
    
    # Legal and Regulatory Requirements
    minimum_capital_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    solvency_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    reserve_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    licensing_fees: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Product Regulations
    mandatory_coverages: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    prohibited_practices: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    rate_filing_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    form_filing_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Consumer Protection
    guarantee_fund: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    guarantee_fund_coverage: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    complaint_procedures: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    grace_period_requirements: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Tax and Financial
    premium_tax_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4))
    surplus_lines_tax: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4))
    fire_marshal_tax: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4))
    other_taxes: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Market Conduct
    market_conduct_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    examination_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    reporting_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Claims Regulations
    claim_settlement_timeframes: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    unfair_claim_practices: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    appraisal_procedures: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Special Programs
    residual_market_programs: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    catastrophe_funds: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    assigned_risk_plans: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Economic Data
    gdp: Mapped[Optional[Decimal]] = mapped_column(Numeric(20, 2))
    gdp_per_capita: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    unemployment_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    median_household_income: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    
    # Risk Factors
    natural_disaster_exposure: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    catastrophe_history: Mapped[Optional[List[Dict[str, Any]]]] = mapped_column(JSONB)
    weather_risks: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    seismic_risk_zone: Mapped[Optional[str]] = mapped_column(String(10))
    
    # Operational Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    licensing_status: Mapped[str] = mapped_column(String(50), default="not_licensed", nullable=False)
    # not_licensed, application_pending, licensed, suspended, revoked
    
    # Compliance Tracking
    last_regulatory_update: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    compliance_status: Mapped[str] = mapped_column(String(50), default="unknown", nullable=False)
    # compliant, non_compliant, under_review, unknown
    regulatory_changes: Mapped[Optional[List[Dict[str, Any]]]] = mapped_column(JSONB)
    
    # Additional Information
    timezone: Mapped[Optional[str]] = mapped_column(String(100))
    postal_code_format: Mapped[Optional[str]] = mapped_column(String(50))
    notes: Mapped[Optional[str]] = mapped_column(Text)
    external_references: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    country = relationship("Country", back_populates="states")
    
    # Indexes
    __table_args__ = (
        Index("idx_states_country", "country_id"),
        Index("idx_states_code", "state_code"),
        Index("idx_states_active", "is_active"),
        Index("idx_states_licensing", "licensing_status"),
        Index("idx_states_compliance", "compliance_status"),
        UniqueConstraint("country_id", "state_code", name="uq_states_country_code"),
    )
    
    def __repr__(self) -> str:
        return f"<State(id={self.id}, name={self.state_name}, code={self.state_code})>"
    
    @property
    def is_licensed(self) -> bool:
        """Check if state has active license"""
        return self.licensing_status == "licensed"
    
    @property
    def is_compliant(self) -> bool:
        """Check if state is in compliance"""
        return self.compliance_status == "compliant"