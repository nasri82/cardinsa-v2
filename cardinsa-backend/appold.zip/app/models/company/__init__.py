"""
Company & Multi-Tenancy Models Package

This package contains all models related to company management, multi-tenancy,
geographic data, localization, and organizational structure for the Cardinsa
Insurance Platform.

Phase 1.2: Company & Multi-Tenancy Module
- Company management and system configuration
- Geographic data (countries, regions, cities, states)
- Localization system (languages, translations, locales)
- Organizational structure (departments, units)
"""

from .company import Company, SystemConfiguration
from .geography import Country, Region, City, State
from .localization import Language, Translation, Locale, LanguageKey, LanguageSetting
from .department import Department, Unit

__all__ = [
    # Company Management
    "Company",
    "SystemConfiguration",
    
    # Geographic Data
    "Country",
    "Region", 
    "City",
    "State",
    
    # Localization System
    "Language",
    "Translation",
    "Locale",
    "LanguageKey",
    "LanguageSetting",
    
    # Organizational Structure
    "Department",
    "Unit"
]