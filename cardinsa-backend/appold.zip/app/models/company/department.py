"""
Department and Organizational Structure Models

Models for managing organizational hierarchy, departments, units,
and user assignments within the company structure.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, List
from sqlalchemy import (
    Column, String, Text, Boolean, DateTime, Integer, 
    Numeric, JSON, ForeignKey, UniqueConstraint, Index
)
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID, JSONB

from app.models.base import BaseModel, TimestampMixin, AuditMixin


class Department(BaseModel, TimestampMixin, AuditMixin):
    """
    Department Model
    
    Organizational departments within a company with hierarchical
    structure, management, and operational configuration.
    """
    __tablename__ = "departments"
    
    # Basic Department Information
    department_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    department_code: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    
    # Company Association
    company_id: Mapped[UUID] = mapped_column(
        ForeignKey("companies.id", ondelete="CASCADE"), 
        nullable=False, 
        index=True
    )
    
    # Hierarchical Structure
    parent_department_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("departments.id", ondelete="SET NULL"),
        index=True
    )
    department_level: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    department_path: Mapped[Optional[str]] = mapped_column(String(500))
    # Materialized path for hierarchy queries: "/1/5/12/"
    
    # Department Type and Classification
    department_type: Mapped[str] = mapped_column(String(50), default="operational", nullable=False)
    # operational, support, executive, administrative, technical
    business_function: Mapped[Optional[str]] = mapped_column(String(100))
    # underwriting, claims, sales, customer_service, finance, hr, it
    
    # Management and Leadership
    head_of_department_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"),
        index=True
    )
    deputy_head_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    
    # Contact Information
    primary_email: Mapped[Optional[str]] = mapped_column(String(255))
    primary_phone: Mapped[Optional[str]] = mapped_column(String(50))
    extension: Mapped[Optional[str]] = mapped_column(String(20))
    
    # Location Information
    office_location: Mapped[Optional[str]] = mapped_column(String(200))
    floor: Mapped[Optional[str]] = mapped_column(String(20))
    building: Mapped[Optional[str]] = mapped_column(String(100))
    room_numbers: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Geographic Information
    city_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("cities.id"))
    region_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("regions.id"))
    country_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("countries.id"))
    
    # Operational Configuration
    working_hours: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    # {"monday": {"start": "09:00", "end": "17:00"}, ...}
    timezone: Mapped[Optional[str]] = mapped_column(String(100))
    holiday_calendar: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Financial Information
    cost_center: Mapped[Optional[str]] = mapped_column(String(50), index=True)
    budget_code: Mapped[Optional[str]] = mapped_column(String(50))
    annual_budget: Mapped[Optional[Decimal]] = mapped_column(Numeric(15, 2))
    currency: Mapped[Optional[str]] = mapped_column(String(3))
    
    # Staffing Information
    max_capacity: Mapped[Optional[int]] = mapped_column(Integer)
    current_headcount: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    target_headcount: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Performance Metrics
    performance_metrics: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    kpi_targets: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Access Control and Security
    security_level: Mapped[str] = mapped_column(String(50), default="standard", nullable=False)
    # public, internal, confidential, restricted, top_secret
    access_requirements: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # Required clearances or permissions
    
    # Workflow and Approval
    approval_workflows: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    escalation_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    delegation_matrix: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Insurance-Specific Configuration
    product_lines: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # Insurance product lines this department handles
    regulatory_scope: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # Regulatory areas this department covers
    license_requirements: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Communication and Collaboration
    internal_communications: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    external_communications: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    collaboration_tools: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Status and Lifecycle
    department_status: Mapped[str] = mapped_column(String(50), default="active", nullable=False)
    # active, inactive, restructuring, dissolved, planned
    effective_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    dissolution_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Priority and Importance
    business_priority: Mapped[str] = mapped_column(String(20), default="normal", nullable=False)
    # critical, high, normal, low
    strategic_importance: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)
    # high, medium, low
    
    # Additional Configuration
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    policies: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    procedures: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Documentation and Help
    notes: Mapped[Optional[str]] = mapped_column(Text)
    documentation_links: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    training_materials: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Relationships
    company = relationship("Company", back_populates="departments")
    parent_department = relationship("Department", remote_side="Department.id")
    child_departments = relationship("Department", cascade="all, delete-orphan")
    head_of_department = relationship("User", foreign_keys=[head_of_department_id])
    deputy_head = relationship("User", foreign_keys=[deputy_head_id])
    units = relationship("Unit", back_populates="department", cascade="all, delete-orphan")
    users = relationship("User", back_populates="department")
    city = relationship("City")
    region = relationship("Region")
    country = relationship("Country")
    
    # Indexes
    __table_args__ = (
        Index("idx_departments_company", "company_id"),
        Index("idx_departments_parent", "parent_department_id"),
        Index("idx_departments_head", "head_of_department_id"),
        Index("idx_departments_status", "department_status"),
        Index("idx_departments_type", "department_type"),
        Index("idx_departments_function", "business_function"),
        Index("idx_departments_cost_center", "cost_center"),
        Index("idx_departments_level", "department_level"),
        UniqueConstraint("company_id", "department_code", name="uq_departments_company_code"),
    )
    
    def __repr__(self) -> str:
        return f"<Department(id={self.id}, name={self.department_name}, company={self.company_id})>"
    
    @property
    def is_active(self) -> bool:
        """Check if department is active"""
        return self.department_status == "active"
    
    @property
    def is_root_department(self) -> bool:
        """Check if this is a root department (no parent)"""
        return self.parent_department_id is None
    
    @property
    def has_children(self) -> bool:
        """Check if department has child departments"""
        return len(self.child_departments) > 0
    
    @property
    def is_over_capacity(self) -> bool:
        """Check if department is over its maximum capacity"""
        return self.max_capacity is not None and self.current_headcount > self.max_capacity


class Unit(BaseModel, TimestampMixin, AuditMixin):
    """
    Unit Model
    
    Organizational units within departments - smaller subdivisions
    for team management and specialized functions.
    """
    __tablename__ = "units"
    
    # Basic Unit Information
    unit_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    unit_code: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    
    # Department Association
    department_id: Mapped[UUID] = mapped_column(
        ForeignKey("departments.id", ondelete="CASCADE"), 
        nullable=False, 
        index=True
    )
    
    # Unit Type and Specialization
    unit_type: Mapped[str] = mapped_column(String(50), default="team", nullable=False)
    # team, squad, group, section, division, bureau
    specialization: Mapped[Optional[str]] = mapped_column(String(100))
    # Specific area of expertise or responsibility
    
    # Management
    unit_manager_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"),
        index=True
    )
    assistant_manager_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    
    # Contact Information
    unit_email: Mapped[Optional[str]] = mapped_column(String(255))
    unit_phone: Mapped[Optional[str]] = mapped_column(String(50))
    extension: Mapped[Optional[str]] = mapped_column(String(20))
    
    # Location and Physical Setup
    location: Mapped[Optional[str]] = mapped_column(String(200))
    floor: Mapped[Optional[str]] = mapped_column(String(20))
    room_number: Mapped[Optional[str]] = mapped_column(String(20))
    seating_arrangement: Mapped[Optional[str]] = mapped_column(String(100))
    # open_plan, cubicles, private_offices, hybrid
    
    # Operational Configuration
    working_schedule: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    shift_pattern: Mapped[Optional[str]] = mapped_column(String(50))
    # standard, rotating, flexible, 24x7
    break_schedule: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Staffing and Capacity
    max_members: Mapped[Optional[int]] = mapped_column(Integer)
    current_members: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    optimal_size: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Skills and Competencies
    required_skills: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    skill_levels: Mapped[Optional[Dict[str, str]]] = mapped_column(JSONB)
    # skill_name -> required_level (beginner, intermediate, advanced, expert)
    certifications_required: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Performance and Metrics
    performance_targets: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    productivity_metrics: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    quality_standards: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Financial Allocation
    cost_center: Mapped[Optional[str]] = mapped_column(String(50), index=True)
    budget_allocation: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2))
    overhead_percentage: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    
    # Workflow and Process
    primary_processes: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    secondary_processes: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    workflow_automation: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Tools and Technology
    software_tools: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    hardware_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    system_access: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Insurance-Specific Functions
    product_specialization: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # Specific insurance products this unit handles
    customer_segments: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # Customer segments this unit serves
    regulatory_functions: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Communication and Coordination
    reporting_frequency: Mapped[Optional[str]] = mapped_column(String(20))
    # daily, weekly, bi_weekly, monthly
    meeting_schedule: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    communication_channels: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Training and Development
    training_programs: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    development_paths: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    mentorship_programs: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Status and Lifecycle
    unit_status: Mapped[str] = mapped_column(String(50), default="active", nullable=False)
    # active, inactive, forming, storming, norming, performing, transitioning
    formation_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    dissolution_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Priority and Classification
    business_criticality: Mapped[str] = mapped_column(String(20), default="normal", nullable=False)
    # critical, high, normal, low
    security_clearance: Mapped[Optional[str]] = mapped_column(String(50))
    
    # Quality and Standards
    quality_certifications: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    compliance_standards: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    audit_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Additional Configuration
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    operating_procedures: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    emergency_procedures: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Documentation
    notes: Mapped[Optional[str]] = mapped_column(Text)
    documentation: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    knowledge_base: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    department = relationship("Department", back_populates="units")
    unit_manager = relationship("User", foreign_keys=[unit_manager_id])
    assistant_manager = relationship("User", foreign_keys=[assistant_manager_id])
    users = relationship("User", back_populates="unit")
    
    # Indexes
    __table_args__ = (
        Index("idx_units_department", "department_id"),
        Index("idx_units_manager", "unit_manager_id"),
        Index("idx_units_status", "unit_status"),
        Index("idx_units_type", "unit_type"),
        Index("idx_units_cost_center", "cost_center"),
        Index("idx_units_criticality", "business_criticality"),
        UniqueConstraint("department_id", "unit_code", name="uq_units_department_code"),
    )
    
    def __repr__(self) -> str:
        return f"<Unit(id={self.id}, name={self.unit_name}, department={self.department_id})>"
    
    @property
    def is_active(self) -> bool:
        """Check if unit is active"""
        return self.unit_status == "active"
    
    @property
    def is_at_capacity(self) -> bool:
        """Check if unit is at maximum capacity"""
        return self.max_members is not None and self.current_members >= self.max_members
    
    @property
    def capacity_utilization(self) -> Optional[Decimal]:
        """Calculate capacity utilization percentage"""
        if self.max_members is None or self.max_members == 0:
            return None
        return Decimal(self.current_members) / Decimal(self.max_members) * 100
    
    @property
    def has_manager(self) -> bool:
        """Check if unit has an assigned manager"""
        return self.unit_manager_id is not None
    
    @property
    def is_critical(self) -> bool:
        """Check if unit is business critical"""
        return self.business_criticality == "critical"