"""
Company and System Configuration Models

Core models for multi-tenant company management and system configuration.
These models form the foundation of the multi-tenant architecture.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, List
from sqlalchemy import (
    Column, String, Text, Boolean, DateTime, Integer, 
    Numeric, JSON, ForeignKey, UniqueConstraint, Index
)
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID, JSONB

from app.models.base import BaseModel, TimestampMixin, AuditMixin


class Company(BaseModel, TimestampMixin, AuditMixin):
    """
    Company Model - Multi-tenant company management
    
    Core entity for multi-tenancy. Each company represents a separate
    insurance organization with its own data, users, and configurations.
    """
    __tablename__ = "companies"
    
    # Basic Company Information
    company_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    legal_name: Mapped[str] = mapped_column(String(255), nullable=False)
    company_code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    registration_number: Mapped[Optional[str]] = mapped_column(String(100), unique=True)
    tax_id: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Industry and Business Type
    industry_type: Mapped[str] = mapped_column(String(100), default="insurance", nullable=False)
    business_type: Mapped[str] = mapped_column(String(50), default="insurance_company", nullable=False)
    company_size: Mapped[Optional[str]] = mapped_column(String(50))  # small, medium, large, enterprise
    
    # Contact Information
    primary_email: Mapped[Optional[str]] = mapped_column(String(255))
    primary_phone: Mapped[Optional[str]] = mapped_column(String(50))
    website_url: Mapped[Optional[str]] = mapped_column(String(500))
    
    # Address Information
    address_line1: Mapped[Optional[str]] = mapped_column(String(255))
    address_line2: Mapped[Optional[str]] = mapped_column(String(255))
    city: Mapped[Optional[str]] = mapped_column(String(100))
    state_province: Mapped[Optional[str]] = mapped_column(String(100))
    postal_code: Mapped[Optional[str]] = mapped_column(String(20))
    country_code: Mapped[Optional[str]] = mapped_column(String(3))
    
    # Geographic and Regulatory
    primary_country_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("countries.id", ondelete="SET NULL")
    )
    headquarters_timezone: Mapped[str] = mapped_column(String(100), default="UTC", nullable=False)
    regulatory_region: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Financial Information
    base_currency: Mapped[str] = mapped_column(String(3), default="USD", nullable=False)
    supported_currencies: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    fiscal_year_start: Mapped[Optional[int]] = mapped_column(Integer, default=1)  # Month 1-12
    
    # Branding and Customization
    logo_url: Mapped[Optional[str]] = mapped_column(String(500))
    favicon_url: Mapped[Optional[str]] = mapped_column(String(500))
    brand_colors: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    custom_themes: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Status and Lifecycle
    company_status: Mapped[str] = mapped_column(String(50), default="active", nullable=False)
    # active, inactive, suspended, terminated, pending_setup
    subscription_tier: Mapped[str] = mapped_column(String(50), default="basic", nullable=False)
    # basic, professional, enterprise, custom
    onboarding_status: Mapped[str] = mapped_column(String(50), default="pending", nullable=False)
    # pending, in_progress, completed, failed
    
    # Feature Flags and Licensing
    enabled_features: Mapped[Optional[List[str]]] = mapped_column(JSONB, default=list)
    feature_limits: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    license_info: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Compliance and Security
    compliance_requirements: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # e.g., ["GDPR", "HIPAA", "SOX", "PCI_DSS"]
    data_residency: Mapped[Optional[str]] = mapped_column(String(100))
    security_level: Mapped[str] = mapped_column(String(50), default="standard", nullable=False)
    # basic, standard, enhanced, maximum
    
    # Integration and API
    api_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    webhook_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    external_integrations: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Billing and Subscription
    billing_contact_email: Mapped[Optional[str]] = mapped_column(String(255))
    payment_terms: Mapped[Optional[int]] = mapped_column(Integer, default=30)  # Days
    billing_frequency: Mapped[str] = mapped_column(String(20), default="monthly", nullable=False)
    # monthly, quarterly, annually
    
    # Operational Dates
    setup_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    go_live_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    contract_start_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    contract_end_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_activity_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Additional Metadata
    notes: Mapped[Optional[str]] = mapped_column(Text)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    tags: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    
    # Relationships
    primary_country = relationship("Country", foreign_keys=[primary_country_id])
    system_configuration = relationship("SystemConfiguration", back_populates="company", uselist=False)
    users = relationship("User", back_populates="company")
    departments = relationship("Department", back_populates="company")
    
    # Indexes for performance
    __table_args__ = (
        Index("idx_companies_status", "company_status"),
        Index("idx_companies_country", "primary_country_id"),
        Index("idx_companies_tier", "subscription_tier"),
        Index("idx_companies_activity", "last_activity_date"),
        UniqueConstraint("company_code", name="uq_companies_code"),
        UniqueConstraint("registration_number", name="uq_companies_registration"),
    )
    
    def __repr__(self) -> str:
        return f"<Company(id={self.id}, name={self.company_name}, code={self.company_code})>"
    
    @property
    def is_active(self) -> bool:
        """Check if company is in active status"""
        return self.company_status == "active"
    
    @property
    def is_enterprise(self) -> bool:
        """Check if company has enterprise subscription"""
        return self.subscription_tier in ("enterprise", "custom")
    
    @property
    def setup_completed(self) -> bool:
        """Check if company onboarding is completed"""
        return self.onboarding_status == "completed"


class SystemConfiguration(BaseModel, TimestampMixin, AuditMixin):
    """
    System Configuration Model
    
    Company-specific system settings and configurations.
    Each company can have different operational parameters.
    """
    __tablename__ = "system_configuration"
    
    # Company Association
    company_id: Mapped[UUID] = mapped_column(
        ForeignKey("companies.id", ondelete="CASCADE"), 
        nullable=False, 
        unique=True,
        index=True
    )
    
    # Authentication & Security Configuration
    password_policy: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    session_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    mfa_requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    security_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Localization Configuration
    default_language: Mapped[str] = mapped_column(String(10), default="en", nullable=False)
    supported_languages: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    default_locale: Mapped[str] = mapped_column(String(10), default="en_US", nullable=False)
    timezone_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Business Rules Configuration
    business_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    workflow_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    approval_workflows: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Insurance-Specific Configuration
    policy_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    claim_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    underwriting_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    pricing_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Financial Configuration
    currency_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    tax_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    billing_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    payment_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Communication Configuration
    email_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    sms_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    notification_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Integration Configuration
    api_configuration: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    third_party_integrations: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    webhook_configuration: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Reporting and Analytics Configuration
    reporting_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    analytics_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    dashboard_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Data Management Configuration
    data_retention_policies: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    backup_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    archival_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Compliance Configuration
    audit_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    compliance_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    gdpr_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # UI/UX Configuration
    ui_customization: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    branding_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    layout_preferences: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Performance Configuration
    performance_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    caching_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    rate_limiting: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Feature Toggles
    feature_flags: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    experimental_features: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    beta_features: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Environment-Specific Settings
    environment_type: Mapped[str] = mapped_column(String(20), default="production", nullable=False)
    # production, staging, development, testing
    debug_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Version and Maintenance
    configuration_version: Mapped[str] = mapped_column(String(20), default="1.0.0", nullable=False)
    last_configuration_update: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    maintenance_windows: Mapped[Optional[List[Dict[str, Any]]]] = mapped_column(JSONB)
    
    # Additional Configuration
    custom_configuration: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    extension_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    company = relationship("Company", back_populates="system_configuration")
    
    # Indexes
    __table_args__ = (
        Index("idx_system_config_company", "company_id"),
        Index("idx_system_config_version", "configuration_version"),
        Index("idx_system_config_environment", "environment_type"),
    )
    
    def __repr__(self) -> str:
        return f"<SystemConfiguration(id={self.id}, company_id={self.company_id})>"
    
    def get_setting(self, category: str, key: str, default: Any = None) -> Any:
        """Get a specific configuration setting"""
        category_settings = getattr(self, category, {}) or {}
        return category_settings.get(key, default)
    
    def update_setting(self, category: str, key: str, value: Any) -> None:
        """Update a specific configuration setting"""
        if not hasattr(self, category):
            raise ValueError(f"Invalid configuration category: {category}")
        
        category_settings = getattr(self, category) or {}
        category_settings[key] = value
        setattr(self, category, category_settings)
        self.last_configuration_update = datetime.utcnow()
    
    @property
    def is_production(self) -> bool:
        """Check if environment is production"""
        return self.environment_type == "production"