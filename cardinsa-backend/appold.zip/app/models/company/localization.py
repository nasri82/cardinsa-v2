"""
Localization Models

Models for managing multi-language support, translations, locales,
and language preferences across the insurance platform.
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, Dict, Any, List
from sqlalchemy import (
    Column, String, Text, Boolean, DateTime, Integer, 
    Numeric, JSON, ForeignKey, UniqueConstraint, Index
)
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID, JSONB

from app.models.base import BaseModel, TimestampMixin, AuditMixin


class Language(BaseModel, TimestampMixin, AuditMixin):
    """
    Language Model
    
    Master data for supported languages with ISO codes,
    completion status, and language-specific configuration.
    """
    __tablename__ = "languages"
    
    # Language Identification
    language_code: Mapped[str] = mapped_column(String(10), unique=True, nullable=False, index=True)
    iso_639_1: Mapped[Optional[str]] = mapped_column(String(2), unique=True, index=True)
    iso_639_2: Mapped[Optional[str]] = mapped_column(String(3), unique=True)
    iso_639_3: Mapped[Optional[str]] = mapped_column(String(3), unique=True)
    
    # Language Names
    language_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    native_name: Mapped[str] = mapped_column(String(100), nullable=False)
    english_name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # Language Properties
    text_direction: Mapped[str] = mapped_column(String(3), default="ltr", nullable=False)
    # ltr (left-to-right), rtl (right-to-left)
    script: Mapped[Optional[str]] = mapped_column(String(50))
    # Latin, Arabic, Cyrillic, Chinese, etc.
    
    # Language Family and Classification
    language_family: Mapped[Optional[str]] = mapped_column(String(100))
    language_branch: Mapped[Optional[str]] = mapped_column(String(100))
    language_group: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Regional and Usage Information
    primary_countries: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # List of country codes where this is primary language
    speaker_count: Mapped[Optional[int]] = mapped_column(Integer)
    native_speakers: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Translation and Localization Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_supported: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    completion_percentage: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0.0, nullable=False)
    
    # Translation Quality and Management
    translation_quality: Mapped[str] = mapped_column(String(20), default="draft", nullable=False)
    # draft, review, approved, published
    last_translation_update: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    translator_notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Formatting and Display
    date_format: Mapped[str] = mapped_column(String(50), default="MM/dd/yyyy", nullable=False)
    time_format: Mapped[str] = mapped_column(String(20), default="HH:mm", nullable=False)
    number_format: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    currency_format: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Pluralization Rules
    plural_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    plural_forms_count: Mapped[int] = mapped_column(Integer, default=2, nullable=False)
    
    # Font and Typography
    recommended_fonts: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    font_size_adjustments: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    line_height_adjustments: Mapped[Optional[Decimal]] = mapped_column(Numeric(3, 2), default=1.0)
    
    # Business and Legal
    business_languages: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # Languages commonly used in business contexts
    legal_status: Mapped[Optional[str]] = mapped_column(String(50))
    # official, regional, minority, foreign
    
    # Technical Configuration
    keyboard_layout: Mapped[Optional[str]] = mapped_column(String(50))
    input_method: Mapped[Optional[str]] = mapped_column(String(50))
    encoding: Mapped[str] = mapped_column(String(20), default="UTF-8", nullable=False)
    
    # Priority and Sorting
    display_priority: Mapped[int] = mapped_column(Integer, default=999, nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=999, nullable=False)
    
    # Additional Metadata
    notes: Mapped[Optional[str]] = mapped_column(Text)
    external_references: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    translations = relationship("Translation", back_populates="language", cascade="all, delete-orphan")
    locales = relationship("Locale", back_populates="language", cascade="all, delete-orphan")
    language_settings = relationship("LanguageSetting", back_populates="language")
    
    # Indexes
    __table_args__ = (
        Index("idx_languages_code", "language_code"),
        Index("idx_languages_active", "is_active"),
        Index("idx_languages_supported", "is_supported"),
        Index("idx_languages_priority", "display_priority"),
        Index("idx_languages_completion", "completion_percentage"),
        UniqueConstraint("language_code", name="uq_languages_code"),
    )
    
    def __repr__(self) -> str:
        return f"<Language(id={self.id}, code={self.language_code}, name={self.language_name})>"
    
    @property
    def is_rtl(self) -> bool:
        """Check if language is right-to-left"""
        return self.text_direction == "rtl"
    
    @property
    def is_complete(self) -> bool:
        """Check if translation is complete (>95%)"""
        return self.completion_percentage >= 95.0


class Translation(BaseModel, TimestampMixin, AuditMixin):
    """
    Translation Model
    
    Key-value pairs for translated content with versioning,
    context, and quality management.
    """
    __tablename__ = "translations"
    
    # Translation Key and Language
    translation_key: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    language_id: Mapped[UUID] = mapped_column(
        ForeignKey("languages.id", ondelete="CASCADE"), 
        nullable=False, 
        index=True
    )
    
    # Translation Content
    translation_value: Mapped[str] = mapped_column(Text, nullable=False)
    original_value: Mapped[Optional[str]] = mapped_column(Text)
    # Store original text for reference
    
    # Context and Usage
    context: Mapped[Optional[str]] = mapped_column(String(200))
    # UI context: button, label, message, title, etc.
    module: Mapped[Optional[str]] = mapped_column(String(100))
    # Module/feature context: auth, claims, policies, etc.
    screen: Mapped[Optional[str]] = mapped_column(String(100))
    # Specific screen or page
    
    # Translation Metadata
    character_count: Mapped[Optional[int]] = mapped_column(Integer)
    word_count: Mapped[Optional[int]] = mapped_column(Integer)
    is_plural: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    plural_forms: Mapped[Optional[Dict[str, str]]] = mapped_column(JSONB)
    
    # Quality and Status
    translation_status: Mapped[str] = mapped_column(String(20), default="draft", nullable=False)
    # draft, review, approved, published, outdated
    quality_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(3, 2))
    # 0.0 to 1.0 quality score
    
    # Translation Management
    translator_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("users.id"))
    reviewer_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("users.id"))
    approved_by: Mapped[Optional[UUID]] = mapped_column(ForeignKey("users.id"))
    
    # Timestamps
    translated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Version Control
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    previous_version_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("translations.id"))
    
    # Usage Statistics
    usage_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_used: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Validation and Constraints
    max_length: Mapped[Optional[int]] = mapped_column(Integer)
    min_length: Mapped[Optional[int]] = mapped_column(Integer)
    validation_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Comments and Notes
    translator_notes: Mapped[Optional[str]] = mapped_column(Text)
    reviewer_comments: Mapped[Optional[str]] = mapped_column(Text)
    client_feedback: Mapped[Optional[str]] = mapped_column(Text)
    
    # Additional Metadata
    tags: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    language = relationship("Language", back_populates="translations")
    translator = relationship("User", foreign_keys=[translator_id])
    reviewer = relationship("User", foreign_keys=[reviewer_id])
    approver = relationship("User", foreign_keys=[approved_by])
    previous_version = relationship("Translation", remote_side="Translation.id")
    
    # Indexes
    __table_args__ = (
        Index("idx_translations_key", "translation_key"),
        Index("idx_translations_language", "language_id"),
        Index("idx_translations_status", "translation_status"),
        Index("idx_translations_module", "module"),
        Index("idx_translations_usage", "usage_count"),
        Index("idx_translations_key_lang", "translation_key", "language_id"),
        UniqueConstraint("translation_key", "language_id", "version", name="uq_translations_key_lang_version"),
    )
    
    def __repr__(self) -> str:
        return f"<Translation(id={self.id}, key={self.translation_key}, language={self.language_id})>"
    
    @property
    def is_approved(self) -> bool:
        """Check if translation is approved"""
        return self.translation_status == "approved"
    
    @property
    def needs_review(self) -> bool:
        """Check if translation needs review"""
        return self.translation_status in ("draft", "review")


class Locale(BaseModel, TimestampMixin, AuditMixin):
    """
    Locale Model
    
    Locale-specific formatting rules combining language,
    country, and cultural conventions.
    """
    __tablename__ = "locales"
    
    # Locale Identification
    locale_code: Mapped[str] = mapped_column(String(10), unique=True, nullable=False, index=True)
    # e.g., en_US, fr_FR, ar_SA
    
    # Language and Country Association
    language_id: Mapped[UUID] = mapped_column(
        ForeignKey("languages.id", ondelete="CASCADE"), 
        nullable=False, 
        index=True
    )
    country_code: Mapped[str] = mapped_column(String(3), nullable=False, index=True)
    
    # Display Names
    locale_name: Mapped[str] = mapped_column(String(100), nullable=False)
    native_name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # Currency Settings
    currency_code: Mapped[str] = mapped_column(String(3), nullable=False)
    currency_symbol: Mapped[str] = mapped_column(String(10), nullable=False)
    currency_position: Mapped[str] = mapped_column(String(10), default="before", nullable=False)
    # before, after
    
    # Number Formatting
    decimal_separator: Mapped[str] = mapped_column(String(1), default=".", nullable=False)
    thousands_separator: Mapped[str] = mapped_column(String(1), default=",", nullable=False)
    number_grouping: Mapped[List[int]] = mapped_column(JSONB, default=[3])
    
    # Date and Time Formatting
    date_format: Mapped[str] = mapped_column(String(50), default="MM/dd/yyyy", nullable=False)
    time_format: Mapped[str] = mapped_column(String(20), default="HH:mm", nullable=False)
    datetime_format: Mapped[str] = mapped_column(String(70), nullable=False)
    
    # Week and Calendar Settings
    first_day_of_week: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    # 1=Monday, 7=Sunday
    weekend_days: Mapped[List[int]] = mapped_column(JSONB, default=[6, 7])
    # Days of week that are weekends
    
    # Regional Preferences
    address_format: Mapped[Optional[str]] = mapped_column(Text)
    phone_format: Mapped[Optional[str]] = mapped_column(String(50))
    postal_code_format: Mapped[Optional[str]] = mapped_column(String(50))
    
    # Measurement Units
    measurement_system: Mapped[str] = mapped_column(String(20), default="metric", nullable=False)
    # metric, imperial, mixed
    temperature_unit: Mapped[str] = mapped_column(String(10), default="celsius", nullable=False)
    # celsius, fahrenheit
    
    # Business and Legal Conventions
    business_hours_format: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    legal_age: Mapped[int] = mapped_column(Integer, default=18, nullable=False)
    business_days: Mapped[List[int]] = mapped_column(JSONB, default=[1, 2, 3, 4, 5])
    
    # Insurance-Specific Formatting
    policy_number_format: Mapped[Optional[str]] = mapped_column(String(100))
    claim_number_format: Mapped[Optional[str]] = mapped_column(String(100))
    member_id_format: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Status and Usage
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    usage_priority: Mapped[int] = mapped_column(Integer, default=999, nullable=False)
    
    # Additional Configuration
    custom_formats: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    cultural_notes: Mapped[Optional[str]] = mapped_column(Text)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Relationships
    language = relationship("Language", back_populates="locales")
    
    # Indexes
    __table_args__ = (
        Index("idx_locales_code", "locale_code"),
        Index("idx_locales_language", "language_id"),
        Index("idx_locales_country", "country_code"),
        Index("idx_locales_active", "is_active"),
        Index("idx_locales_default", "is_default"),
        UniqueConstraint("locale_code", name="uq_locales_code"),
    )
    
    def __repr__(self) -> str:
        return f"<Locale(id={self.id}, code={self.locale_code}, name={self.locale_name})>"
    
    def format_currency(self, amount: Decimal) -> str:
        """Format currency amount according to locale settings"""
        # Format number with thousands separator
        formatted_number = f"{amount:,.{2}f}".replace(",", self.thousands_separator).replace(".", self.decimal_separator)
        
        if self.currency_position == "before":
            return f"{self.currency_symbol}{formatted_number}"
        else:
            return f"{formatted_number}{self.currency_symbol}"
    
    def format_date(self, date: datetime) -> str:
        """Format date according to locale settings"""
        return date.strftime(self.date_format)


class LanguageKey(BaseModel, TimestampMixin, AuditMixin):
    """
    Language Key Model
    
    Registry of all translatable keys in the system with metadata,
    usage tracking, and management information.
    """
    __tablename__ = "language_keys"
    
    # Key Information
    key_name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    key_category: Mapped[Optional[str]] = mapped_column(String(100), index=True)
    # UI, email, sms, document, report, etc.
    
    # Context and Classification
    context: Mapped[Optional[str]] = mapped_column(String(200))
    module: Mapped[Optional[str]] = mapped_column(String(100), index=True)
    component: Mapped[Optional[str]] = mapped_column(String(100))
    feature: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Content Type and Structure
    data_type: Mapped[str] = mapped_column(String(20), default="string", nullable=False)
    # string, html, markdown, json, array
    is_html: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_plural: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    has_variables: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Variables and Parameters
    variables: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # List of variable names used in the key
    variable_types: Mapped[Optional[Dict[str, str]]] = mapped_column(JSONB)
    # Variable name to type mapping
    
    # Constraints and Validation
    max_length: Mapped[Optional[int]] = mapped_column(Integer)
    min_length: Mapped[Optional[int]] = mapped_column(Integer)
    validation_pattern: Mapped[Optional[str]] = mapped_column(String(500))
    validation_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Usage Statistics and Tracking
    usage_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_used: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    first_used: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Lifecycle Management
    is_deprecated: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    deprecation_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    replacement_key: Mapped[Optional[str]] = mapped_column(String(255))
    removal_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Priority and Importance
    translation_priority: Mapped[str] = mapped_column(String(20), default="normal", nullable=False)
    # critical, high, normal, low
    business_impact: Mapped[str] = mapped_column(String(20), default="medium", nullable=False)
    # high, medium, low
    
    # Default Content
    default_value: Mapped[Optional[str]] = mapped_column(Text)
    fallback_value: Mapped[Optional[str]] = mapped_column(Text)
    
    # Documentation and Help
    description: Mapped[Optional[str]] = mapped_column(Text)
    usage_examples: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    context_help: Mapped[Optional[str]] = mapped_column(Text)
    
    # Quality and Completeness
    translation_completeness: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=0.0, nullable=False)
    quality_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(3, 2))
    
    # Change Management
    last_modified_by: Mapped[Optional[UUID]] = mapped_column(ForeignKey("users.id"))
    change_reason: Mapped[Optional[str]] = mapped_column(String(500))
    
    # Additional Metadata
    tags: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    custom_fields: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    translations = relationship("Translation", primaryjoin="LanguageKey.key_name == Translation.translation_key", foreign_keys="Translation.translation_key", viewonly=True)
    last_modifier = relationship("User", foreign_keys=[last_modified_by])
    
    # Indexes
    __table_args__ = (
        Index("idx_language_keys_name", "key_name"),
        Index("idx_language_keys_category", "key_category"),
        Index("idx_language_keys_module", "module"),
        Index("idx_language_keys_deprecated", "is_deprecated"),
        Index("idx_language_keys_priority", "translation_priority"),
        Index("idx_language_keys_usage", "usage_count"),
        UniqueConstraint("key_name", name="uq_language_keys_name"),
    )
    
    def __repr__(self) -> str:
        return f"<LanguageKey(id={self.id}, key={self.key_name}, category={self.key_category})>"
    
    @property
    def is_active(self) -> bool:
        """Check if key is active (not deprecated)"""
        return not self.is_deprecated
    
    @property
    def needs_translation(self) -> bool:
        """Check if key needs translation (< 100% complete)"""
        return self.translation_completeness < 100.0


class LanguageSetting(BaseModel, TimestampMixin, AuditMixin):
    """
    Language Setting Model
    
    User and company-specific language preferences and settings.
    """
    __tablename__ = "language_settings"
    
    # Entity Association (User or Company)
    user_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), 
        index=True
    )
    company_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("companies.id", ondelete="CASCADE"), 
        index=True
    )
    
    # Language Preferences
    preferred_language_id: Mapped[UUID] = mapped_column(
        ForeignKey("languages.id", ondelete="RESTRICT"), 
        nullable=False, 
        index=True
    )
    fallback_language_id: Mapped[Optional[UUID]] = mapped_column(
        ForeignKey("languages.id", ondelete="SET NULL"),
        index=True
    )
    
    # Locale Preferences
    preferred_locale: Mapped[Optional[str]] = mapped_column(String(10))
    timezone: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Content Preferences
    auto_translate: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    show_original_text: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    translation_quality_threshold: Mapped[Decimal] = mapped_column(Numeric(3, 2), default=0.8, nullable=False)
    
    # UI Preferences
    ui_language_override: Mapped[Optional[UUID]] = mapped_column(ForeignKey("languages.id"))
    date_format_override: Mapped[Optional[str]] = mapped_column(String(50))
    time_format_override: Mapped[Optional[str]] = mapped_column(String(20))
    number_format_override: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Communication Preferences
    email_language_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("languages.id"))
    sms_language_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("languages.id"))
    document_language_id: Mapped[Optional[UUID]] = mapped_column(ForeignKey("languages.id"))
    
    # Advanced Settings
    content_regions: Mapped[Optional[List[str]]] = mapped_column(JSONB)
    # Preferred content regions for localized content
    cultural_preferences: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    accessibility_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Usage and Analytics
    language_usage_stats: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    last_language_change: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    
    # Additional Configuration
    custom_settings: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Relationships
    user = relationship("User", foreign_keys=[user_id])
    company = relationship("Company", foreign_keys=[company_id])
    language = relationship("Language", foreign_keys=[preferred_language_id], back_populates="language_settings")
    fallback_language = relationship("Language", foreign_keys=[fallback_language_id])
    ui_language = relationship("Language", foreign_keys=[ui_language_override])
    email_language = relationship("Language", foreign_keys=[email_language_id])
    sms_language = relationship("Language", foreign_keys=[sms_language_id])
    document_language = relationship("Language", foreign_keys=[document_language_id])
    
    # Indexes
    __table_args__ = (
        Index("idx_language_settings_user", "user_id"),
        Index("idx_language_settings_company", "company_id"),
        Index("idx_language_settings_language", "preferred_language_id"),
        Index("idx_language_settings_active", "is_active"),
        # Ensure only one setting per user or company
        UniqueConstraint("user_id", name="uq_language_settings_user"),
        UniqueConstraint("company_id", name="uq_language_settings_company"),
    )
    
    def __repr__(self) -> str:
        entity_type = "user" if self.user_id else "company"
        entity_id = self.user_id if self.user_id else self.company_id
        return f"<LanguageSetting(id={self.id}, {entity_type}={entity_id}, language={self.preferred_language_id})>"
    
    @property
    def effective_language_id(self) -> UUID:
        """Get the effective language ID (preferred or fallback)"""
        return self.preferred_language_id
    
    @property
    def is_user_setting(self) -> bool:
        """Check if this is a user-specific setting"""
        return self.user_id is not None
    
    @property
    def is_company_setting(self) -> bool:
        """Check if this is a company-wide setting"""
        return self.company_id is not None