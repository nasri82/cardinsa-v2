"""
Model mixins for reusable functionality across different models.
"""

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import Column, DateTime, String, Text, Boolean, JSON
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column


class TimestampMixin:
    """Mixin for created_at and updated_at timestamps."""
    
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=False), 
        default=datetime.utcnow,
        nullable=False
    )
    
    updated_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=False), 
        onupdate=datetime.utcnow,
        nullable=True
    )


class AuditMixin:
    """Mixin for audit trail fields."""
    
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        nullable=True
    )
    
    updated_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        nullable=True
    )


class SoftDeleteMixin:
    """Mixin for soft delete functionality."""
    
    archived_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=False), 
        nullable=True
    )

    def soft_delete(self):
        """Mark the record as deleted by setting archived_at."""
        self.archived_at = datetime.utcnow()

    def restore(self):
        """Restore a soft-deleted record."""
        self.archived_at = None

    @property
    def is_deleted(self) -> bool:
        """Check if the record is soft-deleted."""
        return self.archived_at is not None


class ActiveMixin:
    """Mixin for active/inactive status."""
    
    is_active: Mapped[bool] = mapped_column(
        Boolean, 
        default=True,
        nullable=False
    )


class NameDescriptionMixin:
    """Mixin for name and description fields."""
    
    name: Mapped[str] = mapped_column(
        String(100), 
        nullable=False
    )
    
    description: Mapped[Optional[str]] = mapped_column(
        Text, 
        nullable=True
    )


class CodeMixin:
    """Mixin for code field with uniqueness."""
    
    code: Mapped[str] = mapped_column(
        String(50), 
        nullable=False,
        unique=True
    )


class MetadataMixin:
    """Mixin for storing additional metadata as JSONB."""
    
    metadata: Mapped[Optional[dict]] = mapped_column(
        JSONB, 
        nullable=True
    )


class StatusMixin:
    """Mixin for status field with enum-like behavior."""
    
    status: Mapped[Optional[str]] = mapped_column(
        String(50), 
        nullable=True
    )


class PriorityMixin:
    """Mixin for priority field."""
    
    priority: Mapped[Optional[int]] = mapped_column(
        nullable=True,
        default=0
    )


class ContactInfoMixin:
    """Mixin for contact information."""
    
    email: Mapped[Optional[str]] = mapped_column(
        String(255), 
        nullable=True
    )
    
    phone: Mapped[Optional[str]] = mapped_column(
        String(20), 
        nullable=True
    )


class AddressMixin:
    """Mixin for address information."""
    
    address_line_1: Mapped[Optional[str]] = mapped_column(
        String(255), 
        nullable=True
    )
    
    address_line_2: Mapped[Optional[str]] = mapped_column(
        String(255), 
        nullable=True
    )
    
    city: Mapped[Optional[str]] = mapped_column(
        String(100), 
        nullable=True
    )
    
    state: Mapped[Optional[str]] = mapped_column(
        String(100), 
        nullable=True
    )
    
    postal_code: Mapped[Optional[str]] = mapped_column(
        String(20), 
        nullable=True
    )
    
    country: Mapped[Optional[str]] = mapped_column(
        String(100), 
        nullable=True
    )


class ConfigurableMixin:
    """Mixin for configurable settings stored as JSONB."""
    
    settings: Mapped[Optional[dict]] = mapped_column(
        JSONB, 
        nullable=True,
        default=dict
    )
    
    configuration: Mapped[Optional[dict]] = mapped_column(
        JSONB, 
        nullable=True,
        default=dict
    )