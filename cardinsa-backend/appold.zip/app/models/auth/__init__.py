"""
Authentication Models Package
CARDINSA Insurance Platform

This package contains all authentication-related models:
- User: Core user entity with authentication data
- Role: Role-based access control
- Permission: Fine-grained permissions
- Session: User session management
- MFA: Multi-factor authentication (future)
"""

from .user import User

__all__ = [
    "User",
]