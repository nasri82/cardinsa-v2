"""
Authentication models for user management, roles, permissions, and organizational structure.
"""

import uuid
from datetime import datetime, timedelta
from typing import Optional, List

from sqlalchemy import (
    Column, String, Boolean, DateTime, Text, Integer, 
    ForeignKey, Table, UniqueConstraint, Index
)
from sqlalchemy.dialects.postgresql import UUID, JSONB, INET, ARRAY
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from app.models.mixins import (
    ActiveMixin, NameDescriptionMixin, CodeMixin, 
    MetadataMixin, ContactInfoMixin
)


# Association tables for many-to-many relationships
user_roles = Table(
    'user_roles',
    BaseModel.metadata,
    Column('user_id', UUID(as_uuid=True), ForeignKey('users.id', ondelete='CASCADE'), primary_key=True),
    Column('role_id', UUID(as_uuid=True), ForeignKey('roles.id', ondelete='CASCADE'), primary_key=True),
    Column('assigned_at', DateTime(timezone=False), default=datetime.utcnow),
    Column('assigned_by', UUID(as_uuid=True)),
    Column('expires_at', DateTime(timezone=False), nullable=True),
    Column('is_active', Boolean, default=True)
)

role_permissions = Table(
    'role_permissions',
    BaseModel.metadata,
    Column('role_id', UUID(as_uuid=True), ForeignKey('roles.id', ondelete='CASCADE'), primary_key=True),
    Column('permission_id', UUID(as_uuid=True), ForeignKey('permissions.id', ondelete='CASCADE'), primary_key=True),
    Column('granted_at', DateTime(timezone=False), default=datetime.utcnow),
    Column('granted_by', UUID(as_uuid=True))
)


class User(BaseModel, ActiveMixin, ContactInfoMixin):
    """
    User model for authentication and authorization.
    """
    __tablename__ = 'users'

    # Basic user information
    username: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    first_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    last_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    # Authentication fields
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    phone_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    two_factor_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Account status
    is_superuser: Mapped[bool] = mapped_column(Boolean, default=False)
    is_staff: Mapped[bool] = mapped_column(Boolean, default=False)
    account_locked: Mapped[bool] = mapped_column(Boolean, default=False)
    lock_reason: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    locked_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)
    
    # Login tracking
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)
    last_activity: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)
    login_attempts: Mapped[int] = mapped_column(Integer, default=0)
    
    # Organizational relationships
    department_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('departments.id', ondelete='SET NULL'),
        nullable=True
    )
    unit_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('units.id', ondelete='SET NULL'),
        nullable=True
    )
    
    # User preferences and settings
    preferences: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    timezone: Mapped[Optional[str]] = mapped_column(String(50), default='UTC')
    language: Mapped[Optional[str]] = mapped_column(String(10), default='en')
    
    # Profile information
    avatar_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    bio: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    roles: Mapped[List["Role"]] = relationship(
        "Role", 
        secondary=user_roles, 
        back_populates="users",
        lazy='selectin'
    )
    department: Mapped[Optional["Department"]] = relationship("Department", back_populates="users")
    unit: Mapped[Optional["Unit"]] = relationship("Unit", back_populates="users")
    passwords: Mapped[List["UserPassword"]] = relationship("UserPassword", back_populates="user")
    login_logs: Mapped[List["UserLoginLog"]] = relationship("UserLoginLog", back_populates="user")
    sessions: Mapped[List["Session"]] = relationship("Session", back_populates="user")
    mfa_methods: Mapped[List["MfaMethod"]] = relationship("MfaMethod", back_populates="user")

    # Indexes
    __table_args__ = (
        Index('idx_users_email', 'email'),
        Index('idx_users_username', 'username'),
        Index('idx_users_department_id', 'department_id'),
        Index('idx_users_unit_id', 'unit_id'),
        Index('idx_users_active', 'is_active'),
        Index('idx_users_last_login', 'last_login'),
    )

    @property
    def full_name(self) -> str:
        """Get the user's full name."""
        if self.first_name and self.last_name:
            return f"{self.first_name} {self.last_name}"
        elif self.first_name:
            return self.first_name
        elif self.last_name:
            return self.last_name
        return self.username

    @property
    def is_locked(self) -> bool:
        """Check if the user account is currently locked."""
        if not self.account_locked:
            return False
        if self.locked_until and self.locked_until <= datetime.utcnow():
            return False
        return True

    def lock_account(self, reason: str = None, duration_hours: int = None):
        """Lock the user account."""
        self.account_locked = True
        self.lock_reason = reason
        if duration_hours:
            self.locked_until = datetime.utcnow() + timedelta(hours=duration_hours)

    def unlock_account(self):
        """Unlock the user account."""
        self.account_locked = False
        self.lock_reason = None
        self.locked_until = None
        self.login_attempts = 0


class Role(BaseModel, ActiveMixin, NameDescriptionMixin):
    """
    Role model for role-based access control.
    """
    __tablename__ = 'roles'

    # Role properties
    code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    level: Mapped[int] = mapped_column(Integer, default=0)  # For hierarchical roles
    is_system_role: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Role configuration
    settings: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    
    # Relationships
    users: Mapped[List["User"]] = relationship(
        "User", 
        secondary=user_roles, 
        back_populates="roles"
    )
    permissions: Mapped[List["Permission"]] = relationship(
        "Permission", 
        secondary=role_permissions, 
        back_populates="roles"
    )

    # Indexes
    __table_args__ = (
        Index('idx_roles_code', 'code'),
        Index('idx_roles_active', 'is_active'),
        Index('idx_roles_level', 'level'),
    )


class Permission(BaseModel, NameDescriptionMixin):
    """
    Permission model for granular access control.
    """
    __tablename__ = 'permissions'

    # Permission properties
    code: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    resource: Mapped[str] = mapped_column(String(100), nullable=False)  # e.g., 'users', 'policies'
    action: Mapped[str] = mapped_column(String(50), nullable=False)     # e.g., 'read', 'write', 'delete'
    scope: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # e.g., 'own', 'department', 'all'
    
    # Permission configuration
    conditions: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)  # Additional conditions
    is_system_permission: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # Relationships
    roles: Mapped[List["Role"]] = relationship(
        "Role", 
        secondary=role_permissions, 
        back_populates="permissions"
    )

    # Indexes
    __table_args__ = (
        Index('idx_permissions_code', 'code'),
        Index('idx_permissions_resource', 'resource'),
        Index('idx_permissions_action', 'action'),
        Index('idx_permissions_resource_action', 'resource', 'action'),
        UniqueConstraint('resource', 'action', 'scope', name='uq_permission_resource_action_scope'),
    )


class Department(BaseModel, ActiveMixin, NameDescriptionMixin, CodeMixin):
    """
    Department model for organizational structure.
    """
    __tablename__ = 'departments'

    # Department hierarchy
    parent_department_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('departments.id', ondelete='SET NULL'),
        nullable=True
    )
    
    # Department properties
    manager_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('users.id', ondelete='SET NULL'),
        nullable=True
    )
    budget: Mapped[Optional[float]] = mapped_column(nullable=True)
    cost_center: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    # Relationships
    parent_department: Mapped[Optional["Department"]] = relationship(
        "Department", 
        remote_side="Department.id",
        back_populates="child_departments"
    )
    child_departments: Mapped[List["Department"]] = relationship(
        "Department", 
        back_populates="parent_department"
    )
    manager: Mapped[Optional["User"]] = relationship("User", foreign_keys=[manager_id])
    users: Mapped[List["User"]] = relationship("User", back_populates="department")
    units: Mapped[List["Unit"]] = relationship("Unit", back_populates="department")

    # Indexes
    __table_args__ = (
        Index('idx_departments_code', 'code'),
        Index('idx_departments_active', 'is_active'),
        Index('idx_departments_parent', 'parent_department_id'),
        Index('idx_departments_manager', 'manager_id'),
    )


class Unit(BaseModel, ActiveMixin, NameDescriptionMixin, CodeMixin):
    """
    Unit model for sub-department organizational structure.
    """
    __tablename__ = 'units'

    # Unit relationships
    department_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('departments.id', ondelete='CASCADE'),
        nullable=False
    )
    manager_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('users.id', ondelete='SET NULL'),
        nullable=True
    )
    
    # Unit properties
    budget: Mapped[Optional[float]] = mapped_column(nullable=True)
    cost_center: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    # Relationships
    department: Mapped["Department"] = relationship("Department", back_populates="units")
    manager: Mapped[Optional["User"]] = relationship("User", foreign_keys=[manager_id])
    users: Mapped[List["User"]] = relationship("User", back_populates="unit")

    # Indexes
    __table_args__ = (
        Index('idx_units_code', 'code'),
        Index('idx_units_active', 'is_active'),
        Index('idx_units_department', 'department_id'),
        Index('idx_units_manager', 'manager_id'),
    )


class UserPassword(BaseModel):
    """
    User password history model for password management.
    """
    __tablename__ = 'user_passwords'

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('users.id', ondelete='CASCADE'),
        nullable=False
    )
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    is_current: Mapped[bool] = mapped_column(Boolean, default=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="passwords")

    # Indexes
    __table_args__ = (
        Index('idx_user_passwords_user_id', 'user_id'),
        Index('idx_user_passwords_current', 'user_id', 'is_current'),
    )


class UserLoginLog(BaseModel):
    """
    User login log model for tracking authentication attempts.
    """
    __tablename__ = 'user_login_logs'

    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('users.id', ondelete='SET NULL'),
        nullable=True
    )
    username: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)  # For failed attempts
    ip_address: Mapped[Optional[str]] = mapped_column(INET, nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    success: Mapped[bool] = mapped_column(Boolean, nullable=False)
    failure_reason: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    location: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    device_info: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    
    # Relationships
    user: Mapped[Optional["User"]] = relationship("User", back_populates="login_logs")

    # Indexes
    __table_args__ = (
        Index('idx_user_login_logs_user_id', 'user_id'),
        Index('idx_user_login_logs_created_at', 'created_at'),
        Index('idx_user_login_logs_success', 'success'),
        Index('idx_user_login_logs_ip', 'ip_address'),
    )


class Session(BaseModel):
    """
    User session model for session management.
    """
    __tablename__ = 'sessions'

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('users.id', ondelete='CASCADE'),
        nullable=False
    )
    session_token: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    refresh_token: Mapped[Optional[str]] = mapped_column(String(255), unique=True, nullable=True, index=True)
    ip_address: Mapped[Optional[str]] = mapped_column(INET, nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    device_fingerprint: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="sessions")

    # Indexes
    __table_args__ = (
        Index('idx_sessions_user_id', 'user_id'),
        Index('idx_sessions_token', 'session_token'),
        Index('idx_sessions_refresh_token', 'refresh_token'),
        Index('idx_sessions_expires_at', 'expires_at'),
        Index('idx_sessions_active', 'is_active'),
    )


class MfaMethod(BaseModel, ActiveMixin):
    """
    Multi-factor authentication methods for users.
    """
    __tablename__ = 'mfa_methods'

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), 
        ForeignKey('users.id', ondelete='CASCADE'),
        nullable=False
    )
    method_type: Mapped[str] = mapped_column(String(30), nullable=False)  # 'totp', 'sms', 'email'
    method_config: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    backup_codes: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String), nullable=True)
    verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="mfa_methods")

    # Indexes
    __table_args__ = (
        Index('idx_mfa_methods_user_id', 'user_id'),
        Index('idx_mfa_methods_type', 'method_type'),
        Index('idx_mfa_methods_primary', 'user_id', 'is_primary'),
    )