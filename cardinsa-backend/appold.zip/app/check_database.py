#!/usr/bin/env python3
"""
Database connection checker for Cardinsa Insurance API.
This script tests database connectivity and provides detailed diagnostics.
"""

import sys
import asyncio
from pathlib import Path

def check_database_packages():
    """Check if database packages are installed."""
    print("📦 Checking database packages...")
    
    required_packages = {
        'sqlalchemy': 'SQLAlchemy ORM',
        'asyncpg': 'PostgreSQL async driver', 
        'psycopg2': 'PostgreSQL sync driver'
    }
    
    missing_packages = []
    
    for package, description in required_packages.items():
        try:
            if package == 'psycopg2':
                import psycopg2
            else:
                __import__(package)
            print(f"✅ {package}: {description}")
        except ImportError:
            print(f"❌ {package}: Missing - {description}")
            missing_packages.append(package)
    
    return len(missing_packages) == 0, missing_packages

def check_settings():
    """Check database settings."""
    print("\n⚙️ Checking database settings...")
    
    try:
        from app.config.settings import get_settings
        settings = get_settings()
        
        print(f"✅ DATABASE_URL: {settings.DATABASE_URL}")
        print(f"✅ Pool Size: {settings.DATABASE_POOL_SIZE}")
        print(f"✅ Max Overflow: {settings.DATABASE_MAX_OVERFLOW}")
        
        return True, settings
    except Exception as e:
        print(f"❌ Settings error: {e}")
        return False, None

def test_direct_connection(database_url):
    """Test direct database connection with psycopg2."""
    print("\n🔌 Testing direct database connection...")
    
    try:
        import psycopg2
        from urllib.parse import urlparse
        
        # Parse database URL
        parsed = urlparse(database_url)
        
        # Connect to database
        conn = psycopg2.connect(
            host=parsed.hostname,
            port=parsed.port or 5432,
            database=parsed.path.lstrip('/'),
            user=parsed.username,
            password=parsed.password
        )
        
        # Test query
        cursor = conn.cursor()
        cursor.execute("SELECT version();")
        version = cursor.fetchone()[0]
        
        cursor.close()
        conn.close()
        
        print(f"✅ Direct connection successful!")
        print(f"✅ PostgreSQL version: {version}")
        return True
        
    except ImportError:
        print("❌ psycopg2 not installed. Run: pip install psycopg2-binary")
        return False
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        print("\n💡 Common issues:")
        print("   - PostgreSQL server not running")
        print("   - Wrong credentials in DATABASE_URL") 
        print("   - Database doesn't exist")
        print("   - Host/port not accessible")
        return False

async def test_sqlalchemy_async_connection(settings):
    """Test SQLAlchemy async connection."""
    print("\n🔧 Testing SQLAlchemy async connection...")
    
    try:
        from app.config.database import db_manager
        
        # Initialize database manager
        db_manager.initialize()
        print("✅ Database manager initialized")
        
        # Test connection
        is_connected = await db_manager.check_connection()
        
        if is_connected:
            print("✅ SQLAlchemy async connection successful!")
            return True
        else:
            print("❌ SQLAlchemy async connection failed")
            return False
            
    except Exception as e:
        print(f"❌ SQLAlchemy async test failed: {e}")
        return False

def test_sqlalchemy_sync_connection(settings):
    """Test SQLAlchemy sync connection."""
    print("\n🔧 Testing SQLAlchemy sync connection...")
    
    try:
        from app.config.database import db_manager
        
        # Initialize database manager
        db_manager.initialize()
        print("✅ Database manager initialized")
        
        # Test connection
        is_connected = db_manager.check_connection_sync()
        
        if is_connected:
            print("✅ SQLAlchemy sync connection successful!")
            return True
        else:
            print("❌ SQLAlchemy sync connection failed")
            return False
            
    except Exception as e:
        print(f"❌ SQLAlchemy sync test failed: {e}")
        return False

async def test_health_endpoint():
    """Test the API health endpoint."""
    print("\n🏥 Testing API health endpoint...")
    
    try:
        import httpx
        
        async with httpx.AsyncClient() as client:
            response = await client.get("http://localhost:8001/health")
            
            if response.status_code == 200:
                data = response.json()
                print("✅ Health endpoint accessible")
                print(f"✅ API Status: {data.get('status')}")
                
                db_status = data.get('checks', {}).get('database', {})
                print(f"✅ Database Status: {db_status.get('status')}")
                print(f"✅ Database Connected: {db_status.get('connected')}")
                
                return data.get('checks', {}).get('database', {}).get('connected', False)
            else:
                print(f"❌ Health endpoint returned: {response.status_code}")
                return False
                
    except ImportError:
        print("⚠️ httpx not installed. Install with: pip install httpx")
        print("   Using curl instead:")
        print("   curl http://localhost:8001/health")
        return None
    except Exception as e:
        print(f"❌ Health endpoint test failed: {e}")
        print("   Make sure your API is running: python main.py")
        return False

def provide_solutions(missing_packages, settings_ok, direct_ok, sqlalchemy_ok):
    """Provide solutions based on test results."""
    print("\n🔧 SOLUTIONS:")
    print("=" * 50)
    
    if missing_packages:
        print("\n📦 Install missing packages:")
        if 'psycopg2' in missing_packages:
            print("   pip install psycopg2-binary")
        if 'asyncpg' in missing_packages:
            print("   pip install asyncpg")
        if 'sqlalchemy' in missing_packages:
            print("   pip install sqlalchemy")
    
    if not settings_ok:
        print("\n⚙️ Fix settings:")
        print("   1. Check your .env file exists")
        print("   2. Verify DATABASE_URL format:")
        print("      DATABASE_URL=postgresql://username:password@localhost:5432/database")
    
    if not direct_ok:
        print("\n🗄️ Database server issues:")
        print("   1. Start PostgreSQL server:")
        print("      - Windows: Start PostgreSQL service")
        print("      - macOS: brew services start postgresql")
        print("      - Linux: sudo systemctl start postgresql")
        print("      - Docker: docker-compose up -d db")
        print("   2. Create database:")
        print("      createdb cardinsa")
        print("   3. Check credentials in .env file")
    
    if not sqlalchemy_ok and direct_ok:
        print("\n🔧 SQLAlchemy configuration:")
        print("   1. Check if all models are properly imported")
        print("   2. Verify database initialization in main.py")

async def main():
    """Main diagnostic function."""
    print("🔍 CARDINSA API - DATABASE CONNECTION DIAGNOSTICS")
    print("=" * 60)
    
    # Test 1: Check packages
    packages_ok, missing_packages = check_database_packages()
    
    # Test 2: Check settings  
    settings_ok, settings = check_settings()
    
    # Test 3: Test direct connection
    direct_ok = False
    if settings_ok:
        direct_ok = test_direct_connection(settings.DATABASE_URL)
    
    # Test 4: Test SQLAlchemy sync
    sqlalchemy_sync_ok = False
    if packages_ok and settings_ok:
        sqlalchemy_sync_ok = test_sqlalchemy_sync_connection(settings)
    
    # Test 5: Test SQLAlchemy async
    sqlalchemy_async_ok = False
    if packages_ok and settings_ok:
        sqlalchemy_async_ok = await test_sqlalchemy_async_connection(settings)
    
    # Test 6: Test health endpoint
    health_ok = await test_health_endpoint()
    
    # Summary
    print("\n📊 SUMMARY:")
    print("=" * 30)
    print(f"📦 Packages: {'✅' if packages_ok else '❌'}")
    print(f"⚙️  Settings: {'✅' if settings_ok else '❌'}")
    print(f"🔌 Direct Connection: {'✅' if direct_ok else '❌'}")
    print(f"🔧 SQLAlchemy Sync: {'✅' if sqlalchemy_sync_ok else '❌'}")
    print(f"🔧 SQLAlchemy Async: {'✅' if sqlalchemy_async_ok else '❌'}")
    print(f"🏥 Health Endpoint: {'✅' if health_ok else '❌' if health_ok is not None else '⚠️'}")
    
    # Overall status
    if direct_ok and sqlalchemy_async_ok and health_ok:
        print("\n🎉 DATABASE FULLY CONNECTED!")
        print("   Your API is ready for database operations.")
    elif direct_ok:
        print("\n⚠️ DATABASE REACHABLE BUT API NOT CONNECTED")
        print("   Database works but API connection has issues.")
    else:
        print("\n❌ DATABASE NOT CONNECTED")
        print("   Database server or configuration issues.")
    
    # Provide solutions
    if not (direct_ok and sqlalchemy_async_ok and health_ok):
        provide_solutions(missing_packages, settings_ok, direct_ok, sqlalchemy_sync_ok)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n⚠️ Check interrupted by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")