from fastapi import FastAPI
from starlette.middleware.gzip import GZipMiddleware

from app.core.settings import settings
from app.core.logging import configure_logging
from app.core.middleware import install_cors, RequestIDMiddleware
from app.core.exceptions import install_exception_handlers
from app.api.v1.router import api_router

configure_logging()

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None,
)

# Middlewares
app.add_middleware(RequestIDMiddleware)
app.add_middleware(GZipMiddleware, minimum_size=1024)
install_cors(app)

# Exceptions
install_exception_handlers(app)

# Routers
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/", tags=["meta"])
def root():
    return {
        "name": settings.APP_NAME,
        "env": settings.ENV,
        "version": settings.APP_VERSION,
        "api": settings.API_V1_STR,
    }
