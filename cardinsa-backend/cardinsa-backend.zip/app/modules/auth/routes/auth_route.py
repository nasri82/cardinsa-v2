from fastapi import APIRouter
router=APIRouter(prefix='/auth', tags=['auth'])
@router.get('/_ping')
def _ping():
    return {'ok': True, 'module': 'auth'}
