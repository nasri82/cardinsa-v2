from fastapi import APIRouter
router=APIRouter(prefix='/users', tags=['users'])
@router.get('/_ping')
def _ping():
    return {'ok': True, 'module': 'users'}
