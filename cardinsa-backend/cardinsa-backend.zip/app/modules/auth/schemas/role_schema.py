from pydantic import BaseModel

class RoleBase(BaseModel):
    pass

class RoleCreate(RoleBase):
    pass

class RoleRead(RoleBase):
    id: str | None = None
