from pydantic import BaseModel

class UserBase(BaseModel):
    pass

class UserCreate(UserBase):
    pass

class UserRead(UserBase):
    id: str | None = None
