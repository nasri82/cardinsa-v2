# app/core/settings.py
from typing import List, Optional
import json
from pydantic import AnyHttpUrl, Field, field_validator, AliasChoices
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # --- App ---
    APP_NAME: str = "Cardinsa"
    APP_VERSION: str = "0.1.0"
    ENV: str = "dev"  # dev | staging | prod
    DEBUG: bool = True

    # Accept legacy/env alias "project_name" (or PROJECT_NAME)
    project_name: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices("project_name", "PROJECT_NAME"),
    )

    # --- API ---
    API_V1_STR: str = "/api/v1"

    # --- Security (Phase 1.1 will use these) ---
    SECRET_KEY: str = Field("change-me-in-.env", min_length=8)

    # JWT settings: accept snake_case and UPPERCASE env names
    jwt_alg: str = Field(
        default="EdDSA",
        validation_alias=AliasChoices("jwt_alg", "JWT_ALG"),
    )
    jwt_private_key_path: str = Field(
        default="./keys/ed25519-private.pem",
        validation_alias=AliasChoices("jwt_private_key_path", "JWT_PRIVATE_KEY_PATH"),
    )
    jwt_public_key_path: str = Field(
        default="./keys/ed25519-public.pem",
        validation_alias=AliasChoices("jwt_public_key_path", "JWT_PUBLIC_KEY_PATH"),
    )

    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60  # 1 hour
    refresh_token_expire_days: int = Field(
        default=60,
        validation_alias=AliasChoices("refresh_token_expire_days", "REFRESH_TOKEN_EXPIRE_DAYS"),
    )

    # --- Database ---
    DATABASE_URL: str = "postgresql+psycopg://postgres:Rasha%401973@localhost:5432/cardinsa"
    DB_ECHO: bool = False
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    DB_POOL_PRE_PING: bool = True

    # --- CORS ---
    CORS_ORIGINS: List[AnyHttpUrl] = []
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: List[str] = ["*"]
    CORS_ALLOW_HEADERS: List[str] = ["*"]

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, v):
        # Accept JSON array, comma-separated string, list, or empty
        if v is None or v == "":
            return []
        if isinstance(v, list):
            return v
        if isinstance(v, str):
            s = v.strip()
            if s.startswith("["):
                try:
                    return json.loads(s)
                except json.JSONDecodeError:
                    return [s]
            return [item.strip() for item in s.split(",") if item.strip()]
        return v

    # Use the legacy project_name if provided to override APP_NAME (optional)
    @property
    def EFFECTIVE_APP_NAME(self) -> str:
        return self.project_name or self.APP_NAME

    # Pydantic v2 settings config
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",  # ignore unexpected .env keys gracefully
    )


settings = Settings()
