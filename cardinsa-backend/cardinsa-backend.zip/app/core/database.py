from __future__ import annotations

import datetime as dt
from typing import Generator, Optional
from sqlalchemy import create_engine, func
from sqlalchemy.orm import sessionmaker, DeclarativeBase, Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
import uuid

from app.core.settings import settings

# --- Engine & Session ---
engine = create_engine(
    settings.DATABASE_URL,
    echo=settings.DB_ECHO,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_pre_ping=settings.DB_POOL_PRE_PING,
    future=True,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


# --- Declarative Base & Mixins ---
class Base(DeclarativeBase):
    pass

def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)

class TimestampMixin:
    created_at: Mapped[dt.datetime] = mapped_column(default=utcnow, nullable=False)
    updated_at: Mapped[dt.datetime] = mapped_column(default=utcnow, onupdate=utcnow, nullable=False)

class UUIDPrimaryKeyMixin:
    id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


# Example base model: can be reused by all tables
# class ExampleModel(UUIDPrimaryKeyMixin, TimestampMixin, Base):
#     __tablename__ = "examples"
#     name: Mapped[str] = mapped_column(nullable=False)


# --- Dependency ---
def get_session() -> Generator:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
