from typing import Iterable
from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.database import get_session

bearer = HTTPBearer(auto_error=False)

def require_role(roles: Iterable[str]):
    def _inner(credentials: HTTPAuthorizationCredentials = Depends(bearer)):
        # Placeholder: allow all for now; Phase 1.1 will validate JWT & roles
        return True
    return _inner

# Exported dependency for DB session
def get_db(session: Session = Depends(get_session)) -> Session:
    return session
