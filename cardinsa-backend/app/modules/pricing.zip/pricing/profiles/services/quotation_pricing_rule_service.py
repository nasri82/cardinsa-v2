from sqlalchemy.orm import Session
from uuid import UUID
from typing import List, Optional

from app.modules.pricing.profiles.repositories import quotation_pricing_rule_repository as repo
from app.modules.pricing.profiles.schemas.quotation_pricing_rule_schema import (
    QuotationPricingRuleCreate,
    QuotationPricingRuleUpdate,
)
from app.modules.pricing.profiles.models.quotation_pricing_rule_model import QuotationPricingRule

def get_all_rules(db: Session) -> List[QuotationPricingRule]:
    return repo.get_all(db)

def get_rule_by_id(db: Session, rule_id: UUID) -> Optional[QuotationPricingRule]:
    return repo.get_by_id(db, rule_id)

def create_rule(db: Session, data: QuotationPricingRuleCreate) -> QuotationPricingRule:
    return repo.create(db, data)

def update_rule(db: Session, rule_id: UUID, data: QuotationPricingRuleUpdate) -> Optional[QuotationPricingRule]:
    db_obj = repo.get_by_id(db, rule_id)
    if not db_obj:
        return None
    return repo.update(db, db_obj, data)

def delete_rule(db: Session, rule_id: UUID) -> bool:
    return repo.delete(db, rule_id)
