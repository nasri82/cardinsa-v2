from sqlalchemy.orm import Session
from uuid import UUID
from typing import List

from app.modules.pricing.profiles.repositories import quotation_pricing_profile_history_repository as repo
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_history_schema import (
    QuotationPricingProfileHistoryCreate,
)
from app.modules.pricing.profiles.models.quotation_pricing_profile_history_model import QuotationPricingProfileHistory

def get_history_for_profile(db: Session, profile_id: UUID) -> List[QuotationPricingProfileHistory]:
    return repo.get_by_profile_id(db, profile_id)

def add_snapshot(db: Session, data: QuotationPricingProfileHistoryCreate) -> QuotationPricingProfileHistory:
    return repo.create(db, data)
