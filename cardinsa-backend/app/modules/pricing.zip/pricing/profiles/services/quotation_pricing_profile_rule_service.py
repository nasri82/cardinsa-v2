from sqlalchemy.orm import Session
from uuid import UUID
from typing import List, Optional

from app.modules.pricing.profiles.repositories import quotation_pricing_profile_rule_repository as repo
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_rule_schema import (
    QuotationPricingProfileRuleCreate,
)
from app.modules.pricing.profiles.models.quotation_pricing_profile_rule_model import QuotationPricingProfileRule

def get_all_links(db: Session) -> List[QuotationPricingProfileRule]:
    return repo.get_all(db)

def create_link(db: Session, data: QuotationPricingProfileRuleCreate) -> QuotationPricingProfileRule:
    return repo.create(db, data)

def delete_link(db: Session, link_id: UUID) -> bool:
    return repo.delete(db, link_id)
