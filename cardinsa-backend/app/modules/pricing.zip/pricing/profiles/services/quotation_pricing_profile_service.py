from sqlalchemy.orm import Session
from uuid import UUID
from typing import List, Optional

from app.modules.pricing.profiles.repositories import quotation_pricing_profile_repository as repo
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_schema import (
    QuotationPricingProfileCreate,
    QuotationPricingProfileUpdate,
)
from app.modules.pricing.profiles.models.quotation_pricing_profile_model import QuotationPricingProfile

def get_all_profiles(db: Session) -> List[QuotationPricingProfile]:
    return repo.get_all(db)

def get_profile_by_id(db: Session, profile_id: UUID) -> Optional[QuotationPricingProfile]:
    return repo.get_by_id(db, profile_id)

def create_profile(db: Session, data: QuotationPricingProfileCreate) -> QuotationPricingProfile:
    return repo.create(db, data)

def update_profile(db: Session, profile_id: UUID, data: QuotationPricingProfileUpdate) -> Optional[QuotationPricingProfile]:
    db_obj = repo.get_by_id(db, profile_id)
    if not db_obj:
        return None
    return repo.update(db, db_obj, data)

def delete_profile(db: Session, profile_id: UUID) -> bool:
    return repo.delete(db, profile_id)
