# app/modules/pricing/profiles/router.py

from fastapi import APIRouter

from app.modules.pricing.profiles.routes import (
    quotation_pricing_profile_route,
    quotation_pricing_rule_route,
    quotation_pricing_profile_rule_route,
    quotation_pricing_profile_history_route,
)

router = APIRouter()

router.include_router(quotation_pricing_profile_route.router)
router.include_router(quotation_pricing_rule_route.router)
router.include_router(quotation_pricing_profile_rule_route.router)
router.include_router(quotation_pricing_profile_history_route.router)
