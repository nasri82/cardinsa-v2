from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from uuid import UUID
from typing import List

from app.core.database import get_db
from app.core.dependencies import  require_permission_scoped
from app.modules.pricing.profiles.services import quotation_pricing_profile_history_service
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_history_schema import QuotationPricingProfileHistory

router = APIRouter(prefix="/profile-history", tags=["Pricing Profile History"])

@router.get("/{profile_id}", response_model=List[QuotationPricingProfileHistory])
def get_history(profile_id: UUID, db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "view"))):
    return quotation_pricing_profile_history_service.get_history_for_profile(db, profile_id)
