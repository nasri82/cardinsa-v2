from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from uuid import UUID
from typing import List

from app.core.database import get_db
from app.core.dependencies import  require_permission_scoped
from app.modules.pricing.profiles.services import quotation_pricing_rule_service
from app.modules.pricing.profiles.schemas.quotation_pricing_rule_schema import (
    QuotationPricingRule,
    QuotationPricingRuleCreate,
    QuotationPricingRuleUpdate,
)

router = APIRouter(prefix="/rules", tags=["Quotation Pricing Rules"])

@router.get("/", response_model=List[QuotationPricingRule])
def list_rules(db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "view"))):
    return quotation_pricing_rule_service.get_all_rules(db)

@router.get("/{rule_id}", response_model=QuotationPricingRule)
def get_rule(rule_id: UUID, db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "view"))):
    rule = quotation_pricing_rule_service.get_rule_by_id(db, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    return rule

@router.post("/", response_model=QuotationPricingRule)
def create_rule(data: QuotationPricingRuleCreate, db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "create"))):
    return quotation_pricing_rule_service.create_rule(db, data)

@router.put("/{rule_id}", response_model=QuotationPricingRule)
def update_rule(rule_id: UUID, data: QuotationPricingRuleUpdate, db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "update"))):
    updated = quotation_pricing_rule_service.update_rule(db, rule_id, data)
    if not updated:
        raise HTTPException(status_code=404, detail="Rule not found")
    return updated

@router.delete("/{rule_id}")
def delete_rule(rule_id: UUID, db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "delete"))):
    success = quotation_pricing_rule_service.delete_rule(db, rule_id)
    if not success:
        raise HTTPException(status_code=404, detail="Rule not found")
    return {"success": True}
