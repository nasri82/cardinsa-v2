from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from uuid import UUID
from typing import List

from app.core.database import get_db
from app.core.dependencies import  require_permission_scoped
from app.modules.pricing.profiles.services import quotation_pricing_profile_rule_service
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_rule_schema import (
    QuotationPricingProfileRule,
    QuotationPricingProfileRuleCreate,
)

router = APIRouter(prefix="/profile-rule-links", tags=["Profile Rule Links"])

@router.get("/", response_model=List[QuotationPricingProfileRule])
def list_links(db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "view"))):
    return quotation_pricing_profile_rule_service.get_all_links(db)

@router.post("/", response_model=QuotationPricingProfileRule)
def create_link(data: QuotationPricingProfileRuleCreate, db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "create"))):
    return quotation_pricing_profile_rule_service.create_link(db, data)

@router.delete("/{link_id}")
def delete_link(link_id: UUID, db: Session = Depends(get_db), _: bool = Depends(require_permission_scoped("pricing", "delete"))):
    success = quotation_pricing_profile_rule_service.delete_link(db, link_id)
    if not success:
        raise HTTPException(status_code=404, detail="Link not found")
    return {"success": True}
