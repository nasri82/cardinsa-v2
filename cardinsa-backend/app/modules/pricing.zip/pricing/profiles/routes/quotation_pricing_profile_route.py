from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from uuid import UUID
from typing import List

from app.core.database import get_db
from app.core.dependencies import  require_permission_scoped
from app.modules.pricing.profiles.services import quotation_pricing_profile_service
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_schema import (
    QuotationPricingProfile,
    QuotationPricingProfileCreate,
    QuotationPricingProfileUpdate,
)

router = APIRouter(prefix="/profiles", tags=["Quotation Pricing Profiles"])

@router.get("/", response_model=List[QuotationPricingProfile])
def list_all_profiles(
    db: Session = Depends(get_db),
    _: bool = Depends(require_permission_scoped("pricing", "view"))
):
    return quotation_pricing_profile_service.get_all_profiles(db)

@router.get("/{profile_id}", response_model=QuotationPricingProfile)
def get_profile(
    profile_id: UUID,
    db: Session = Depends(get_db),
    _: bool = Depends(require_permission_scoped("pricing", "view"))
):
    profile = quotation_pricing_profile_service.get_profile_by_id(db, profile_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile

@router.post("/", response_model=QuotationPricingProfile)
def create_profile(
    data: QuotationPricingProfileCreate,
    db: Session = Depends(get_db),
    _: bool = Depends(require_permission_scoped("pricing", "create"))
):
    return quotation_pricing_profile_service.create_profile(db, data)

@router.put("/{profile_id}", response_model=QuotationPricingProfile)
def update_profile(
    profile_id: UUID,
    data: QuotationPricingProfileUpdate,
    db: Session = Depends(get_db),
    _: bool = Depends(require_permission_scoped("pricing", "update"))
):
    updated = quotation_pricing_profile_service.update_profile(db, profile_id, data)
    if not updated:
        raise HTTPException(status_code=404, detail="Profile not found")
    return updated

@router.delete("/{profile_id}")
def delete_profile(
    profile_id: UUID,
    db: Session = Depends(get_db),
    _: bool = Depends(require_permission_scoped("pricing", "delete"))
):
    success = quotation_pricing_profile_service.delete_profile(db, profile_id)
    if not success:
        raise HTTPException(status_code=404, detail="Profile not found")
    return {"success": True}
