# app/modules/pricing/profiles/schemas/quotation_pricing_profile_rule_schema.py

from pydantic import BaseModel
from uuid import UUID

class QuotationPricingProfileRuleBase(BaseModel):
    profile_id: UUID
    rule_id: UUID

class QuotationPricingProfileRuleCreate(QuotationPricingProfileRuleBase):
    pass

class QuotationPricingProfileRuleUpdate(QuotationPricingProfileRuleBase):
    pass

class QuotationPricingProfileRule(QuotationPricingProfileRuleBase):
    id: UUID

    class Config:
        orm_mode = True
