# app/modules/pricing/profiles/schemas/quotation_pricing_profile_history_schema.py

from pydantic import BaseModel
from typing import Optional, Any
from uuid import UUID
from datetime import datetime

class QuotationPricingProfileHistoryBase(BaseModel):
    profile_id: UUID
    snapshot_at: datetime
    data: Any
    action: Optional[str] = "updated"
    user_id: Optional[UUID]

class QuotationPricingProfileHistoryCreate(QuotationPricingProfileHistoryBase):
    pass

class QuotationPricingProfileHistory(QuotationPricingProfileHistoryBase):
    id: UUID

    class Config:
        orm_mode = True
