# app/modules/pricing/profiles/schemas/quotation_pricing_rule_schema.py

from pydantic import BaseModel
from typing import Optional
from uuid import UUID
from datetime import datetime

class QuotationPricingRuleBase(BaseModel):
    name: str
    description: Optional[str] = None
    rule_type: Optional[str] = None
    formula_expression: Optional[str] = None
    priority: Optional[int] = 0
    is_active: Optional[bool] = True
    insurance_type: Optional[str] = None

class QuotationPricingRuleCreate(QuotationPricingRuleBase):
    pass

class QuotationPricingRuleUpdate(QuotationPricingRuleBase):
    pass

class QuotationPricingRuleInDBBase(QuotationPricingRuleBase):
    id: UUID
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    created_by: Optional[UUID]
    updated_by: Optional[UUID]

    class Config:
        orm_mode = True

class QuotationPricingRule(QuotationPricingRuleInDBBase):
    pass
