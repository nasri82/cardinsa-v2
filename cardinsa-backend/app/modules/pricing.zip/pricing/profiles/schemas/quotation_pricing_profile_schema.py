# app/modules/pricing/profiles/schemas/quotation_pricing_profile_schema.py

from pydantic import BaseModel, Field
from typing import Optional, List
from uuid import UUID
from datetime import datetime

class QuotationPricingProfileBase(BaseModel):
    name: str
    description: Optional[str] = None
    tags: Optional[str] = None
    is_active: Optional[bool] = True
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None

class QuotationPricingProfileCreate(QuotationPricingProfileBase):
    pass

class QuotationPricingProfileUpdate(QuotationPricingProfileBase):
    pass

class QuotationPricingProfileInDBBase(QuotationPricingProfileBase):
    id: UUID
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    created_by: Optional[UUID]
    updated_by: Optional[UUID]

    class Config:
        orm_mode = True

class QuotationPricingProfile(QuotationPricingProfileInDBBase):
    pass
