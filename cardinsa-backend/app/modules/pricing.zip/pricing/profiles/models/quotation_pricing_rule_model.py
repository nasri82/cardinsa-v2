# app/modules/pricing/profiles/models/quotation_pricing_rule_model.py

from sqlalchemy import Column, String, Integer, Boolean, Text, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from uuid import uuid4
from app.core.database import Base

class QuotationPricingRule(Base):
    __tablename__ = "quotation_pricing_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(String, nullable=False)
    description = Column(Text)
    rule_type = Column(String)  # base, surcharge, cap, etc.
    formula_expression = Column(Text)
    priority = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    insurance_type = Column(String)

    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(UUID(as_uuid=True))
    updated_by = Column(UUID(as_uuid=True))

    # Relationships
    profile_rules = relationship("QuotationPricingProfileRule", back_populates="rule", cascade="all, delete")
