# app/modules/pricing/profiles/models/quotation_pricing_profile_rule_model.py

from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from uuid import uuid4
from app.core.database import Base

class QuotationPricingProfileRule(Base):
    __tablename__ = "quotation_pricing_profile_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    profile_id = Column(UUID(as_uuid=True), ForeignKey("quotation_pricing_profiles.id", ondelete="CASCADE"))
    rule_id = Column(UUID(as_uuid=True), ForeignKey("quotation_pricing_rules.id", ondelete="CASCADE"))

    # Relationships
    profile = relationship("QuotationPricingProfile", back_populates="rules")
    rule = relationship("QuotationPricingRule", back_populates="profile_rules")
