# app/modules/pricing/profiles/models/quotation_pricing_profile_model.py

from sqlalchemy import Column, String, Boolean, DateTime, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from uuid import uuid4
from app.core.database import Base

class QuotationPricingProfile(Base):
    __tablename__ = "quotation_pricing_profiles"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(String, nullable=False)
    description = Column(String)
    tags = Column(String)
    is_active = Column(Boolean, default=True)
    start_date = Column(DateTime)
    end_date = Column(DateTime)

    created_at = Column(DateTime)
    updated_at = Column(DateTime)
    created_by = Column(UUID(as_uuid=True))
    updated_by = Column(UUID(as_uuid=True))

    # Relationships
    rules = relationship("QuotationPricingProfileRule", back_populates="profile", cascade="all, delete")
