# app/modules/pricing/profiles/models/quotation_pricing_profile_history_model.py

from sqlalchemy import Column, String, DateTime, JSON
from sqlalchemy.dialects.postgresql import UUID
from uuid import uuid4
from app.core.database import Base

class QuotationPricingProfileHistory(Base):
    __tablename__ = "quotation_pricing_profiles_history"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    profile_id = Column(UUID(as_uuid=True))
    snapshot_at = Column(DateTime)
    data = Column(JSON)  # Full serialized profile at that moment
    action = Column(String)  # created, updated, deleted
    user_id = Column(UUID(as_uuid=True))
