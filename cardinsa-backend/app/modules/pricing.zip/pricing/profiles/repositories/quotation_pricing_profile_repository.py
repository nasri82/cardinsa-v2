from sqlalchemy.orm import Session
from uuid import UUID
from typing import List, Optional

from app.modules.pricing.profiles.models.quotation_pricing_profile_model import QuotationPricingProfile
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_schema import (
    QuotationPricingProfileCreate,
    QuotationPricingProfileUpdate,
)

def get_all(db: Session) -> List[QuotationPricingProfile]:
    return db.query(QuotationPricingProfile).all()

def get_by_id(db: Session, profile_id: UUID) -> Optional[QuotationPricingProfile]:
    return db.query(QuotationPricingProfile).filter(QuotationPricingProfile.id == profile_id).first()

def create(db: Session, profile_data: QuotationPricingProfileCreate) -> QuotationPricingProfile:
    profile = QuotationPricingProfile(**profile_data.dict())
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile

def update(db: Session, db_obj: QuotationPricingProfile, update_data: QuotationPricingProfileUpdate) -> QuotationPricingProfile:
    for field, value in update_data.dict(exclude_unset=True).items():
        setattr(db_obj, field, value)
    db.commit()
    db.refresh(db_obj)
    return db_obj

def delete(db: Session, profile_id: UUID) -> bool:
    obj = get_by_id(db, profile_id)
    if obj:
        db.delete(obj)
        db.commit()
        return True
    return False
