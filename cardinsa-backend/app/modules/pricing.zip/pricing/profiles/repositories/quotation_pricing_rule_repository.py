from sqlalchemy.orm import Session
from uuid import UUID
from typing import List, Optional

from app.modules.pricing.profiles.models.quotation_pricing_rule_model import QuotationPricingRule
from app.modules.pricing.profiles.schemas.quotation_pricing_rule_schema import (
    QuotationPricingRuleCreate,
    QuotationPricingRuleUpdate,
)

def get_all(db: Session) -> List[QuotationPricingRule]:
    return db.query(QuotationPricingRule).all()

def get_by_id(db: Session, rule_id: UUID) -> Optional[QuotationPricingRule]:
    return db.query(QuotationPricingRule).filter(QuotationPricingRule.id == rule_id).first()

def create(db: Session, rule_data: QuotationPricingRuleCreate) -> QuotationPricingRule:
    rule = QuotationPricingRule(**rule_data.dict())
    db.add(rule)
    db.commit()
    db.refresh(rule)
    return rule

def update(db: Session, db_obj: QuotationPricingRule, update_data: QuotationPricingRuleUpdate) -> QuotationPricingRule:
    for field, value in update_data.dict(exclude_unset=True).items():
        setattr(db_obj, field, value)
    db.commit()
    db.refresh(db_obj)
    return db_obj

def delete(db: Session, rule_id: UUID) -> bool:
    obj = get_by_id(db, rule_id)
    if obj:
        db.delete(obj)
        db.commit()
        return True
    return False
