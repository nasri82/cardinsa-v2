from sqlalchemy.orm import Session
from uuid import UUID
from typing import List, Optional

from app.modules.pricing.profiles.models.quotation_pricing_profile_rule_model import QuotationPricingProfileRule
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_rule_schema import (
    QuotationPricingProfileRuleCreate,
)

def get_all(db: Session) -> List[QuotationPricingProfileRule]:
    return db.query(QuotationPricingProfileRule).all()

def get_by_id(db: Session, link_id: UUID) -> Optional[QuotationPricingProfileRule]:
    return db.query(QuotationPricingProfileRule).filter(QuotationPricingProfileRule.id == link_id).first()

def create(db: Session, data: QuotationPricingProfileRuleCreate) -> QuotationPricingProfileRule:
    obj = QuotationPricingProfileRule(**data.dict())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj

def delete(db: Session, link_id: UUID) -> bool:
    obj = get_by_id(db, link_id)
    if obj:
        db.delete(obj)
        db.commit()
        return True
    return False
