from sqlalchemy.orm import Session
from uuid import UUID
from typing import List, Optional

from app.modules.pricing.profiles.models.quotation_pricing_profile_history_model import QuotationPricingProfileHistory
from app.modules.pricing.profiles.schemas.quotation_pricing_profile_history_schema import (
    QuotationPricingProfileHistoryCreate,
)

def get_all(db: Session) -> List[QuotationPricingProfileHistory]:
    return db.query(QuotationPricingProfileHistory).all()

def get_by_profile_id(db: Session, profile_id: UUID) -> List[QuotationPricingProfileHistory]:
    return db.query(QuotationPricingProfileHistory).filter(
        QuotationPricingProfileHistory.profile_id == profile_id
    ).order_by(QuotationPricingProfileHistory.snapshot_at.desc()).all()

def create(db: Session, data: QuotationPricingProfileHistoryCreate) -> QuotationPricingProfileHistory:
    obj = QuotationPricingProfileHistory(**data.dict())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj
